/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Simple Test Program for QMP global message passing
 *
 * Author:  
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_msg.c,v $
 *   Revision 1.3  2004/10/08 19:59:29  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.2  2004/04/08 15:34:02  chen
 *   Chnage some prinf
 *
 *   Revision 1.1.1.1  2003/11/18 18:55:36  chen
 *   First CVS QMP_mvia_gigeD_mesh
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

#include <qmp.h>

static void 
my_binary_func (void* inout, void* in)
{
  float *res, *source;
  int   len, i;
  /* assume this is float array with size 10 */
  
  res = (float *)inout;
  source = (float *)in;
  len = 10;

  for (i = 0; i < 10; i++) 
    res[i] = 2* (res[i] + source[i]);

}

int main (int argc, char** argv)
{
  int i;
  QMP_bool_t status;
  unsigned int num_nodes;
  QMP_thread_level_t th_level;

  QMP_verbose (QMP_FALSE);

  status = QMP_init_msg_passing (&argc, &argv, 
				 QMP_THREAD_MULTIPLE, &th_level);

  if (status != QMP_SUCCESS) {
    QMP_fprintf (stderr, "QMP_init failed\n");
    return -1;
  }

  num_nodes = QMP_get_number_of_nodes ();
  QMP_fprintf (stderr, "There are %d nodes for this job\n", num_nodes);

  /* do a broacast test */

  {
    double bcast_value;

    if (QMP_get_node_number () == 0) 
      bcast_value = 1243.3232;
    else
      bcast_value = 2321333.0;
    
    QMP_broadcast (&bcast_value, 8);
    
    QMP_fprintf (stderr, "bcast value is %lf\n", bcast_value);
  }

  /* global sum test.
   */
  {
    int value;

    value = 4;
    QMP_sum_int (&value);
    
    QMP_fprintf (stderr, "sum is %d\n", value);
  }


  /**
   * Global array sum
   */
  {
    double dvalue[10];
    unsigned int length = 10;
    unsigned int rank;
    int    i;

    rank = QMP_get_node_number ();
    for (i = 0; i < 10; i++) {
      dvalue[i] = rank * 10.0 + i;
    }

    if (QMP_sum_double_array (dvalue, length) == QMP_SUCCESS) {
      for (i = 0; i < length; i++) 
	QMP_fprintf (stderr, "dvalue[%d] is %lf\n", i, dvalue[i]);
    }
    else
      QMP_fprintf (stderr, "Error in global array sum\n");
  }

#if 0
  /**
   * Global float array sum
   */
  {
    float fvalue[10];
    unsigned int length = 10;
    unsigned int rank;
    int    i;

    rank = QMP_get_node_number ();
    for (i = 0; i < length; i++) {
      fvalue[i] = rank * 10.0 + i;
    }

    if (QMP_sum_float_array (fvalue, length) == QMP_SUCCESS) {
      for (i = 0; i < length; i++) 
	QMP_fprintf (stderr, "fvalue[%d] is %lf\n", i, fvalue[i]);
    }
    else
      QMP_fprintf (stderr, "Error in global array sum\n");
  }

  /**
   * Sync barrier
   */

  QMP_fprintf (stderr, "Wait for a barrier\n");
  QMP_wait_for_barrier (1000.0);
  QMP_fprintf (stderr, "Done Wait for a barrier\n");

  /**
   * Global XOR Test
   */
  {
    long mask;
    unsigned int rank;

    rank = QMP_get_node_number ();
#ifdef QMP_64BIT_LONG
    if (rank % 2 == 0)
      mask = 0xffff0000ffff0000;
    else
      mask = 0x0000ffff0000ffff;
#else
    mask = 1 << rank;
#endif

    QMP_global_xor (&mask);

    QMP_fprintf (stderr, "final mask is 0x%lx\n", mask);
  }

  
  /* global binary reduction test */
  {
    float value[10];
    unsigned int rank;

    rank = QMP_get_node_number ();
    for (i = 0; i < 10; i++)
      value[i] = (float)i - (float)rank;

    if (QMP_binary_reduction (value, 10*sizeof(float), 
			      my_binary_func) != QMP_SUCCESS)
      QMP_error ("Binary reduction error.\n");

    QMP_fprintf (stderr, "Reduced float array looks like : ");
    for (i = 0; i < 10; i++) 
      fprintf (stderr, "%10.5f ", value[i]);
    fprintf (stderr, "\n");

  }
#endif

  QMP_finalize_msg_passing ();

  return 0;
}


