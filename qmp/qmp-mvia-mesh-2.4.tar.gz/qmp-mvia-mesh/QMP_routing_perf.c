/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Simple QMP_ packet routing performance
 *      This code works on 1-D ring
 *
 * Author:  
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_routing_perf.c,v $
 *   Revision 1.1  2004/10/08 19:59:30  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.3  2004/02/19 15:22:02  chen
 *   Use static buffer inside QMP_route
 *
 *   Revision 1.2  2003/12/15 14:58:49  chen
 *   minor change
 *
 *   Revision 1.1  2003/12/12 20:12:58  chen
 *   Add global routing, scatter, gather
 *
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "qmp.h"

/**
 * Result holding timing result
 */

typedef struct res_time
{
  double it;
  double ft;
}res_time_t;

#define MAX_SIZE 100000
#define MIN_SIZE 4

#define INIT_LOOPS 10000

#define round(a, b) ((a) -((a)%(b)))

/* pick the next message size based on the current size 
 * code modified from WCS Perf1.1a2 MPI tests */
static int next_size(int size) 
{
  int delta = 0;
  double dsize = size;

  /* for small sizes, return fixed increments */
  /* choose not quite power ot two increments so that we don't
   * always end up on some nice boundary
   * choose multiple of four because it will be rare to send smaller
   * amounts (bytes or chars or shorts).
   */
  if (size < 8)         delta = 1;
  else if (size < 16)   delta = 4;
  else if (size < 128)  delta = 32;
  else if (size < 512)  delta = 64;
  else if (size < 8192) delta = 256;
  else {
    dsize *= 1.04;
    delta = dsize - size;
  }

  delta = round(delta, 1);

  return(size+delta);
}  

/* pick the next message size based on the current size 
 * code modified from WCS Perf1.1a2 MPI tests */
static int next_loop (int size, int loop)
{
  int retloop;
  int delta = 0;
  double dloop = loop;

  /* for small sizes, return fixed increments */
  /* choose not quite power ot two increments so that we don't
   * always end up on some nice boundary
   * choose multiple of four because it will be rare to send smaller
   * amounts (bytes or chars or shorts).
   */
  if (size < 8)         delta = 1;
  else if (size < 16)   delta = 4;
  else if (size < 128)  delta = 32;
  else if (size < 512)  delta = 64;
  else if (size < 8192) delta = 64;
  else {
    dloop *= 0.97;
    delta = loop - dloop;
  }

  delta = round(delta, 1);

  retloop = loop - delta;
  if (retloop < 1000)
    retloop = 1000;

  return retloop;
}  

/**
 * Get current time in milli seconds.
 */
static double
get_current_time (void)
{
  struct timeval tv;

  gettimeofday (&tv, 0);

  return tv.tv_sec*1000.0 + tv.tv_usec/1000.0;
}

/**
 * Output final result
 */
static void output_result (int size, int loops,
			   res_time_t* results, int num_nodes)
{
  double dt, rit, rft;
  int i;

  rit = results[0].it;
  rft = results[0].ft;

#if 0
  for (i = 1; i < num_nodes; i++) {
    if (results[i].it < rit) {
      rit = results[i].it;
    }
    if (results[i].ft > rft) {
      rft = results[i].ft;
    }
  }
#endif

  dt = rft - rit;

#if 1
  fprintf (stderr, "%d      %lf\n", size,
	   (double)size/dt/(double)1000.0*loops);
#endif

#if 0
  fprintf (stderr, "%d      %lf\n", size, dt/loops*1000.0);
#endif

}

int
main (int argc, char** argv)
{
  int i, num_nodes, rank, datasize;
  int src, dest, loops;
  QMP_status_t status;
  int *sbuffer, *rbuffer;
  QMP_mem_t *sqbuf, *rqbuf;
  QMP_thread_level_t th_level;
  int size;
  res_time_t myres, *finalres;

  status = QMP_init_msg_passing (&argc, &argv, 
				 QMP_THREAD_MULTIPLE, &th_level);

  if (status != QMP_SUCCESS) {
    QMP_error ("QMP_init failed: %s\n", QMP_error_string(status));
    exit (status);
  }
  
  /* get number of nodes */
  size = QMP_get_number_of_nodes ();

  num_nodes = QMP_get_number_of_nodes ();
  rank = QMP_get_node_number ();

  if (rank == 0)
    finalres = (res_time_t *)malloc (size * sizeof (res_time_t));
  else
    finalres = 0;
  
  /* we are interested in src and dest */
  src = 0;
  dest = 1;

  /* allocate memory */
  sqbuf = QMP_allocate_aligned_memory (MAX_SIZE, sizeof(int), 0);
  sbuffer = QMP_get_memory_pointer (sqbuf);

  rqbuf = QMP_allocate_aligned_memory (MAX_SIZE, sizeof(int), 0);
  rbuffer = QMP_get_memory_pointer (rqbuf);

  
  datasize = MIN_SIZE;
  loops = INIT_LOOPS;
  while (datasize <= MAX_SIZE) {
    myres.it = get_current_time ();

    for (i = 0; i < loops; i++) 
      QMP_route (sbuffer, datasize, src, dest);

    myres.ft = get_current_time ();
    
    QMP_gather (&myres, sizeof(res_time_t),
		finalres, sizeof(res_time_t), 0);

    if (rank == src) 
      output_result (datasize, loops, finalres, size);

    loops = next_loop (datasize, loops);    
    datasize = next_size (datasize);

    QMP_barrier ();

  }

  /* Free memory */
  QMP_free_memory (sqbuf);
  QMP_free_memory (rqbuf);

  if (finalres)
    free (finalres);

  QMP_finalize_msg_passing ();

  return 0;
}
