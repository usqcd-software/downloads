/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Simple Test Program for routing test
 *
 * Author:  
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_routing_test.c,v $
 *   Revision 1.2  2004/10/08 19:59:30  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.1  2003/12/12 20:13:29  chen
 *   Simple local routing test
 *
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

#include <qmp.h>

#define Nd 4

extern void QMP_show_routing_paths (unsigned int root);

int main (int argc, char** argv)
{
  QMP_status_t status;
  unsigned int num_nodes;
  unsigned int layout[]={4, 8, 16, 32};
  unsigned int num_dims = Nd;
  unsigned int* logic_dims;
  unsigned int  num_logic_dims;
  QMP_thread_level_t th_level;

  QMP_verbose (QMP_FALSE);

  status = QMP_init_msg_passing (&argc, &argv, 
				 QMP_THREAD_MULTIPLE, &th_level);

  if (status != QMP_SUCCESS) {
    QMP_printf ( "QMP_init failed\n");
    return -1;
  }

  QMP_layout_grid (layout, num_dims);

  logic_dims = QMP_get_logical_dimensions();
  num_logic_dims = QMP_get_logical_number_of_dimensions();


  num_nodes = QMP_get_number_of_nodes ();
  QMP_fprintf (stderr, "There are %d nodes for this job\n", num_nodes);

  QMP_show_routing_paths (0);

  QMP_finalize_msg_passing ();

  return 0;
}


