/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Simple Test Program for Scatter Test
 *
 * Author:  
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_scatter_test.c,v $
 *   Revision 1.2  2004/10/08 19:59:30  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.1  2003/12/12 20:12:58  chen
 *   Add global routing, scatter, gather
 *
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

#define Nd 4
#define TOTAL_SIZE 1024
#define LOOPS 100

#include <qmp.h>

int main (int argc, char** argv)
{
  int i, k;
  QMP_bool_t status;
  unsigned int num_nodes, rank;
  int     info[TOTAL_SIZE];
  int     recvbuf[1024];
  unsigned int layout[]={4, 8, 16, 32};
  unsigned int num_dims = Nd;
  unsigned int* logic_dims;
  unsigned int  num_logic_dims;
  QMP_thread_level_t th_level;

  status = QMP_init_msg_passing (&argc, &argv,
				 QMP_THREAD_SINGLE, &th_level);

  if (status != QMP_SUCCESS) {
    QMP_printf ( "QMP_init failed\n");
    return -1;
  }

  QMP_layout_grid (layout, num_dims); 

  logic_dims = QMP_get_logical_dimensions();
  num_logic_dims = QMP_get_logical_number_of_dimensions();

  num_nodes = QMP_get_number_of_nodes ();
  rank = QMP_get_node_number ();

  if (rank == 0) {
    for (i = 0; i < TOTAL_SIZE; i++) 
      info[i] = (i * num_nodes/TOTAL_SIZE);
  }

  
  for (k = 0; k < LOOPS; k++) {
    if (QMP_scatter (info, TOTAL_SIZE/num_nodes * sizeof(int), recvbuf, TOTAL_SIZE/num_nodes * sizeof(int), 0) != QMP_SUCCESS)
      QMP_error ("Cannot do scatter\n");
    
    for (i = 0; i < TOTAL_SIZE/num_nodes; i++)
      if (recvbuf[i] != rank) {
	QMP_fprintf (stderr, "Receiving error.\n");
	break;
      }
  }
    
  QMP_finalize_msg_passing ();

  return 0;
}


