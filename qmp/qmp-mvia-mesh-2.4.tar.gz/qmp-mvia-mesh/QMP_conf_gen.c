/* Generator for configuration file for diffrent mesh */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#define MAX_DIM 3
#define HOST_PREFIX "qcd3g"

static char* host_prefix[]={"unknown", "qcd3g00", "qcd3g0", "qcd3g"};
static char* via_prefix[]={"unknown", "via00", "via0", "via"};

/** This is for 2 dimension */
/*
static char* via_device[]={"/dev/via_eth2", "/dev/via_eth3",
			   "/dev/via_eth0", "/dev/via_eth1"};

static char* via_host[]={"eth3", "eth2",
			 "eth1", "eth0"};
*/


static char* via_device[]={"/dev/via_eth6", "/dev/via_eth7",
			   "/dev/via_eth2", "/dev/via_eth3",
			   "/dev/via_eth0", "/dev/via_eth1"};

static char* via_host[]={"eth7", "eth6",
			 "eth3", "eth2",
			 "eth1", "eth0"};

static int
get_integers (char* line, int ret[], int size)
{
  int i, num;
  int val[MAX_DIM];
   
  num = sscanf (line, "%d %d %d", &val[0], &val[1], &val[2]);

  if (num > 0) {
    for (i = 0; i < num; i++)
      ret[i] = val[i];
  }
  return num;
}

/**
 * Calculate logic coordinates (allocated already) with a given logic
 * node number (rank), dimensionality and size of the grid.
 */
static void
calculate_coordinates_from_rank (int rank,
				 int dimension,
				 int* size,
				 int coordinates[])

{
  int i;
  int pos;


  /* Calculate the Cartesian coordinates of the VALUE of IPOS where the 
   * value is defined by
   *
   *     for i =  0 to NDIM - 1 {
   *        X_i  <- mod( IPOS, L(i) )
   *        IPOS <- int( IPOS / L(i) )
   *     }
   *
   * NOTE: here the coord(i) and IPOS have their origin at 0. 
   * for 3 dimension, pos = z * Ny * Nx + y * Nx + x;
   */
  pos = rank;

  for (i = 0; i < dimension; i++) {
    coordinates[i] = pos % size[i];
    pos = pos / size[i];
  }
}

static void
write_header (FILE* fd, int dim, int dim_size[])
{
  int i;

  fprintf (fd, "# This is a sample configuration file\n");
  fprintf (fd, "# Dimension\n");
  fprintf (fd, "%d\n", dim);

  fprintf (fd, "# Dimension size\n");
  i = 0;
  while (i < dim) {
    fprintf (fd, "%d ", dim_size[i]);
    i++;
  }
  fprintf (fd, "\n");
}

static void
write_switch_info (FILE* fd, FILE* lfd, int dim, int coord[])
{
  int i;
  char host[80], via_host[80], tmp[32];

  strcpy (host, host_prefix[dim]);
  strcpy (via_host, via_prefix[dim]);

  i = 0;
  while (i < dim) {
    sprintf (tmp, "%d", coord[i]);
    strcat(host, tmp);
    strcat(via_host, tmp);
    i++;
  }
  strcat (via_host, "-eth4");
  fprintf (fd, "%s         %s\n", host, via_host);
}

static void
write_host (FILE* fd, FILE* lfd, int dim, int dim_size[], int coord[])
{
  int i, k;
  char host[80], tmp[32], plus[80], minus[80];
  int nbp[MAX_DIM], nbm[MAX_DIM];

  strcpy (host, host_prefix[dim]);

  i = 0;
  while (i < dim) {
    sprintf (tmp, "%d", coord[i]);
    strcat(host, tmp);
    i++;
  }
  

  fprintf (fd, "# Host %s configuration \n", host);
  fprintf (fd, "%s\n", host);
  fprintf (fd, "{\n");

  i = 0;
  while (i < dim) {
    fprintf (fd, "%d ", coord[i]);
    i++;
  }
  fprintf (fd, "\n");

  fprintf (fd, "# device vip_host direction (+1 -1) and axis.\n");
  for (i = 0; i < dim; i++) {

    /* calculate neighbors */
    for (k = 0; k < dim; k++) {
      nbm[k] = nbp[k] = coord[k];
    }
    /* positive direction */
    nbp[i] = (nbp[i] + 1) % dim_size[i];

    strcpy (plus, via_prefix[dim]);
    k = 0;
    while (k < dim) {
      sprintf (tmp, "%d", nbp[k]);
      strcat (plus, tmp);
      k++;
    }
    strcat(plus, "-");
    strcat(plus, via_host[2*i]);

    /* negative direction */
    nbm[i] = nbm[i] - 1;
    if (nbm[i] < 0)
      nbm[i] = dim_size[i] - 1;

    strcpy (minus, via_prefix[dim]);
    k = 0;
    while (k < dim) {
      sprintf (tmp, "%d", nbm[k]);
      strcat (minus, tmp);
      k++;
    }
    strcat(minus, "-");
    strcat(minus, via_host[2*i + 1]);

    fprintf (fd, "%s   %s      1        %d\n", 
	     via_device[2*i], plus, i);
    fprintf (fd, "%s   %s     -1       %d\n", 
	     via_device[2*i + 1], minus, i);
  }
  fprintf (fd, "#connection to switch.\n");
  fprintf (fd, "/dev/via_eth4 \n");
  fprintf (fd, "}\n");

  /* write host name to list file */
  fprintf (lfd, "%s\n", host);
}



int
main (int argc, char** argv)
{
  int num_nodes, i;
  int dimension, nodimsize;
  int dim_size[MAX_DIM], coord[MAX_DIM];
  char line[80];
  char *fname, *lfname;
  FILE *fd, *lfd;

  if (argc < 3) {
    fprintf (stderr, "usage: %s conf-fname list-fname.\n", argv[0]);
    exit (1);
  }

  fname = argv[1];
  lfname = argv[2];

  fd = fopen (fname, "w");
  if (!fd) {
    fprintf (stderr, "Cannot open file %s to write configuration.\n", fname);
    exit (1);
  }

  lfd = fopen (lfname, "w");
  if (!fd) {
    fprintf (stderr, "Cannot open file %s to write list.\n", lfname);
    exit (1);
  }
  
  fprintf (stderr, "Enter number of dimension.\n");
  scanf ("%d", &dimension);
  if (dimension > MAX_DIM) {
    fprintf (stderr, "Dimension cannot exceed %d.\n", MAX_DIM);
    exit (1);
  }

  nodimsize = 0;
  while (!nodimsize) {
    fprintf (stderr, "Enter dimension sizes.\n");
    if (fgets (line, sizeof (line) - 1, stdin)) {
      if (get_integers (line, dim_size, dimension) >= dimension - 1)
	nodimsize = 1;
    }
  }

  num_nodes = 1;
  for (i = 0; i < dimension; i++)
    num_nodes = num_nodes * dim_size[i];

  fprintf (stderr, "Total number of nodes is %d.\n", num_nodes);

  write_header (fd, dimension, dim_size);

  /* write switched information to the beginning */
  fprintf (fd, "# Switch information\n");
  fprintf (fd, "# Hostname               ViaHost\n");


  for (i = 0; i < num_nodes; i++) {
    calculate_coordinates_from_rank (i, dimension, dim_size, coord);
    write_switch_info (fd, lfd, dimension, coord);
  }

  for (i = 0; i < num_nodes; i++) {
    calculate_coordinates_from_rank (i, dimension, dim_size, coord);
    write_host(fd, lfd, dimension, dim_size, coord);
  }

  fclose (fd);
  fclose (lfd);

  return 0;
 }

  
