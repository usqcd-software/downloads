/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Simple QCD IO Test using QMP_route mechanism
 *
 * Author:  
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_io_test.c,v $
 *   Revision 1.4  2004/10/08 19:59:29  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.3  2004/02/19 15:22:02  chen
 *   Use static buffer inside QMP_route
 *
 *   Revision 1.2  2003/12/15 14:58:49  chen
 *   minor change
 *
 *   Revision 1.1  2003/12/12 20:12:58  chen
 *   Add global routing, scatter, gather
 *
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "qmp.h"

typedef struct prog_arg_
{
  int loops;
  int size;
  int verify;
}prog_arg_t;

#define Nd 4

int
main (int argc, char** argv)
{
  int cb, i, k, num_nodes, rank;
  QMP_status_t status;
  int *buffer;
  unsigned int layout[]={4, 8, 16, 32};
  unsigned int num_dims = Nd;
  unsigned int* logic_dims;
  unsigned int  num_logic_dims;
  prog_arg_t pargs;
  QMP_thread_level_t th_level;

  status = QMP_init_msg_passing (&argc, &argv, 
				 QMP_THREAD_MULTIPLE, &th_level);

  if (status != QMP_SUCCESS) {
    QMP_error ("QMP_init failed: %s\n", QMP_error_string(status));
    exit (status);
  }
  
  QMP_layout_grid (layout, num_dims);

  logic_dims = QMP_get_logical_dimensions();
  num_logic_dims = QMP_get_logical_number_of_dimensions();

  num_nodes = QMP_get_number_of_nodes ();
  rank = QMP_get_node_number ();

  if (QMP_is_primary_node()) {
    fprintf (stderr, "Input numberloops size(integer size) verify\n");
    scanf ("%d %d %d", &pargs.loops, &pargs.size, &pargs.verify);
  }

  QMP_broadcast (&pargs, sizeof (pargs));

  QMP_info ("Number loops = %d size = %d verify = %d\n",
	    pargs.loops, pargs.size, pargs.verify);

  buffer = (int *)malloc(pargs.size * sizeof (int));

  /**
   * First send out data to all nodes
   */
  for (cb = 0; cb < pargs.loops; cb++) {
    /* Now send data from root to every other node */
    for (i = 1; i < num_nodes; i++) {
      if (rank == 0) {
	for (k = 0; k < pargs.size; k++)
	  buffer[k] = i;
      }
      if (QMP_route (buffer, pargs.size * sizeof(int), 0, i) != QMP_SUCCESS)
	return -1;
      if (i == rank) {
	for (k = 0; k < pargs.size; k++) {
	  if (buffer[k] != rank) {
	    QMP_error ("QMP_routing error for %d -> %d %d != %d k = %d\n", 0, rank,
		       rank, buffer[k], k);
	    break;
	  }
	}
      }
    }
  }

#if 1
  /** Now receive from all nodes */
  for (cb = 0; cb < pargs.loops; cb++) {
    /* Now receive data from all other node */
    for (i = 1; i < num_nodes; i++) {
      if (rank == i) {
	for (k = 0; k < pargs.size; k++)
	  buffer[k] = i;
      }
      if (QMP_route (buffer, pargs.size * sizeof(int), i, 0) != QMP_SUCCESS)
	return -1;

      if (rank == 0) {
	for (k = 0; k < pargs.size; k++) {
	  if (buffer[k] != i) {
	    QMP_error ("QMP_routing error for %d -> %d\n", i, rank);
	    break;
	  }
	}
      }
    }
  }
#endif

  /* Free memory */
  free (buffer);
  QMP_finalize_msg_passing ();

  return 0;
}
