/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Simple LQCD Style Canonical Communication Test
 *
 * Author:  
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_qcd_canonical_test.c,v $
 *   Revision 1.3  2004/11/01 20:34:39  chen
 *   Change QMP_declare_multiple to conform to 2.0 spec
 *
 *   Revision 1.2  2004/10/08 19:59:29  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.1.1.1  2003/11/18 18:55:36  chen
 *   First CVS QMP_mvia_gigeD_mesh
 *
 *
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <math.h>

#include <qmp.h>

#define Nd 4

typedef struct prog_arg_
{
  int loops;
  int verify;
  unsigned int dimsize[Nd];
  unsigned int num_dims;

}prog_arg_t;

/* Nearest neighbor communication channels */
static QMP_msgmem_t request_msg[Nd][2];
static QMP_msghandle_t request_mh[Nd][2];
static QMP_msghandle_t mh_both[Nd];


static int total_comm = 0;
static void* forw_mem[Nd][2];
static void* back_mem[Nd][2];
static QMP_msgmem_t forw_msg[Nd][2];
static QMP_msgmem_t back_msg[Nd][2];
static QMP_msghandle_t forw_mh[Nd][2];
static QMP_msghandle_t back_mh[Nd][2];
static QMP_msghandle_t forw_all_mh;
static QMP_msghandle_t back_all_mh;
static int num = 0;

/**
 * This is optimized part of code 
 */
void init_wnxtsu3dslash(unsigned int* surface_size)
{
  int mu;
  const unsigned int *size = QMP_get_logical_dimensions();
  unsigned int num_dim = QMP_get_logical_number_of_dimensions();

  /* Loop over all communicating directions and build up the two message
   * handles. If there is no communications, the message handles will not
   * be initialized 
   */
  num = 0;
  
  for(mu=0; mu < num_dim; ++mu)
  {
    if(size[mu] > 1)
    {
      forw_mem[num][0] = malloc(surface_size[mu]);
      forw_mem[num][1] = malloc(surface_size[mu]);

      forw_msg[num][0] = QMP_declare_msgmem(forw_mem[num][0], surface_size[mu]);
      forw_msg[num][1] = QMP_declare_msgmem(forw_mem[num][1], surface_size[mu]);
      
      forw_mh[num][0]  = QMP_declare_receive_relative(forw_msg[num][1], mu, +1, 0);
      forw_mh[num][1]  = QMP_declare_send_relative(forw_msg[num][0], mu, -1, 0);
      

      back_mem[num][0] = malloc(surface_size[mu]);
      back_mem[num][1] = malloc(surface_size[mu]);

      back_msg[num][0] = QMP_declare_msgmem(back_mem[num][0], surface_size[mu]);
      back_msg[num][1] = QMP_declare_msgmem(back_mem[num][1], surface_size[mu]);

      back_mh[num][0]  = QMP_declare_receive_relative(back_msg[num][1], mu, -1, 0); 
      back_mh[num][1]  = QMP_declare_send_relative(back_msg[num][0], mu, +1, 0);
      num++;
    }
  }

  if (num > 0)
  {
    forw_all_mh = QMP_declare_multiple(&(forw_mh[0][0]), 2*num);
    back_all_mh = QMP_declare_multiple(&(back_mh[0][0]), 2*num); 
  }

  total_comm = num;
}


/* Fast send-receive (non-blocking) */
static void
quick_sendrecv(void *send_buf, void *recv_buf,
	       int count, int isign0, int dir)
{
 int isign = (isign0 > 0) ? 1 : -1;
 int err;

#ifdef DEBUG
 QMP_fprintf(stderr,"starting a PARSMP_sendrecv, count=%d, isign=%d dir=%d\n",
         count,isign,dir);
#endif

 request_msg[dir][0] = QMP_declare_msgmem(send_buf, count);
 request_msg[dir][1] = QMP_declare_msgmem(recv_buf, count);
 request_mh[dir][1] = QMP_declare_send_relative(request_msg[dir][0], dir, isign, 0);
 request_mh[dir][0] = QMP_declare_receive_relative(request_msg[dir][1], dir, -isign, 0);
 mh_both[dir] = QMP_declare_multiple(request_mh[dir], 2);

 err = QMP_start(mh_both[dir]);
 if (err != QMP_SUCCESS) {
   QMP_error("PARSMP_sendrecv: QMP_start failed with code: %d\n", err);
   exit (err);
 }

#ifdef DEBUG
 QMP_fprintf(stderr,"finished a PARSMP_sendrecv\n");
#endif
}

/* Wait on send-receive (now blocks) */
static void
quick_wait(int dir)
{
#ifdef DEBUG
 QMP_fprintf(stderr,"starting a PARSMP_wait\n");
#endif

 QMP_wait(mh_both[dir]);

 /* No need to delete individual message handle */
 QMP_free_msghandle(mh_both[dir]);
 QMP_free_msgmem(request_msg[dir][1]);
 QMP_free_msgmem(request_msg[dir][0]);

#ifdef DEBUG
 QMP_fprintf(stderr,"finished a PARSMP_wait\n");
#endif
}

int
main (int argc, char** argv)
{
  int cb, mu, i, num_nodes, rank;
  QMP_status_t status;
  unsigned int* logic_dims;
  unsigned int  num_logic_dims;
  unsigned int ilogic_dims[] = {4, 8, 8, 1};
  unsigned int* subgrid_length;
  unsigned int  surface[Nd];
  char  *tmp1[Nd], *tmp2[Nd];
  char  *a1[Nd], *a2[Nd];
  int fermion, numd, ncolor, type, iter, fixed_size;
  unsigned int dim_size[Nd];
  QMP_thread_level_t th_level;

  status = QMP_init_msg_passing (&argc, &argv, 
				 QMP_THREAD_SINGLE, &th_level);

  if (status != QMP_SUCCESS) {
    QMP_error ("QMP_init failed: %s\n", QMP_error_string(status));
    exit (status);
  }

  if (QMP_is_primary_node()) {
    fprintf (stderr, "Enter Fermion Type.\n");
    scanf ("%d", &fermion);
  }

  QMP_broadcast (&fermion, sizeof(fermion));

  if (QMP_is_primary_node()) {
    fprintf (stderr, "Enter Number of dimensions\n");
    scanf ("%d", &numd);
  }
  QMP_broadcast (&numd, sizeof (numd));

  if (QMP_is_primary_node()) {  
    fprintf (stderr, "Enter number of colors.\n");
    scanf ("%d", &ncolor);
  }
  QMP_broadcast (&ncolor, sizeof(ncolor));

  if (QMP_is_primary_node()) {  
    fprintf (stderr, "Input %d dimension sizes.\n", numd);
    i = 0;
    while (i < numd) 
      scanf ("%d", &dim_size[i++]);
  }
  QMP_broadcast (dim_size, numd * sizeof (int));

  if (QMP_is_primary_node()) {  
    fprintf (stderr, "Enter Type of Run.\n");
    scanf ("%d", &type);
  }
  QMP_broadcast (&type, sizeof (type));

  if (QMP_is_primary_node()) {  
    fprintf (stderr, "Enter fixed size.\n");
    scanf ("%d", &fixed_size);
  }
  QMP_broadcast (&fixed_size, sizeof (fixed_size));


  if (QMP_is_primary_node()) {  
    fprintf (stderr, "Enter number of iterations.\n");
    scanf ("%d", &iter);
  }
  QMP_broadcast (&iter, sizeof (iter));


  /*   QMP_declare_logical_topology (ilogic_dims, 4); */
  QMP_layout_grid (dim_size, numd);

  logic_dims = QMP_get_logical_dimensions();
  num_logic_dims = QMP_get_logical_number_of_dimensions();

  num_nodes = QMP_get_number_of_nodes ();
  rank = QMP_get_node_number ();

  /* Get subgrid surface volume */
  subgrid_length = QMP_get_subgrid_dimensions ();

  for (i = 0; i < Nd; i++) {
    surface[i] = 1;
    for (mu = 0; mu < Nd; mu++) {
      if (i != mu)
	surface[i] *= subgrid_length[mu];
    }
    surface[i] *= 48;

    tmp1[i] = (char *)malloc(surface[i]*sizeof(char));
    if (!tmp1[i]) {
      QMP_fprintf (stderr, "Cannot allocate space for tmp1[%d]. \n", i);
      exit (1);
    }
    tmp2[i] = (char *)malloc(surface[i]*sizeof(char));
    if (!tmp2[i]) {
      QMP_fprintf (stderr, "Cannot allocate space for tmp2[%d]. \n", i);
      exit (1);
    }

    a1[i] = (char *)malloc(surface[i]*sizeof(char));
    if (!a1[i]) {
      QMP_fprintf (stderr, "Cannot allocate space for a1[%d]. \n", i);
      exit (1);
    }
    a2[i] = (char *)malloc(surface[i]*sizeof(char));
    if (!a2[i]) {
      QMP_fprintf (stderr, "Cannot allocate space for a2[%d]. \n", i);
      exit (1);
    }
    if (QMP_is_primary_node()) {      
      QMP_fprintf (stderr, "Surface[%d] = %d\n", i, surface[i]);
    }

  }

  /* Calling optimized initialize routine */
  init_wnxtsu3dslash(surface);
  
  for(cb=0; cb < iter; ++cb) {

    for(mu=0; mu < Nd; ++mu) {
      if (logic_dims[mu] != 1) {
	quick_sendrecv(a1[mu], tmp1[mu], surface[mu], 1, mu);
	quick_wait(mu);

	quick_sendrecv(a2[mu], tmp2[mu], surface[mu], -1, mu);
	quick_wait(mu);
      }
    }
  }

  QMP_finalize_msg_passing ();


  for (i = 0; i < Nd; i++) {
    free (a1[i]);
    free (a2[i]);
    free (tmp1[i]);
    free (tmp2[i]);
  }

  return 0;
}
