#/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Utility to test GigE Connection for all configuration file in a dir
 *
 * Author:  
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_link_test.c,v $
 *   Revision 1.1.1.1  2003/11/18 18:55:36  chen
 *   First CVS QMP_mvia_gigeD_mesh
 *
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <dirent.h>
#include <ctype.h>

/**
 * Get number from the file name
 * filename looks like 1d_conf_l_xxxx
 */
static int
config_filename_number (char* filename, char num[])
{
  int retnum = -1;
  char* lastunderscore;
  char* tmp;

  lastunderscore = strrchr (filename, '_');
  tmp = ++lastunderscore;

  if (isdigit(*tmp)) {
    strcpy (num, tmp);
    retnum = 0;
  }
  else
    retnum = -1;

  return retnum;
}

/**
 * Get prefix from the filename
 */
static void
config_filename_prefix (char* filename, char prefix[])
{
  char* firstunderscore;
  char  *tp, *tf;

  firstunderscore = strchr (filename, '_');

  tp = prefix;
  tf = filename;

  while (tf != firstunderscore) {
    *tp = *tf;
    tp++;
    tf++;
  }
  *tp = '\0';
}



int
main (int argc, char** argv)
{
  char* configdir;
  char* testcode;
  char  fullcomd[256], confname[80], listname[80], prefix[32], numstr[32];
  DIR*  confdir;
  struct dirent* fe;
  int   num;
  
  if (argc < 3) {
    fprintf (stderr, "Usage: %s configdir executable\n", argv[0]);
    exit (1);
  }
  configdir = argv[1];
  testcode = argv[2];

  /* First open configuration directory */
  confdir = opendir (configdir);
  if (!confdir) {
    fprintf (stderr, "Cannot open directory %s\n", configdir);
    exit (1);
  }

  while ((fe = readdir (confdir))) {
    if (strstr (fe->d_name, "1d_conf")) {
      strcpy (confname, fe->d_name);
      num = config_filename_number (confname, numstr);
      config_filename_prefix(confname, prefix);
      if (num == -1) 
	sprintf (listname, "%s_list_l", prefix);
      else
      	sprintf (listname, "%s_list_l_%s", prefix, numstr);

      sprintf (fullcomd, "QMP_run.gige --qmp-f %s/%s --qmp-l %s/%s %s",
	       configdir, confname, configdir, listname, testcode);
      fprintf (stderr, "%s\n", fullcomd);

      system (fullcomd); 
    }
  }
  
  closedir (confdir);

  return 0;
}

