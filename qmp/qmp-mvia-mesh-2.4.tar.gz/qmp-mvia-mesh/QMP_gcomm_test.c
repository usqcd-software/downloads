/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Simple Test Program for QMP Broadcast and Reduction
 *
 * Author:  
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_gcomm_test.c,v $
 *   Revision 1.2  2004/10/08 19:59:29  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.1.1.1  2003/11/18 18:55:36  chen
 *   First CVS QMP_mvia_gigeD_mesh
 *
 *
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>
#include <math.h>

#include <qmp.h>

static void 
my_binary_func (void* inout, void* in)
{
  float *res, *source;
  int   len, i;
  /* assume this is float array with size 10 */
  
  res = (float *)inout;
  source = (float *)in;
  len = 10;

  for (i = 0; i < 10; i++) 
    res[i] = res[i] + 2 * source[i];

}

int main (int argc, char** argv)
{
  int i, loops, value, ival;
  QMP_bool_t status;
  double bcast_value;
  unsigned int num_nodes;
  QMP_thread_level_t th_level;

  QMP_verbose (QMP_FALSE);

  status = QMP_init_msg_passing (&argc, &argv, 
				 QMP_THREAD_SINGLE, &th_level);

  if (status != QMP_SUCCESS) {
    QMP_fprintf (stderr, "QMP_init failed\n");
    return -1;
  }

  num_nodes = QMP_get_number_of_nodes ();

  if (QMP_is_primary_node()) {
    fprintf (stderr, "Input numberloops \n");
    scanf ("%d", &loops);
  }
  QMP_broadcast (&loops, sizeof (int));


  /* do a broacast test */
  for (i = 0; i < loops; i++) {
    if (QMP_get_node_number () == 0) 
      bcast_value = 1243.3232;
    else
      bcast_value = 2321333.0;
    
    QMP_broadcast (&bcast_value, 8);
    
    if (fabs(bcast_value - 1243.3232) > 0.001)
      QMP_fprintf (stderr, "Broadcast error.\n");

    /* global sum test.
     */
    ival = i % 13 + 10;
    value = ival;
    QMP_sum_int (&value);
    
    if (value != (ival * num_nodes)) {
      QMP_fprintf (stderr, "Global sum error.\n");
    }
  }

  QMP_barrier ();

  QMP_finalize_msg_passing ();

  return 0;
}


