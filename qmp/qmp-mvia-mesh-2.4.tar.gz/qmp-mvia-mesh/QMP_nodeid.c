/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Simple code to return qmp node id given a configuration file
 *
 * Author:  
 *      Jie Chen, Chip Watson and Robert Edwards
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_nodeid.c,v $
 *   Revision 1.1  2005/05/03 17:46:55  chen
 *   import
 *
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>


#include <qmp.h>
#include <QMP_P_MVIA_MESH.h>

/**
 * Check whether we have an empty line.
 *
 * @param line a char string we are checking
 * @param size length of this char string
 * @return QMP_TRUE if we do have an empty line
 */
static QMP_bool_t
qmp_empty_line_i (char line[], QMP_u32_t size)
{
  char* p;

  QMP_TRACE("empty_line");

  p = line;

  while (p && *p) {
    if (isprint(*p))
      return QMP_FALSE;
    p++;
  }
  return QMP_TRUE;
}

/**
 * Parsing a string containing multiple integers seperated by white spaces
 *
 * @param  line a string containing multiple integers
 * @param  ret  an allocated array of integers
 * @param  size size of the above array
 * @return number of integers obtained.
 */
static int
qmp_get_integers_i (char* line, int ret[], int size)
{
  int i;
  char* token;

  QMP_TRACE ("qmp_get_integers_i");

  i = 0;
  token = strtok (line, " ");
  if (!token) 
    return 0;
  
  if (sscanf (token, "%d", &ret[i]) < 1) 
    return 0;

  i = 1;
  while ((token = strtok (0, " ")) != NULL && i < size) {
    if (sscanf (token, "%d", &ret[i]) < 1) 
      return i;
    i++;
  }

  return i;
}

/**
 * Get number of CPUs for this linux box.
 *
 * @return number of CPU this machine has
 *      
 */
static QMP_u32_t
qmp_get_num_cpus_i (void)
{
  FILE* fd;
  char  line[80];
  int   numcpu = 0;

  QMP_TRACE ("qmp_get_num_cpus_i");

  fd = fopen ("/proc/cpuinfo", "r");
  if (!fd) {
    QMP_error ("cannot open /proc/cpuinfo file.");
    return 0;
  }

#if defined (__linux) && defined (__i386)
  while (!feof (fd)) {
    memset (line, 0, sizeof (line));
    if (fgets (line, sizeof (line) - 1, fd) &&
	!qmp_empty_line_i (line, sizeof (line) - 1)) {
      if (strstr (line, "processor"))
	numcpu++;
    }
  }
#endif

#if defined (__linux) && defined (__alpha)
    while (!feof (fd)) {
      memset (line, 0, sizeof (line));
      if (fgets (line, sizeof (line) - 1, fd) &&
	  !empty_line (line, sizeof (line) - 1)) {
	if (strstr (line, "cpus detected")) {
	  char token0[32], token1[32], sep;
	  if (sscanf (line,"%s %s %c %d", token0, token1, &sep, &numcpu) <4){
	    QMP_error ("/proc/cpuinfo format error.");
	    return 0;
	  }
	}
      }
    }
#endif    
    
    fclose (fd);
    return numcpu;
}


/**
 * Load a QMP configuration file
 *
 * @param glm a QMP global machine instance
 * @param fname a configuration filename
 * @return QMP_SUCCESS if everything is ok.
 */
static QMP_status_t
qmp_load_configuration_i (QMP_machine_t* glm, char* fname)
{
  FILE* fd;
  int   i, j, k, m, num, type, dim, hosttype;
  int   ret[QMP_PHYS_NMD], match;
  char  line[128], hname[QMP_HOSTNAME_LEN];

  QMP_TRACE ("qmp_load_configuration_i");

  fd = fopen (fname, "r");
  if (!fd) {
    QMP_error ("Cannot open configuration file %s .\n", fname);
    return QMP_RTENV_ERR;
  }
  
  num = 0;
  type = 0;
  dim = 0;
  hosttype = 0;
  k = m = 0;
  match = 0;

  /**
   * Scan the configuration file to find out how many nodes and dimension
   * information of the mesh
   */
  while (!feof (fd)) {
    memset (line, 0, sizeof (line));
    if (fgets (line, sizeof (line) - 1, fd) && 
	!qmp_empty_line_i (line, sizeof (line) - 1) && line[0] != '#') {
      switch (type) {
      case 0:
	/* get dimension information */
	if (sscanf (line, "%d", &dim) < 1) {
	  QMP_error ("configuration %s provide no dimension information.\n",
		     fname);
	  fclose (fd);
	  return QMP_RTENV_ERR;
	}
	if (dim <= 0 || dim > QMP_PHYS_NMD) {
	  QMP_error ("configuration %s provide wrong dimension information (dimension = %d) .\n",
		     fname, dim);
	  fclose (fd);
	  return QMP_RTENV_ERR;
	}

	/* set dimension information */
	QMP_PHYS_SET_DIMENSION (glm->phys, dim);
	
	type++;
	break;
      case 1:
	/* Find out dimension size information */
	i = qmp_get_integers_i (line, ret, QMP_PHYS_NMD);
	
	if (i < dim - 1) {
	  QMP_error ("configuration %s has wrong dimension size information.\n",
		     fname);
	  fclose (fd);
	  return QMP_RTENV_ERR;
	}

	/* update geometry information */
	QMP_PHYS_SET_DIMSIZE (glm->phys, ret);

	/* calculate total number of nodes */
	QMP_PHYS_CALC_NUMNODES(glm->phys);

	/**
	 * Get number of nodes information created by the previous step
	 */
	num = QMP_PHYS_NUMNODES(glm->phys);
	if (num <= 0) {
	  QMP_error ("configuration %s has wrong number of nodes. \n", fname);
	  fclose (fd);
	  return QMP_RTENV_ERR;
	}

	/* now allocate memory for all physical nodes information */
	QMP_RTENV_SET_NUMNODES(glm->rtenv,num);
	QMP_RTENV_SET_DIMENSION(glm->rtenv, QMP_PHYS_DIMENSION(glm->phys));
	QMP_RTENV_SET_DIMSIZE(glm->rtenv, QMP_PHYS_DIMSIZE(glm->phys));

	/**
	 * Create an empty via host switch table 
	 */
	if (QMP_create_rtenv_swtable (&glm->rtenv,num) != QMP_SUCCESS) {
	  QMP_error ("cannot allocated space for via switched host table.\n");
	  fclose (fd);
	  return QMP_RTENV_ERR;
	}
	
	type++;

	break;
      case 2:
	if(QMP_insert_rtenv_swtable (&glm->rtenv, line, m)!= QMP_SUCCESS) {
	  QMP_error ("configuration format error for switched via hosts.\n");
	  fclose (fd);
	  QMP_delete_rtenv_swtable (&glm->rtenv);
	  return QMP_RTENV_ERR;
	}
	m++;
	if (m >= num) {
	  /* done with switched via host information */
	  if (QMP_create_rtenv_nodes(&glm->rtenv,num) != QMP_SUCCESS) {
	    QMP_error ("cannot allocate memory for run time physical nodes information. \n");
	    fclose (fd);
	    return QMP_NOMEM_ERR;
	  }    

	  /* create all switched port for this physical geometry */
	  if (QMP_create_switched_ports (glm->phys, num) != QMP_SUCCESS) {
	    QMP_error ("cannot create all switched gige ports.\n");
	    fclose (fd);
	    return QMP_RTENV_ERR;
	  }

	  type++;
	}
	break;
      case 3:
	switch (hosttype) {
	case 0:
	  /* get host name */
	  if (strchr (line, '{') != 0) 
	    hosttype = 1;
	  else {
	    sscanf (line, "%s", hname);
	    QMP_RTENV_NODE_SET_HOST(glm->rtenv, hname, k);
	  }
	  break;
	case 1:
	  /* inside the left brackt */
	  if (strchr (line, '}') != 0) {
	    hosttype = 0;
	    k++;
	  }
	  else {
	    if (strstr (line, "/dev") == 0) {
	      /* get coordinates of this host */
	      j = qmp_get_integers_i (line, ret, QMP_PHYS_NMD);
	      if (j < QMP_PHYS_DIMENSION(glm->phys) - 1) {
		QMP_error ("configuration %s for host %s has wrong coordinates.\n",
			   fname, QMP_RTENV_NODE_HOST(glm->rtenv, k));
		QMP_delete_rtenv_nodes (&glm->rtenv);
		QMP_delete_rtenv_swtable (&glm->rtenv);
		fclose (fd);
		return QMP_RTENV_ERR;
	      }
	      
	      /* calculate rank number of this node              */
	      QMP_RTENV_NODE_SET_RANK(glm->rtenv,
		      QMP_calc_node_rank(ret,
					 QMP_PHYS_DIMSIZE(glm->phys),
					 QMP_PHYS_DIMENSION(glm->phys)), k);

	      /* Set coordinate for this rtenv node              */
	      QMP_RTENV_NODE_SET_COORDINATES(glm->rtenv, ret, k);
	      
	      if (strcmp (QMP_RTENV_NODE_HOST(glm->rtenv, k),glm->host) == 0) {
		/* update physical geometry coordinate information */
		QMP_PHYS_SET_COORDINATES(glm->phys, ret);
		
		/* update physical rank of this node               */
		QMP_PHYS_SET_RANK(glm->phys, QMP_RTENV_NODE_RANK(glm->rtenv, k));

		/* This node is in the configuration file */
		match = 1;
	      }
	    }
	    else {
	      /* This is gige mesh port information */
	      if (strcmp (QMP_RTENV_NODE_HOST(glm->rtenv, k), glm->host) == 0) {

		/* Only process gige port information for this host */
		if (QMP_setup_gige_port (line, glm->phys, &glm->rtenv) != QMP_SUCCESS) {
		  QMP_error ("configuration %s error for ethernet port. \n",
			     fname);
		  QMP_delete_rtenv_nodes (&glm->rtenv);
		  QMP_delete_rtenv_swtable (&glm->rtenv);
		  fclose (fd);
		  return QMP_RTENV_ERR;
		}

		/* This node is in the configuration file */
		match = 1;
	      }
	    }
	  }
	  break;
	default:
	  break;
	}
      }
    }
  }
  fclose (fd);

  if (match)
    return QMP_SUCCESS;
  else
    return QMP_ERROR;
}
  

/**
 * Local initialization of global machine.
 */
static QMP_status_t
qmp_init_machine_i (QMP_machine_t* glm)
{
  char* host;
  int   i;

  QMP_TRACE ("qmp_init_machine_i");

  /* This machine is not initialized yet */
  glm->inited = QMP_FALSE;

  /* get host name */
  glm->host = (char *)malloc (QMP_HOSTNAME_LEN*sizeof (char));
  if (!glm->host) {
    QMP_error ("cannot allocate memory for host name\n");
    return QMP_NOMEM_ERR;
  }

  /* get host name from an environment variable */
  /* this environment should be set by a script */
  host = getenv ("QMP_HOST");
  if (!host) {
    if (gethostname (glm->host, QMP_HOSTNAME_LEN - 1) != 0) {
      QMP_error ("cannot get host name for this machine.\n");
      return QMP_HOSTNAME_ERR;
    }
  }
  else
    strncpy (glm->host, host, QMP_HOSTNAME_LEN - 1);
  

  /* get number of CPUs */
  glm->num_cpus = qmp_get_num_cpus_i ();

  if (glm->num_cpus == 0) {
    QMP_error ("This machine has no cpu information.\n");
    return QMP_CPUINFO_ERR;
  }
    
  glm->th_level  = QMP_THREAD_SERIALIZED;
  glm->ic_type  = QMP_MESH;

  /* allocate memory for physical geometry */
  glm->phys = QMP_create_phys_geometry ();
  if (!glm->phys) 
    return QMP_NOMEM_ERR;

  /* initialize the mesh geometry */
  QMP_init_phys_geometry (glm->phys, glm->host);

  glm->tpl = 0;

  glm->max_msg_length = QMP_MAX_MSGLEN;

  /* Send tag to distinguaish different channnels */
  glm->send_tag = 0;

  /* initialize all free lists */
  glm->regmem_free_list = 0;
  glm->regmem_free_list_inited = 0;

  glm->num_free_lists = 0;
  for (i = 0; i < QMP_NUM_FREELISTS; i++)
    glm->allocated_free_lists[i] = 0;

  QMP_init_req_free_list(glm);

  /* Initialize the msg handles free list */
  QMP_init_msghandle_free_list (glm);

  /* Initialize all completion queue table */
  glm->numcqs = 0;
  for (i = 0; i < QMP_MAX_VIADEV; i++)
    glm->allcqs[i] = 0;

  glm->err_code = QMP_SUCCESS;

  return QMP_SUCCESS;
}


/**
 * a real routine that is doing initialization using
 * a global machine pointer.
 */
static QMP_bool_t
qmp_init_config_i (QMP_machine_t* glm, char *conf_file)
{
  /* load run time environment */
  char         conf[256];
  char*        rtconf;
  QMP_status_t status;

  /* initialize this machine */
  if ((status = qmp_init_machine_i (glm)) != QMP_SUCCESS)
    return status;

  rtconf = getenv (QMP_CONF_ENV);
  if (rtconf) 
    strcpy (conf, rtconf);
  else 
    sprintf (conf, "%s", conf_file);

  status = qmp_load_configuration_i (glm, conf);

  if (status != QMP_SUCCESS) {
    return status;
  }

  glm->inited = QMP_TRUE;

  return QMP_SUCCESS;
}


int 
main (int argc, char** argv)
{
  int status;

  if (argc != 2) {
    fprintf (stderr, "Usage: %s configuration \n", argv[0]);
    exit (1);
  }
  
  status = qmp_init_config_i (&QMP_global_m, argv[1]);

  if (status == QMP_SUCCESS) {
    fprintf (stdout, "%d\n", QMP_PHYS_RANK(QMP_global_m.phys));
  }
  else
    fprintf (stdout, "This node is not in this configuration file %s .\n", argv[1]);

  return 0;
}

