/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Simple LQCD Style QMP_layout Test
 *
 * Author:  
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_grid_test.c,v $
 *   Revision 1.2  2004/10/08 19:59:29  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.1.1.1  2003/11/18 18:55:36  chen
 *   First CVS QMP_mvia_gigeD_mesh
 *
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <qmp.h>

#ifdef DMALLOC
#include <dmalloc.h>
#endif

#define MAX_DIMS 4

int 
main (int argc, char** argv)
{
  int          i, k, ndims, dimsizes[MAX_DIMS], logic_dec;
  QMP_status_t status;
  unsigned int    oldprank, prank, pnp;
  unsigned int    logic_dimsize[MAX_DIMS];
  unsigned int    logic_numdims;
  char         dec_logical[16];
  unsigned int    *coord;
  QMP_thread_level_t th_level;

  fprintf (stderr, "Enter number of virtual dimension.\n");
  scanf ("%d", &ndims);

  fprintf (stderr, "Entet dimension size for the %d dimensions.\n",
	   ndims);

  i = 0;
  while (i < ndims) 
    scanf ("%d", &dimsizes[i++]);

  logic_dec = 0;
  fprintf (stderr, "Do you want to declare logical topology?\n");
  scanf ("%s", dec_logical);

  if (dec_logical[0] == 'Y' || dec_logical[0] == 'y')
    logic_dec = 1;

  if (logic_dec) {
    fprintf (stderr, "Enter number of logical dimension.\n");
    scanf ("%d", &logic_numdims);

    fprintf (stderr, "Enter dimension size for the %d logical dimensions.\n",
	     logic_numdims);

    i = 0;
    while (i < logic_numdims) 
      scanf ("%d", &logic_dimsize[i++]);
  }
  
  
  QMP_verbose (QMP_FALSE);

  status = QMP_init_msg_passing (&argc, &argv, QMP_THREAD_MULTIPLE, &th_level);

  if (status != QMP_SUCCESS) {
    fprintf (stderr, "Cannot initialize QMP system.: %s\n", 
	     QMP_error_string(status));
    exit (1);
  }

  if (logic_dec)
    QMP_declare_logical_topology (logic_dimsize, logic_numdims);

  if (QMP_layout_grid (dimsizes, ndims) != 0)
    QMP_fprintf (stderr, "Cannot layout grid.\n");

  pnp = QMP_get_number_of_nodes ();
  oldprank = prank = QMP_get_node_number();

  for (i = 0; i < pnp; i++) {
    coord = QMP_get_logical_coordinates_from (i);

    fprintf (stderr, "Obtained coordinates for rank %d are [ ", i);
    for (k = 0; k < ndims; k++) 
      fprintf (stderr, " %d ", coord[k]);
    fprintf (stderr, " ] \n");

    prank = QMP_get_node_number_from (coord);

    fprintf (stderr, "Rank = %d prank = %d\n", i, prank);
  }

  QMP_finalize_msg_passing ();

  return 0;
}
