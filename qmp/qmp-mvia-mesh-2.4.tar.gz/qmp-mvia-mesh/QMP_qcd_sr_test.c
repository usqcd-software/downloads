/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Simple LQCD Style Communication Test
 *
 * Author:  
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_qcd_sr_test.c,v $
 *   Revision 1.3  2004/11/01 20:34:39  chen
 *   Change QMP_declare_multiple to conform to 2.0 spec
 *
 *   Revision 1.2  2004/10/08 19:59:29  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.1.1.1  2003/11/18 18:55:36  chen
 *   First CVS QMP_mvia_gigeD_mesh
 *
 *
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#include <qmp.h>

typedef struct prog_arg_
{
  int loops;
  int verify;
}prog_arg_t;

/**
 * Get current time in milli seconds.
 */
static double
get_current_time (void)
{
  struct timeval tv;

  gettimeofday (&tv, 0);

  return tv.tv_sec*1000.0 + tv.tv_usec/1000.0;
}

#define Nd 4

/* Nearest neighbor communication channels */
static QMP_msgmem_t request_msg[Nd][2];
static QMP_msghandle_t request_mh[Nd][2];
static QMP_msghandle_t mh_both[Nd];

/* Fast send-receive (non-blocking) */
static void
quick_sendrecv(void *send_buf, void *recv_buf,
	       int count, int isign0, int dir)
{
 int isign = (isign0 > 0) ? 1 : -1;
 int err;

#ifdef DEBUG
 QMP_fprintf(stderr,"starting a PARSMP_sendrecv, count=%d, isign=%d dir=%d\n",
         count,isign,dir);
#endif

 request_msg[dir][0] = QMP_declare_msgmem(send_buf, count);
 request_msg[dir][1] = QMP_declare_msgmem(recv_buf, count);
 request_mh[dir][1] = QMP_declare_send_relative(request_msg[dir][0], dir, isign, 0);
 request_mh[dir][0] = QMP_declare_receive_relative(request_msg[dir][1], dir, -isign, 0);
 mh_both[dir] = QMP_declare_multiple(request_mh[dir], 2);

 err = QMP_start(mh_both[dir]);
 if (err != QMP_SUCCESS) {
   QMP_error("PARSMP_sendrecv: QMP_start failed with code: %d\n", err);
   exit (1);
 }

#ifdef DEBUG
 QMP_fprintf(stderr,"finished a PARSMP_sendrecv\n");
#endif
}

/* Wait on send-receive (now blocks) */
static void
quick_wait(int dir)
{
#ifdef DEBUG
 QMP_fprintf(stderr,"starting a PARSMP_wait\n");
#endif

 QMP_wait(mh_both[dir]);

 /* No need to free individual handle */
 QMP_free_msghandle(mh_both[dir]);
 QMP_free_msgmem(request_msg[dir][1]);
 QMP_free_msgmem(request_msg[dir][0]);

#ifdef DEBUG
 QMP_fprintf(stderr,"finished a PARSMP_wait\n");
#endif
}

int
main (int argc, char** argv)
{
  int cb, mu, nu, i, num_nodes, rank;
  QMP_status_t status;
  prog_arg_t pargs;
  int *sbuf[Nd], *rbuf[Nd];
  double value, expval;
  unsigned int layout[]={8, 16, 16, 32};
  unsigned int num_dims = Nd;
  unsigned int* subgrid_length;
  unsigned int  surface[Nd];
  unsigned int* logic_dims;
  unsigned int  num_logic_dims;
  QMP_thread_level_t th_level;

  status = QMP_init_msg_passing (&argc, &argv, 
				 QMP_THREAD_MULTIPLE, &th_level);

  if (status != QMP_SUCCESS) 
    QMP_error_exit ("QMP_init failed: %s\n", QMP_error_string(status));
  
  QMP_layout_grid (layout, num_dims); 

  logic_dims = QMP_get_logical_dimensions();
  num_logic_dims = QMP_get_logical_number_of_dimensions();

  num_nodes = QMP_get_number_of_nodes ();
  rank = QMP_get_node_number ();


  /* Get subgrid surface volume */
  subgrid_length = QMP_get_subgrid_dimensions ();
  for (i = 0; i < Nd; i++) {
    surface[i] = 1;
    for (mu = 0; mu < Nd; mu++) {
      if (i != mu)
	surface[i] *= subgrid_length[mu];
    }
    surface[i] *= 48;
    if (QMP_is_primary_node()) 
      QMP_fprintf (stderr, "Surface[%d] = %d\n", i, surface[i]);

    sbuf[i] = (int *)malloc(surface[i]/4 * sizeof(int));
    rbuf[i] = (int *)malloc(surface[i]/4 * sizeof(int));
    memset (sbuf[i], 0, surface[i]);
    memset (rbuf[i], 0, surface[i]);
  }

  if (QMP_is_primary_node()) {
    fprintf (stderr, "Input numberloops verify\n");
    scanf ("%d %d", &pargs.loops, &pargs.verify);
  }

  QMP_broadcast (&pargs, sizeof (pargs));

  QMP_info ("Number loops = %d verify = %d\n",
	    pargs.loops, pargs.verify);

  value = get_current_time ();

  for(cb=0; cb < pargs.loops; ++cb) {

    for(mu=1; mu < Nd; ++mu) {

      for(nu=0; nu < mu; ++nu) {

	if (logic_dims[nu] != 1) {
	
	  if (pargs.verify) {
	    for (i = 0; i < surface[nu]/4; i++) 
	      sbuf[nu][i] = cb + mu * 3 + i + nu;
	  }
	
	  quick_sendrecv(sbuf[nu], rbuf[nu], surface[nu], -1, nu);
	  quick_wait(nu);

	  if (pargs.verify) {
	    for (i = 0; i < surface[nu]/4; i++) 
	      if (rbuf[nu][i] != (cb + mu * 3 + i + nu))
		QMP_error ("Receiving error.\n");
	  }
	}

	if (logic_dims[mu] != 1) {
	  if (pargs.verify) {
	    for (i = 0; i < surface[mu]/4; i++) 
	      sbuf[mu][i] = 3* cb + mu * 5 + i * 2 + nu;
	  }


	  quick_sendrecv(sbuf[mu], rbuf[mu], surface[mu], -1, mu);
	  quick_wait(mu);

	  if (pargs.verify) {
	    for (i = 0; i < surface[mu]/4; i++) 
	      if (rbuf[mu][i] != (3* cb + mu * 5 + i * 2 + nu))
		QMP_error ("Receiving error again.\n");
	  }
	}

	if (pargs.verify) 
	  value = (double)(cb + rank);

	QMP_sum_double_array(&value, 1);

	QMP_broadcast(&value, 8);
	
	if (pargs.verify) {
	  expval = (double)(cb * num_nodes);
	  for (i = 0; i < num_nodes; i++)
	    expval += i;

	  if (fabs (value - expval) > 0.0000001) 
	    QMP_fprintf (stderr, "Broadcast value error %lf != %lf.\n",
			 value, expval);
	}
      }
    }
  }

  QMP_finalize_msg_passing ();

  for (i = 0; i < Nd; i++) {
    free (sbuf[i]); 
    free (rbuf[i]);
  }

  return 0;
}
