/* Generator for configuration file for 1d configuration */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#define NUM_DIM 1

#define HOST_PREFIX "qcd4g"
#define VIAH_PREFIX "via4g"
#define CONF_PREFIX "1d_conf_"
#define LIST_PREFIX "1d_list_"

#define BAD_ETH "eth1"

#define NUM_CONF 8


/* Mapping from node name to rank number along z direction */
static int node_to_rank[8]= {0, 1, 3, 2, 7, 6, 4, 5};

static int rank_to_node[8]= {0, 1, 3, 2, 6, 7, 5, 4};

/* ethernet names for forward connection for the ranks */
static char* plus_ethnames[] = {"eth4", "eth5", "eth4", "eth1",
				"eth4", "eth5", "eth4", "eth1"};

static char* minus_ethnames[] = {"eth1", "eth4", "eth5", "eth4",
				 "eth1", "eth4", "eth5", "eth4"};

static int dimsize[] = {8};

static void
write_header (FILE* fd, int dim, int dim_size[])
{
  int i;

  fprintf (fd, "# This is a sample configuration file\n");
  fprintf (fd, "# Dimension\n");
  fprintf (fd, "%d\n", dim);

  fprintf (fd, "# Dimension size\n");
  i = 0;
  while (i < dim) {
    fprintf (fd, "%d ", dim_size[i]);
    i++;
  }
  fprintf (fd, "\n");
}

static void
write_switch_info (char* host, FILE* fd)
{
  int i;
  char via_host[80], tmp[32];

  sprintf (via_host, "%s%s-eth0", VIAH_PREFIX, &host[strlen(HOST_PREFIX)]);

  fprintf (fd, "%s         %s\n", host, via_host);
}

static void
write_host (char* host, int panel, FILE* fd, FILE* lfd,
	    int y, int z,
	    int dim, int dim_size[])
{
  int i, k;
  char tmp[32], plus[80], minus[80];
  int zp, zm, realz;

  /* calculate real z */
  realz = node_to_rank[z];
  fprintf (fd, "# Host %s configuration \n", host);
  fprintf (fd, "%s\n", host);
  fprintf (fd, "{\n");

  
  fprintf (fd, "%d ", realz);
  fprintf (fd, "\n");

  fprintf (fd, "# device vip_host direction (+1 -1) and axis.\n");

  /* calculate neighbors */
  zp = (realz + 1) % dim_size[0];

  /* Plus side of hostname */
  sprintf (plus, "%s%d", VIAH_PREFIX, panel);
  sprintf (tmp, "%d%d", y, rank_to_node[zp]);
  strcat (plus, tmp);

  strcat (plus, "-");
  strcat (plus, plus_ethnames[realz]);
  if (strcmp (plus_ethnames[realz], BAD_ETH) == 0)
    fprintf (fd, "/dev/via_%s   %s      1        %d         r\n", 
	     plus_ethnames[realz], plus, 0);
  else
    fprintf (fd, "/dev/via_%s   %s      1        %d\n", 
	     plus_ethnames[realz], plus, 0);
  
  /* negative direction */
  zm = realz - 1;
  if (zm < 0)
    zm = dim_size[0] - 1;


  /* Minus side of hostname */
  sprintf (minus, "%s%d", VIAH_PREFIX, panel);
  sprintf (tmp, "%d%d", y, rank_to_node[zm]);
  strcat (minus, tmp);

  strcat (minus, "-");
  strcat (minus, minus_ethnames[realz]);
  if (strcmp (minus_ethnames[realz], BAD_ETH) == 0)
    fprintf (fd, "/dev/via_%s   %s     -1       %d          r\n", 
	     minus_ethnames[realz], minus, 0);
  else
    fprintf (fd, "/dev/via_%s   %s     -1       %d\n", 
	     minus_ethnames[realz], minus, 0);

  fprintf (fd, "#connection to switch.\n");
  fprintf (fd, "/dev/via_eth0 \n");
  fprintf (fd, "}\n");

  /* write host name to list file */
  fprintf (lfd, "%s\n", host);
}



int
main (int argc, char** argv)
{
  int num_nodes, i, m, k, panel, conf_dir;
  int dimension, nodimsize;
  int coord[NUM_DIM], namecoord[NUM_DIM];
  char line[80], hostp[32], hostname[80], dirname[8];
  char fname[32], lfname[32];
  FILE *fd, *lfd;

  if (argc < 2) {
    fprintf (stderr, "usage: %s panelnum .\n", argv[0]);
    exit (1);
  }
  panel = atoi (argv[1]);

  for (m = 0; m < NUM_CONF; m++) {
     /* host prefix */
    sprintf (hostp, "%s%d", HOST_PREFIX, panel);
    sprintf (fname, "%s%d%d0", CONF_PREFIX, panel, m);
    sprintf (lfname, "%s%d%d0", LIST_PREFIX, panel, m);

    fd = fopen (fname, "w");
    if (!fd) {
      fprintf (stderr, "Cannot open file %s to write configuration.\n", fname);
      exit (1);
    }

    lfd = fopen (lfname, "w");
    if (!fd) {
      fprintf (stderr, "Cannot open file %s to write list.\n", lfname);
      exit (1);
    }
  
    dimension = NUM_DIM;
    num_nodes = 1;
    for (i = 0; i < dimension; i++)
      num_nodes = num_nodes * dimsize[i];
    fprintf (stderr, "Total number of nodes is %d.\n", num_nodes);

    write_header (fd, dimension, dimsize);

    /* write switched information to the beginning */
    fprintf (fd, "# Switch information\n");
    fprintf (fd, "# Hostname               ViaHost\n");

  
    /* Get switch information */
    for (i = 0; i < dimsize[0]; i++) {
      sprintf (hostname, "%s%d%d", hostp, m, i);
      write_switch_info (hostname, fd);
    }
  

    /* Write individual host information */
    for (i = 0; i < dimsize[0]; i++) {
      sprintf (hostname, "%s%d%d", hostp, m, i);
      write_host (hostname, panel, fd, lfd, m, i, 
		  dimension, dimsize);
    }
    fclose (fd);
    fclose (lfd);
  }
  
  return 0;
}

  
