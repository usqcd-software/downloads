/* Generate 3d 128 node configuration file */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define HOST_PREFIX "qcd4g"
#define VIAH_PREFIX "via4g"

#define VIADEV_PREFIX "/dev/via_"

#define BAD_VIADEV "/dev/via_eth1"

/**
 * 2^3 1 dim loop index 
 */
static int ztoy[2][4]={
  {0, 2, 6, 4},
  {1, 3, 7 ,5}
};

/* Each panel is dimension of 2 interms of naming */
#define PANEL_DIM 2
static int panel_dimsize[]={8, 8};

#define REAL_DIM 3
static int dimsize[]={4, 4, 8};


/* Physicsl connection by ethernet devices */
static char eth_connections[3][8][8][16]={
  {
    {"n/a", "eth2", "n/a", "n/a", "n/a", "eth3", "n/a", "n/a"},
    {"eth3", "n/a", "eth2", "n/a", "n/a", "n/a", "n/a", "n/a"},
    {"n/a", "eth3", "n/a", "eth2", "n/a", "n/a", "n/a", "n/a"},
    {"n/a", "n/a", "eth3", "n/a", "eth2", "n/a", "n/a", "n/a"},
    {"n/a", "n/a", "n/a", "eth3", "n/a", "eth2", "n/a", "n/a"},
    {"eth2", "n/a", "n/a", "n/a", "eth3", "n/a", "n/a", "n/a"},
    {"n/a", "n/a", "n/a", "n/a", "n/a", "n/a", "n/a", "n/a"},
    {"n/a", "n/a", "n/a", "n/a", "n/a", "n/a", "n/a", "n/a"},
  },
  {
    {"n/a", "eth6", "n/a", "n/a", "n/a", "n/a", "n/a", "eth7"},
    {"eth7", "n/a", "eth6", "n/a", "n/a", "n/a", "n/a", "n/a"},
    {"n/a", "eth7", "n/a", "eth6", "n/a", "n/a", "n/a", "n/a"},
    {"n/a", "n/a", "eth7", "n/a", "eth6", "n/a", "n/a", "n/a"},
    {"n/a", "n/a", "n/a", "eth7", "n/a", "eth6", "n/a", "n/a"},
    {"n/a", "n/a", "n/a", "n/a", "eth7", "n/a", "eth6", "n/a"},
    {"n/a", "n/a", "n/a", "n/a", "n/a", "eth7", "n/a", "eth6"},
    {"eth6", "n/a", "n/a", "n/a", "n/a", "n/a", "eth7", "n/a"},
  },
  {
    {"n/a", "eth4", "eth5", "n/a", "eth1", "n/a", "n/a", "n/a"},
    {"eth4", "n/a", "n/a", "eth5", "n/a", "eth1", "n/a", "n/a"},
    {"eth5", "n/a", "n/a", "eth4", "n/a", "n/a", "eth1", "n/a"},
    {"n/a", "eth5", "eth4", "n/a", "n/a", "n/a", "n/a", "eth1"},
    {"eth1", "n/a", "n/a", "n/a", "n/a", "eth4", "eth5", "n/a"},
    {"n/a", "eth1", "n/a", "n/a", "eth4", "n/a", "n/a", "eth5"},
    {"n/a", "n/a", "eth1", "n/a", "eth5", "n/a", "n/a", "eth4"},
    {"n/a", "n/a", "n/a", "eth1", "n/a", "eth5", "eth4", "n/a"},
  },
};


static void
write_header (FILE* fd, int dim, int dim_size[])
{
  int i;

  fprintf (fd, "# This is a sample configuration file\n");
  fprintf (fd, "# Dimension\n");
  fprintf (fd, "%d\n", dim);

  fprintf (fd, "# Dimension size\n");
  i = 0;
  while (i < dim) {
    fprintf (fd, "%d ", dim_size[i]);
    i++;
  }
  fprintf (fd, "\n");
}

static void
write_switch_info (char* host, FILE* fd)
{
  int i;
  char via_host[80], tmp[32];

  sprintf (via_host, "%s%s-eth0", VIAH_PREFIX, &host[strlen(HOST_PREFIX)]);

  fprintf (fd, "%s         %s\n", host, via_host);
}

static void
get_logic_coord (int* pcoord, int* lcoord, int dim, int otherxpanelnum)
{
  int i, j;

  /* First get xcoodinates */
  if (pcoord[0] < otherxpanelnum) {
    if (pcoord[2] % 2 == 0)
      lcoord[0] = 0;
    else
      lcoord[0] = 1;
  }
  else {
    if (pcoord[2] % 2 == 0)
      lcoord[0] = 3;
    else
      lcoord[0] = 2;
  }

  /* Get y coordinate */
  for (i = 0; i < 2; i++) {
    for (j = 0; j < 4; j++) {
      if (pcoord[2] == ztoy[i][j]) {
	lcoord[1] = j;
	break;
      }
    }
  }

  /* Finally get z coordinate == current y coordinate */
  lcoord[2] = pcoord[1];
}


static void
get_phys_coord (int* lcoord, int* pcoord, int dim, int panel0, int panel1)
{
  int i, j;

  /* First get xcoodinates */
  if (lcoord[0] < 2) {
    /* First panel */
    pcoord[0] = panel0;
  }
  else 
    pcoord[0] = panel1;

  /* get physical zdir */
  if (lcoord[0] == 0 || lcoord[0] == 3) 
    pcoord[2] = ztoy[0][lcoord[1]];
  else 
    pcoord[2] = ztoy[1][lcoord[1]];
      
  /* Finally get y coordinate == current z coordinate */
  pcoord[1] = lcoord[2];
}

/**
 * Get physical connection information for two neighbor points
 *
 * return physical axis and direction (1 plus, -1 minus)
 */
static void
get_phys_connection_info (int* pcoord, int* pnp, int dims,
			  int* paxis)
{
  int i;

  for (i = 0; i < dims; i++) {
    if (pnp[i] != pcoord[i]) {
      *paxis = i;
      return;
    }
  }
  fprintf (stderr, "Should never reach here. \n");
  exit (1);
}

/**
 * Write a single host information
 */
static void
write_host (char* host, int* pcoord, int* lcoord, int dims,
	    FILE* fd, FILE* lfd, int panel0, int panel1)
{
  int lnp[REAL_DIM], lnm[REAL_DIM], pnp[REAL_DIM], pnm[REAL_DIM];
  int i, k, paxis, pdir;
  char viadev[32], viahost[48], tmp[32];
  
  fprintf (fd, "# Host %s configuration \n", host);
  fprintf (fd, "%s\n", host);
  fprintf (fd, "{\n");

  for (i = 0; i < dims; i++)
    fprintf (fd, "%d ", lcoord[i]);
  fprintf (fd, "\n");

  fprintf (fd, "# device vip_host direction (+1 -1) and axis.\n");

  for (i = 0; i < dims; i++) {

    /* Calculate neighbors */
    for (k = 0; k < dims; k++) {
      lnp[k] = lnm[k] = lcoord[k];
    }
    lnp[i] = (lnp[i] + 1) % dimsize[i];
    lnm[i] = lnm[i] - 1;
    if (lnm[i] < 0)
      lnm[i] = dimsize[i] - 1;

    /* Plus side information */
    get_phys_coord (lnp, pnp, dims, panel0, panel1);

    /* Figure out which physical direction and +/- */
    get_phys_connection_info (pcoord, pnp, dims, &paxis);

    /* Get via device name */
    sprintf (viadev, "%s%s", VIADEV_PREFIX, eth_connections[paxis][pcoord[paxis]][pnp[paxis]]);


    /* Get neighbors via host name */
    strcpy (viahost, VIAH_PREFIX);
    for (k = 0; k < dims; k++) {
      sprintf (tmp, "%d", pnp[k]);
      strcat (viahost, tmp);
    }
    strcat (viahost, "-");
    strcat (viahost, eth_connections[paxis][pnp[paxis]][pcoord[paxis]]);
    /* Finally print out */
    if (strcmp (viadev, BAD_VIADEV) == 0)
      fprintf (fd, "%s       %s       1             %d             r\n",
	       viadev, viahost, i);
    else
      fprintf (fd, "%s       %s       1             %d             r\n",
	       viadev, viahost, i);


    /* Minus side information */
    get_phys_coord (lnm, pnm, dims, panel0, panel1);

    /* Figure out which physical direction and +/- */
    get_phys_connection_info (pcoord, pnm, dims, &paxis);

    /* Get via device name */
    sprintf (viadev, "%s%s", VIADEV_PREFIX, eth_connections[paxis][pcoord[paxis]][pnm[paxis]]);


    /* Get neighbors via host name */
    strcpy (viahost, VIAH_PREFIX);
    for (k = 0; k < dims; k++) {
      sprintf (tmp, "%d", pnm[k]);
      strcat (viahost, tmp);
    }
    strcat (viahost, "-");
    strcat (viahost, eth_connections[paxis][pnm[paxis]][pcoord[paxis]]);

    /* Finally print out */
    if (strcmp (viadev, BAD_VIADEV) == 0)
      fprintf (fd, "%s       %s       -1             %d           r\n",
	       viadev, viahost, i);
    else
      fprintf (fd, "%s       %s       -1             %d           r\n",
	       viadev, viahost, i);

  }

  fprintf (fd, "#connection to switch.\n");
  fprintf (fd, "/dev/via_eth0 \n");
  fprintf (fd, "}\n");

  /* write host name to list file */
  fprintf (lfd, "%s\n", host);
}



int main (int argc, char** argv)
{
  char fname[80], lfname[80];
  char hostp0[80], hostp1[80];
  int  xpanel0, xpanel1;
  int  i, j;
  int  host_pcoord[REAL_DIM], logic_coord[REAL_DIM];
  FILE *fd, *lfd;

  if (argc < 5) {
    fprintf (stderr, "Usage: %s conf list xpanel1 xpanel2.\n", argv[0]);
    exit (1);
  }
  strcpy (fname, argv[1]);
  strcpy (lfname, argv[2]);
  xpanel0 = atoi (argv[3]);
  xpanel1 = atoi (argv[4]);

  fd = fopen (fname, "w");
  if (!fd) {
    fprintf (stderr, "Cannot open file %s to write configuration.\n", fname);
    exit (1);
  }

  lfd = fopen (lfname, "w");
  if (!fd) {
    fprintf (stderr, "Cannot open file %s to write list.\n", lfname);
    exit (1);
  }

  write_header (fd, REAL_DIM, dimsize);

  /* write switched information to the beginning */
  fprintf (fd, "# Switch information\n");
  fprintf (fd, "# Hostname               ViaHost\n");

  /* Panel 0 host name */
  for (i = 0; i < panel_dimsize[0]; i++) {
    for (j = 0; j < panel_dimsize[1]; j++) {
      sprintf (hostp0, "%s%d%d%d", HOST_PREFIX, xpanel0, i, j);
      write_switch_info (hostp0, fd);
    }
  }

  /* Panel 1 host name */
  for (i = 0; i < panel_dimsize[0]; i++) {
    for (j = 0; j < panel_dimsize[1]; j++) {
      sprintf (hostp1, "%s%d%d%d", HOST_PREFIX, xpanel1, i, j);
      write_switch_info (hostp1, fd);
    }
  }

  /* Now work on the panel0 hosts */
  for (i = 0; i < panel_dimsize[0]; i++) {
    for (j = 0; j < panel_dimsize[1]; j++) {
      sprintf (hostp0, "%s%d%d%d", HOST_PREFIX, xpanel0, i, j);
      /* set host physical coordinate information */
      host_pcoord[0] = xpanel0;
      host_pcoord[1] = i;
      host_pcoord[2] = j;

      /* get logic coordinates */
      get_logic_coord (host_pcoord, logic_coord, REAL_DIM,
		       xpanel1);

      /* write host */
      write_host (hostp0, host_pcoord, logic_coord, REAL_DIM,
		  fd, lfd, xpanel0, xpanel1);

    }
  }


  /* Now work on the panel1 hosts */
  for (i = 0; i < panel_dimsize[0]; i++) {
    for (j = 0; j < panel_dimsize[1]; j++) {
      sprintf (hostp1, "%s%d%d%d", HOST_PREFIX, xpanel1, i, j);
      /* set host physical coordinate information */
      host_pcoord[0] = xpanel1;
      host_pcoord[1] = i;
      host_pcoord[2] = j;

      /* get logic coordinates */
      get_logic_coord (host_pcoord, logic_coord, REAL_DIM,
		       xpanel0);

      /* write host */
      write_host (hostp1, host_pcoord, logic_coord, REAL_DIM,
		  fd, lfd, xpanel0, xpanel1);

    }
  }
      
  
  fclose (fd);
  fclose (lfd);
}
