/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Simple LQCD Style Communication Test
 *
 * Author:  
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_qcd_bsr_test.c,v $
 *   Revision 1.5  2004/11/01 20:34:39  chen
 *   Change QMP_declare_multiple to conform to 2.0 spec
 *
 *   Revision 1.4  2004/10/08 19:59:29  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.3  2003/12/17 20:25:07  chen
 *   Change QMP_allocate/free_aligned_memory to deregister memory from system
 *
 *   Revision 1.2  2003/11/26 15:40:44  chen
 *   Change verification mechanism
 *
 *   Revision 1.1.1.1  2003/11/18 18:55:36  chen
 *   First CVS QMP_mvia_gigeD_mesh
 *
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <sys/time.h>

#include <qmp.h>


typedef struct prog_arg_
{
  int loops;
  int verify;
}prog_arg_t;

static  prog_arg_t pargs;

/**
 * Get current time in milli seconds.
 */
static double
get_current_time (void)
{
  struct timeval tv;

  gettimeofday (&tv, 0);

  return tv.tv_sec*1000.0 + tv.tv_usec/1000.0;
}

#define Nd 4

/* Slow send-receive (blocking) */
static void
slow_sendrecv(void *send_buf, void *recv_buf,
	      int count, int isign0, int dir)
{
  QMP_msgmem_t request_msg[2];
  QMP_msghandle_t request_mh[2], mh_both;

  unsigned int *mycoord;
  int left[Nd], right[Nd];
  unsigned int leftnode, rightnode, myrank;
  const unsigned int *size = QMP_get_logical_dimensions();
  unsigned int num_dim = QMP_get_logical_number_of_dimensions();
  int i, *sbuf, *rbuf;

  int isign = (isign0 > 0) ? 1 : -1;
  int err;

#ifdef DEBUG
  QMP_fprintf(stderr,"starting a SLOW_sendrecv, count=%d, isign=%d dir=%d\n",
	     count,isign,dir);
#endif

  /* First get my logical coordinates */
  mycoord = QMP_get_logical_coordinates ();

  for (i = 0; i < num_dim; i++) {
    left[i] = right[i] = mycoord[i];
  }

  /* Get left neightbor */
  left[dir] = (left[dir] + isign);
  if (left[dir] < 0)
    left[dir] = size[dir] - 1;
  if (left[dir] >= size[dir])
    left[dir] = 0;

  leftnode = QMP_get_node_number_from (left);

  /* Get Right neighbour */
  right[dir] = (right[dir] - isign);
  if (right[dir] < 0)
    right[dir] = size[dir] - 1;
  if (right[dir] >= size[dir])
    right[dir] = 0;

  rightnode = QMP_get_node_number_from (right);

#ifdef DEBUG
  QMP_fprintf(stderr,"starting a SLOW_sendrecv left node = %d right node = %d\n",leftnode, rightnode);
#endif

  request_msg[0] = QMP_declare_msgmem(send_buf, count);
  request_msg[1] = QMP_declare_msgmem(recv_buf, count);
  request_mh[0]  = QMP_declare_receive_from(request_msg[1], rightnode, 0);
  request_mh[1]  = QMP_declare_send_to(request_msg[0], leftnode, 0);
  mh_both        = QMP_declare_multiple(request_mh, 2);

  if (pargs.verify) {
    sbuf = (int *)send_buf;
    for (i = 0; i < count/4; i++) 
      sbuf[i] = i + leftnode * leftnode;
  }


  err = QMP_start(mh_both);
  if (err != QMP_SUCCESS) {
    QMP_error("PARSMP_sendrecv: QMP_start failed with code: %d\n", err);
    exit (err);
  }

  err = QMP_wait(mh_both);
  if (err != QMP_SUCCESS) {
    QMP_error("PARSMP_sendrecv: QMP_wait failed with code: %d\n", err);
    exit (err);
  }

  if (pargs.verify) {
    myrank = QMP_get_node_number ();
    rbuf = (int *)recv_buf;
    for (i = 0; i < count/4; i++) 
      if (rbuf[i] != (i + myrank * myrank))
	QMP_fprintf (stderr, "Receing error recv_buf[%d] = %d != %d\n",
		     i, rbuf[i], i + myrank * myrank);
  }

  /* No need to release individual handle that is released by multiple */
  QMP_free_msghandle(mh_both);

  QMP_free_msgmem(request_msg[1]);
  QMP_free_msgmem(request_msg[0]);

#ifdef DEBUG
  QMP_fprintf(stderr,"finished a SLOW_sendrecv\n");
#endif
}

int
main (int argc, char** argv)
{
  int cb, mu, nu, i, num_nodes, rank;
  QMP_status_t status;
  int *sbuf[Nd], *rbuf[Nd];
  QMP_mem_t *smem[Nd], *rmem[Nd];
  double value[Nd], expval[Nd];
  unsigned int layout[]={4, 8, 16, 32};
  unsigned int num_dims = Nd;
  unsigned int* logic_dims;
  unsigned int  num_logic_dims;
  unsigned int  surface[Nd];
  unsigned int* subgrid_length;
  QMP_thread_level_t th_level;

  status = QMP_init_msg_passing (&argc, &argv, 
				 QMP_THREAD_MULTIPLE, &th_level);

  if (status != QMP_SUCCESS) {
    QMP_error ("QMP_init failed: %s\n", QMP_error_string(status));
    exit (status);
  }
  
  QMP_layout_grid (layout, num_dims); 

  logic_dims = QMP_get_logical_dimensions();
  num_logic_dims = QMP_get_logical_number_of_dimensions();

  num_nodes = QMP_get_number_of_nodes ();
  rank = QMP_get_node_number ();

  /* Get subgrid surface volume */
  subgrid_length = QMP_get_subgrid_dimensions ();
  for (i = 0; i < Nd; i++) {
    surface[i] = 1;
    for (mu = 0; mu < Nd; mu++) {
      if (i != mu)
	surface[i] *= subgrid_length[mu];
    }
    surface[i] *= 48;
    if (QMP_is_primary_node()) 
      QMP_fprintf (stderr, "Surface[%d] = %d\n", i, surface[i]);

    /* Allocate aligned memory */
    smem[i] = QMP_allocate_aligned_memory (surface[i]/4 * sizeof(int),
					   sizeof (int), 0);
    rmem[i] = QMP_allocate_aligned_memory (surface[i]/4 * sizeof(int),
					   sizeof (int), 0);
    sbuf[i] = QMP_get_memory_pointer (smem[i]);
    rbuf[i] = QMP_get_memory_pointer (rmem[i]);
    memset (sbuf[i], 0, surface[i]);
    memset (rbuf[i], 0, surface[i]);
  }

  if (QMP_is_primary_node()) {
    fprintf (stderr, "Input numberloops verify\n");
    scanf ("%d %d", &pargs.loops, &pargs.verify);
  }

  QMP_broadcast (&pargs, sizeof (pargs));

  QMP_info ("Number loops = %d verify = %d\n",
	    pargs.loops, pargs.verify);

  for (i = 0; i < Nd; i++) {
    value[i] = expval[i] = (double)0.0;
  }

  for(cb=0; cb < pargs.loops; ++cb) {

    for(mu=1; mu < Nd; ++mu) {
      value[mu] = (double)0.0;

      for(nu=0; nu < mu; ++nu) {

	if (logic_dims[nu] != 1) {
	  QMP_fprintf (stderr, "Sending/recv along nu %d direction sbuf = %p rbuf = %p\n", nu,
		       sbuf[nu], rbuf[nu]);
	  slow_sendrecv(sbuf[nu], rbuf[nu], surface[nu], -1, nu);
	  for (i = 0; i < surface[nu]/4; i++)
	    value[mu] += (double)rbuf[nu][i];
	}


	if (logic_dims[mu] != 1) {
	  QMP_fprintf (stderr, "Sending/recv along mu %d direction sbuf = %p rbuf = %p\n", 
		       mu, sbuf[mu], rbuf[mu]);
	  slow_sendrecv(sbuf[mu], rbuf[mu], surface[mu], -1, mu);
	  for (i = 0; i < surface[mu]/4; i++)
	    value[mu] += (double)rbuf[mu][i];
	}
	
	QMP_sum_double_array(&value[mu], 1);

      }
    }

    if (pargs.verify) {
      if (fabs (expval[mu] - 0.0) > 0.00001) {
	if (fabs (expval[mu] - value[mu]) > 0.1)
	  QMP_fprintf (stderr, "Expect value = %lf value = %lf\n",
		       expval[mu], value[mu]);
      }
      expval[mu] = value[mu];
    }


    // Loop over this 4 times
    for(i=0; i < Nd; ++i)
      QMP_sum_double_array(&value[0], 1);

    for (mu = 0; mu < Nd; mu++) {
      if (logic_dims[mu] != 1) 
	slow_sendrecv(sbuf[mu], rbuf[mu], surface[mu], -1, mu); 
    }
  }

  for (i = 0; i < Nd; i++) {
    QMP_free_memory (smem[i]);
    QMP_free_memory (rmem[i]);
  }

  QMP_finalize_msg_passing ();


  return 0;
}
