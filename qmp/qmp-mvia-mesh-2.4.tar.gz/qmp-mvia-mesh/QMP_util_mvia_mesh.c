/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Some utility functions used by other parts of QMP
 *
 * Author:  
 *      Jie Chen, Chip Watson and Robert Edwards
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_util_mvia_mesh.c,v $
 *   Revision 1.8  2005/03/19 22:32:47  morten
 *   Added the function
 *   QMP_status_t
 *   QMP_get_error_number (QMP_msghandle_t mh);
 *
 *   Revision 1.7  2004/10/08 19:59:30  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.6  2004/10/04 13:36:59  chen
 *   Add a right error message
 *
 *   Revision 1.5  2004/02/19 19:21:49  chen
 *   Add more debug info for RDMA
 *
 *   Revision 1.4  2004/02/19 15:22:02  chen
 *   Use static buffer inside QMP_route
 *
 *   Revision 1.3  2003/12/15 18:53:11  chen
 *   Add QMP_free and correct regmem refcount
 *
 *   Revision 1.2  2003/12/12 20:12:58  chen
 *   Add global routing, scatter, gather
 *
 *   Revision 1.1.1.1  2003/11/18 18:55:36  chen
 *   First CVS QMP_mvia_gigeD_mesh
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <stdarg.h>
#include <assert.h>

#include "qmp.h"
#include "QMP_P_MVIA_MESH.h"

/*****************************************************************************
 *  A Simple HACK to find out how many buffer are posted inside a VI         *
 ****************************************************************************/
typedef struct _VIP_VI {
    /** Run-time type information */
    QMP_u32_t		TypeId;

    /** VIPL NIC Handle the VI for this VI */
    VIP_NIC_HANDLE	NicHandle;

    /** M-VIA Kernel Agent NIC Handle for this VI */
    QMP_u32_t	KernNicHandle;

    /** M-VIA Kernel Agent VI Handle for this VI */
    QMP_u32_t  	KernViHandle;

    /** Number of times the wait routines will spin before blocking. */
    QMP_u32_t		SpinCount;

    /** 
     * Type of doorbell used by this VI.
     * Replicated from VIP_NIC for performance.
     */
    QMP_u32_t	        DoorbellType;

    /** If non-NULL, refers to the Completion Queue associated with 
     * the VI Send Work Queue.
     */
    VIP_CQ_HANDLE	SendCQHandle;

    /** If non-NULL, refers to the Completion Queue associated with the 
     * VI Receive Work Queue.
     */
    VIP_CQ_HANDLE	RecvCQHandle;

    /** If non-NULL, points to the first descriptor of the VI Receive
     * Work Queue.
     */
    VIP_DESCRIPTOR	*RecvQHead;

    /** If non-NULL, points to the last descriptor of the VI Recive 
     * Work Queue.
     */
    VIP_DESCRIPTOR	*RecvQTail;

    /** If non-NULL, points to the first descriptor of the 
     * VI Send Work Queue. 
     */
    VIP_DESCRIPTOR	*SendQHead;

    /** If non-NULL, points to the last descriptor of the VI
     * Receive Work Queue.
     */
    VIP_DESCRIPTOR	*SendQTail;

    /* Ignore a lot of junk */ 
} VIP_VI;

QMP_u32_t
QMP_number_posted_bufs (VIP_VI_HANDLE vi)
{
  QMP_u32_t num = 0;
  VIP_DESCRIPTOR* desc;

  desc = vi->RecvQHead;
  while (desc) {
    if (!(desc->CS.Status & VIP_STATUS_DONE))
      num++;
    desc = desc->CS.Next.Address;
  }
  return num;
}

/**
 * Allocate aligned memory space
 * GNU distributed memalign function has problem when dmalloc package 
 * is used.
 *
 * size: allocate 'size' bytes of memory
 * alignment: alignment for this memory
 * realaddr:  real allocated memory address (may not be alignend)
 * aligned_addr: this is the aligned memory address
 */
void
QMP_alloc_memory_aligned (QMP_u32_t size, QMP_u32_t alignment,
			  char** realaddr, char** aligned_addr)
{
  char *ptr, *aptr;
  QMP_u32_t mask = alignment - 1;

  ptr = malloc (size + alignment - 1);

  if (!ptr) {
    QMP_error ("cannot allocate aligned memory of size %d and alignment %d\n",
	       size, alignment);
    exit (1);
  }

  if (((QMP_u32_t)ptr & mask) != 0) 
    /* ptr is not aligned */
    aptr = (char *)(((QMP_u32_t)ptr + mask) & ~mask);
  else
    aptr = ptr;
  
  *aligned_addr = aptr;
  *realaddr = ptr;
}

/*****************************************************************************
 * Adding VI completion QUEUE to the glm cq table                            *
 ****************************************************************************/
void
QMP_add_viacq (QMP_machine_t* glm, VIP_CQ_HANDLE cq)
{
  int i;

  QMP_TRACE("QMP_add_viadev");

  if (glm->numcqs >= QMP_MAX_VIADEV) {
    QMP_error ("Number of completion queues >= %d \n", QMP_MAX_VIADEV);
    exit (1);
  }
  for (i = 0; i < glm->numcqs; i++) {
    if (cq == glm->allcqs[i]) {
      QMP_info ("This CQ is already here, no need to add.\n");
      return;
    }
  }
      
  glm->allcqs[glm->numcqs++] = cq;
}

void
QMP_remove_viacq (QMP_machine_t* glm, VIP_CQ_HANDLE cq)
{
  int i, j;

  QMP_TRACE("QMP_remove_viadev");

  j = -1;
  for (i = 0; i < glm->numcqs; i++) {
    if (glm->allcqs[i] == cq) {
      j = i;
      break;
    }
  }
  if (j == -1) {
    /* Not found */
    /* 
    QMP_info ("Cannot find this cq to remove, must from switched device.\n"); 
    */
    ;
  }
  else {
    for (i = j; i < glm->numcqs - 1; i++)
      glm->allcqs[i] = glm->allcqs[i + 1];
    
    glm->allcqs[glm->numcqs - 1] = 0;
    glm->numcqs--;
  }
}


/*****************************************************************************
 *           Setting VI Application Data                                     *
 ****************************************************************************/
QMP_status_t
QMP_mvia_set_vi_app_data (VIP_VI_HANDLE vi, void* data)
{
#ifdef QMP_64BIT_LONG
  VIP_PVOID64 x;
  x.AddressBits = (VIP_UINT64)data;

  return mviaSetViAppData(vi,x);
#else
  return mviaSetViAppData(vi, (VIP_PVOID64)data);
#endif
}

QMP_status_t
QMP_mvia_get_vi_app_data (VIP_VI_HANDLE vi, void** data)
{
  VIP_PVOID64 x;
  VIP_RETURN rc;

  rc = mviaGetViAppData(vi, &x);
  if (rc != VIP_SUCCESS) return rc;
  *data = (void *)((QMP_u32_t)(x.AddressBits));
  return QMP_SUCCESS;
}

/*****************************************************************************
 *           Managing all free lists                                         *
 ****************************************************************************/

/**
 * Add a allocated free list to the holder
 */
void
QMP_remember_free_list (QMP_machine_t* glm, void* free_list)
{
  QMP_TRACE("QMP_remember_free_list");

  glm->allocated_free_lists[glm->num_free_lists++] = free_list;
}

/**
 * Clean out all free lists
 */
void
QMP_cleanup_free_lists (QMP_machine_t* glm)
{
  int i;

  QMP_TRACE ("QMP_cleanup_free_lists");

  for (i = 0; i < glm->num_free_lists; i++) {
    QMP_DEBUG(QMP_DBGLVL_FREELIST, "free allocated free list at 0x%x \n", 
	      glm->allocated_free_lists[i]);
    free (glm->allocated_free_lists[i]);
  }
}


/**
 * Allocate memory for switched via host table
 */
QMP_status_t
QMP_create_rtenv_swtable (QMP_rtenv_t* rt, QMP_u32_t num)
{
  QMP_TRACE ("QMP_create_rtenv_stable");

  rt->switched_table = (QMP_switched_viahost_t *)
    malloc(num * sizeof (QMP_switched_viahost_t));
  if (!rt->switched_table) 
    return QMP_NOMEM_ERR;

  return QMP_SUCCESS;
}

/**
 * Free memory associated with swithed via host table.
 */
void
QMP_delete_rtenv_swtable (QMP_rtenv_t* rt)
{
  QMP_TRACE("QMP_delete_rtenv_stable");

  if (rt->switched_table)
    free (rt->switched_table);

  rt->switched_table = 0;
}

/**
 * Populate a switched via host table using a single line 
 * definition like "host via_host"
 */
QMP_status_t
QMP_insert_rtenv_swtable (QMP_rtenv_t* rt, char* line, int idx)
{
  QMP_TRACE("QMP_insert_rtenv_table");
  
  if (sscanf (line, "%s %s", rt->switched_table[idx].host,
	      rt->switched_table[idx].via_host) < 2)
    return QMP_RTENV_ERR;

  return QMP_SUCCESS;
}


/**
 * Allocate memory for list of physical nodes
 */
QMP_status_t
QMP_create_rtenv_nodes (QMP_rtenv_t* rt, QMP_u32_t num)
{
  int i, j;

  QMP_TRACE ("QMP_create_rtenv_nodes");

  rt->all_nodes = (QMP_phys_node_t *)malloc(num * sizeof (QMP_phys_node_t));
  if (!rt->all_nodes) 
    return QMP_NOMEM_ERR;

  for (i = 0; i < num; i++) {
    rt->all_nodes[i].rank = 0;
    for (j = 0; j < QMP_PHYS_NMD; j++)
      rt->all_nodes[i].coordinates[j] = 0;
    rt->all_nodes[i].host[0] = '\0';
  }
  return QMP_SUCCESS;
}

/**
 * Free memory associated with physical nodes.
 */
void
QMP_delete_rtenv_nodes (QMP_rtenv_t* rt)
{
  QMP_TRACE ("QMP_delete_rtenv_nodes");

  if (rt->all_nodes)
    free (rt->all_nodes);

  rt->all_nodes = 0;
}

/***************************************************************
 * qbuf manipulate routines                                    *
 **************************************************************/

/**
 * Create and initialize qbuf manager
 */
QMP_status_t
QMP_init_qbuf_manager (QMP_viadev_handle_t* h,
		       QMP_qbuf_manager_t* manager,
		       QMP_mh_type_t type,
		       QMP_gige_conn_type_t conn_type)
{
  VIP_MEM_ATTRIBUTES memattrs;
  VIP_MEM_HANDLE     mem_handle;
  VIP_RETURN         status;
  int                alignment, i;
  QMP_qbuf_t*        q;

  QMP_TRACE ("QMP_init_qbuf_manager");

  manager->type = type;

  /**
   * For direct connections we use a lot receiving/sending buffers for
   * higher performance. But for switched connection, we use fewer buffers
   * to save memory.
   */
  if (conn_type == QMP_CONN_DIRECT) {
    if (manager->type == QMP_MH_RECV)
      manager->count = QMP_NUM_RECV_QBUFS;
    else
      manager->count = QMP_NUM_SEND_QBUFS;
  }
  else {
    if (manager->type == QMP_MH_RECV)
      manager->count = QMP_NUM_RECV_QBUFS/3;
    else
      manager->count = QMP_NUM_SEND_QBUFS/2;
  }

  /* qbufs must be aligned on 64 byte (VIP_DESCRIPTOR_ALIGNMENT)
   * boundary due to VIPL spec, but also, dont want a VBUF to
   * span multiple memory pages to reduce dma accesses by NIC
   * on PCI bus.  So, alloc block with QBUF-sizeed alignment.
   * Note: QBUF size is already a multiple of VIP_DESCRIPTOR_ALIGNMENT.
   */
  alignment = QMP_QBUF_TOTAL_SIZE;

  /* Now allocate memory */
  QMP_alloc_memory_aligned (manager->count * QMP_QBUF_TOTAL_SIZE,
			    alignment,
			    (char **)&manager->addr,
			    (char **)&manager->head);
  /*
  manager->addr = QMP_memalign (manager->count * QMP_QBUF_TOTAL_SIZE, 
				alignment);
  if (!manager->addr) {
    QMP_error ("cannot allocate memory for %d number of qbufs.\n",
	       manager->count);
    return QMP_NOMEM_ERR;
  }
  
  manager->head = (QMP_qbuf_t *)(manager->addr);
  */

  memset (manager->addr, 0, manager->count * QMP_QBUF_TOTAL_SIZE);

  /* Set up memory attributes */
  /* These memories for protocols only, no rdma */
  memattrs.Ptag = h->ptag;
  memattrs.EnableRdmaWrite = VIP_FALSE;
  memattrs.EnableRdmaRead = VIP_FALSE;
  
  /* Now register memory to a VIA NIC */
  status = VipRegisterMem (h->nic_handle, manager->head,
			   manager->count * QMP_QBUF_TOTAL_SIZE,
			   &memattrs, &mem_handle);
  if (status != VIP_SUCCESS) {
    QMP_error ("cannot register memory to VIA device %s . \n", h->eth_device);
    free (manager->addr);
    return status;
  }
  
  /* Now setup memory handle */
  manager->mem_handle = mem_handle;

  /* Now initialize the list */
  for (i = 0; i < manager->count - 1; i++) {
    q = manager->head + i;
    q->descp.CS.Next.Address = manager->head + i + 1;
    q->manager = manager;
  }

  /* Last one on the list */
  q = manager->head + manager->count - 1;
  q->descp.CS.Next.Address = 0;
  q->manager = manager;

  return QMP_SUCCESS;
}

/**
 * Remove qbuf manager
 */
void
QMP_finalize_qbuf_manager (QMP_viadev_handle_t* h,
			   QMP_qbuf_manager_t* manager)
{
  QMP_TRACE("qmp_finalize_qbuf_manager_i");

  VipDeregisterMem (h->nic_handle,
		    manager->addr,
		    manager->mem_handle);
  free (manager->addr);
}

/**
 * Get a qbuf from a manager
 */
QMP_qbuf_t*
QMP_get_qbuf (QMP_qbuf_manager_t* manager)
{
  QMP_qbuf_t *ret, *tmp;

  QMP_TRACE ("QMP_get_qbuf");

  tmp = manager->head;
  if (tmp && manager->count) {
    (manager->count)--;
    /*
    QMP_DEBUG(QMP_DBGLVL_FREELIST, "Get QBUF: QMP Qbuf manager %p has %d entries now.\n",
	      manager, manager->count);
    */
    ret = tmp;
    tmp = tmp->descp.CS.Next.Address;
    manager->head = tmp;
    /* set some attributes of this qbuf */
    ret->descp.CS.Next.Address = 0;
    ret->req = 0;
    return ret;
  }
  /* Do I need add more qbufs ? */
  /* QMP_DEBUG (QMP_DBGLVL_FREELIST, "Running out qbufs, what to do !!!, wait for other to release.");
   */
  return 0;
}


/**
 * Put a qbuf back to the manager
 */
void
QMP_release_qbuf (QMP_qbuf_manager_t* manager,
		  QMP_qbuf_t* qbuf)
{

  QMP_TRACE ("QMP_release_qbuf");

  qbuf->descp.CS.Next.Address = manager->head;
  (manager->count)++;
  manager->head = qbuf;
  /*
  QMP_DEBUG(QMP_DBGLVL_FREELIST, "Put QBUF: QMP Qbuf manager has %d entries now.\n",
	      manager->count);
  */
}

/**
 * Set qbuf ready for send and receive
 */
void
QMP_set_qbuf_sendrecv_ready (QMP_qbuf_t* qbuf, QMP_u32_t len)
{
  QMP_TRACE ("QMP_set_qbuf_sendrecv_ready");

  qbuf->descp.CS.Control = VIP_CONTROL_OP_SENDRECV;
  qbuf->descp.CS.SegCount = 1;
  qbuf->descp.CS.Length = len;
  qbuf->descp.CS.Reserved = 0;
  qbuf->descp.CS.Status = 0; /* xxx should be done by VIPL */
  qbuf->descp.DS[0].Local.Data.Address = &qbuf->buffer;
  qbuf->descp.DS[0].Local.Handle = qbuf->manager->mem_handle;
  qbuf->descp.DS[0].Local.Length = len;
}

/**
 * Set a qbuf remote write ready
 */
void
QMP_set_qbuf_rdmaw_ready (QMP_qbuf_t* qbuf, 
			  void* local_addr, VIP_MEM_HANDLE local_memh,
			  void* remote_addr, VIP_MEM_HANDLE remote_memh,
			  QMP_u32_t len, 
			  QMP_u32_t idata)
{

  QMP_TRACE("QMP_set_qbuf_rdmaw_ready");

  qbuf->descp.CS.Control = VIP_CONTROL_OP_RDMAWRITE | VIP_CONTROL_IMMEDIATE;
  qbuf->descp.CS.SegCount = 2;
  qbuf->descp.CS.Length = len;
  qbuf->descp.CS.Reserved = 0;
  qbuf->descp.CS.Status = 0;
  qbuf->descp.CS.ImmediateData = idata;
  qbuf->descp.DS[0].Remote.Data.Address= remote_addr;
  qbuf->descp.DS[0].Remote.Handle = remote_memh;
  qbuf->descp.DS[0].Remote.Reserved = 0;
  qbuf->descp.DS[1].Local.Data.Address = local_addr;
  qbuf->descp.DS[1].Local.Handle = local_memh;
  qbuf->descp.DS[1].Local.Length = len;
}

/**
 * Post a send using a particular qbuf
 *
 * If rdma_send is true, remote_tokens will be reduced by one anyway
 * since the immediate data will consume a qbuf on my peer.
 *
 * But the local tokens will not be reset since the token information
 * will not be sent over the net.
 *
 */
QMP_status_t
QMP_qbuf_post_send (QMP_machine_t* glm,
		    QMP_gige_port_t* port,
		    QMP_qbuf_t* qbuf,
		    QMP_bool_t rdma_send)
{
  VIP_RETURN status;

  QMP_TRACE ("QMP_qbuf_post_send");

  status = VipPostSend(port->conn->vi_handle, (VIP_DESCRIPTOR *)qbuf,
		       qbuf->manager->mem_handle);
  if (status == VIP_SUCCESS) {

    QMP_DEBUG(QMP_DBGLVL_TOKEN, "Post_send: Port %p has %d remote tokens %d local tokenssend qbuf has %d qbufs .\n", port, port->conn->remote_tokens, port->conn->local_tokens, qbuf->manager->count);

    if (!rdma_send) {
      /* Decrease remote tokens */
      port->conn->remote_tokens--;      
      /* Reset local tokens to 0 since this value has been sent over */
      port->conn->local_tokens = 0;
    }
    else {
      /* Decrease remote tokens */
      port->conn->remote_tokens--;
    }
  }
  else {
    QMP_error ("failure in VipPostSend: %s \n", QMP_error_string (status));
    port->err_code = status;
  }
  return status;
}


/**
 * Post a recv using a particular qbuf
 */
QMP_status_t
QMP_qbuf_post_recv (QMP_machine_t* glm, 
		    QMP_gige_port_t* port,
		    QMP_qbuf_t* qbuf)
{
  VIP_RETURN status;

  QMP_TRACE ("QMP_qbuf_post_recv");

  status = VipPostRecv(port->conn->vi_handle, (VIP_DESCRIPTOR *)qbuf,
		       qbuf->manager->mem_handle);
  if (status == VIP_SUCCESS) {
    /* increase local tokens */
    port->conn->local_tokens++;
    QMP_DEBUG(QMP_DBGLVL_TOKEN, "Post_recv: port %p has %d local_tokens \n",
	      port, port->conn->local_tokens);
    if (port->conn->notify_peer &&
	port->conn->local_tokens > QMP_TOKEN_NOTIFY_THRESHOLD) {
      QMP_DEBUG(QMP_DBGLVL_TOKEN, "Send noop to peer with local tokens %d\n",
		port->conn->local_tokens);
      if (QMP_isend_nodata (port->peer->rank, QMP_NO_OP, 0, 0, port, glm) 
	  == QMP_SUCCESS) {
	port->conn->notify_peer = QMP_FALSE;
      }
    }
  }
  else {
    QMP_error ("failure in VipPostRecv: %s \n", QMP_error_string (status));
    port->err_code = status;
  }
  return status;
}

/***************************************************************
 * Send and receive request manipulating routines              *
 **************************************************************/

QMP_status_t
QMP_init_req_free_list (QMP_machine_t* glm)
{
  int i;

  QMP_TRACE ("QMP_init_req_free_list");

  glm->req_free_list = (QMP_request_t *)malloc(sizeof(QMP_request_t)*QMP_REQS_FREELIST_SIZE);
  if (!glm->req_free_list) {
    QMP_error ("cannot allocate memory for request free list.\n");
    exit (1);
  }

  /* Set up links */
  for (i = 1; i < QMP_REQS_FREELIST_SIZE - 1; i++) {
    glm->req_free_list[i].next = &(glm->req_free_list[i+1]);
    glm->req_free_list[i].prev = &(glm->req_free_list[i-1]);
  }
  glm->req_free_list[0].next = &(glm->req_free_list[1]);
  glm->req_free_list[0].prev = 0;
  
  glm->req_free_list[QMP_REQS_FREELIST_SIZE - 1].next = 0;
  glm->req_free_list[QMP_REQS_FREELIST_SIZE - 1].prev = &(glm->req_free_list[QMP_REQS_FREELIST_SIZE - 2]);
      
  QMP_DEBUG (QMP_DBGLVL_FREELIST, 
	     "allocate %d entries of qmp_sendreq_t for free list at %p. \n",
	     QMP_REQS_FREELIST_SIZE, glm->req_free_list);

  QMP_remember_free_list (glm, glm->req_free_list);
  
  return QMP_SUCCESS;
}

/***************************************************************
 * Registered memory for VIA handling routines                 *
 **************************************************************/

/**
 * A global free list for all QMP_regmem_entry_t. This list
 * is for all VIA NIC devices (via_eth0, via_eth1, ....)
 */

/**
 * Delete entry d from the double-linked unused list.
 * Take care if d is either the head or the tail of the list.
 */

#define QMP_REGMEM_RM_FROM_UNUSED_LIST(table,d) {   \
    QMP_regmem_entry_t *prev = (d)->prev_u;         \
    QMP_regmem_entry_t *next = (d)->next_u;         \
    (d)->next_u = 0;                                \
    (d)->prev_u = 0;                                \
    if (prev) {                                     \
	prev->next_u = next;                        \
    }                                               \
    if (next) {                                     \
	next->prev_u = prev;                        \
    }                                               \
    if ((table)->unused_head == (d)) {              \
        (table)->unused_head = next;                \
    }                                               \
    if ((table)->unused_tail == (d)) {              \
        (table)->unused_tail = prev;                \
    }                                               \
}                                                 

/**
 * Add entries to the head of the unused list. remove() takes
 * them from the tail. This gives us a simple LRU mechanism 
 */

#define QMP_REGMEM_ADD_TO_UNUSED_LIST(table,d) {    \
    d->next_u = (table)->unused_head;               \
    d->prev_u = 0;                                  \
    if ((table)->unused_head) (table)->unused_head->prev_u = d; \
    (table)->unused_head = d;                           \
    if ((table)->unused_tail == 0) (table)->unused_tail = d; \
}


/**
 * adding to the hash table is just 
 * putting it on the head of the hash chain
 */

#define QMP_REGMEM_ADD_TO_HASH_TABLE(table,addr,d) { \
  int hash = QMP_REGMEM_HASH(addr);                  \
  QMP_regmem_entry_t *d1 = (table)->slots[hash];     \
  (table)->slots[hash] = d;                          \
  (d)->next = d1;                                    \
}

/**
 * deleting from the hash table (hopefully a rare event)
 * may be expensive because we have to walk the single-linked
 * hash chain until we find the entry. The special and easy
 * case is if the entry is at the head of the chain
 */

#define QMP_REGMEM_DELETE_FROM_HASH_TABLE(table,d) {   \
  QMP_along_t addr = (d)->page_num << QMP_OS_PAGEBITS; \
  int hash = QMP_REGMEM_HASH(addr);                    \
  QMP_regmem_entry_t *d1 = (table)->slots[hash];       \
  if (d1 == d) (table)->slots[hash] = d1->next;        \
  else {                                               \
    while(d1->next != d) {                             \
      assert(d1->next != NULL);                        \
      d1 = d1->next;                                   \
    }                                                  \
    d1->next = d->next;                                \
  }                                                    \
}

#define QMP_REGMEM_GET_FROM_FREE_LIST(mach, d) {      \
    d = mach->regmem_free_list;                       \
    if (mach->regmem_free_list)                       \
        mach->regmem_free_list = mach->regmem_free_list->next; \
}

#define QMP_REGMEM_ADD_TO_FREE_LIST(mach, d) {         \
    d->next = mach->regmem_free_list;                  \
    mach->regmem_free_list = d;                        \
}


/**
 * Get a new QMP_regmem_entry_t from the free list.
 */
QMP_regmem_entry_t *
qmp_regmem_get_entry_i (QMP_machine_t* glm)
{
  QMP_regmem_entry_t* d;

  QMP_TRACE ("qmp_regmem_get_entry_i");

  d = 0;
  while (!d) {
    QMP_REGMEM_GET_FROM_FREE_LIST(glm,d);

    if (d) {
      d->refcount = 0;
      d->next_u = 0;
      d->prev_u = 0;
      d->next = 0;
      d->mem_handle = 0;
    }
    else {
      int i;

      glm->regmem_free_list = (QMP_regmem_entry_t *)malloc(sizeof(QMP_regmem_entry_t) * QMP_REGMEM_FREELIST_SIZE);
      
      if (!glm->regmem_free_list) {
	QMP_error ("cannot allocate free list for registered memory.n");
	exit (1);
      }
    
      /* Set up links */
      for (i = 0; i < QMP_REGMEM_FREELIST_SIZE - 1; i++) 
	glm->regmem_free_list[i].next = &(glm->regmem_free_list[i+1]);
      /* i should be QMP_REGMEM_FREELIST_SIZE - 1: last one */
      glm->regmem_free_list[i].next = 0;
      
      QMP_DEBUG (QMP_DBGLVL_FREELIST, 
		 "allocate %d entries of qmp_regmem_entry_t for free list. \n",
		 QMP_REGMEM_FREELIST_SIZE);

      QMP_remember_free_list (glm, glm->regmem_free_list);
    }
  }
  return d;
}


/**
 * Put a memory entry back to the free list
 */
void 
qmp_regmem_release_entry_i (QMP_machine_t* glm, QMP_regmem_entry_t *d)
{
  /* note this correctly handles appending to empty free list */
  d->next = glm->regmem_free_list;
  glm->regmem_free_list = d;
}

/**
 * Decrement reference count on a registered memory entry.
 * If ref count goes to zero, don't free it, but put it on the 
 * unused list so we
 * can evict it if necessary. Put on head of unused list. 
 */
void 
qmp_regmem_decr_refcount_i (QMP_regmem_table_t* table, QMP_regmem_entry_t *d)
{
  QMP_TRACE ("qmp_regmem_decr_refcount_i");

  assert(d->refcount > 0);
  d->refcount--;
  if (d->refcount == 0) 
    QMP_REGMEM_ADD_TO_UNUSED_LIST(table,d);

  QMP_DEBUG(QMP_DBGLVL_REGMEM,
	    "entry 0x%x refcount %d memhandle %x\n", 
	    d, d->refcount, (unsigned int)d->mem_handle);
}

/**
 * Increment reference count on a dreg entry. If reference count
 * was zero and it was on the unused list (meaning it had been
 * previously used, and the refcount had been decremented),
 * we should take it off
 */
void 
qmp_regmem_incr_refcount_i(QMP_regmem_table_t* table, QMP_regmem_entry_t *d)
{
  QMP_TRACE ("qmp_regmem_incr_refcount_i");

  assert(d != NULL);
  if (d->refcount == 0) 
    QMP_REGMEM_RM_FROM_UNUSED_LIST(table, d);

  d->refcount++;
}


/**
 * Find a registered memory slot from a table.
 * return NULL, if  there is none to match.
 */
static QMP_regmem_entry_t * 
qmp_regmem_find_i (QMP_regmem_table_t* table, void* buf, QMP_u32_t len)
{
  QMP_regmem_entry_t* slot;
  QMP_along_t pagebase_a, buf_a, pagenum;
  QMP_u32_t npages;

  QMP_TRACE("qmp_regmem_find_i");

  slot = table->slots[QMP_REGMEM_HASH(buf)];
  if (!slot)
    return 0;

  buf_a = (QMP_along_t)buf;
  pagebase_a = buf_a & ~QMP_OS_PAGEMASK;
  pagenum = buf_a >> QMP_OS_PAGEBITS;

  /**
   * Figure out how many pages we are going to register
   */
  npages = 1 + ((buf_a + (QMP_along_t)len - pagebase_a) >> QMP_OS_PAGEBITS);
  while (slot) {
    if (slot->page_num == pagenum && slot->npages >= npages)
      break;
    slot = slot->next;
  }
  
  if (slot) {
    QMP_DEBUG(QMP_DBGLVL_REGMEM, 
	      "found entry at pagebase = 0x%x and npages = %d.\n", 
	      slot->page_num << QMP_OS_PAGEBITS, slot->npages);
  }

  return slot;
}

/**
 * qmp_regmem_new_entry_i is called only when we have already
 * found that the memory isn't registered. Register it 
 * and put it in the hash table 
 */
static QMP_regmem_entry_t *
qmp_regmem_new_entry_i (QMP_machine_t* glm,
			QMP_regmem_table_t* table, void *buf, int len)
{
  QMP_regmem_entry_t *d;
  QMP_along_t pagenum_low, pagenum_high;
  int npages;
  int rc;

  /* user_low_a is the bottom address the user wants to register;
   * user_high_a is one greater than the top address 
   * the user wants to register
   */
  QMP_along_t user_low_a, user_high_a;


  /* pagebase_low_a and pagebase_high_a are the addresses of the beginning of
   * the page containing user_low_a and user_high_a respectively. 
   */

  QMP_along_t pagebase_low_a, pagebase_high_a;
  void *pagebase_low_p;

  VIP_ULONG register_nbytes;
  VIP_MEM_ATTRIBUTES memattrs;

  QMP_TRACE ("qmp_regmem_new_entry_i");

  /* Get a new memory entry structure */
  d = qmp_regmem_get_entry_i (glm);

  /* calculate base page address for registration */
  user_low_a = (QMP_along_t)buf;
  user_high_a = user_low_a + (QMP_along_t)len;
  
  pagebase_low_a = user_low_a & ~QMP_OS_PAGEMASK;
  pagebase_high_a = user_high_a & ~QMP_OS_PAGEMASK;

  /* info to store in hash table */
  pagenum_low = pagebase_low_a >> QMP_OS_PAGEBITS;
  pagenum_high = pagebase_high_a >> QMP_OS_PAGEBITS;
  npages = 1 + (pagenum_high - pagenum_low);

  pagebase_low_p = (void *)pagebase_low_a;

  /* Enable remote write */
  memattrs.Ptag = table->viadev->ptag;
  memattrs.EnableRdmaWrite = VIP_TRUE;
  memattrs.EnableRdmaRead = VIP_FALSE;

  register_nbytes = npages * QMP_OS_PAGESIZE;

  QMP_DEBUG (QMP_DBGLVL_REGMEM, 
	     "register memory 0x%x (origianl 0x%x) len %d (original %d)\n", 
	     pagebase_low_a,  buf, register_nbytes, len);
  
  rc = VipRegisterMem(table->viadev->nic_handle, pagebase_low_p, 
		      register_nbytes, &memattrs, &d->mem_handle);

  if (rc != VIP_SUCCESS) {
    if (rc == VIP_INVALID_PARAMETER) {
      QMP_error ("cannot register memory 0x%x (origianl 0x%x) len %d (original %d) with %d pages because of invalid parameter\n", 
		 pagebase_low_a,  buf, register_nbytes, len, npages);
      QMP_abort (QMP_INVALID_ARG);
    }
    else {
      QMP_error ("cannot register memory 0x%x (origianl 0x%x) len %d (original %d)\n", 
		 pagebase_low_a,  buf, register_nbytes, len);
      qmp_regmem_release_entry_i (glm, d);
    }
    return 0;
  }

  QMP_DEBUG (QMP_DBGLVL_REGMEM,
	     "Regsiter memory 0x%x (origianl 0x%x) len %d (original %d) successful\n", 
	     pagebase_low_a,  buf, register_nbytes, len);

  d->page_num = pagenum_low;
  d->npages = npages;
  
  /* Add to hash table */
  QMP_REGMEM_ADD_TO_HASH_TABLE (table, pagebase_low_a, d);
  
  return d;
}



/**
 * Initialize a registered memory table
 */
void
QMP_regmem_table_init (QMP_machine_t* glm,
		       QMP_viadev_handle_t* viadev,
		       QMP_regmem_table_t* table)
{
  int i;

  QMP_TRACE ("QMP_regmem_table_init");
  
  for (i = 0; i < QMP_REGMEM_HASHSIZE; i++)
    table->slots[i] = 0;

  table->unused_head = 0;
  table->unused_tail = 0;
  table->viadev = viadev;

  if (!glm->regmem_free_list_inited) {
    glm->regmem_free_list_inited = 1;

    glm->regmem_free_list = (QMP_regmem_entry_t *)malloc(sizeof(QMP_regmem_entry_t) * QMP_REGMEM_FREELIST_SIZE);

    if (!glm->regmem_free_list) {
      QMP_error ("cannot allocate free list for registered memory\n");
      exit (1);
    }
    
    /* Set up links */
    for (i = 0; i < QMP_REGMEM_FREELIST_SIZE - 1; i++) 
      glm->regmem_free_list[i].next = &(glm->regmem_free_list[i+1]);
    /* i should be QMP_REGMEM_FREELIST_SIZE - 1: last one */
    glm->regmem_free_list[i].next = 0;

    QMP_DEBUG (QMP_DBGLVL_REGMEM, 
	       "allocate %d entries of qmp_regmem_entry_t for free list. \n",
	       QMP_REGMEM_FREELIST_SIZE);
    QMP_remember_free_list (glm, glm->regmem_free_list);
  }
}

/**
 * Cleanout a register memory table. This is called when a VIA device 
 * is closed.
 */
void
QMP_regmem_table_clean (QMP_viadev_handle_t* viadev)
{
  int i;
  QMP_status_t rc;
  void *buf;
  QMP_regmem_entry_t *d;
  QMP_along_t bufint;

  QMP_TRACE ("QMP_regmem_table_clean");

  for (i = 0; i < QMP_REGMEM_HASHSIZE; i++) {
    d = viadev->regmem_table.slots[i];
    while (d) {
      bufint = (d->page_num) << QMP_OS_PAGEBITS;
      buf = (void *)bufint;

      QMP_DEBUG (QMP_DBGLVL_REGMEM,
		 "clean registered memory at slot %d addr 0x%x.\n",
		 i, buf);
      
      rc = VipDeregisterMem (viadev->nic_handle, buf, d->mem_handle);

      d = d->next;
    }
  }
}

/**
 * Remove a registration. This means delete it from the unused list, 
 * add it to the free list, and deregister the associated memory.
 */
static QMP_status_t
qmp_regmem_cleanup_i (QMP_machine_t* glm, QMP_regmem_table_t* table)
{
  QMP_status_t rc;
  void *buf;
  QMP_regmem_entry_t *d;
  QMP_along_t bufint;

  QMP_TRACE ("qmp_regmem_cleanup_i");

  d = table->unused_tail;
  if (!d) {
    /* no entries left on unused list, return failure */
    return QMP_ERROR;
  }
  QMP_REGMEM_RM_FROM_UNUSED_LIST(table, d);
    
  assert(d->refcount == 0);

  bufint = d->page_num << QMP_OS_PAGEBITS;
  buf = (void *)bufint;

  QMP_DEBUG (QMP_DBGLVL_REGMEM,
	     "deregistering address= 0x%x memhandle = %x\n", 
	     bufint, d->mem_handle);

  rc = VipDeregisterMem(table->viadev->nic_handle, buf, d->mem_handle);
  
  QMP_REGMEM_DELETE_FROM_HASH_TABLE(table, d);
  QMP_REGMEM_ADD_TO_FREE_LIST(glm,d);
  return QMP_SUCCESS;
}


/**
 * Register a memory buffer
 * return NULL if registration fails.
 */
QMP_regmem_entry_t *
QMP_regmem_register (QMP_machine_t* glm, QMP_regmem_table_t* table, 
		     void* buf, QMP_u32_t len)
{
  QMP_status_t rc;
  QMP_regmem_entry_t* slot;


  QMP_TRACE ("QMP_regmem_register");

  slot = qmp_regmem_find_i (table, buf, len);
  
  if (slot) {
    qmp_regmem_incr_refcount_i (table, slot);
    QMP_DEBUG(QMP_DBGLVL_REGMEM,
	      "found a registered buffer for 0x%x len %d and refcount = %d.\n",
	      buf, len, slot->refcount);
  }
  else {
    while ((slot = qmp_regmem_new_entry_i (glm, table, buf, len)) == 0) {
      /** 
       * Cannot allocate new memory entry. It is usually because cannot 
       * we cannot register memory to VIA. Remove some of regisered memories
       * that are registered earliest and try again.
       */
      QMP_DEBUG (QMP_DBGLVL_REGMEM, 
		 "no memory entries are available, get rid of some old entries.\n");
      
      rc = qmp_regmem_cleanup_i (glm, table);
      if (rc != QMP_SUCCESS) {
	/* bad: we cannot register memory anymore */
	QMP_error ("clean up registered memory failed, cannot register memory.\n");
	return 0;
      }
    }
    qmp_regmem_incr_refcount_i (table, slot);
    QMP_DEBUG (QMP_DBGLVL_REGMEM, 
	       "created new entry for buffer 0x%x and length %d.\n",
	       buf, len);
  }
  return slot;
}

/**
 * Decrease reference count of a registered meomory from a request
 *
 */
void
QMP_request_done (QMP_machine_t* glm,
		  QMP_request_t* request)
{
  QMP_u32_t      len  = QMP_REQ_USERBUFLEN(request);

  QMP_TRACE ("QMP_request_done");

  /**
   * RDMA requests are characterized by either a memory size or
   * an operation type
   */
  if (len > QMP_MEMCPY_THRESHOLD || request->hdr.op == QMP_RDMA_PUT) {
    QMP_regmem_entry_t *d;
    QMP_gige_port_t* port = QMP_REQ_PORT(request);
    void*          buf  = QMP_REQ_USERBUF(request);

    /* Find out entry for this memory length */
    d = qmp_regmem_find_i (QMP_PORT_REGMEM_TABLE(port), buf, len);
  
    if (d) {
      qmp_regmem_decr_refcount_i (QMP_PORT_REGMEM_TABLE(port), d);
      QMP_DEBUG (QMP_DBGLVL_REGMEM, "Decrease refcount for memory %p and len %d and refcount = %d\n", buf, len, d->refcount);
    }
  }
}



/**
 * Remove a registered memory from the table
 * and also unping this memory from OS
 * If this memory is not registered, do not send out error message
 */
void
QMP_regmem_complete_remove (QMP_machine_t* glm, QMP_gige_port_t* port,
			    void* buf, QMP_u32_t len)
{
  QMP_regmem_entry_t* slot;
  QMP_regmem_table_t* table;
  void *pagebuf;
  QMP_along_t bufint;

  QMP_TRACE ("QMP_regmem_remove");

  table = QMP_PORT_REGMEM_TABLE(port);

  /* Find out entry for this memory length */
  slot = qmp_regmem_find_i (table, buf, len);
  
  if (slot) {
    if (slot->refcount == 0) {
      QMP_DEBUG(QMP_DBGLVL_REGMEM,
		"Remove found a registered buffer for 0x%x len %d.\n",
		buf, len);

      /* Remove from UNused list */
      QMP_REGMEM_RM_FROM_UNUSED_LIST(table, slot);

      /* Now we are remove this slot from the table */
      bufint = (slot->page_num) << QMP_OS_PAGEBITS;
      /* Get page aligned buffer address */
      pagebuf = (void *)bufint;
    
      if (VipDeregisterMem (port->viadev->nic_handle, 
			    pagebuf, slot->mem_handle) == VIP_SUCCESS) {
	/* Remove from the hash table and put it back to free list */
	QMP_REGMEM_DELETE_FROM_HASH_TABLE(table, slot);
	
	QMP_REGMEM_ADD_TO_FREE_LIST(glm, slot);
      }
      else
	QMP_error ("Cannot deregister memory %p of len %d.\n", buf, len);
    }
  }
}

/**
 * Remove a registered memory from the tables of all ports
 * and also unping this memory from OS
 * If this memory is not registered, do not send out error message
 */
void
QMP_regmem_remove_from_all (QMP_machine_t* glm,
			    void* buf, QMP_u32_t len)
{
  int i;
  QMP_gige_port_t* port;

  QMP_TRACE ("QMP_regmem_remove_from_all");


  /* Open VIA Nic Handle for neighbors */
  for (i = 0; i < glm->phys->dimension; i++) {
    /* minus direction */
    port = &glm->phys->ports[i][0];

    QMP_regmem_complete_remove (glm, port, buf, len);

    /* plus direction */
    port = &glm->phys->ports[i][1];

    QMP_regmem_complete_remove (glm, port, buf, len);
  }
}


/*************************************************************************
 * Message Handle manipulate routines                                    *
 ************************************************************************/
QMP_status_t
QMP_init_msghandle_free_list (QMP_machine_t* glm)
{
  int i;

  QMP_TRACE ("QMP_init_msghandle_free_list");

  glm->msg_handle_free_list = (QMP_msghandle_i_t *)malloc(sizeof(QMP_msghandle_i_t)*QMP_MSGHANDLE_FREELIST_SIZE);

  if (!glm->msg_handle_free_list) {
    QMP_error ("cannot allocate memory for msg_handle free list.\n");
    exit (1);
  }

  /* Set up links */
  for (i = 0; i < QMP_MSGHANDLE_FREELIST_SIZE - 1; i++) 
    glm->msg_handle_free_list[i].next = &(glm->msg_handle_free_list[i+1]);


  glm->msg_handle_free_list[QMP_MSGHANDLE_FREELIST_SIZE - 1].next = 0;
      
  QMP_DEBUG (QMP_DBGLVL_FREELIST, 
	     "allocate %d entries of QMP_msghandle_t for free list. \n",
	     QMP_MSGHANDLE_FREELIST_SIZE);

  QMP_remember_free_list (glm, glm->msg_handle_free_list);
  
  return QMP_SUCCESS;
}

/**
 * Get a new tag value for the send message handles 
 */
QMP_u16_t
QMP_get_send_tag (QMP_gige_port_t* port, QMP_msghandle_i_t* mh)
{
  QMP_u16_t rtag = QMP_INTERNAL_TAG;
  QMP_msghandle_i_t* curr = port->conn->send_handles;
  int found = 0;

  QMP_TRACE ("QMP_get_send_tag");

  while (curr) {
    if (curr->sh_memory->nbytes == mh->sh_memory->nbytes) {
      found = 1;
      if (rtag < curr->sh_tag)
	rtag = curr->sh_tag;
    }
    curr = curr->next;
  }
  if(found) 
    rtag++;

  return rtag;
}

/**
 * Get a new tag value for the send message handles 
 */
QMP_u16_t
QMP_get_recv_tag (QMP_gige_port_t* port, QMP_msghandle_i_t* mh)
{
  QMP_u16_t rtag = QMP_ANY;

  /* On the receiving side we always return QMP_ANY */
  return rtag;
}

  


/**
 * Error strings corresponding to the error codes.
 */
static char* QMP_error_strings[] = {
  "successful",
  "general QMP error",
  "message passing system is not initialized yet",
  "run time environment set up error",
  "machine CPU information retrieval error",
  "node run time information retrieval error",
  "malloc failure",
  "sending memory size is larger than receiving memory size",
  "node hostname retrieval error",
  "initiate underlying service (gm) error",
  "logical topology exists already",
  "channel connection time out",
  "not supported",
  "underlying service (gm) is busy",
  "invalid communication message",
  "invalid function arguments",
  "invalid declared topology",
  "topology neighboring information error",
  "declare memory size exceeeds the maximum allowed size",
  "invalid memory for a message handle",
  "no more gm ports available",
  "remote node number is out of range",
  "channel definition error (send/recv to/from itself)",
  "receiving memory is already used by others",
  "a sending/receiving operation applied in a wrong state",
  "communication time out",
};


/**
 * Error strings corresponding to VIA function return status
 */
static char* QMP_viastatus_error_strings[] = {
  "Via not done",
  "Via invalid parameter",
  "Via resource error",
  "Via time out",
  "Via connection reject",
  "Via invalid reliability level",
  "Via invalid MTU size",
  "Via invalid QoS setting",
  "Via invalid PTAG parameter",
  "Via invalid remote memory read",
  "Via descriptor error",
  "Via invalid state",
  "Via error in naming service",
  "Via connection has no match",
  "Via remote host cannot be reached"
};


/**
 * Error strings corresponding to the error codes generated by VIA
 * error callbacks
 */
static char* QMP_viacallback_error_strings[] = {
  "Via post descriptor error",
  "Via connection lost",
  "Via receiving queue is empty",
  "Via VI is being overrun",
  "Via remote memory write protection error",
  "Via remote memory write data error",
  "Via remote memory write aborted",
  "Via remote memory read protection error",
  "Via componet protection error",
  "Via remote memory access transport error",
  "Via catastrophic error!"
};

/**
 * Macros to retrieve rank and node number of a system.
 */
#define QMP_RANK(glm) (glm.inited ? glm.phys->my_node.rank : 0)
#define QMP_NUM_NODES(glm) (glm.inited ? glm.phys->num_nodes : 0)
#define QMP_HOST(glm) (glm.host)

/**
 * Simple QMP specific printf type of routine
 */
int
QMP_printf (const char* format, ...)
{
  va_list argp;
  int     status;
  char    info[128];
  char    buffer[1024];

  sprintf (info, "QMP m%d,n%d@%s : ", 
	   QMP_RANK(QMP_global_m),
	   QMP_NUM_NODES(QMP_global_m),
	   QMP_HOST(QMP_global_m));

  va_start (argp, format);
  status = vsprintf (buffer, format, argp);
  va_end (argp);

  printf ("%s %s", info, buffer);
  return status;
}


/**
 * Simple QMP specific fprintf type of routine
 */
int
QMP_fprintf (FILE* stream, const char* format, ...)
{
  va_list argp;
  int     status;
  char    info[128];
  char    buffer[1024];

  sprintf (info, "QMP m%d,n%d@%s : ", 
	   QMP_RANK(QMP_global_m),
	   QMP_NUM_NODES(QMP_global_m),
	   QMP_HOST(QMP_global_m));

  va_start (argp, format);
  status = vsprintf (buffer, format, argp);
  va_end (argp);

  fprintf (stream, "%s %s", info, buffer);
  fflush (stream);
  return status;
}


/**
 * Simple information display routine
 */
int
QMP_info (const char* format, ...)
{
  va_list argp;
  int     status;
  char    info[128];
  char    buffer[1024];

  sprintf (info, "QMP m%d,n%d@%s info : ", 
	   QMP_RANK(QMP_global_m),
	   QMP_NUM_NODES(QMP_global_m),
	   QMP_HOST(QMP_global_m));

  va_start (argp, format);
  status = vsprintf (buffer, format, argp);
  va_end (argp);

  fprintf (stderr, "%s %s", info, buffer);
  fflush (stderr);
  return status;
}


/**
 * Simple error display routine
 */
int
QMP_error (const char* format, ...)
{
  va_list argp;
  int     status;
  char    info[128];
  char    buffer[1024];

  sprintf (info, "QMP m%d,n%d@%s error : ", 
	   QMP_RANK(QMP_global_m),
	   QMP_NUM_NODES(QMP_global_m),
	   QMP_HOST(QMP_global_m));

  va_start (argp, format);
  status = vsprintf (buffer, format, argp);
  va_end (argp);

  fprintf (stderr, "%s %s", info, buffer);
  fflush (stderr);
  return status;
}

/**
 * Simple error display routine and exit
 */
void
QMP_error_exit (const char* format, ...)
{
  va_list argp;
  int     status;
  char    info[128];
  char    buffer[1024];


  sprintf (info, "QMP m%d,n%d@%s error : ", 
	   QMP_RANK(QMP_global_m),
	   QMP_NUM_NODES(QMP_global_m),
	   QMP_HOST(QMP_global_m));

  va_start (argp, format);
  status = vsprintf (buffer, format, argp);
  va_end (argp);

  fprintf (stderr, "%s %s", info, buffer);
  fflush (stderr);

  /* Shutdown gm and so on */
  QMP_finalize_msg_passing ();

  /* Just Quit */
  exit (1);
}

/**
 * QMP Fatal error: exit this thing.
 */
void
QMP_fatal (QMP_u32_t rank, const char* format, ...)
{
  va_list argp;
  int     status;
  char    info[128], hostname[256];
  char    buffer[1024];
  char*   host;

  /* get machine host name */
  host = getenv ("QMP_HOST");
  if (!host)
    gethostname (hostname, sizeof (hostname) - 1);
  else
    strncpy (hostname, host, sizeof (hostname) - 1);

  sprintf (info, "QMP rank = %d at host %s fatal: ", rank, hostname);

  va_start (argp, format);
  status = vsprintf (buffer, format, argp);
  va_end (argp);

  fprintf (stderr, "%s %s", info, buffer);
  fflush (stderr);

  /* Shutdown gm and so on */
  QMP_finalize_msg_passing ();

  /* Now quit */
  exit(1);
}


/**
 * Print out machine information.
 */
void
QMP_print_machine_info (QMP_machine_t* glm)
{
  int i;
  QMP_u32_t* size;
  QMP_u32_t* coord;
  QMP_gige_port_t* port;

  QMP_TRACE ("QMP_print_machine_info");

  if (!glm->inited) {
    fprintf (stderr, "this machine is not properly initialized yet.");
    return;
  }

  QMP_fprintf (stderr, "Machine information: \n");
  QMP_fprintf (stderr, "ncpu %d ic_type %d\n", glm->num_cpus, glm->ic_type);
  QMP_fprintf (stderr, "hostname %s\n", glm->host);

  QMP_print_rtenv (&glm->rtenv);

  QMP_fprintf (stderr, "dimension %d dimension size [", 
	       QMP_PHYS_DIMENSION(glm->phys));
  size = QMP_PHYS_DIMSIZE(glm->phys);
  for (i = 0; i < QMP_PHYS_DIMENSION(glm->phys); i++)
    fprintf (stderr, " %d", size[i]);
  fprintf (stderr, "]\n");

  QMP_fprintf (stderr, "coordinates [");
  coord = QMP_PHYS_COORDINATES(glm->phys);
  for (i = 0; i < QMP_PHYS_DIMENSION(glm->phys); i++)
    fprintf (stderr, " %d", coord[i]);
  fprintf (stderr, "]\n");

  QMP_fprintf (stderr, "Port information \n");
  for (i = 0; i < QMP_PHYS_DIMENSION(glm->phys); i++) {
    port = &(glm->phys->ports[i][0]);
    QMP_print_port_info (port);

    port = &(glm->phys->ports[i][1]);
    QMP_print_port_info (port);
  }

  QMP_fprintf (stderr, " Switched connection looks like: \n");
  for (i = 0; i < QMP_PHYS_NUMNODES(glm->phys); i++) {
    port = &glm->phys->switch_ports[i];
    QMP_print_port_info (port);
  }    
}

/**
 * Return an error string from a error code.
 */
const char*
QMP_error_string (QMP_status_t code)
{
  static char errstr[256];

  if (code == QMP_SUCCESS)
    return QMP_error_strings[code];

  if (code < QMP_MAX_STATUS && code >= QMP_ERROR)
    return QMP_error_strings[code - QMP_ERROR + 1];

  if (code <= VIP_NOT_REACHABLE && code >= VIP_NOT_DONE)
    return QMP_viastatus_error_strings[code - 1];

  if (code >= VIP_ERRCBK_CODE_OFFSET && code < QMP_ERROR)
    return QMP_viacallback_error_strings[code - VIP_ERRCBK_CODE_OFFSET];

  snprintf (errstr, sizeof (errstr) - 1, "unknown error code %d", code);
  return (const char *)&errstr;
}

/**
 * Return error string of last function call if there is an error.
 * If a function returns a status code, this function will not produce
 * any useful information. 
 *
 * This function should be used when no status
 * code is returned from a function call.
 */
const char*
QMP_get_error_string (QMP_msghandle_t mh)
{
  if (!mh)
    return QMP_error_string (QMP_global_m.err_code);
  else {
    QMP_msghandle_i_t* rmh;
    rmh = (QMP_msghandle_i_t *)mh;
    return QMP_error_string (rmh->errcode);
  }
}
/*
 * const QMP_status_t QMP_get_error_number (QMP_msghandle_t mh);
 * If the argument is null, returns a global error number from 
 * the last operation.
 */
QMP_status_t
QMP_get_error_number (QMP_msghandle_t mh)
{
  if (!mh)
    return QMP_global_m.err_code;
  else {
    QMP_msghandle_i_t* rmh;
    rmh = (QMP_msghandle_i_t *)mh;
    return rmh->errcode;
  }
}

/**************************************************************************
 *  QMP Debug and TRACING function                                        *
 **************************************************************************/
#ifdef _QMP_DEBUG
unsigned int qmp_debug_level = QMP_DBGLVL_RDMA;

void QMP_DUMP_IDATA_PACKET (QMP_idata_packet_t* p) 
{
  QMP_DEBUG(QMP_DBGLVL_IDATA,"IDataPacket op=%d num_qbufs=%d remote_qbufs=%d source=%d dest=%d tag=%d datalen=%d.\n",p->hdr.op,p->hdr.num_qbufs,p->hdr.remote_qbufs,p->hdr.source, p->hdr.dest,p->hdr.tag,p->idata.payload_len);
}

void QMP_DUMP_PACKET (QMP_packet_t* p)
{
  QMP_DEBUG(QMP_DBGLVL_PACKET,"Packet op=%d num_qbufs=%d remote_qbufs=%d source=%d dest=%d tag=%d \n",p->op,p->num_qbufs,p->remote_qbufs,p->source, p->dest,p->tag);
}

void QMP_DUMP_REQUEST (QMP_request_t* rq) 
{
  QMP_DEBUG(QMP_DBGLVL_REQUEST,"Request hdr: op=%d num_qbufs=%d remote_qbufs=%d source=%d dest=%d tag=%d Type=%d state=%d qbuf=0x%x port=%x count=%d datatype=%d Memory: addr=0x%x len=%d sid=%d rid=%d \n",rq->hdr.op, rq->hdr.num_qbufs,rq->hdr.remote_qbufs,rq->hdr.source,rq->hdr.dest,rq->hdr.tag, rq->type, rq->state,rq->qbuf, rq->port, rq->count, rq->datatype, rq->memory.address, rq->memory.len, rq->memory.sid, rq->memory.rid);
}

#endif

/**************************************************************************
 *  The following routines are related to general messages passing        *
 **************************************************************************/

static char* QMP_data_type_strs[] = {"unsigned char",
				     "char",
				     "byte",
				     "unsigned short",
				     "short",
				     "unsigned integer 32bit",
				     "integer 32bit",
				     "unsigned integer 64bit",
				     "integer 64bit",
				     "float",
				     "double"
};


/**************************************************************************
 *  The following code for simple topology manipulation                   *
 **************************************************************************/

/**
 * check whether array1 contains the array2
 * 
 * If array2 contains element of 1, the element does not count
 */
QMP_bool_t
QMP_array_contains (QMP_u32_t* array1, QMP_u32_t size1,
		    QMP_u32_t* array2, QMP_u32_t size2)
{
  int i, k, realsize, numchecked;
  QMP_u32_t* checked;

  QMP_TRACE ("QMP_array_equal");

  /* First create a checked array */
  checked = (QMP_u32_t *)malloc(size1 * sizeof (QMP_u32_t));
  if (!checked) {
    QMP_fprintf (stderr, "Cannot allocated memory for QMP_array_equal.\n");
    exit (1);
  }
  for (i = 0; i < size1; i++)
    checked[i] = 0;

  /* Find out rea size of array 2 excluding element = 1 */
  realsize = size2;
  for (i = 0; i < size2; i++) {
    if (array2[i] == 1)
      realsize--;
  }
    
  numchecked = 0;
  for (k = 0; k < size2; k++) {
    for (i = 0; i < size1; i++) {
      if (!checked[i] && array2[k] == array1[i]) {
	checked[i] = 1;
	numchecked++;
	break;
      }
    }
  }
  
  free (checked);

  if (numchecked == realsize) 
    return QMP_TRUE;
  
  return QMP_FALSE;
}

/**************************************************************************
 *  The following routines are releated to socket initialize code to QMP  *
 **************************************************************************/
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <netdb.h>

#define QMP_SOCKET_UNKNOWN     (QMP_u16_t)1000
#define QMP_SOCKET_START       (QMP_u16_t)1003
#define QMP_SOCKET_GO          (QMP_u16_t)1004
#define QMP_SOCKET_READY_QUIT  (QMP_u16_t)1005
#define QMP_SOCKET_QUIT        (QMP_u16_t)1006


#define QMP_MASTER_PORT    (QMP_u16_t)9873

/**
 * Total socket timeout value is 200 seconds
 */
#define QMP_ALRM_INTERVAL  5
#define QMP_NUM_ALRMS      40
#define QMP_CONN_TIMEOUT   200

typedef struct QMP_socket_msg_
{
  QMP_u16_t op;
  QMP_u16_t rank;
}QMP_socket_msg_t;

/**
 * Initialize socket and waiting for messages
 *
 * This routine is called by root node that is listening on a socket
 * to accept connection from all other nodes.
 *
 * These routines are called after the configuration is done
 */

/**
 * The following are used by root node
 */
static  int          mfd = 0;
static  QMP_u16_t*   recved_ranks = 0;
static  int*         connected_fds = 0;
static  int          alarm_loops = 0;

/**
 * This is used by the other nodes
 */
static  int          conn_fd = 0;

/**
 * Clean up routines for root and others
 */
static void
qmp_socket_cleanup_i (QMP_machine_t* glm)
{
  QMP_u16_t i, nbytes;
  QMP_socket_msg_t smsg;

  smsg.op = htons (QMP_SOCKET_QUIT);
  
  for (i = 0; i < QMP_RTENV_NUMNODES(glm->rtenv); i++) {
    if (connected_fds[i] != 0) {
      smsg.rank = htons (i);
      nbytes = write (connected_fds[i], &smsg, sizeof (smsg));
    }
  }
  sleep (5);
  
  for (i = 0; i < QMP_RTENV_NUMNODES(glm->rtenv); i++) {
    if (connected_fds[i] != 0) 
      close (connected_fds[i]);
  }
  
  free (recved_ranks);
  free (connected_fds);

  /* Get out here */
  exit (1);
}

/**
 * Alarm handlers for QMP initilization
 */
static void 
qmp_alarm_handler_i (int signal)
{
  int i, done;
  
  done = 1;
  for (i = 1; i < QMP_RTENV_NUMNODES(QMP_global_m.rtenv); i++) {
    if (recved_ranks[i] == 0) {
      done = 0;
      QMP_info ("\nWaiting for message from rank %d on host %s.\n",
		i, QMP_get_allocated_hostname (&QMP_global_m, i));
    }
  }
  
  alarm_loops++;
  if (alarm_loops >= QMP_NUM_ALRMS)
    qmp_socket_cleanup_i (&QMP_global_m);

  if (!done)
    alarm (QMP_ALRM_INTERVAL);
  else
    alarm (0);
}

/**
 * Check whether socket is done all connection
 */
static QMP_bool_t
qmp_socket_root_done_i (QMP_machine_t* glm)
{
  int i;

  for (i = 0; i < QMP_RTENV_NUMNODES(glm->rtenv); i++) {
    if (recved_ranks[i] == 0)
      return QMP_FALSE;
  }
  return QMP_TRUE;
}

/**
 * Initialize a root socket
 */
QMP_status_t
QMP_init_root_socket (QMP_machine_t* glm)
{
  QMP_u16_t    i, done, nbytes;
  int          cfd;
  QMP_socket_msg_t smsg;
  struct sockaddr_in netaddr;
  int sockaddr_len = sizeof(netaddr);
  int reuse, active;
  

  QMP_TRACE ("QMP_init_root_socket");

  /**
   * Frist create socket and rank arrays
   */
  recved_ranks = (QMP_u16_t *)malloc(QMP_RTENV_NUMNODES(glm->rtenv) * sizeof(QMP_u16_t));
  if (!recved_ranks) {
    QMP_error ("Cannot allocate memory for socket received rank array.\n");
    exit (1);
  }

  connected_fds = (int *)malloc(QMP_RTENV_NUMNODES(glm->rtenv) * sizeof(int));
  if (!connected_fds) {
    QMP_error ("Cannot allocate memory for socket connected fd array.\n");
    exit (1);
  }

  for (i = 0; i < QMP_RTENV_NUMNODES(glm->rtenv); i++) {
    if (i == 0)
      recved_ranks[i] = 1;
    else
      recved_ranks[i] = 0;
    connected_fds[i] = 0;
  }

  /* Create a listensing socket at port */
  mfd = socket (AF_INET, SOCK_STREAM, 0);
  if (mfd < 0) {
    QMP_error ("cannot create master socket. \n");
    perror ("Master socket");
    exit (1);
  }
  /* Set socket option of reuse address */
  reuse = 1;
  setsockopt (mfd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof (reuse));

  /* Set socket address */
  memset (&netaddr, 0, sizeof(netaddr));
  netaddr.sin_family = AF_INET;
  netaddr.sin_addr.s_addr = htonl(INADDR_ANY);
  netaddr.sin_port = htons(QMP_MASTER_PORT);
  if (bind (mfd, (struct sockaddr *)&netaddr, sizeof(netaddr)) < 0) {
    QMP_error ("cannot bind master socket.\n");
    perror ("bind");
    exit (1);
  }

  /* Listen for number of nodes */
  listen (mfd, QMP_RTENV_NUMNODES(glm->rtenv));
  
  done = 0;

  signal (SIGALRM, qmp_alarm_handler_i);
  alarm (QMP_ALRM_INTERVAL);

  while (!done) {
_qmp_accept_retry:
    sockaddr_len = sizeof (netaddr);
    cfd = accept (mfd, (struct sockaddr *)&netaddr, &sockaddr_len);
    if (cfd < 0) {
      if (errno == EINTR) goto _qmp_accept_retry;
      perror ("accept");
      qmp_socket_cleanup_i (glm);
      exit (1);
    }

    /* Set keep alive socket option on this newly connected socket */
    active = 1;
    setsockopt (cfd, SOL_SOCKET, SO_KEEPALIVE, &active, sizeof (active));    
    /* Now read rank information */
    nbytes = read (cfd, &smsg, sizeof (smsg));
    if (nbytes <= 0) {
      perror ("read");
      qmp_socket_cleanup_i (glm);
    }

    smsg.op = ntohs (smsg.op);
    smsg.rank = ntohs (smsg.rank);

    if (smsg.op != QMP_SOCKET_START) {
      QMP_error ("Received wrong qmp process message.\n");
      qmp_socket_cleanup_i (glm);
    }

    QMP_DEBUG (QMP_DBGLVL_INIT, "Received QMP %d from host %s.\n",
	       smsg.rank, QMP_get_allocated_hostname (glm, smsg.rank));
    
    /* Change a right index to 1 */
    connected_fds[smsg.rank] = cfd;
    recved_ranks[smsg.rank] = smsg.rank;

    if (qmp_socket_root_done_i (glm))
      done = 1;
  }

  /* disable alarm */
  alarm (0);

  QMP_DEBUG (QMP_DBGLVL_INIT, "Root have all messages, now let us go.\n");

  /* Now send message to all other processes */
  smsg.op = htons (QMP_SOCKET_GO);
  for (i = 1; i < QMP_RTENV_NUMNODES(glm->rtenv); i++) {
    smsg.rank = htons (i);

    nbytes = write (connected_fds[i], &smsg, sizeof (smsg));
    if (nbytes <= 0) {
      QMP_error ("cannot send message to rank %d on host %s.\n",
		 i, QMP_get_allocated_hostname (glm, smsg.rank));
    }
  }
  return QMP_SUCCESS;
}

/**
 * Finalize the socket the root node created
 */
void
QMP_finalize_root_socket (QMP_machine_t* glm)
{
  QMP_u16_t i;
  int       done, nbytes;
  QMP_socket_msg_t smsg;
  

  /* Clean out recved rank array */
  for (i = 0; i < QMP_RTENV_NUMNODES(glm->rtenv); i++) {
    if (i == 0)
      recved_ranks[i] = 1;
    else
      recved_ranks[i] = 0;
  }

  done = 0;

  signal (SIGALRM, qmp_alarm_handler_i);
  alarm (QMP_ALRM_INTERVAL);

  i = 0;
  while (!done) {
    if (connected_fds[i] != 0) {
      nbytes = read (connected_fds[i], &smsg, sizeof (smsg));
      if (nbytes <= 0) {
	QMP_error ("Read error from rank %d\n", i);
	perror ("Read error");
	qmp_socket_cleanup_i (glm);
      }
      smsg.op = ntohs (smsg.op);
      smsg.rank = ntohs (smsg.rank);

      if (smsg.op != QMP_SOCKET_READY_QUIT) {
	QMP_error ("Received a wrong qmp message.\n");
	qmp_socket_cleanup_i (glm);
      }
      QMP_DEBUG (QMP_DBGLVL_INIT, "Received QMP_READY_QUIT rank %d from host %s.\n",
		 smsg.rank, QMP_get_allocated_hostname (glm, smsg.rank));

      recved_ranks[smsg.rank] = smsg.rank;

      if (qmp_socket_root_done_i (glm))
	done = 1;
    }
    i++;
  }

  /* Disable Alarm */
  alarm (0);
  
  QMP_DEBUG (QMP_DBGLVL_INIT, "Root have all messages, now let us all exit.\n");

  /* Now send message to all other processes */
  smsg.op = htons (QMP_SOCKET_QUIT);
  for (i = 1; i < QMP_RTENV_NUMNODES(glm->rtenv); i++) {
    smsg.rank = htons (i);

    nbytes = write (connected_fds[i], &smsg, sizeof (smsg));
    if (nbytes <= 0) {
      QMP_error ("cannot send message to rank %d on host %s.\n",
		 i, QMP_get_allocated_hostname (glm, smsg.rank));
    }
  }

  /**
   * Close all connected socket
   */
  for (i = 0; i < QMP_RTENV_NUMNODES(glm->rtenv); i++) {
    if (connected_fds[i] != 0) 
      close (connected_fds[i]);
  }

  /**
   * Close master socket
   */
  close (mfd);

  free (recved_ranks);
  free (connected_fds);
}


QMP_status_t
QMP_init_socket (QMP_machine_t* glm)
{
  QMP_u16_t    i, nbytes;
  char*        roothost;
  QMP_socket_msg_t smsg;
  struct sockaddr_in sockaddr;
  struct hostent*    het;

  QMP_TRACE ("QMP_init_socket");

  /* Get root rank host name */
  roothost = QMP_get_allocated_hostname (glm, 0);
  
  /* Get information for the root host */
  het = gethostbyname (roothost);
  if (!het) {
    QMP_error ("Cannot get host information for root node %s. \n", roothost);
    exit (1);
  }
  
  /* Set socket address information */
  memset (&sockaddr, 0, sizeof (sockaddr));
  sockaddr.sin_family = AF_INET;
  sockaddr.sin_port = htons (QMP_MASTER_PORT);
  memcpy (&sockaddr.sin_addr, het->h_addr, het->h_length);

  /* Create a socket */
  conn_fd = socket (AF_INET, SOCK_STREAM, 0);

  if (!conn_fd) {
    QMP_error ("Cannot a socket to root node %s.\n", roothost);
    exit (1);
  }

  i = 0;
  while (i < QMP_CONN_TIMEOUT) {
    if (connect(conn_fd, (const struct sockaddr *)&sockaddr, 
		sizeof(sockaddr))==0)
      break;
    sleep (1);
    i++;
  }
  
  QMP_DEBUG (QMP_DBGLVL_INIT, "Connected to root host %s.\n", roothost);

  /* Send message to root */
  smsg.op = htons (QMP_SOCKET_START);
  smsg.rank = htons (glm->phys->my_node.rank);

  nbytes = write (conn_fd, &smsg, sizeof (smsg));
  if (nbytes <= 0) {
    QMP_error ("Cannot write socket.\n");
    close (conn_fd);
    exit (1);
  }

  /* Now waiting for message back from the root */
  nbytes = read (conn_fd, &smsg, sizeof (smsg));
  if (nbytes <= 0) {
    QMP_error ("Cannot receive from the root.\n");
    close (conn_fd);
    exit (1);
  }

  smsg.op = ntohs (smsg.op);
  smsg.rank = ntohs (smsg.rank);

  /* This is a wrong message */
  if (smsg.rank != glm->phys->my_node.rank) {
    QMP_error ("Received wrong message from root.\n");
    close (conn_fd);
    exit (1);
  }
  else {
    if (smsg.op == QMP_SOCKET_QUIT) {
      QMP_info ("I am quiting because the root asked me to do.\n");
      exit (1);
    }
  }

  QMP_DEBUG (QMP_DBGLVL_INIT, "All processes are going now.\n");
  return QMP_SUCCESS;
}


/**
 * Finalize socket created by the nodes other than the root
 */
void
QMP_finalize_socket (QMP_machine_t* glm)
{
  QMP_u16_t    nbytes;
  QMP_socket_msg_t smsg;

  QMP_TRACE ("QMP_finalize_socket");

  /* Send message to root */
  smsg.op = htons (QMP_SOCKET_READY_QUIT);
  smsg.rank = htons (glm->phys->my_node.rank);

  nbytes = write (conn_fd, &smsg, sizeof (smsg));
  if (nbytes <= 0) {
    QMP_error ("Cannot write socket.\n");
    close (conn_fd);
    exit (1);
  }

  /* Now waiting for message back from the root */
  nbytes = read (conn_fd, &smsg, sizeof (smsg));
  if (nbytes <= 0) {
    QMP_error ("Cannot receive from the root.\n");
    close (conn_fd);
    exit (1);
  }

  smsg.op = ntohs (smsg.op);
  smsg.rank = ntohs (smsg.rank);

  /* This is a wrong message */
  if (smsg.rank != glm->phys->my_node.rank) {
    QMP_error ("Received wrong message rank id from root.\n");
    close (conn_fd);
    exit (1);
  }

  if (smsg.op != QMP_SOCKET_QUIT) {
    QMP_error ("Received wrong message type from root.\n");
    close (conn_fd);
    exit (1);
  }

  QMP_DEBUG (QMP_DBGLVL_INIT, "I am exiting now.\n");

  close (conn_fd);
}


/*******************************************************************
 *           Some of QMP 2.0 I/O utility                           *
 ******************************************************************/

/**
 * For partitioned I/O, nodes are partitioned into subsets.  Each
 * subset includes a designated I/O node.  This function maps a node
 * to its I/O node.
 *
 * QMP GigE: everynode can do I/O
 */
int
QMP_io_node (int node)
{
  return node;
}

/**
 * For binary file I/O we designate a master I/O node for the entire
 * machine.  This function defines it 
 *
 */
int
QMP_master_io_node(void)
{
  return 0;
}


