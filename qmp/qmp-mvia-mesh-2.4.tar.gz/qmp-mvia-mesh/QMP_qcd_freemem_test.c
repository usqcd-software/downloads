/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Simple LQCD Style Communication Test with free/alloc memories
 *
 * Author:  
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_qcd_freemem_test.c,v $
 *   Revision 1.3  2004/11/01 20:34:39  chen
 *   Change QMP_declare_multiple to conform to 2.0 spec
 *
 *   Revision 1.2  2004/10/08 19:59:29  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.1  2004/02/13 20:09:39  chen
 *   Add a test and utility program
 *
 *
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include <qmp.h>

typedef struct prog_arg_
{
  int loops;
  int verify;
}prog_arg_t;


/* This is the memory size for 4x4x4x4: SIZE = 48XPHASE SIZE */

#define Nd 4
#define Nc 3
#define Ns 4
#define Ns2 2


/* Nearest neighbor communication channels */
static int total_comm = 0;
static QMP_mem_t*  forw_qmem[Nd][2];
static QMP_mem_t*  back_qmem[Nd][2];
static int* forw_mem[Nd][2];
static int* back_mem[Nd][2];

static QMP_msgmem_t forw_msg[Nd][2];
static QMP_msgmem_t back_msg[Nd][2];
static QMP_msghandle_t forw_mh[Nd][2];
static QMP_msghandle_t back_mh[Nd][2];
static QMP_msghandle_t forw_all_mh;
static QMP_msghandle_t back_all_mh;
static int num = 0;
static int verify = 0;

/* Set value for all sending data */
static void set_send_data (int step)
{
  int i, k, mu, num;
  unsigned int *mycoord;
  int left[Nd], right[Nd];
  unsigned int leftnode, rightnode;
  unsigned int num_dim = QMP_get_logical_number_of_dimensions();
  const unsigned int *subgrid_size = QMP_get_subgrid_dimensions();
  const unsigned int *size = QMP_get_logical_dimensions();
  unsigned int msgsize;

  /* First get my logical coordinates */
  mycoord = QMP_get_logical_coordinates ();

  num = 0;
  for (mu = 0; mu < num_dim; ++mu) {
    if (size[mu] > 1) {
      msgsize = 1;
      for (i = 0; i < Nd; i++) {
	if (i != mu)
	  msgsize *= subgrid_size[i];
      }
      msgsize *= 48;

      for (i = 0; i < num_dim; i++) {
	left[i] = right[i] = mycoord[i];
      }
      /* Get left neightbor */
      left[mu] = (left[mu] - 1);
      if (left[mu] < 0)
	left[mu] = size[mu] - 1;
      if (left[mu] >= size[mu])
	left[mu] = 0;

      leftnode = QMP_get_node_number_from (left);

      /* Get Right neighbour */
      right[mu] = (right[mu] + 1);
      if (right[mu] < 0)
	right[mu] = size[mu] - 1;
      if (right[mu] >= size[mu])
	right[mu] = 0;

      rightnode = QMP_get_node_number_from (right);

      /* forw_mem[num][0] is sent to -1 mu direction, left */
      /* back_mem[num][0] is sent to +1 mu direction, right */
      for (k = 0; k < msgsize / 4; k++) {
	forw_mem[num][0][k] = step + leftnode * leftnode + k;
	back_mem[num][0][k] = step + rightnode * rightnode - k;
      }
      num++;
    }
  }

}


/* Check values for all recving data */
static void check_recved_data (int step)
{
  int i, k, mu, num;
  unsigned int *mycoord, myrank;
  unsigned int num_dim = QMP_get_logical_number_of_dimensions();
  const unsigned int *subgrid_size = QMP_get_subgrid_dimensions();
  const unsigned int *size = QMP_get_logical_dimensions();
  unsigned int msgsize;
  myrank = QMP_get_node_number ();

  /* First get my logical coordinates */
  mycoord = QMP_get_logical_coordinates ();

  num = 0;
  for (mu = 0; mu < num_dim; ++mu) {
    if (size[mu] > 1) {
      msgsize = 1;
      for (i = 0; i < Nd; i++) {
	if (i != mu)
	  msgsize *= subgrid_size[i];
      }
      msgsize *= 48;

      for (k = 0; k < msgsize / 4; k++) {
	if (forw_mem[num][1][k] != step + myrank * myrank + k) {
	  QMP_fprintf (stderr, "Receving error for forward communication.\n");
	  break;
	}
	
	if (back_mem[num][1][k] != step + myrank * myrank - k) {
	  QMP_fprintf (stderr, "Receving error for backward communication.\n");
	  break;
	}
      }
      num++;
    }
  }
}
      
      

void init_wnxtsu3dslash(void)
{
  int mu, i;
  const unsigned int *size = QMP_get_logical_dimensions();
  const unsigned int *subgrid_size = QMP_get_subgrid_dimensions();
  unsigned int num_dim = QMP_get_logical_number_of_dimensions();
  unsigned int msgsize;

  /* Loop over all communicating directions and build up the two message
   * handles. If there is no communications, the message handles will not
   * be initialized 
   */
  num = 0;
  
  for(mu=0; mu < num_dim; ++mu) {
    if(size[mu] > 1) {
      msgsize = 1;
      for (i = 0; i < Nd; i++) {
	if (i != mu)
	  msgsize *= subgrid_size[i];
      }
      msgsize *= 48;
      if (QMP_is_primary_node()) 
	QMP_fprintf (stderr, "Surface[%d] = %d\n", mu, msgsize);

      forw_qmem[num][0] = QMP_allocate_aligned_memory (msgsize*sizeof(char),
						       sizeof(int), 0);
      forw_qmem[num][1] = QMP_allocate_aligned_memory (msgsize*sizeof(char),
						       sizeof(int), 0);

      forw_mem[num][0] = QMP_get_memory_pointer (forw_qmem[num][0]);
      forw_mem[num][1] = QMP_get_memory_pointer (forw_qmem[num][1]);

      forw_msg[num][0] = QMP_declare_msgmem(forw_mem[num][0], msgsize);
      forw_msg[num][1] = QMP_declare_msgmem(forw_mem[num][1], msgsize);
      
      forw_mh[num][0]  = QMP_declare_receive_relative(forw_msg[num][1], mu, +1, 0);
      forw_mh[num][1]  = QMP_declare_send_relative(forw_msg[num][0], mu, -1, 0);
      

      back_qmem[num][0] = QMP_allocate_aligned_memory(msgsize*sizeof(char),
						      sizeof(int), 0);
      back_qmem[num][1] = QMP_allocate_aligned_memory(msgsize*sizeof(char),
						      sizeof(int), 0);

      back_mem[num][0] = QMP_get_memory_pointer (back_qmem[num][0]);
      back_mem[num][1] = QMP_get_memory_pointer (back_qmem[num][1]);

      back_msg[num][0] = QMP_declare_msgmem(back_mem[num][0], msgsize);
      back_msg[num][1] = QMP_declare_msgmem(back_mem[num][1], msgsize);

      back_mh[num][0]  = QMP_declare_receive_relative(back_msg[num][1], mu, -1, 0); 
      back_mh[num][1]  = QMP_declare_send_relative(back_msg[num][0], mu, +1, 0);
      num++;
    }
  }

  if (num > 0)
  {
    forw_all_mh = QMP_declare_multiple(&(forw_mh[0][0]), 2*num);
    back_all_mh = QMP_declare_multiple(&(back_mh[0][0]), 2*num); 
  }

  total_comm = num;
}


void free_wnxtsu3dslash(void)
{
  int i;
  const unsigned int *machine_size = QMP_get_logical_dimensions();

  if (total_comm > 0) {
    
    QMP_free_msghandle(forw_all_mh);
    QMP_free_msghandle(back_all_mh);

    /* No need to delete individual handle */
  }

  /* Free space */
  for (i = 0; i < total_comm; i++) {
    QMP_free_memory(forw_qmem[i][0]);
    QMP_free_memory(forw_qmem[i][1]);

    QMP_free_memory(back_qmem[i][0]);
    QMP_free_memory(back_qmem[i][1]);
  }
    
  total_comm = 0;
}

int main (int argc, char** argv)
{
  int i, k, loops;
  QMP_status_t err, status;
  prog_arg_t pargs;
  unsigned int ilogic_dims[]={1, 1, 4, 16};
  /* unsigned int layout[]={16, 16, 16, 64}; */
  unsigned int layout[]={16, 16, 16, 64};
  unsigned int num_dims = Nd;
  QMP_thread_level_t th_level;

  status = QMP_init_msg_passing (&argc, &argv, 
				 QMP_THREAD_MULTIPLE, &th_level);

  if (status != QMP_SUCCESS) {
    QMP_error ("QMP_init failed: %s\n", QMP_error_string(status));
    exit (1);
  }

  /* QMP_declare_logical_topology (ilogic_dims, 4); */

  QMP_layout_grid (layout, num_dims); 

  if (QMP_is_primary_node()) {
    fprintf (stderr, "Input numberloops verify or not.\n");
    scanf ("%d %d", &pargs.loops, &pargs.verify);
  }
  QMP_broadcast (&pargs, sizeof (pargs));

  loops = pargs.loops;
  verify = pargs.verify;

  QMP_fprintf (stderr, "Run loops = %d verify = %d.\n", loops, verify);

  for (k = 0; k < 12; k++) {
    init_wnxtsu3dslash();

    for (i = 0; i < loops; i++) {

      if (verify)
	set_send_data (i);

      if ((err = QMP_start (forw_all_mh))!= QMP_SUCCESS)
	QMP_printf ("Start forward operations failed: %s\n", 
		    QMP_error_string(err));

      if (QMP_wait (forw_all_mh) != QMP_SUCCESS)
	QMP_printf ("Error in sending %d\n", i);

    
      if ((err = QMP_start (back_all_mh)) != QMP_SUCCESS)
	QMP_printf ("Start backward failed: %s\n", QMP_error_string(err));


      if (QMP_wait (back_all_mh) != QMP_SUCCESS)
	QMP_printf ("Error in wait receiving %d\n", i);

      if (verify)
	check_recved_data (i);
    }

    free_wnxtsu3dslash(); 
  }


  QMP_finalize_msg_passing ();

  return 0;
}

