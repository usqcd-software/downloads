/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      MVIA Link Level Test Server Code on Individual Node
 *
 * Author:
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: mvia_link.h,v $
 *   Revision 1.1.1.1  2005/09/06 15:44:54  chen
 *   mvia link test package
 *
 *
 */
#ifndef _MVIA_LINK_SERVER_H
#define _MVIA_LINK_SERVER_H

/**
 * Server port : each server listens on this port for connection
 * Potential connections: one from interactive node, upto 7 from 
 * nearst neighbors
 */
#define ML_S_PORT (unsigned short)9331

/**
 * Number of milli-seconds we allow the mvia test child process 
 * to live. If this time period is exceeded, we kill the process
 */
#define ML_MAX_TIME 10000

/**
 * Maximum ethernet device name len
 */
#define ML_ETHDEV_NAME_LEN 32

/**
 * Maximum length of hostname
 */
#define ML_HOSTNAME_LEN 128




#define ML_CHECK_LINK_START         1000
#define ML_CHECK_LINK_DONE          1001
#define ML_CHECK_LINK_IN_PROG       1002
#define ML_CHECK_SINGLE_LINK        1010
#define ML_CHECK_SINGLE_LINK_READY  1011
#define ML_CHECK_SINGLE_LINK_FAILED 1012

#define ML_CHECK_STATS              1020
#define ML_CHECK_STATS_PROG         1021
#define ML_CHECK_STATS_DONE         1022

#define ML_SET_LINK_SPEED           1030
#define ML_SET_LINK_SPEED_PROG      1031
#define ML_SET_LINK_SPEED_DONE      1032

#define ML_RELOAD_CONF              1040

/**
 * Maximum number of physical dimension
 */
#define ML_ND 6


/**
 * Gigabit Ethernet Link Information
 */
typedef struct ml_gige_
{
  /* Link ethernet device                                 */
  char eth_device[ML_ETHDEV_NAME_LEN];

  /* Direction and axis of this link                      */
  /* +1 positive direction, -1 negative direction         */
  int  direction;
  int  axis;

  /* The other end via host name                          */
  char peer_via_host[ML_HOSTNAME_LEN];

  /* The other end machine name                           */
  char peer_host[ML_HOSTNAME_LEN];

  /* reliable connection or not                           */
  int reliable;

  /* this link test status: 0, ok, 1 bad, 2 no server repsponding 
     -1 not done     */
  int test_code;
  
  /* this link test send code child process id            */
  pid_t s_child;

  /* timestamp of s_child creation                        */
  double   s_child_ct;

  /* this link test recv code child process id            */
  pid_t r_child;

  /* timestamp of r_child creation                        */
  double   r_child_ct;

}ml_gige_t;

/**
 * Node information
 */
typedef struct ml_node_
{
  /* my coordinates inside the torus                      */
  unsigned int coordinates[ML_ND];

  /* host name of my node                                 */
  char         host[ML_HOSTNAME_LEN];

}ml_node_t;

/**
 * Physical torus geometry viewed by each server
 */
typedef struct ml_torus_
{
  /* Total number of nodes participating the system       */
  unsigned int num_nodes;

  /* dimension of geoemtry                                */
  unsigned int dimension;

  /* size of this geometry                                */
  unsigned int size[ML_ND];

  /* node information                                     */
  ml_node_t    mynode;

  /* all my neighbors gige connections                    */
  ml_gige_t    links[ML_ND][2];

  /* Client connection socket file descriptor             */
  /* If this file descriptor is -1, this means not client */
  /* has asked to do any link test yet                    */
  int          test_fd;

  /* timeout value for server to check                    */
  struct timeval *tv;

}ml_torus_t;

/**
 * Event handling function
 */
typedef struct _ml_client_table_ ml_client_table_t;
typedef struct _ml_client_info_  ml_client_info_t;

typedef int (*ml_event_handler_t) (ml_torus_t* torus,
				   ml_client_info_t* conn,
				   ml_client_table_t* table,
				   int cfd,
				   void* arg);

/**
 * Timer handling function
 */
typedef int (*ml_timer_handler_t) (ml_torus_t* torus, 
				   ml_client_table_t* table,
				   double *next_time_to_fire,
				   void* arg);
				 

/**
 * Connect client information
 */
struct _ml_client_info_
{
  /* Connected fd                                       */
  int cfd;

  /* host name of the client                            */
  char host[ML_HOSTNAME_LEN];

  /* port of the client                                 */
  unsigned short port;

  /* Event handler */
  ml_event_handler_t event_handler;
  void* arg;

  /* pointer to the next one                            */
  struct _ml_client_info_ *next;
};

/**
 * Timer handlers for the server
 */
typedef struct _ml_timer_
{
  /* Next time to fire the routine in milliseconds     */
  double              time_to_fire;

  /* handler function                                  */
  ml_timer_handler_t timer_handler;
  void* arg;

  /* pointer to the next one                           */
  struct _ml_timer_ *next;

}ml_timer_t;


/**
 * Server socket decriptor table
 */
struct _ml_client_table_
{
  /*     Listening file descriptor                      */
  int  lfd;

  /*     master file descriptor table                   */
  fd_set* mfdset;

  /*     Set of connection socket file descriptors      */
  int  num_clients;

  /*     all connected sockets                          */
  ml_client_info_t* clients;

  /*     all timer handlers                             */
  ml_timer_t*       timers;
};


#define ML_MAGIC (unsigned short)0xcebf

/**
 * Protocol
 */
typedef struct _ml_data_
{
  /* magic number                        */
  unsigned short magic;
  /* op code                             */
  unsigned short op;

  /* check connection direction and axis */
  int            axis;
  int            direction;

  /* operation status                    */
  int            status;
  
  /* everything else is string           */
  unsigned int   buflen;
  char*          buffer;

}ml_data_t;

#define ML_DATA_SIZE (sizeof(ml_data_t) - sizeof(char *))

/**
 * Network functions 
 */
extern void ml_printf (const char* format, ...);
extern int ml_add_event_handler (ml_client_table_t* table,
				 int cfd, char* host, unsigned short port,
				 ml_event_handler_t handler, void* arg);

extern double ml_current_time (void);

extern int ml_remove_event_handler (ml_client_table_t* table, int cfd);
extern int ml_tcp_listen (unsigned short port);
extern int ml_tcp_connect (const char* host, unsigned short port);
extern int ml_check_recvdata (ml_data_t* data);
extern int ml_get_inet_info (struct sockaddr_in* addr,
			     char host[], int hostlen,
			     unsigned short* port);
extern int ml_read_nbytes (int fd, char* buffer, int nbytes);
extern int ml_write_data (int fd, unsigned short op, int status, 
			  int axis, int direction, int buflen, char *buf);

extern int ml_handle_socket_event (ml_torus_t* torus,
				   ml_client_info_t* client,
				   ml_client_table_t* client_table,
				   int cfd,
				   void* arg);

extern int ml_poll (ml_torus_t* torus, ml_client_table_t* table);

extern ml_data_t *ml_dup_data (ml_data_t* data);
extern void ml_free_data (ml_data_t *data);

extern int ml_reload_conf_file (char* filename, ml_torus_t* torus);

extern int  ml_daemonize (void);
extern void dump_torus_info (ml_torus_t* t);

#ifdef DMALLOC
#include <dmalloc.h>
#endif

#endif
