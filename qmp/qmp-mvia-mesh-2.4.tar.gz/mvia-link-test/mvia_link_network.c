/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      MVIA Link Level Test Server Network Part of Code
 *
 * Author:
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: mvia_link_network.c,v $
 *   Revision 1.1.1.1  2005/09/06 15:44:54  chen
 *   mvia link test package
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#include <sys/select.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/uio.h>
#include <fcntl.h>

#include "mvia_link.h"

#define ML_LISTEN_Q_LEN 1024

/**
 * Create a TCP Listening Socket on the host calling this routine
 *
 * return TCP socket descriptor
 */
int
ml_tcp_listen (unsigned short port)
{
  int sockfd;
  const int on = 1;
  struct sockaddr_in sin;
  int len = sizeof (sin);

  /* First create a socket */
  sockfd = socket (PF_INET, SOCK_STREAM, IPPROTO_IP);

  if (!sockfd)
    return sockfd;

  /* Set socket option to reuse address */
  setsockopt (sockfd, SOL_SOCKET, SO_REUSEADDR,
	      &on, sizeof(on));


  /* Now bind this socket to a port specified */
  memset (&sin, 0, sizeof(sin));
  sin.sin_family = AF_INET;
  sin.sin_addr.s_addr = INADDR_ANY;

  sin.sin_port = htons (port);

  /* Now calling bind */
  if (bind (sockfd, (struct sockaddr *)&sin, len) != 0) {
    close (sockfd);
    return 0;
  }


  /* Now make this socket listen on this port */
  listen (sockfd, ML_LISTEN_Q_LEN);
    
  return sockfd;
}


/**
 * Connect to remote host server using a port 
 */
int
ml_tcp_connect (const char* host, unsigned short port)
{
  int sockfd;
  struct sockaddr_in svraddr;
  struct hostent* svent;

  /* Get inet address information of the host */
  svent = gethostbyname (host);
  if (!svent) {
    fprintf (stderr, "Cannot get host %s information .\n", host);
    return -1;
  }

  /* Set up remote host socket address information */
  memset (&svraddr, 0, sizeof (struct sockaddr_in));
  svraddr.sin_family = AF_INET;
  svraddr.sin_port = htons (port);
  memcpy (&svraddr.sin_addr, svent->h_addr, svent->h_length);

  /* Create a socket */
  sockfd = socket (AF_INET, SOCK_STREAM, 0);

  if (!sockfd) {
    fprintf (stderr, "Cannot create a TCP socket .\n");
    return -1;
  }
  
  if (connect (sockfd, (const struct sockaddr *)&svraddr,
	       sizeof (svraddr)) != 0) {
      fprintf (stderr, "Cannot connect to remote host %s on port %d\n",
	       host, port);
      close (sockfd);
      return -1;
  }
  
  return sockfd;
}


/**
 * Return network address information
 */
int
ml_get_inet_info (struct sockaddr_in* addr, 
		  char host[], int hostlen,
		  unsigned short* port)
{
  struct hostent *hp;
  int alen = sizeof (addr->sin_addr.s_addr);

#if 1
  hp = gethostbyaddr ((char *)(&(addr->sin_addr.s_addr)), alen, AF_INET);
  if (!hp) {
    fprintf (stderr, "Cannot do gethostbyaddr errno = %d\n", errno);
    return -1;
  }
  else {
    strncpy (host, hp->h_name, hostlen - 1);
    *port = ntohs (addr->sin_port);
  }
#endif

#if 0
  strcpy (host, inet_ntoa (addr->sin_addr));
#endif

  return 0;
}


/**
 * Write ml_data_t to a socket
 */
int
ml_write_data (int fd, unsigned short op, int status, 
	       int axis, int direction, int buflen, char *buf)
{
  ml_data_t data;
  int nbytes, numvec;
  struct iovec wvec[2];

  data.magic = htons (ML_MAGIC);
  data.op = htons (op);
  data.axis = htonl (axis);
  data.direction = htonl (direction);
  data.status = htonl (status);
  if (buflen)
    data.buflen = htonl (buflen);
  else
    data.buflen = htonl (0);

  numvec = 1;
  wvec[0].iov_base = (void *)&data;
  wvec[0].iov_len = ML_DATA_SIZE;
  if (buflen) {
    wvec[1].iov_base = (void *)buf;
    wvec[1].iov_len = buflen;
    numvec = 2;
  }
  nbytes = writev (fd, wvec, numvec);
  return nbytes;
}

/**
 * Check whether we received what we expected
 */
int
ml_check_recvdata (ml_data_t* data)
{
  data->magic = ntohs (data->magic);
  data->op = ntohs (data->op);
  data->axis = ntohl (data->axis);
  data->direction = ntohl (data->direction);
  data->status = ntohl (data->status);
  data->buflen = ntohl (data->buflen);
  data->buffer = 0;

  if (data->magic != ML_MAGIC)
    return -1;

  return 0;
}

/**
 * Read untill finish reading nbytes of data
 * return -1: if error
 * return nbytes
 */
int
ml_read_nbytes (int fd, char* buffer, int nbytes)
{
  int totalbytes = 0;
  int bytesread;

  while (nbytes > 0) {
    bytesread = read (fd, (void *)&(buffer[totalbytes]), nbytes);
    if (bytesread <= 0)
      return -1;
    totalbytes += bytesread;
    nbytes -= totalbytes;
  }
  return totalbytes;
}


/**
 * Duplicate a ml_data_t
 */
ml_data_t *
ml_dup_data (ml_data_t* data)
{
  ml_data_t* ret;

  ret = (ml_data_t *)malloc(sizeof(ml_data_t));
  if (!ret)
    return 0;

  ret->magic = data->magic;
  ret->op = data->op;
  ret->axis = data->axis;
  ret->direction = data->direction;
  ret->status = data->status;
  ret->buflen = data->buflen;
  ret->buffer = 0;

  if (ret->buflen) {
    ret->buffer = (char *)malloc(ret->buflen * sizeof(char));
    if (!ret->buffer) {
      free (ret);
      return 0;
    }
    memcpy (ret->buffer, data->buffer, ret->buflen);
  }

  return ret;
}


void
ml_free_data (ml_data_t *data)
{
  if (data->buflen)
    free (data->buffer);

  free (data);
}


/**
 * Daemonize a process into a server
 */
int
ml_daemonize (void)
{
  /* First change working directory */
  if (chdir ("/") != 0)
    exit (1);

  /* Fork a child process */
  if (fork() != 0) 
    return 0;
  else {
    /* Set this a session leader */
    setsid ();

    /* clear umask value */
    umask (0);
    
    close (0);
    close (1);
    close (2);

    open ("/dev/null", O_RDWR);
    
    dup (0);
    dup (1);
    dup (2);

    return 1;
  }
}
