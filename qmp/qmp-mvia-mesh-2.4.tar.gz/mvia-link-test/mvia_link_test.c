/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      MVIA Link Level Test Point-to-point connection
 *
 * Author:
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: mvia_link_test.c,v $
 *   Revision 1.1.1.1  2005/09/06 15:44:54  chen
 *   mvia link test package
 *
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <sys/time.h>
#include <malloc.h>
#include <signal.h>

#include <assert.h>

#include <vipl.h>

#define ML_BUF_SIZE 128
#define ML_LOOPS 500

/* This process only lives for 10  seconds */
#define ML_TIME_TO_LIVE 10

/**
 * Global flag to tell whether via device is created
 */
static int ml_via_inited = 0;
static VIP_VI_HANDLE lvi;


/**
 * Signal handling routine
 */
static int ml_signals[]={SIGINT, SIGTERM, SIGALRM};
static int ml_num_signals = 3;

static void
ml_signal_func (int signo)
{
  if (ml_via_inited)
    VipDestroyVi (lvi);
  else
    exit (1);
}

static void
ml_register_signal_handler (void)
{
  int i;
  struct sigaction act, oact;
  
  act.sa_handler = ml_signal_func;
  sigemptyset (&act.sa_mask);
  act.sa_flags = 0;

#ifdef SA_RESTART
  act.sa_flags |= SA_RESTART;
#endif

  for (i = 0; i < ml_num_signals; i++) {
    if (sigaction (ml_signals[i], &act, &oact) < 0)
      break;
  }
}

/**
 * Malloc aligned memory
 */
static char *
ml_amalloc(int size, int align)
{
  return (char *)memalign (align, size);
}


/**
 * Print out usage information
 */
static void
ml_usage (int argc, char** argv)
{
  fprintf (stderr, "Usage: %s via_dev r|s via_host\n", argv[0]);
}

int 
main (int argc, char** argv)
{
  char via_dev[32], via_host[32];
  int  send, size, i;
  VIP_CONN_HANDLE ch;
  VIP_NET_ADDRESS *local, *remote;
  VIP_NIC_HANDLE  nic;
  VIP_NIC_ATTRIBUTES nic_attr;
  VIP_VI_ATTRIBUTES lvi_attr, rvi_attr;
  VIP_MEM_ATTRIBUTES mem_attr;
  VIP_MEM_HANDLE desch, buffh;
  VIP_PROTECTION_HANDLE ptag;
  VIP_DESCRIPTOR *descp, *desc;
  VIP_RETURN status;
  char *buffer, *sendbuf, *recvbuf;
  
  if (argc < 4) {
    ml_usage (argc, argv);
    return -1;
  }

  send = 1;
  strncpy (via_dev, argv[1], sizeof(via_dev) - 1);
  strncpy (via_host, argv[3], sizeof(via_host) - 1);
  if (strcasecmp (argv[2], "r") == 0)
    send = 0;
  else if (strcasecmp (argv[2], "s") == 0)
    send = 1;
  else {
    ml_usage (argc, argv);
    return -1;
  }

  /* signal handler */
  ml_register_signal_handler ();

  /* First open local nic device */
  if (VipOpenNic (via_dev, &nic) != VIP_SUCCESS) {
    fprintf (stderr, "Failed to open via device %s \n", via_dev);
    return -1;
  }

  /* Check Via Name service      */
  if (VipNSInit (nic, 0) != VIP_SUCCESS) {
    fprintf (stderr, "Failed to initialize via name service. \n");
    return -1;
  }

  /* Query NIC attributes */
  if (VipQueryNic (nic, &nic_attr) != VIP_SUCCESS) {
    fprintf (stderr, "Failed to query via device %s \n", via_dev);
    return -1;
  }
  
  /* Set up simple local and remote addresses */
  local = (VIP_NET_ADDRESS *)malloc(sizeof (VIP_NET_ADDRESS) + 
				    nic_attr.NicAddressLen);
  if (!local) {
    fprintf (stderr, "Cannot allocate space for local address \n");
    return -1;
  }
  local->HostAddressLen = nic_attr.NicAddressLen;
  local->DiscriminatorLen = 0;
  memcpy (local->HostAddress,
	  nic_attr.LocalNicAddress, nic_attr.NicAddressLen);

  remote = (VIP_NET_ADDRESS *)malloc(sizeof (VIP_NET_ADDRESS) +
				     nic_attr.NicAddressLen);
  if (!remote) {
    fprintf (stderr, "Cannot allocate space for remote address.\n");
    free (local);
    return -1;
  }
  memset (remote, 0, sizeof (VIP_NET_ADDRESS));
  remote->HostAddressLen = nic_attr.NicAddressLen;
  remote->DiscriminatorLen = 0;

  /* Set up remote host information */
  if (VipNSGetHostByName (nic, via_host, remote, 0) != VIP_SUCCESS) {
    fprintf (stderr, "Cannot resolve host information for %s \n",
	     via_host);
    free (local);
    free (remote);
    return -1;
  }

  /* Allocate descriptors */
  desc = (VIP_DESCRIPTOR *)ml_amalloc (2*sizeof(VIP_DESCRIPTOR),
				       VIP_DESCRIPTOR_ALIGNMENT);
  if (!desc) {
    fprintf (stderr, "Cannot allocate memory for via descriptors \n");
    free (local); free (remote);
    return -1;
  }

  /* allocate send and recv buffers */
  size = ML_BUF_SIZE;
  buffer = (char *)ml_amalloc (2 * ML_BUF_SIZE, 4096);
  if (!buffer) {
    fprintf (stderr, "Cannot allocate memory for buffers \n");
    free (local); free (remote);
    free (desc);
    return -1;
  }

  /* Create PTAG */
  if (VipCreatePtag (nic, &ptag) != VIP_SUCCESS) {
    fprintf (stderr, "Failed creating memory ptag \n");
    free (local); free (remote);
    free (desc);
    return -1;
  } 

  /* Set memory attributes */
  mem_attr.Ptag = ptag;
  mem_attr.EnableRdmaWrite = VIP_FALSE;
  mem_attr.EnableRdmaRead = VIP_FALSE;

  /* Now register memory and descriptors */
  if (VipRegisterMem (nic, desc, 2 * sizeof (VIP_DESCRIPTOR),
		      &mem_attr, &desch) != VIP_SUCCESS) {
    fprintf (stderr, "Cannot register memory for via descriptors. \n");
    free (local); free (remote);
    free (desc);
    return -1;
  }

  if (VipRegisterMem (nic, buffer, 2 * ML_BUF_SIZE,
		      &mem_attr, &buffh) != VIP_SUCCESS) {
    fprintf (stderr, "Cannot perform register memory for send/recv buffers\n");
    VipDeregisterMem(nic, desc, desch);

    free (local); free (remote);
    free (desc); free (buffer);
    return -1;
  }    

  /* Set up viahandle attributes */
  lvi_attr.ReliabilityLevel = VIP_SERVICE_RELIABLE_DELIVERY; 
  lvi_attr.Ptag = ptag;
  lvi_attr.EnableRdmaWrite = VIP_FALSE;
  lvi_attr.EnableRdmaRead = VIP_FALSE;
  lvi_attr.QoS = 0;
  lvi_attr.MaxTransferSize = ML_BUF_SIZE;

  /* Now create VI */
  if (VipCreateVi (nic, &lvi_attr, 0, 0, &lvi) != VIP_SUCCESS) {
    fprintf (stderr, "Cannot create vi for device %s\n", via_dev);
    
    VipDeregisterMem(nic, desc, desch);
    VipDeregisterMem(nic, buffer, buffh);

    free (local); free (remote);
    free (desc);  free (buffer);
    return -1;
  }

  /* register alarm */
  alarm (ML_TIME_TO_LIVE);

  /* Initialize descriptor information */
  for (i = 0; i < 2; i++) {
    desc[i].CS.Length = size;
    desc[i].CS.Status = 0;
    desc[i].CS.Control = VIP_CONTROL_OP_SENDRECV;
    desc[i].CS.SegCount = 1;
    desc[i].CS.Reserved = 0;
    desc[i].DS[0].Local.Data.Address = &buffer[i*size];
    desc[i].DS[0].Local.Handle = buffh;
    desc[i].DS[0].Local.Length = size;
  }
  sendbuf = desc[1].DS[0].Local.Data.Address;
  recvbuf = desc[0].DS[0].Local.Data.Address;

  /* Now via is created */
  ml_via_inited = 1;

  /* Now doing connection */
  if (send) {
    status = VIP_NO_MATCH;
    while (status == VIP_NO_MATCH) {
      status = VipConnectRequest (lvi, local,
				  remote, VIP_INFINITE,
				  &rvi_attr);
    }
    if (status != VIP_SUCCESS) {
      fprintf (stderr, "Cannot connect to remote via host %s \n",
	       via_host);
      
      VipDeregisterMem(nic, desc, desch);
      VipDeregisterMem(nic, buffer, buffh);

      free (local); free (remote);
      free (desc);  free (buffer);
      goto _ml_error;
    }
    /* Now send number packet over */
    
    for (i = 0; i < ML_LOOPS; i++) {
      VipPostRecv (lvi, &desc[0], desch);
      VipPostSend (lvi, &desc[1], desch);
      VipSendWait (lvi, VIP_INFINITE, &descp);
      VipRecvWait (lvi, VIP_INFINITE, &descp);
    }
    VipDisconnect (lvi);
  }
  else {
    /* Send out ready message */
    fprintf (stderr, "Ready\n");

    VipPostRecv (lvi, &desc[0], desch);
    descp = &desc[1];

    if (VipConnectWait (nic, local, VIP_INFINITE, 
			remote, &rvi_attr, &ch) != VIP_SUCCESS) {
      fprintf (stderr, "Failed connection wait for %s \n", via_host);

      VipDeregisterMem(nic, desc, desch);
      VipDeregisterMem(nic, buffer, buffh);

      free (local); free (remote);
      free (desc);  free (buffer);
      goto _ml_error;
    }
    if (VipConnectAccept (ch, lvi) != VIP_SUCCESS) {
      fprintf (stderr, "Failed connection accept for %s\n", via_host);
      VipDeregisterMem(nic, desc, desch);
      VipDeregisterMem(nic, buffer, buffh);

      free (local); free (remote);
      free (desc);  free (buffer);
      goto _ml_error;
    }

    /* Now ping pong recv/send packet */
    for (i = 0; i < ML_LOOPS; i++) {
      VipPostRecv (lvi, descp, desch);
      VipRecvWait (lvi, VIP_INFINITE, &descp);
      VipPostSend (lvi, descp, desch);
      VipSendWait (lvi, VIP_INFINITE, &descp);
    }

    VipDisconnect (lvi);
    /* Finishing all packet */
    while (VipRecvDone (lvi, &descp) == VIP_SUCCESS);
    
  }

  /* Now free memory */
  VipDeregisterMem(nic, desc, desch);
  VipDeregisterMem(nic, buffer, buffh);

  free (local); free (remote);
  free (desc);  free (buffer);    

  /* Close Vi */
_ml_error:
  VipDestroyVi (lvi);

  /* Send out ok */
  fprintf (stderr, "Ok MVIA Test is great success, good bye!!!\n");

  return 0;
}
