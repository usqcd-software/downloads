/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      MVIA Link Level Test Client Network Part of Code
 *
 * Author:
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: mvia_link_client.c,v $
 *   Revision 1.1.1.1  2005/09/06 15:44:54  chen
 *   mvia link test package
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <errno.h>
#include <sys/select.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/uio.h>

#include "mvia_link.h"

/**
 * Print out usage of this program and exit
 */
static void 
ml_usage (int argc, char** argv)
{
  fprintf (stderr, "Usage: %s host status|speed|link|reload [conf]\n", 
	   argv[0]);
  fprintf (stderr, "       status: check ethernet status\n");
  fprintf (stderr, "       speed : set ethernet card to 1000Mb/s\n");
  fprintf (stderr, "       link  : verify via connection of each link\n");
  fprintf (stderr, "       reload: load a configuration file\n");
}

/**
 * Process status results from server. Only print out error information
 */
static int
ml_process_stat_results (char* buf, int buflen)
{
  int i, nf, status;
  char line[256], *p;
  char attr[128], statval[128], eth_device[ML_ETHDEV_NAME_LEN];

  status = 0;

  i = 0;
  while (i < buflen) {
    p = line;
    while (buf[i] != '\n') {
      *p = buf[i];
      p++; i++;
    }
    *p = '\0';
    i++;

    /* Do a scanf of the newly formed line */
    if ((nf = sscanf (line, "%s %s", attr, statval)) == 1) {
      /* This is ethernet device field */
      strncpy (eth_device, attr, ML_ETHDEV_NAME_LEN - 1);
    }
    else if (nf >= 2) {
      if (strcmp (attr, "Speed:") == 0) {
	if (strcmp (statval, "1000Mb/s") != 0) {
	  fprintf (stderr, "%s %s %s\n", eth_device, attr, statval);
	  status = -1;
	}
      }
      else {
	if (atoi(statval) != 0) {
	  fprintf (stderr, "attr = %s len = %d statval = %s len = %d\n", attr, strlen(attr), statval, strlen (statval));
	  
	  fprintf (stderr, "%s %s %s\n", eth_device, attr, statval);
	  status = -1;
	}
      }
    }
  }
  return status;
}


/**
 * Process status results from server. Only print out error information
 */
static int
ml_process_speed_results (char* buf, int buflen)
{
  int i, nf, status;
  char line[256], *p;
  char attr[128], statval[128], eth_device[ML_ETHDEV_NAME_LEN];

  status = 0;

  i = 0;
  while (i < buflen) {
    p = line;
    while (buf[i] != '\n') {
      *p = buf[i];
      p++; i++;
    }
    *p = '\0';
    i++;

    /* Do a scanf of the newly formed line */
    if ((nf = sscanf (line, "%s %s", attr, statval)) == 1) {
      /* This is ethernet device field */
      strncpy (eth_device, attr, ML_ETHDEV_NAME_LEN - 1);
    }
    else if (nf >= 2) {
      if (strcasecmp (attr, "Speed") == 0 && strcmp (statval, "1000Mb/s") != 0) {
	fprintf (stderr, "%s %s %s\n", eth_device, attr, statval);
	status = -1;
      }
    }
  }
  return status;
}


/**
 * Process link results from server. Only print out error information
 */
static int
ml_process_link_results (char* buf, int buflen)
{
  int i, nf, status, val;
  char line[256], *p;
  char attr[128];

  status = 0;

  i = 0;
  while (i < buflen) {
    p = line;
    while (buf[i] != '\n') {
      *p = buf[i];
      p++; i++;
    }
    *p = '\0';
    i++;

    /* Do a scanf of the newly formed line */
    if ((nf = sscanf (line, "%s %d", attr, &val)) == 2) 
      fprintf (stderr, "%s %d\n", attr, val);
  }

  return status;
}

/**
 * Send and receive check status request and results to a node
 */
static int
ml_check_status (int cfd, unsigned short op)
{
  int status, nbytes, done, doprint;
  ml_data_t recvdata;
  char* recvbuff;

  status = 0;
  /* Do we print out good report */
  doprint = 1;

  /* Send request to server */
  nbytes = ml_write_data (cfd, op, 0, 0, 0, 0, 0);
  if (nbytes <= 0) {
    status = -1;
    return status;
  }

  done = 0;
  while (!done) {
    /* Now read data back from server */
    /* first read first size data */
    nbytes = read (cfd, (void *)&recvdata, ML_DATA_SIZE);
  
    if (nbytes <= 0) {
      status = -1;
      return status;
    }
    /* convert and check data integrity */
    if (ml_check_recvdata (&recvdata) != 0) {
      status = -1;
      return status;
    }

    if (recvdata.buflen > 0) {
      recvbuff = (char *)malloc (sizeof (recvdata.buflen));
      if (!recvbuff) {
	fprintf (stderr, "Cannot allocate space for %d bytes of char \n", 
		 recvdata.buflen);
	return -1;
      }

      /* Now read all data in */
      if (ml_read_nbytes (cfd, recvbuff, recvdata.buflen) != 
	  recvdata.buflen) {
	fprintf (stderr, "Reading error from server for %d bytes \n",
		 recvdata.buflen);
	free (recvbuff);
	
	status = -1;
	return status;
      }
      recvdata.buffer = recvbuff;
      
      /* Now let us process the results */
      if (ml_process_stat_results (recvdata.buffer, recvdata.buflen) == -1)
	doprint = 0;
    }

    if (recvdata.buffer)
      free (recvdata.buffer);

    if (recvdata.op == ML_CHECK_STATS_DONE) {
      done = 1;
    }
  }

  if (doprint)
    fprintf (stderr, "Ok\n");
  return status;
}


/**
 * Send and receive set speed request and result
 */
static int
ml_set_speed (int cfd, unsigned short op)
{
  int status, nbytes, done, doprint;
  ml_data_t recvdata;
  char* recvbuff;

  status = 0;
  /* Do we print out good report */
  doprint = 1;

  /* Send request to server */
  nbytes = ml_write_data (cfd, op, 0, 0, 0, 0, 0);
  if (nbytes <= 0) {
    status = -1;
    return status;
  }

  done = 0;
  while (!done) {
    /* Now read data back from server */
    /* first read first size data */
    nbytes = read (cfd, (void *)&recvdata, ML_DATA_SIZE);
  
    if (nbytes <= 0) {
      status = -1;
      return status;
    }
    /* convert and check data integrity */
    if (ml_check_recvdata (&recvdata) != 0) {
      status = -1;
      return status;
    }

    if (recvdata.buflen > 0) {
      recvbuff = (char *)malloc (sizeof (recvdata.buflen));
      if (!recvbuff) {
	fprintf (stderr, "Cannot allocate space for %d bytes of char \n", 
		 recvdata.buflen);
	return -1;
      }

      /* Now read all data in */
      if (ml_read_nbytes (cfd, recvbuff, recvdata.buflen) != 
	  recvdata.buflen) {
	fprintf (stderr, "Reading error from server for %d bytes \n",
		 recvdata.buflen);
	free (recvbuff);
	
	status = -1;
	return status;
      }
      recvdata.buffer = recvbuff;

      /* Now let us process the results */
      if (ml_process_speed_results (recvdata.buffer, recvdata.buflen) == -1)
	doprint = 0;
    }

    if (recvdata.buffer)
      free (recvdata.buffer);

    if (recvdata.op == ML_SET_LINK_SPEED_DONE) {
      done = 1;
    }
  }

  if (doprint)
    fprintf (stderr, "Ok\n");
  return status;
}

/**
 * Send and receive check via link test
 */
static int
ml_check_link (int cfd, unsigned short op)
{
  int status, nbytes, done, doprint;
  ml_data_t recvdata;
  char* recvbuff;

  status = 0;
  /* Do we print out good report */
  doprint = 1;

  /* Send request to server */
  nbytes = ml_write_data (cfd, op, 0, 0, 0, 0, 0);
  if (nbytes <= 0) {
    status = -1;
    return status;
  }

  done = 0;
  while (!done) {
    /* Now read data back from server */
    /* first read first size data */
    nbytes = read (cfd, (void *)&recvdata, ML_DATA_SIZE);
  
    if (nbytes <= 0) {
      status = -1;
      return status;
    }
    /* convert and check data integrity */
    if (ml_check_recvdata (&recvdata) != 0) {
      status = -1;
      return status;
    }

    if (recvdata.buflen > 0) {
      recvbuff = (char *)malloc (sizeof (recvdata.buflen));
      if (!recvbuff) {
	fprintf (stderr, "Cannot allocate space for %d bytes of char \n", 
		 recvdata.buflen);
	return -1;
      }

      /* Now read all data in */
      if (ml_read_nbytes (cfd, recvbuff, recvdata.buflen) != 
	  recvdata.buflen) {
	fprintf (stderr, "Reading error from server for %d bytes \n",
		 recvdata.buflen);
	free (recvbuff);
	
	status = -1;
	return status;
      }
      recvdata.buffer = recvbuff;
      
      /* Now let us process the results */
      if (ml_process_link_results (recvdata.buffer, recvdata.buflen) == -1)
	doprint = 0;
    }

    if (recvdata.buffer)
      free (recvdata.buffer);

    if (recvdata.op == ML_CHECK_LINK_IN_PROG) {
      fprintf (stderr, "Link check is in progress.\n");
      doprint = 0;
      done = 1;
    }
    else if (recvdata.op == ML_CHECK_LINK_DONE) {
      done = 1;
    }
  }

  return status;
}


/**
 * Ask server to reload configuration file
 */
static int
ml_reload_conf (int cfd, unsigned short op, char* filename)
{
  int status, nbytes, good;
  ml_data_t recvdata;

  status = 0;

  /* Send request to server */
  nbytes = ml_write_data (cfd, op, 0, 0, 0, strlen(filename) + 1, filename); 
  if (nbytes <= 0) {
    status = -1;
    return status;
  }

  good = 0;
  /* Now read data back from server */
  /* first read first size data */
  nbytes = read (cfd, (void *)&recvdata, ML_DATA_SIZE);
  
  if (nbytes <= 0) {
    status = -1;
    return status;
  }
  /* convert and check data integrity */
  if (ml_check_recvdata (&recvdata) != 0) {
    status = -1;
    return status;
  }

  if (recvdata.status == 0) 
    good = 1;
  else
    good = 0;

  if (good)
    fprintf (stderr, "Loading configuration file %s Ok\n", filename);
  else
    fprintf (stderr, "Loading configuration file %s Failed\n", filename);

  return status;
}
    


int
main (int argc, char** argv)
{
  char rhost[ML_HOSTNAME_LEN], conf[128];
  char operation[32];
  int  cfd, status;
  unsigned short op;

  if (argc < 3) {
    ml_usage (argc, argv);
    return -1;
  }
  status = 0;

  strncpy (rhost, argv[1], ML_HOSTNAME_LEN - 1);
  strncpy (operation, argv[2], sizeof(operation) - 1);

  /* Convert string into integer operation code */
  if (strcasecmp (operation, "status") == 0)
    op = ML_CHECK_STATS;
  else if (strcasecmp (operation, "link") == 0)
    op = ML_CHECK_LINK_START;
  else if (strcasecmp (operation, "speed") == 0)
    op = ML_SET_LINK_SPEED;
  else if (strcasecmp (operation, "reload") == 0) {
    if (argc < 4) {
      ml_usage (argc, argv);
      return -1;
    }
    strncpy (conf, argv[3], sizeof(conf) - 1);
    op = ML_RELOAD_CONF;
  }
  else {
    ml_usage (argc, argv);
    return -1;
  }

  /* Now first connect to the server */
  cfd = ml_tcp_connect (rhost, ML_S_PORT);
  if (!cfd) 
    return -1;

  switch (op) {
  case ML_CHECK_STATS:
    status = ml_check_status (cfd, op);
    break;
  case ML_SET_LINK_SPEED:
    status = ml_set_speed (cfd, op);
    break;
  case ML_CHECK_LINK_START:
    status = ml_check_link (cfd, op);
    break;
  case ML_RELOAD_CONF:
    status = ml_reload_conf (cfd, op, conf);
    break;
  default:
    fprintf (stderr, "This operation has not been implemented yet .\n");
    status = -1;
    break;
  }
  close (cfd);

  return status;
}
