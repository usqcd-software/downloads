/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      MVIA Link Level Test Server Code on Individual Node
 *
 * Author:
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: mvia_link_server.c,v $
 *   Revision 1.1.1.1  2005/09/06 15:44:54  chen
 *   mvia link test package
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <syslog.h>
#include <stdarg.h>
#include <ctype.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <errno.h>
#include <sys/select.h>
#include <unistd.h>
#include <sys/time.h>
#include <signal.h>
#include <sys/stat.h>

#include "mvia_link.h"

/**
 * VIA HOST NAME Prefix
 */
#define ML_VIAHOST_PREFIX "via"

/**
 * Server option structure
 */
#define ML_CONF_FILE_LEN 128

typedef struct _ml_server_op_
{
  /* configuration file of this server                   */
  char conf_file[ML_CONF_FILE_LEN];

  /* Owner of this server                                */
  uid_t owner;

  /* Host name assigned by caller                        */
  char* host;

  /* all nodes participate to parallel process           */
  ml_node_t* all_nodes;
  unsigned int num_nodes;

}ml_server_op_t;

/**
 * Default configuration file location
 */
#define ML_CONF "/etc/mvia_link.conf"

/**
 * global instance of server options
 */
ml_server_op_t* ml_options = 0;

/**
 * Log error and information message 
 */
void
ml_printf (const char* format, ...)
{
  va_list argp;

  if (ml_options->owner == 0) {
    /* this server process is owned by root, we log message into
     * system /var/log/message
     */
    va_start (argp, format);
    vsyslog (LOG_INFO, format, argp);
    va_end (argp);
  }    
  else {
    va_start (argp, format);
    vfprintf (stderr, format, argp);
    va_end (argp);
  }
}

/**
 * Print out usage and exit
 */
static void 
ml_usage (int argc, char** argv)
{
  fprintf (stderr, "Usage : %s [configuration]\n", argv[0]);
  fprintf (stderr, "Default configuration file is at /etc/mvia_link.conf \n");
}

/**
 * Check whether a line is an empty line
 *
 * @return 1: empty line, otherwise return 0
 */
static int
ml_empty_line_i (char line[], unsigned int size)
{
  char* p;

  p = line;

  while (p && *p) {
    if (isprint(*p))
      return 0;
    p++;
  }
  return 1;
}


/**
 * Parsing a string containing multiple integers seperated by white spaces
 *
 * @param  line a string containing multiple integers
 * @param  ret  an allocated array of integers
 * @param  size size of the above array
 * @return number of integers obtained.
 */
static int
ml_get_integers_i (char* line, int ret[], int size)
{
  int i;
  char* token;

  i = 0;
  token = strtok (line, " ");
  if (!token) 
    return 0;
  
  if (sscanf (token, "%d", &ret[i]) < 1) 
    return 0;

  i = 1;
  while ((token = strtok (0, " ")) != NULL && i < size) {
    if (sscanf (token, "%d", &ret[i]) < 1) 
      return i;
    i++;
  }

  return i;
}

/**
 * Set geometry dimension size information
 */
static inline void
ml_set_torus_dimsize (ml_torus_t* torus, int ret[])
{
  int i;

  for (i = 0; i < torus->dimension; i++)
    torus->size[i] = ret[i];
}

static inline void
ml_set_torus_coordinates (ml_torus_t* torus,
			  int ret[])
{
  int i;

  for (i = 0; i < torus->dimension; i++)
    torus->mynode.coordinates[i] = ret[i];  
}

/**
 * Set host coordinates information
 */
static inline void
ml_set_host_coordinates (ml_server_op_t *op, int idx, int ret[], int dims)
{
  int i;

  for (i = 0; i < dims; i++)
    op->all_nodes[idx].coordinates[i] = ret[i];  
}

/**
 * Calculate number of nodes for the whole system
 */
static inline void
ml_calc_num_nodes (ml_torus_t* torus)
{
  int i;

  torus->num_nodes = 1;
  for (i = 0; i < torus->dimension; i++)
    torus->num_nodes = torus->num_nodes * torus->size[i];
}

/**
 * Check matching coordinates
 */
static inline int
ml_same_coordinates (int coord1[], int coord2[], int size)
{
  int i;

  for (i = 0; i < size; i++) {
    if (coord1[i] != coord2[i])
      return 0;
  }
  return 1;
}



/**
 * Update gige links remote hostname information
 */
static int
ml_update_gige_links (ml_torus_t* t, ml_server_op_t* op)
{
  int i, k, m, found;
  int nbp[ML_ND], nbm[ML_ND];
  ml_gige_t *portp, *portm;

  for (i = 0; i < t->dimension; i++) {
    /* minus direction */
    portm = &(t->links[i][0]);
    
    /* positive direction */
    portp = &(t->links[i][1]);

    for (k = 0; k < t->dimension; k++) {
      nbp[k] = t->mynode.coordinates[k];
      nbm[k] = t->mynode.coordinates[k];
    }

    nbp[i] = (nbp[i] + 1) % (t->size[i]);
    nbm[i] = (nbm[i] == 0) ? (t->size[i] - 1) : (nbm[i] - 1);

    /* now check which host inside option list has the same coordinates */
    found = 0;
    for (m = 0; m < op->num_nodes; m++) {
      if (ml_same_coordinates (op->all_nodes[m].coordinates, nbm,
			       t->dimension)) {
	strncpy (portm->peer_host, op->all_nodes[m].host, 
		 ML_HOSTNAME_LEN);
	found = 1;
	break;
      }
    }
    if (!found) {
      ml_printf ("Cannot find matching neighbor along negative direction on axis %d\n", i);
      return -1;
    }

    found = 0;
    for (m = 0; m < op->num_nodes; m++) {
      if (ml_same_coordinates (op->all_nodes[m].coordinates, nbp,
			       t->dimension)) {
	strncpy (portp->peer_host, op->all_nodes[m].host, 
		 ML_HOSTNAME_LEN);
	found = 1;
	break;
      }
    }
    if (!found) {
      ml_printf ("Cannot find matching neighbor along positive direction on axis %d\n", i);
      return -1;
    }      
  }
  return 0;
}


/**
 * Set up gigbit ethernet port from a single line
 *
 * @param line a char string containing gigebit port information
 * @phys  physical geometry pointer
 * @return 0 if everything is ok.
 */
static int 
ml_setup_gige_port (char* line, ml_torus_t* torus)
{
  ml_gige_t* port;
  int direction, axis, match, reliable;
  char name[ML_HOSTNAME_LEN];
  char ethd[ML_ETHDEV_NAME_LEN];
  char rel[32];

  if ((match = sscanf (line,"%s %s %d %d %s", ethd, name ,&direction, &axis, rel)) >= 4 && axis >= 0 && axis < ML_ND) {
    if (direction == -1|| direction == 1) {
      port = &(torus->links[axis][(direction + 1)/2]);
      strncpy (port->eth_device, ethd, ML_ETHDEV_NAME_LEN - 1);
      strncpy (port->peer_via_host, name, ML_HOSTNAME_LEN - 1);
      port->direction = direction;
      port->axis = axis;

      reliable = 0;      
      if (match >= 5) {
	if (strcmp (rel, "r") == 0)
	  reliable = 1;
      }

      if (reliable)
	port->reliable = 1;
      else
	port->reliable = 0;
    }
    else {
      ml_printf ("Direction specification error at line: %s.\n", line);
      return -1;
    }
  }
  else if (sscanf (line, "%s", ethd) >= 1) {
    /* Skip switched port information */
  }
  else {
    ml_printf ("Configuration syntax error for ports at line: %s \n", line);
    return -1;
  }
  return 0;
}




/**
 * Parse configuration file to establish geometry information
 *
 * @return 0: everythin is ok
 * @return -1: error
 */
static int
ml_parse_conf (ml_server_op_t* op, ml_torus_t* torus)
{
  FILE* cfd;
  int   i, j, k, m, num, type, dim, hosttype, myhost;
  int   ret[ML_ND];
  char  line[128], hname[ML_HOSTNAME_LEN];

  if (strlen(op->conf_file) == 0)
    return -1;

  /* This routine may be called twice */
  if (op->all_nodes) {
    free (op->all_nodes);
    op->all_nodes = 0;
  }

  cfd = fopen (op->conf_file, "r");
  if (!cfd) {
    ml_printf ("Cannot open configuration file %s . \n", 
	       op->conf_file);
    return -1;
  }

  num = 0;
  type = 0;
  dim = 0;
  hosttype = 0;
  k = m = 0;
  myhost = 0;

  /**
   * Scan the configuration file to find out how many nodes and dimension
   * information of the mesh
   */
  while (!feof (cfd)) {
    memset (line, 0, sizeof (line));
    if (fgets (line, sizeof (line) - 1, cfd) && 
	!ml_empty_line_i (line, sizeof (line) - 1) && line[0] != '#') {
      switch (type) {
      case 0:
	/* get dimension information */
	if (sscanf (line, "%d", &dim) < 1) {
	  ml_printf ("configuration %s provide no dimension information.\n",
		     op->conf_file);
	  fclose (cfd);
	  return -1;
	}
	if (dim <= 0 || dim > ML_ND) {
	  ml_printf ("configuration %s provide wrong dimension information (dimension = %d) .\n",
		     op->conf_file, dim);
	  fclose (cfd);
	  return -1;
	}

	/* set dimension information */
	torus->dimension = dim;
	
	type++;
	break;
      case 1:
	/* Find out dimension size information */
	i = ml_get_integers_i (line, ret, ML_ND);
	
	if (i < dim - 1) {
	  ml_printf ("configuration %s has wrong dimension size information.\n",
		     op->conf_file);
	  fclose (cfd);
	  return -1;
	}

	/* update geometry information */
	ml_set_torus_dimsize (torus, ret);

	/* calculate total number of nodes */
	ml_calc_num_nodes (torus);

	/**
	 * Get number of nodes information created by the previous step
	 */
	if ((num = torus->num_nodes) <= 0) {
	  ml_printf ("configuration %s has wrong number of nodes. \n",
		     op->conf_file);
	  fclose (cfd);
	  return -1;
	}

	/**
	 * Set server option number nodes to allnode information
	 */
	op->num_nodes = num;
	op->all_nodes = (ml_node_t *)malloc(num * sizeof(ml_node_t));
	if (!op->all_nodes) {
	  ml_printf ("Cannot allocate space for all_nodes information.\n");
	  fclose (cfd);
	  return -1;
	}

	type++;
	
	break;
      case 2:
	/* Switch environment which I do not care */
	m++;
	if (m >= num) {
	  /* done with switched via host information */
	  type++;
	}
	break;
      case 3:
	/* Each host information */
	switch (hosttype) {
	case 0:
	  /* get host name */
	  if (strchr (line, '{') != 0) 
	    hosttype = 1;
	  else { 
	    sscanf (line, "%s", hname);
	    
	    /* Set up option hostname info */
	    strncpy (op->all_nodes[k].host, hname, ML_HOSTNAME_LEN - 1);

	    if (strcmp (hname, torus->mynode.host) == 0) 
	      myhost = 1;
	    else
	      myhost = 0;
	  }
	  break;
	case 1:
	  if (myhost) {
	    /* inside the left brackt */
	    if (strchr (line, '}') != 0) {
	      /* I am done, should quit the loop */
	      hosttype = 0;
	      k++;
	    }
	    else {
	      if (strstr (line, "/dev") == 0) {
		/* get coordinates of this host */
		j = ml_get_integers_i (line, ret, ML_ND);
		if (j != torus->dimension) {
		  ml_printf ("configuration %s for host %s has wrong coordinates.\n",
			     op->conf_file, hname);
		  fclose (cfd);
		  return -1;
		}
	      
		/* update physical geometry coordinate information */
		ml_set_torus_coordinates (torus, ret);

		/* update options coordination information */
		ml_set_host_coordinates (op, k, ret, torus->dimension);
	      }
	      else {
		/* This is gige mesh port information */

		/* Only process gige port information for this host */
		if (ml_setup_gige_port (line, torus) != 0) {
		  ml_printf ("configuration %s error for ethernet port. \n",
			     op->conf_file);
		  fclose (cfd);
		  return -1;
		}
	      }
	    }
	  }
	  else {
	    if (strchr (line, '}') != 0) {
	      hosttype = 0;
	      k++;
	    }
	    else {
	      if (strstr (line, "/dev") == 0) {
		/* get coordinates of this host */
		j = ml_get_integers_i (line, ret, ML_ND);
		if (j != torus->dimension) {
		  ml_printf ("configuration %s for host %s has wrong coordinates.\n",
			     op->conf_file, hname);
		  fclose (cfd);
		  return -1;
		}
		/* update options coordination information */
		ml_set_host_coordinates (op, k, ret, torus->dimension);
	      }
	    }
	  }
	  break;
	default:
	  break;
	}
      }
    }
  }

  fclose (cfd);

  /* Now setup remote host information */
  return ml_update_gige_links (torus, op);
}


/**
 * Reload configuration file
 * return 0: success. otherwise failure
 */
int
ml_reload_conf_file (char* filename, ml_torus_t* torus)
{
  /* Change global server option file name */
  strncpy (ml_options->conf_file, filename, ML_CONF_FILE_LEN - 1);

  return ml_parse_conf (ml_options, torus);
}

/**
 * Check command line options
 */
static int
ml_check_options (int argc, char** argv, ml_server_op_t* op)
{
  op->host = 0;
  op->owner = getuid ();
  if (argc > 1) {
    strncpy (op->conf_file, argv[1], ML_CONF_FILE_LEN - 1);
    if (argc > 2) {
      op->host = (char *)malloc(strlen (argv[2]) + 1);
      strcpy (op->host, argv[2]);
    }
  }
  else
    op->conf_file[0]='\0';

  /* Set all nodes information */
  op->num_nodes = 0;
  op->all_nodes = 0;

  return 0;
}

/**
 * Initialize torus information structure
 */
static void
ml_init_torus (ml_torus_t* t, char* host)
{
  int i;

  t->num_nodes = 0;
  t->dimension = 0;
  
  for (i = 0; i < ML_ND; i++) {
    t->size[i] = 0;
    t->mynode.coordinates[i] = 0;
  }

  if (!host)
    gethostname (t->mynode.host, ML_HOSTNAME_LEN - 1);
  else
    strncpy (t->mynode.host, host, ML_HOSTNAME_LEN - 1);
  
  for (i = 0; i < ML_ND; i++) {
    /* minus direction */
    t->links[i][0].direction = -1;
    t->links[i][0].axis = i;
    t->links[i][0].reliable = 0;
    t->links[i][0].eth_device[0] = '\0';
    t->links[i][0].peer_via_host[0] = '\0';
    t->links[i][0].peer_host[0] = '\0';
    t->links[i][0].test_code = -1;
    t->links[i][0].s_child = 0;
    t->links[i][0].s_child_ct = 0;
    t->links[i][0].r_child = 0;
    t->links[i][0].r_child_ct = 0;

    t->links[i][1].direction = 1;
    t->links[i][1].axis = i;
    t->links[i][1].reliable = 0;
    t->links[i][1].eth_device[0] = '\0';
    t->links[i][1].peer_via_host[0] = '\0';
    t->links[i][1].peer_host[0] = '\0';
    t->links[i][1].test_code = 0;
    t->links[i][1].s_child = 0;
    t->links[i][1].s_child_ct = 0;
    t->links[i][1].r_child = 0;
    t->links[i][1].r_child_ct = 0;
  }
  t->test_fd = -1;
}

/**
 * Initialize client table
 */
static void
ml_init_client_table (ml_client_table_t* table)
{
  table->lfd = -1;
  table->mfdset = 0;
  table->num_clients = 0;
  table->clients = 0;
  table->timers = 0;
}


/**
 * Add an event handler to the table
 *
 * return 0: success
 * return -1: error
 */
int
ml_add_event_handler (ml_client_table_t* table,
		      int cfd, char* host, unsigned short port,
		      ml_event_handler_t handler,
		      void* arg)
{
  ml_client_info_t *p, *q;

  /* there no event handler yet */
  p = (ml_client_info_t *)malloc(sizeof(ml_client_info_t));
  if (!p) {
    ml_printf ("Cannot allocate space for connected client.\n");
    return -1;
  }
  p->next = 0;
  p->cfd = cfd;
  p->port = port;
  p->event_handler = handler;
  p->arg = arg;
  strncpy (p->host, host, ML_HOSTNAME_LEN - 1);
  
  /* Add this event handler to the table */
  if (table->clients) {
    q = table->clients;
    while (q->next)
      q = q->next;
    q->next = p;
  }
  else
    table->clients = p;

  
  /* Set master fd_set */
  FD_SET(cfd, table->mfdset);
  table->num_clients++;
  
  return 0;
}

/**
 * Add a client to the table
 */
int
ml_remove_event_handler (ml_client_table_t* table,
			 int cfd)
{
  int found;
  ml_client_info_t *p, *q, *rem;

  rem = 0;
  found = 0;
  p = table->clients;
  q = 0;
  while (p) {
    if (p->cfd == cfd) {
      /* remove from master fd set */
      FD_CLR (cfd, table->mfdset);

      /* remove p from the list */
      if (!q) 
	table->clients = p->next;
      else 
	q->next = p->next;

      rem = p;
      found = 1;
      break;
    }
    q = p;
    p = p->next;
  }
  if (found) {
    table->num_clients--;
    free (rem); 
  }
  else {
    ml_printf ("Cannot remove this client fd %d\n", cfd);
    return -1;
  }

  p = table->clients;
  while (p) {
    p = p->next;
  }
    
  return 0;
}

/**
 * Return current largest file descriptor plus 1
 */
static int
ml_max_fdp1 (ml_client_table_t* table, int lfd)
{
  int maxfd;
  ml_client_info_t *p;

  maxfd = -1;

  p = table->clients;
  while (p) {
    if (p->cfd > maxfd)
      maxfd = p->cfd;
    p = p->next;
  }

  if (lfd > maxfd)
    maxfd = lfd;

  return maxfd + 1;
}

/**
 * Dispatch timer event
 *
 * ml_handle_timer returns number seconds for next timer
 * 
 */
static int
ml_dispatch_timer (ml_client_table_t* table, ml_torus_t* torus)
{
  ml_timer_t *p, *q, *rem;
  double currt, nextfire;
  int    again;

  currt = ml_current_time ();
  
  q = 0;
  p = table->timers;
  while (p) {
    rem = 0;
    if (p->time_to_fire <= currt) {
      again = (*(p->timer_handler))(torus, table, &nextfire, p);
      if (again) 
	p->time_to_fire = currt + nextfire;
      else {
	/* remove this from the list */
	if (!q) 
	  table->timers = p->next;
	else 
	  q->next = p->next;
	
	rem = p;
      }
    }

    /* q is pointing to the previous node of p
     * if p is being removed, q should not change
     */
    if (!rem) {
      q = p;
      p = p->next;
    }
    else {
      p = p->next;
      free (rem);
    }
  }

  /* Now figure out the smallest time to fire and select time out value */
  nextfire = 10000*1000.0;
  p = table->timers;

  while (p) {
    if (p->time_to_fire < nextfire + currt)
      nextfire = p->time_to_fire - currt;
    p = p->next;
  }

  torus->tv->tv_sec = nextfire/1000.0;
  torus->tv->tv_usec = (nextfire - 1000*(int)(nextfire/1000.0))*1000;
  return 0;
}


/**
 * Dispatch network event
 */
static int
ml_dispatch_event (int n, fd_set* rset, fd_set* masterset,
		   ml_client_table_t* table, ml_torus_t* torus)
{
  ml_client_info_t *p, *q, *rem;

  p = table->clients;
  q = 0;
  while (p) {
    rem = 0;
    if (FD_ISSET (p->cfd, rset)) {
      if ((*(p->event_handler)) (torus, p, table, p->cfd, p->arg) <= 0) {
	/* This connection is closed */
	/* Remove this cfd from master set */
	FD_CLR (p->cfd, masterset);
	ml_printf ("Connection from remote %s and port %d closed\n",
		   p->host, p->port);
	close (p->cfd);

	/* remove this from the list */
	if (!q) 
	  /* This is the first one */
	  table->clients = p->next;
	else 
	  q->next = p->next;

	rem = p;
      }

      /* check timer event anyway */
      ml_dispatch_timer (table, torus);
    }

    /* q is pointing to the previous node of p
     * is p is being deleted, q should not change 
     */
    if (!rem) {
      q = p;
      p = p->next;
    }
    else {
      /* delete this object */
      /* q stays where it was */
      p = p->next;
      free (rem);
      table->num_clients--;
    }
  }
  return 0;
}


/**
 * Poll all file decriptor to find out whether
 * there are something needs to be done
 */
int
ml_poll (ml_torus_t* torus, ml_client_table_t* table)
{
  struct timeval tv;
  fd_set rset;
  int maxfd, nsel, connfd;
  char clihost[ML_HOSTNAME_LEN];
  unsigned short cliport;
  struct sockaddr_in cliaddr;
  int cliaddrlen = sizeof(cliaddr);

  /* This is a poll */
  tv.tv_sec = 0;
  tv.tv_usec = 0;

  /* get max fd set */
  maxfd = ml_max_fdp1 (table, table->lfd);

  rset = *(table->mfdset);

  do {
    nsel = select (maxfd, &rset, 0, 0, &tv);
  }while (nsel == -1 && errno == EINTR);

  /* Check whether this is the master connection fd */
  if (FD_ISSET (table->lfd, &rset)) {

    cliaddrlen = sizeof (cliaddr);
    do {
      connfd = accept (table->lfd, (struct sockaddr *)&cliaddr, &cliaddrlen);
    }while (!connfd && errno == EINTR);

    if (!connfd) {
      ml_printf("accept error with error no %d\n", errno);
      return -1;
    }
      
    /* Now add connfd to master set */
    FD_SET (connfd, table->mfdset);

    /* Find client connect information */
    ml_get_inet_info (&cliaddr, clihost, ML_HOSTNAME_LEN, &cliport);
    
    /* Now update maxfd number */
    /* Add connfd to master fd_set */
    ml_add_event_handler (table, connfd, clihost, cliport,
			  ml_handle_socket_event,
			  (void *)0);

    maxfd = ml_max_fdp1 (table, table->lfd);

    nsel--;
  }
    
  /* Now check again */
  if (nsel > 0) {
    ml_dispatch_event (nsel, &rset, table->mfdset, table,
		       torus);
    maxfd = ml_max_fdp1 (table, table->lfd);

  }
  else if (nsel == 0) {
    ml_dispatch_timer (table, torus);
  }

  return 0;
}


/**
 * Print information of torus
 */
void dump_torus_info (ml_torus_t* t)
{
  int i;

  fprintf (stderr, "number nodes: %d \n", t->num_nodes);
  fprintf (stderr, "dimension: %d \n", t->dimension);

  fprintf (stderr, "dimension size : [ ");
  for (i = 0; i < t->dimension; i++)
    fprintf (stderr, "%d ", t->size[i]);
  fprintf (stderr, "]\n");

  fprintf (stderr, "coordinates : [ ");
  for (i = 0; i < t->dimension; i++)
    fprintf (stderr, "%d ", t->mynode.coordinates[i]);
  fprintf (stderr, "]\n");

  fprintf (stderr, "hostname: %s\n", t->mynode.host);

  fprintf (stderr, "--------------------------------------------------\n");
  for (i = 0; i < t->dimension; i++) {
    fprintf (stderr, "Gige device along axis %d\n\n", i);
    fprintf (stderr, "Minus Direction \n");
    fprintf (stderr, "Device : %s \n", t->links[i][0].eth_device);
    fprintf (stderr, "Peer via host: %s \n", t->links[i][0].peer_via_host);
    fprintf (stderr, "Peer host: %s \n", t->links[i][0].peer_host);

    fprintf (stderr, "\n");
    fprintf (stderr, "Plus Direction \n");
    fprintf (stderr, "Device : %s \n", t->links[i][1].eth_device);
    fprintf (stderr, "Peer via host: %s \n", t->links[i][1].peer_via_host);
    fprintf (stderr, "Peer host: %s \n", t->links[i][1].peer_host);

    fprintf (stderr, "\n");
  }
  fprintf (stderr, "--------------------------------------------------\n");

}

/**
 * Signal handling routine
 */
static int ml_signals[]={SIGINT, SIGTERM, SIGPIPE};
static int ml_num_signals = 2;

static void
ml_signal_func (int signo)
{
  fprintf (stderr, "Caught signal %d\n", signo);
  if (signo != SIGPIPE)
    exit (127);
}

static void
ml_register_signal_handler (void)
{
  int i;
  struct sigaction act, oact;
  
  act.sa_handler = ml_signal_func;
  sigemptyset (&act.sa_mask);
  act.sa_flags = 0;

#ifdef SA_RESTART
  act.sa_flags |= SA_RESTART;
#endif

  for (i = 0; i < ml_num_signals; i++) {
    if (sigaction (ml_signals[i], &act, &oact) < 0)
      break;
  }
}


int
main (int argc, char** argv)
{
  int lfd, maxfd, nsel, connfd;
  fd_set rset, masterset;
  char clihost[ML_HOSTNAME_LEN];
  unsigned short cliport;
  struct sockaddr_in cliaddr;
  int cliaddrlen = sizeof(cliaddr);
  ml_server_op_t options;
  ml_torus_t torus;
  ml_client_table_t client_table;
  struct timeval tv;
  

  ml_options = &options;

  ml_check_options (argc, argv, ml_options);

  if (ml_options->owner == 0)
    /* open syslog */
    openlog ("MVIA_LINKTEST", LOG_CONS | LOG_NDELAY | LOG_PERROR, LOG_DAEMON);

  /* initialize torus information */
  ml_init_torus (&torus, ml_options->host);

  /* If failed we can reload another file */
  ml_parse_conf (ml_options, &torus);

#if 1
  if (ml_daemonize () == 0)
    return 0;
#endif

  /* register signal handler */
  ml_register_signal_handler ();

  /* Setup initial time out value */
  tv.tv_sec = 10000;
  tv.tv_usec = 0;

  /* Link time out value to torus */
  torus.tv = &tv;

  /* Client up client table */
  ml_init_client_table (&client_table);

  /* First create a network server */
  lfd = ml_tcp_listen (ML_S_PORT);

  if (!lfd) {
    ml_printf ("Cannot open server port %d\n", ML_S_PORT);
    return -1;
  }

  /* Clean read set and master set */
  FD_ZERO (&masterset);
  FD_SET (lfd, &masterset);
  maxfd = lfd + 1;

  /* Set client table master to the master */
  client_table.mfdset = &masterset;

  /* Update client table listening fd */
  client_table.lfd = lfd;

  /* Main Event Loop */
  while (1) {
    rset = masterset;

    do {
      nsel = select (maxfd, &rset, 0, 0, torus.tv);
    }while (nsel == -1 && errno == EINTR);
    
    /* Check anyone want to coonect to me */
    if (FD_ISSET (lfd, &rset)) {
      cliaddrlen = sizeof (cliaddr);
      do {
	connfd = accept (lfd, (struct sockaddr *)&cliaddr, &cliaddrlen);
      }while (!connfd && errno == EINTR);

      if (!connfd) {
	ml_printf("accept error with error no %d\n", errno);
	goto ml_end;
      }
      
      /* Now add connfd to master set */
      FD_SET (connfd, &masterset);

      /* Find client connect information */
      ml_get_inet_info (&cliaddr, clihost, ML_HOSTNAME_LEN, &cliport);

      /* Now update maxfd number */
      /* Add connfd to master fd_set */
      ml_add_event_handler (&client_table, connfd, clihost, cliport,
			    ml_handle_socket_event,
			    (void *)0);

      maxfd = ml_max_fdp1 (&client_table, lfd);

      nsel--;
    }
    
    /* Go through each descriptor check which one is ready to read */
    if (nsel > 0) {
      ml_dispatch_event (nsel, &rset, &masterset, &client_table,
			 &torus);
      maxfd = ml_max_fdp1 (&client_table, lfd);
    }
    else if (nsel == 0) {
      /* Time out: run out timer routine */
      ml_dispatch_timer (&client_table, &torus);
    }
    
  }

ml_end:
  /* Close socket */
  close (lfd);

  /* free memory */
  free (ml_options->all_nodes);

  if (ml_options->host)
    free (ml_options->host);

  return 0;
}
