/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      MVIA Link Level Test Server Network Part of Code
 *
 * Author:
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: mvia_link_svr_util.c,v $
 *   Revision 1.1.1.1  2005/09/06 15:44:54  chen
 *   mvia link test package
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <netdb.h>
#include <errno.h>
#include <sys/select.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/uio.h>

#include "mvia_link.h"

#define ML_LINK_STAT_COMMAND "/sbin/ethtool"

/**
 * Some forward decleration 
 */
static int  ml_check_link_test_code_timer (ml_torus_t* torus,
					   ml_client_table_t* table,
					   double* next_to_fire,
					   void* arg);


static int  ml_check_link_receiver_timer (ml_torus_t* torus,
					  ml_client_table_t* table,
					  double* next_to_fire,
					  void* arg);

/**
 * Get current time in milli seconds
 */
double
ml_current_time (void)
{
  double t;
  struct timeval tv;

  gettimeofday (&tv, 0);

  t = (tv.tv_sec * 1000.0 + tv.tv_sec/1000.0);

  return t;
}

/**
 * Add timer handler
 */
static void
ml_add_timer_handler (ml_torus_t* torus,
		      ml_client_table_t* table,
		      int msec,
		      ml_timer_handler_t handler,
		      void* arg)
{
  ml_timer_t *p, *q;
  double nextfire, currt;

  currt = ml_current_time ();

  p = (ml_timer_t *)malloc(sizeof(ml_timer_t));
  if (!p) {
    ml_printf ("cannot allocate space for timer obejct.\n");
    return;
  }
  p->timer_handler = handler;
  p->arg = arg;
  p->time_to_fire = currt + msec;
  p->next = 0;

  if (table->timers) {
    q = table->timers;
    while (q->next)
      q = q->next;
    q->next = p;
  }
  else
    table->timers = p;


  /* Now figure out the smallest time to fire and select time out value */
  nextfire = 10000*1000.0;
  p = table->timers;

  while (p) {
    if (p->time_to_fire < nextfire + currt)
      nextfire = p->time_to_fire - currt;
    p = p->next;
  }

  torus->tv->tv_sec = nextfire/1000.0;
  torus->tv->tv_usec = (nextfire - 1000*(int)(nextfire/1000.0))*1000;
}
		      

/**
 * Check ethernet device status by invoking /sbin/ethtool command line
 */
static int
ml_check_eth_status (int cfd, char *devices[], int num_devices)
{
  char buffer[4096], command[512], tmp[256];
  int  nbytes, i, nw, status, cid;

  /* First creta a pipe to communicate with soon to be
   * launched child process
   */
  int comm_pipe[2];
  int child;

  /* comm_pipe[0] is for read, comm_pipe[1] is for write */
  if (pipe (comm_pipe) != 0)
    return -1;
  
  /* Now launch a child process */
  child = fork ();
  if (child == 0) {
    /* this is launched child process */
    /* First close read end of pipe */
    close (comm_pipe[0]);
    
    /* close all stdout, stderr */
    close (1); close (2);
      
    /* duplicate stdout and stderr to comm_pipe[1] */
    dup2 (comm_pipe[1], 1);
    dup2 (comm_pipe[1], 2);

    close (comm_pipe[1]); 

    sprintf (command, "echo %s; /sbin/ethtool %s | grep Speed; /sbin/ethtool -S %s | grep errors ; ", 
	     devices[0], devices[0], devices[0]);
    for (i = 1; i < num_devices; i++) {
      sprintf (tmp, "echo %s; /sbin/ethtool %s | grep Speed; /sbin/ethtool -S %s | grep errors; ", 
	       devices[i], devices[i], devices[i]);      
      strcat (command, tmp);
    }
    execlp ("/bin/sh", "sh", "-c", command, 0);
    exit (127);
  }
  else {
    /* This is the parent process */
    close (comm_pipe[1]);
    
    /* Read output from child process */
    do {
      nbytes = read (comm_pipe[0], buffer, 4096);
      if (nbytes > 0) {
	nw = ml_write_data (cfd, ML_CHECK_STATS_PROG, 0,
			    0, 0, nbytes, buffer);
      }
    }while (nbytes > 0);

    /* Wait to Child process to finish */
    cid = waitpid (child, &status, 0);
    

    /* Write last bit to tell client done */
    nw = ml_write_data (cfd, ML_CHECK_STATS_DONE, 0,
			0, 0, 0, 0);
  }
  return 1;
}


/**
 * Set ethernet device speed by invoking /sbin/ethtool command line
 */
static int
ml_set_link_speed (int cfd, char *devices[], int num_devices)
{
  char buffer[4096], command[1028], tmp[256];
  int  nbytes, i, nw, status, cid;

  /* First creta a pipe to communicate with soon to be
   * launched child process
   */
  int comm_pipe[2];
  int child;

  /* comm_pipe[0] is for read, comm_pipe[1] is for write */
  if (pipe (comm_pipe) != 0)
    return -1;
  
  /* Now launch a child process */
  child = fork ();
  if (child == 0) {
    /* this is launched child process */
    /* First close read end of pipe */
    close (comm_pipe[0]);
    
    /* close all stdout, stderr */
    close (1); close (2);
      
    /* duplicate stdout and stderr to comm_pipe[1] */
    dup2 (comm_pipe[1], 1);
    dup2 (comm_pipe[1], 2);
    close (comm_pipe[1]); 

    sprintf (command, "echo %s; speed=`/sbin/ethtool %s | grep Speed | sed 's/Speed://g'`; if [ $speed != \"1000Mb/s\" ]; then /sbin/ethtool -s %s speed 1000; fi; /sbin/ethtool %s | grep Speed; ", 
	     devices[0], devices[0], devices[0], devices[0]);
    for (i = 1; i < num_devices; i++) {
    sprintf (tmp, "echo %s; speed=`/sbin/ethtool %s | grep Speed | sed 's/Speed://g'`; if [ $speed != \"1000Mb/s\" ]; then /sbin/ethtool -s %s speed 1000; fi; /sbin/ethtool %s | grep Speed; ", 
	     devices[i], devices[i], devices[i], devices[i]);
      strcat (command, tmp);
    }
    execlp ("/bin/sh", "sh", "-c", command, 0);

    exit (127);
  }
  else {
    /* This is the parent process */
    close (comm_pipe[1]);
    
    /* Read output from child process */
    do {
      nbytes = read (comm_pipe[0], buffer, 4096);
      if (nbytes > 0) {
	nw = ml_write_data (cfd, ML_SET_LINK_SPEED_PROG, 0,
			    0, 0, nbytes, buffer);
      }
    }while (nbytes > 0);

    /* Wait to Child process to finish */
    cid = waitpid (child, &status, 0);

    /* Write last bit to tell client done */
    nw = ml_write_data (cfd, ML_SET_LINK_SPEED_DONE, 0,
			0, 0, 0, 0);
  }
  return 1;
}


/**
 * Get all ethernet devices from configuration file
 */
static void
ml_get_eth_devices (ml_torus_t* torus, 
		    char *eth_devices[], int* num_devices)
{
  int i, k;

  k = 0;
  for (i = 0; i < torus->dimension; i++) {
    eth_devices[k] = (char *)malloc(16*sizeof(char));
    if (!eth_devices[k]) {
      ml_printf ("Cannot allocate space for ethernet device name\n");
      *num_devices = 0;
      return;
    }
    strcpy (eth_devices[k++], 
	    torus->links[i][0].eth_device + strlen ("/dev/via_"));


    eth_devices[k] = (char *)malloc(16*sizeof(char));
    if (!eth_devices[k]) {
      ml_printf ("Cannot allocate space for ethernet device name\n");
      *num_devices = 0;
      return;
    }
    strcpy (eth_devices[k++], 
	    torus->links[i][1].eth_device + strlen ("/dev/via_"));
  }

  *num_devices =  2 * torus->dimension;
}

/**
 * Send request from this node to all its neighbor to test
 * every gigabit ethernet link
 */
static int
ml_check_link_req (ml_client_table_t* client_table, 
		   ml_torus_t* torus)
{
  int i, linkfd;
  
  for (i = 0; i < torus->dimension; i++) {
    /* check negative direction first */
    linkfd = ml_tcp_connect (torus->links[i][0].peer_host,
			     ML_S_PORT);
    if (linkfd <= 0) {
      ml_printf ("Cannot connect to my neightbor %s port %d\n",
		 torus->links[i][0].peer_host, ML_S_PORT);
      torus->links[i][0].test_code = 2;
    }

    /* Now send request check link to the neighbor */
    /* Always send direction in the neighbors view. i.e. if I am
     * talking about negtive direction, I will send positive direction
     */
    if (linkfd > 0) {
      if (ml_write_data (linkfd, ML_CHECK_SINGLE_LINK, 0,
			 i, 1, 0, 0) <= 0) {
	ml_printf ("Cannot send message to my neighbor %s\n",
		   torus->links[i][0].peer_host);
	return 0;
      }
    
      /* add this file descritpor to the client table of the server */
      ml_add_event_handler (client_table, linkfd, 
			    torus->links[i][0].peer_host, 
			    ML_S_PORT,
			    ml_handle_socket_event, 0);
    }


    /* check positive direction first 
     * Of course, if the positive and negative share the same
     * link, We will not do it again
     */
    if (strcmp (torus->links[i][1].eth_device, 
		torus->links[i][0].eth_device) == 0)
      continue;

    linkfd = ml_tcp_connect (torus->links[i][1].peer_host,
			     ML_S_PORT);
    if (linkfd <= 0) {
      ml_printf ("Cannot connect to my neightbor %s port %d\n",
		 torus->links[i][1].peer_host, ML_S_PORT);
      torus->links[i][1].test_code = 2;      
    }

    /* Now send request check link to the neighbor */
    /* Always send direction in the neighbors view. i.e. if I am
     * talking about negtive direction, I will send positive direction
     */
    if (linkfd > 0) {
      if (ml_write_data (linkfd, ML_CHECK_SINGLE_LINK, 0,
			 i, 0, 0, 0) <= 0) {
	ml_printf ("Cannot send message to my neighbor %s\n",
		   torus->links[i][1].peer_host);
	return 0;
      }
    
      /* add this file descritpor to the client table of the server */
      ml_add_event_handler (client_table, linkfd,
			    torus->links[i][1].peer_host, 
			    ML_S_PORT,
			    ml_handle_socket_event, 0);
    }
  }

  /* add timer routine */
  ml_add_timer_handler (torus, 
			client_table, 1000, ml_check_link_test_code_timer, 0);

  return 1;
}

static void
ml_reset_link_flags (ml_torus_t*  torus)
{
  int i;

  for (i = 0; i < torus->dimension; i++) {
    torus->links[i][0].test_code = -1;
    torus->links[i][0].s_child = 0;
    torus->links[i][0].s_child_ct = 0;
    torus->links[i][0].r_child = 0;
    torus->links[i][0].r_child_ct = 0;

    torus->links[i][1].test_code = -1;
    torus->links[i][1].s_child = 0;
    torus->links[i][1].s_child_ct = 0;
    torus->links[i][1].r_child = 0;
    torus->links[i][1].r_child_ct = 0;

  }
}

/**
 * An event handler that handles pipe information for child process
 */
static int
ml_single_receiver_handler (ml_torus_t* torus,
			    ml_client_info_t* client,
			    ml_client_table_t* client_table,
			    int cfd,
			    void* arg)
{
  char buffer[4096];
  int nbytes, status, cid;
  ml_data_t* recvdata = (ml_data_t *)arg;


  /* Wait for the process to end and do not care the result */
  nbytes = read (cfd, buffer, 4096);

  /* Now the child process should finished, clean up */
  cid = waitpid (torus->links[recvdata->axis][recvdata->direction].r_child,
		 &status, 0);

  /* we do not care what we receive */
  torus->links[recvdata->axis][recvdata->direction].r_child = 0;
  torus->links[recvdata->axis][recvdata->direction].r_child_ct = 0;

  ml_free_data (recvdata);

  /* we do close this pipe */
  return 0;
}

/**
 * A host starts a link test receiver code
 */
static int
ml_start_single_link_receiver (int rfd, ml_torus_t* torus,
			       ml_client_table_t* table,
			       ml_data_t* recvdata)
{
  char hostname[128], buffer[4096], command[512];
  int  nbytes, status, cid;

  /* First creta a pipe to communicate with soon to be
   * launched child process
   */
  int comm_pipe[2];
  int child;

  /* Get this host name */
  gethostname (hostname, sizeof(hostname) - 1);

  /* comm_pipe[0] is for read, comm_pipe[1] is for write */
  if (pipe (comm_pipe) != 0)
    return -1;

  /* Now launch a child process */
  child = fork ();
  if (child == 0) {
    /* This is a lauched child process */
        /* First close read end of pipe */
    close (comm_pipe[0]);
    
    /* close all stdout, stderr */
    close (1); close (2);
      
    /* duplicate stdout and stderr to comm_pipe[1] */
    dup2 (comm_pipe[1], 1);
    dup2 (comm_pipe[1], 2);
    close (comm_pipe[1]); 

    sprintf (command, "/usr/local/bin/mvia_link_test %s r %s",
	     torus->links[recvdata->axis][recvdata->direction].eth_device,
	     torus->links[recvdata->axis][recvdata->direction].peer_via_host);
    
    execlp ("/bin/sh", "sh", "-c", command, 0);
    exit (127);
  }
  else {
    /* This is the parent process */
    close (comm_pipe[1]);

    /* remember the child process id */
    torus->links[recvdata->axis][recvdata->direction].r_child = child;
    torus->links[recvdata->axis][recvdata->direction].r_child_ct = 
      ml_current_time ();

    /* Read output from child process */
    nbytes = read (comm_pipe[0], buffer, 4096);
    if (nbytes > 0 && buffer[0] == 'R') {
      if (ml_write_data (rfd, ML_CHECK_SINGLE_LINK_READY, 0, recvdata->axis,
			 recvdata->direction == 0 ? 1 : 0, 0, 0) <= 0)
	return 0;

      /* Now change timeout value to 1 second so that we can check
       * child process
       */
      ml_add_timer_handler (torus, table, 1000, 
			    ml_check_link_receiver_timer, 0);

      /* Now add event handler for read pipe */
      ml_add_event_handler (table, comm_pipe[0], 
			    hostname, 0, 
			    ml_single_receiver_handler,
			    (void *)ml_dup_data(recvdata));
			    

    }
    else {
      /* Now wait for child process to clean up */
      cid = waitpid (child, &status, 0);

      /* Now child process is cleaned up */
      torus->links[recvdata->axis][recvdata->direction].r_child = 0;
      torus->links[recvdata->axis][recvdata->direction].r_child_ct = 0;

      /* The child process fail to start */
      if (ml_write_data (rfd, ML_CHECK_SINGLE_LINK_FAILED, 0, recvdata->axis,
			 recvdata->direction == 0 ? 1 : 0, 0, 0) <= 0)
	return 0;
    }
  }

  return 1;
}

/**
 * Check everylink to find out whether test is done
 *
 * return 1: all test are done
 * return 0: not done
 */
static int
ml_check_link_test_code (ml_torus_t* torus)
{
  int first, i, finished;
  char buffer[1024], sbuf[128];

  /* if torus is not in the link test mode, we just return 1 */
  if (torus->test_fd == -1)
    return 1;
      

  /* Check whether every link is tested correctly and finished */
  finished = 1;
  for (i = 0; i < torus->dimension; i++) {
    if (torus->links[i][0].test_code == -1) {
      finished = 0;
      break;
    }
    if (torus->links[i][1].test_code == -1) {
      finished = 0;
      break;
    }
  }

  if (finished) {
    first = 1;
    for (i = 0; i < torus->dimension; i++) {
      if (first) {
	sprintf (buffer, "%s %d\n", torus->links[i][0].eth_device,
		 torus->links[i][0].test_code);
	first = 0;
      }
      else {
	sprintf (sbuf, "%s %d\n", torus->links[i][0].eth_device,
		 torus->links[i][0].test_code);
	strcat (buffer, sbuf);
      }
      sprintf (sbuf, "%s %d\n", torus->links[i][1].eth_device,
	       torus->links[i][1].test_code);
      strcat (buffer, sbuf);
    }
    
    /* Now send information back to the original client */
    if (ml_write_data (torus->test_fd, ML_CHECK_LINK_DONE, 0, 
		       0, 0, strlen (buffer), buffer) <= 0) {
      ml_printf ("cannot sendout checklink done to client\n");
    }

    /* Now reset torus test_fd to -1 to signal this is done */
    torus->test_fd = -1;
  }

  return finished;
}

/**
 * Timer routine to check whether our test code is done
 */
static int  
ml_check_link_test_code_timer (ml_torus_t* torus,
			       ml_client_table_t* table,
			       double* next_to_fire,
			       void* arg)
{
  int i, allfinished;
  double currt;

  /* Check whether receiver process is finished or not */
  currt = ml_current_time ();

  /* Check whether sender process is finished or not */
  for (i = 0; i < torus->dimension; i++) {
    if (torus->links[i][0].test_code == -1 && 
	torus->links[i][0].s_child != 0) {
      if (currt - torus->links[i][0].s_child_ct >= ML_MAX_TIME) {
	kill (torus->links[i][0].s_child, SIGTERM);
	torus->links[i][0].s_child = 0;
	torus->links[i][0].s_child_ct = 0;
	torus->links[i][0].test_code = 1;
      }
    }
    if (torus->links[i][1].test_code == -1 && 
	torus->links[i][1].s_child != 0) {
      if (currt - torus->links[i][1].s_child_ct >= ML_MAX_TIME) {
	kill (torus->links[i][1].s_child, SIGTERM);
	torus->links[i][1].s_child = 0;
	torus->links[i][1].s_child_ct = 0;
	torus->links[i][1].test_code = 1;
      }
    }
  }

  /* Check whether all receving process is done */
  allfinished = ml_check_link_test_code (torus);
  if (allfinished) {
    return 0;
  }
  else {
    /* schedule next time out 1000 milli-seconds */
    *next_to_fire = 1000.0;
    return 1;
  }
}


/**
 * Check whether all mvia link test receiver finished or not
 * return 1: finished
 * return 0: not done
 */
static int
ml_recv_children_done (ml_torus_t* torus)
{
  int i, allfinished;

  allfinished = 1;

  for (i = 0; i < torus->dimension; i++) {
    if (torus->links[i][0].r_child != 0) {
      allfinished = 0;
      break;
    }
    if (torus->links[i][1].r_child != 0) {
      allfinished = 0;
      break;
    }
  }
  return allfinished;
}

/**
 * Check whether all link receivers are finished
 */
static int
ml_check_link_receiver_timer (ml_torus_t* torus,
			      ml_client_table_t* table,
			      double* next_to_fire,
			      void* arg)
{
  int i, pstatus, allfinished, cfinished;
  pid_t chid;
  double currt;
  
  /* Check whether receiver process is finished or not */
  currt = ml_current_time ();

  for (i = 0; i < torus->dimension; i++) {
    if (torus->links[i][0].r_child != 0) {
      cfinished = 0;

      pstatus = 0;
      chid = waitpid (torus->links[i][0].r_child, &pstatus, 
		      WNOHANG);

      if (chid == -1 && errno == ECHILD) 
	cfinished = 1;
      else if (chid == torus->links[i][0].r_child && WIFEXITED(&pstatus))
	cfinished = 1;

      if (cfinished) {
	torus->links[i][0].r_child = 0;
	torus->links[i][0].r_child_ct = 0;	
      }
      else {
	/* This child is not finished yet */
	if (currt - torus->links[i][0].r_child_ct >= ML_MAX_TIME) {
	  kill (torus->links[i][0].r_child, SIGTERM);
	  torus->links[i][0].r_child = 0;
	  torus->links[i][0].r_child_ct = 0;
	}
      }
    }
    if (torus->links[i][1].r_child != 0) {
      cfinished = 0;
      chid = waitpid (torus->links[i][1].r_child, &pstatus, 
		      WNOHANG);
      if (chid == -1 && errno == ECHILD) 
	cfinished = 1;
      else if (chid == torus->links[i][1].r_child && WIFEXITED(&pstatus))
	cfinished = 1;

      if (cfinished) {
	torus->links[i][1].r_child = 0;
	torus->links[i][1].r_child_ct = 0;	
      }
      else {
	/* This child is not finished yet */
	if (currt - torus->links[i][1].r_child_ct >= ML_MAX_TIME) {
	  kill (torus->links[i][1].r_child, SIGTERM);
	  torus->links[i][1].r_child = 0;
	  torus->links[i][1].r_child_ct = 0;
	}
      }
    }
  }


  allfinished = ml_recv_children_done (torus);
  if (allfinished) {
    return 0;
  }
  else {
    /* schedule next time out 1000 milli-seconds */
    *next_to_fire = 1000.0;
    return 1;
  }
}


/**
 * MVIA Sender Pipe Event Handler
 */
static int
ml_sender_link_handler (ml_torus_t* torus,
			ml_client_info_t* client,
			ml_client_table_t* client_table,
			int cfd,
			void* arg)
{
  ml_data_t* recvdata = (ml_data_t *)arg;
  char buffer[4096];
  int  nbytes, status, cid;


  /* Read output from child process */
  nbytes = read (cfd,  buffer, 4096);

  /* collect child process */
  cid = waitpid (torus->links[recvdata->axis][recvdata->direction].s_child,
		 &status, 0);

  if (nbytes > 0 && buffer[0] == 'O') {
    /* Success */
    torus->links[recvdata->axis][recvdata->direction].test_code = 0;
    torus->links[recvdata->axis][recvdata->direction].s_child = 0;
    torus->links[recvdata->axis][recvdata->direction].s_child_ct = 0;
  }
  else {
    /* remember the child process id */
    torus->links[recvdata->axis][recvdata->direction].test_code = 1;
    torus->links[recvdata->axis][recvdata->direction].s_child = 0;
    torus->links[recvdata->axis][recvdata->direction].s_child_ct = 0;
  }

  /* free memory */
  ml_free_data (recvdata);

  /* this pipe is closed */
  return 0;
}

/**
 * This node received its neighbor's message about being ready to do test
 * single via link
 */
static int
ml_start_test_link (int rfd, ml_torus_t* torus, 
		    ml_client_table_t* client_table, 
		    ml_data_t* recvdata)
{
  char hostname[128], command[512];

  /* First creta a pipe to communicate with soon to be
   * launched child process
   */
  int comm_pipe[2];
  int child;

  /* get my local hostname */
  gethostname (hostname, sizeof(hostname) - 1);

  /* Now check what direction is ready */

  /* set link test flag */
  if (  torus->links[recvdata->axis][recvdata->direction].test_code != 2)
    torus->links[recvdata->axis][recvdata->direction].test_code = -1;

  /* Now launch mvia send code */
  /* comm_pipe[0] is for read, comm_pipe[1] is for write */
#if 1
  if (pipe (comm_pipe) != 0)
    return -1;
#endif

#if 0
  if (socketpair (PF_UNIX, SOCK_STREAM, AF_LOCAL, comm_pipe) != 0)
    return -1;
#endif

  /* Now launch a child process */
  child = fork ();
  if (child == 0) {
    /* This is a lauched child process */
    
    /* close all stdout, stderr */
    close (0); close (1); close (2); 
      
    /* duplicate stdout and stderr to comm_pipe[1] */
    dup2 (comm_pipe[0], 0);
    dup2 (comm_pipe[1], 1);
    dup2 (comm_pipe[1], 2);

    close (comm_pipe[1]);
    close (comm_pipe[0]);


    sprintf (command, "/usr/local/bin/mvia_link_test %s s %s",
	     torus->links[recvdata->axis][recvdata->direction].eth_device,
	     torus->links[recvdata->axis][recvdata->direction].peer_via_host);

    execlp ("/bin/sh", "sh", "-c", command, 0);

    exit (127);
  }
  else {
    /* This is the parent process */
    close (comm_pipe[1]);

    torus->links[recvdata->axis][recvdata->direction].s_child = child;
    torus->links[recvdata->axis][recvdata->direction].s_child_ct = 
      ml_current_time ();

    /* add this pipe descriptor to the event handler */
    ml_add_event_handler (client_table, comm_pipe[0], hostname, 0,
			  ml_sender_link_handler, 
			  (void *)ml_dup_data (recvdata));

  }

  /* Check whether every link is tested correctly and finished */
  ml_check_link_test_code (torus);

  /* return 0 to close this socket since we are done with this */
  return 0;
}


/**
 * This node received its neighbor's message about being ready to do test
 * single via link
 */
static int
ml_test_link_failed (int rfd, ml_torus_t* torus, 
		     ml_client_table_t* client_table, 
		     ml_data_t* recvdata)
{
  /* Now check what direction is ready */

  /* set link test flag */
  torus->links[recvdata->axis][recvdata->direction].test_code = 1;

  /* Check whether every link is tested correctly and finished */
  ml_check_link_test_code (torus);

  /* Close the socket connection since we have done with this */
  return 0;
}

/**
 * Reload a configuration file embedded inside received data
 */
static int
ml_reload_conf (int rfd, ml_torus_t* torus,
		ml_data_t* recvdata)
{
  int nbytes;
  char* filename = recvdata->buffer;

  if (ml_reload_conf_file (filename, torus) == 0) 
    /* Good, reload ok */
    nbytes = ml_write_data (rfd, ML_RELOAD_CONF, 0, 
			    0, 0, 0, 0);
  else
    nbytes = ml_write_data (rfd, ML_RELOAD_CONF, -1, 
			    0, 0, 0, 0);    
#if 0
  dump_torus_info (torus);
#endif

  return 1;
}

/**
 * Major part of code to handle network request from clients
 *
 * return 0 or -1 to signal that the connnect clients is finished
 *
 */
int
ml_handle_socket_event (ml_torus_t* torus,
			ml_client_info_t* client,
			ml_client_table_t* client_table,
			int cfd,
			void* arg)
{
  int rfd, nbytes, status, i, num_devices;
  char* eth_devices[10];
  ml_data_t recvdata;
  char* recvbuff;

  /* connected socket file descriptor */
  rfd = client->cfd;

  /* first read first size data */
  nbytes = read (rfd, (void *)&recvdata, ML_DATA_SIZE);
  
  if (nbytes <= 0)
    return 0;

  /* convert and check data integrity */
  if (ml_check_recvdata (&recvdata) != 0) 
    return -1;

  if (recvdata.buflen > 0) {
    recvbuff = (char *)malloc (recvdata.buflen * sizeof(char));
    if (!recvbuff) {
      ml_printf ("Cannot allocate space for %d bytes of char \n", 
		 recvdata.buflen);
      return -1;
    }

    /* Now read all data in */
    if (ml_read_nbytes (rfd, recvbuff, recvdata.buflen) != 
	recvdata.buflen) {
      ml_printf ("Reading error from host %s for %d bytes \n",
		 client->host, recvdata.buflen);
      free (recvbuff);

      return -1;
    }
    recvdata.buffer = recvbuff;
  }

  /* Now check operation */
  switch (recvdata.op) {
  case ML_RELOAD_CONF:
    if (torus->test_fd != -1) 
      /* Test already in progress send error back to the client */
      status = ml_write_data (rfd, ML_RELOAD_CONF, -1, 0, 0, 0, 0);
    else 
      status = ml_reload_conf (rfd, torus, &recvdata);
    break;
  case ML_CHECK_STATS:
    /* First find out all ethernet devices */
    num_devices = 10;
    ml_get_eth_devices (torus, eth_devices, &num_devices);
    status = ml_check_eth_status (rfd, eth_devices, num_devices);
    /* free memory */
    for (i = 0; i < num_devices; i++)
      free (eth_devices[i]);
    break;
  case ML_SET_LINK_SPEED:
    /* First find out all ethernet devices */
    num_devices = 10;
    ml_get_eth_devices (torus, eth_devices, &num_devices);

    status = ml_set_link_speed (rfd, eth_devices, num_devices);
    /* free memory */
    for (i = 0; i < num_devices; i++)
      free (eth_devices[i]);
    break;
  case ML_CHECK_LINK_START:
    if (torus->test_fd != -1) {
      /* Test already in progress send error back to the client */
      status = ml_write_data (rfd, ML_CHECK_LINK_IN_PROG, -1, 0, 0, 0, 0);
    }
    else {
      /* Now set test ready and tested flag to zero */
      ml_reset_link_flags (torus);

      /* Try to memorize client fd */
      torus->test_fd = rfd;

      /* Recevied a request from a client to start testing
       * every single link
       */
      status = ml_check_link_req (client_table, torus);
    
      /* Check whether every link test is done already */
      ml_check_link_test_code (torus);
    }
    break;
  case ML_CHECK_SINGLE_LINK:
    /* Received a check single link request */
    status = ml_start_single_link_receiver (rfd, torus, client_table,
					    &recvdata);
    break;
  case ML_CHECK_SINGLE_LINK_READY:
    /* One of the neighbor has via link test code running */
    status = ml_start_test_link (rfd, torus, client_table, &recvdata);
    break;
  case ML_CHECK_SINGLE_LINK_FAILED:
    /* One of the neighbor has via link test code running */
    status = ml_test_link_failed (rfd, torus, client_table, &recvdata);
    break;
  default:
    ml_printf ("Opration %d not yet implemented \n", recvdata.op);
    status = -1;
    break;
  }

  if (recvdata.buffer)
    free (recvdata.buffer);

  return status;
}
