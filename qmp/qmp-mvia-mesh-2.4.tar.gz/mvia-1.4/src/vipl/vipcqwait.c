/* vipcqwait.c
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/ioctl.h>

#include "vipl_private.h"

VIP_RETURN
VipCQWait(IN   	VIP_CQ_HANDLE		CQHandle,
	  IN   	VIP_ULONG		TimeOut,
	  OUT	VIP_VI_HANDLE		*ViHandle,
	  OUT	VIP_BOOLEAN		*RecvQueue)
{
    VIP_CQ_WAIT_ARGS		VipCQWaitArgs;
    VIP_CQ_PRE_WAIT_ARGS	VipCQPreWaitArgs;
    VIP_RETURN			Status;
    int i;


    if(CQHandle->TypeId != VIP_TYPE_CQ_HANDLE) {
	return VIP_INVALID_PARAMETER;
    }

    for(i=0; i < CQHandle->SpinCount; i++) {
	if(VipCQDone(CQHandle, ViHandle, RecvQueue) == VIP_SUCCESS) {
	    return VIP_SUCCESS;
	}
    }

    VipCQWaitArgs.CQHandle = CQHandle->KernCQHandle;
    VipCQWaitArgs.Timeout = TimeOut;

    VipCQPreWaitArgs.CQHandle = CQHandle->KernCQHandle;

    /* Loop until timeout occurs */
    do {
	Status = ioctl(CQHandle->NicHandle->DeviceDesc,
		       VIP_CQ_PRE_WAIT, &VipCQPreWaitArgs);

	if(VipSystemError(Status)) {
	    PERROR("VipCQPreWait: ioctl");
	    return VipSystemReturn(Status);
	}

	if(Status != VIP_SUCCESS) {
	    return Status;
	}

	Status = VipCQDone(CQHandle, ViHandle, RecvQueue);
	if(Status != VIP_NOT_DONE) {
	    return Status;
	}

	Status = ioctl(CQHandle->NicHandle->DeviceDesc,
		       VIP_CQ_WAIT, &VipCQWaitArgs);

	if(VipSystemError(Status)) {
	    PERROR("VipCQWait: ioctl");
	    return VipSystemReturn(Status);
	}

	Status = VipCQDone(CQHandle, ViHandle, RecvQueue);
	if(Status != VIP_NOT_DONE) {
	    return Status;
	}
    } while(VipCQWaitArgs.Timeout);

    return VIP_TIMEOUT;
}
