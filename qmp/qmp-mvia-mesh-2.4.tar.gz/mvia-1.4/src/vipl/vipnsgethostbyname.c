/* vipnsgethostbyname.c
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include "vipl_private.h"


VIP_RETURN 
VipNSGetHostByName(VIP_NIC_HANDLE	NicHandle,
		   VIP_CHAR		*Name,
		   VIP_NET_ADDRESS	*Address,
		   VIP_ULONG		NameIndex)
{
    VIP_NS_ENTRY	*NSEntry;
    VIP_ULONG		Index = 0;

    if(NicHandle->TypeId != VIP_TYPE_NIC_HANDLE) {
	return VIP_INVALID_PARAMETER;
    }
    
    if(!NicHandle->NSList) {
	return VIP_ERROR_NAMESERVICE;
    }


    NSEntry = NicHandle->NSList;
    while(NSEntry) {
	if(!strcasecmp(NSEntry->HostName, Name)) {
	    if(Index++ == NameIndex) {
		if(Address->HostAddressLen < NSEntry->Address.HostAddressLen) {
		    return VIP_INVALID_PARAMETER;
		}
		VipAddrCopy(Address, (VIP_NET_ADDRESS *)&NSEntry->Address);
		return VIP_SUCCESS;
	    }
	}
	NSEntry = NSEntry->Next;
    }

    return VIP_ERROR_NAMESERVICE;
}

    

