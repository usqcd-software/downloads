/** \file vipl_private.h
 * Defines the private implementaion of the M-VIA VIPL API.
 *
 * Contains data structures and constants used internally by the M-VIA
 * VI Provider Library as well as data structures which are shared with
 * the M-VIA Kernel Agent.
 *
 * Users writing VI applications should not make use of the data structures
 * and constants defined in this file.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

/* XXX: do proper __KERNEL__ ifdefs */

#ifndef _VIPL_PRIVATE_H
#define _VIPL_PRIVATE_H

#include "vipl.h"

#ifndef __KERNEL__
# include <pthread.h>
# include <string.h>
#else
# include <linux/string.h>
#endif

#if 0
/* enable to receive perror error messages resulting
 * from a failed system call.
 */
#define PERROR(x) perror(x)
#else
#define PERROR(x)
#endif

/** \def VIP_NET_ADDR_MAX_SIZE
 * The maximum size of the HostAddress filed of a  VIP_NET_ADDRESS.
 */
#define VIP_NET_ADDR_MAX_SIZE 64

/** \def VIP_SPIN_COUNT
 * Number of times to poll for descriptor completion before blocking
 * in the various VipWait routines.
 *
 * The M-VIA VIPL performs a rudementary form of implicit coscheduling.
 * Ideally, this value would be set such that the number of times a node
 * polled for completion would be just over the round trip time of a 
 * VIA packet.  Methods for dynamically determining this value should
 * be investigated.
 *
 * Currently, if on a multiprocessor system and the connection 
 * is local to the machine, the spincount will be reset to 1.
 */
#define VIP_SPIN_COUNT 50000

/** \def VIP_NO_CQ
 * Used a a NULL VIPK_CQ_HANDLE in the VIP_CREATE_VI_ARGS structure.
 *
 * \bug Consider renaming to VIPK_CQ_NULL_HANDLE.
 */
#define VIP_NO_CQ MAXINT


/** \def VIP_NS_DEFAULT_HOSTFILE
 * The default host file to be used by the name service routines.
 */
#ifdef MVIA_NS_DEFAULT_HOSTFILE
#define VIP_NS_DEFAULT_HOSTFILE MVIA_NS_DEFAULT_HOSTFILE
#else
#define VIP_NS_DEFAULT_HOSTFILE "/etc/vip_hosts"
#endif 

/**
 * Run-time type information for VIPL handles.
 *
 * The VIPL Conformance Tests require that the VIPL functions detect 
 * when a bad handle has been passed to them.  A VIP_TYPE_ID field
 * is thus added to each VIPL handle in order to perform run-time
 * type checking.
 */
typedef unsigned int 	VIP_TYPE_ID;

#define VIP_TYPE_INVALID	0x00000000
#define VIP_TYPE_NIC_HANDLE	0xABCD0000
#define VIP_TYPE_VI_HANDLE	0xABCD0001
#define VIP_TYPE_CONN_HANDLE	0xABCD0002
#define VIP_TYPE_CQ_HANDLE	0xABCD0003

/** 
 * A VIP_NET_ADDRESS of maximum size.
 *
 * This is used in several of the private data structures to ensure that 
 * sufficient space is allocated for VIP_NET_ADDRESSes.  This has proven
 * handy, especially when passing addresses to/from the kernel; however, 
 * functions and data structures which utilize VIP_NET_MAX_ADDRESS should be 
 * redesigned to support variable sized addresses.
 *
 * @see VIP_NET_ADDRESS
 */
typedef struct {
    VIP_UINT16		HostAddressLen;
    VIP_UINT16		DiscriminatorLen;
    VIP_UINT8		HostAddress[VIP_NET_ADDR_MAX_SIZE];
} VIP_NET_MAX_ADDRESS;

/**
 * The type of doorbell operation to perform when posting a descriptor.
 *
 * @see _VIP_NIC
 */
typedef enum {
    VIP_DOORBELL_REGISTER,
    VIP_DOORBELL_FAST_TRAP,
    VIP_DOORBELL_IOCTL
} VIP_DOORBELL;
	

/* kernel handles */

/** M-VIA Kernel Agent Completion Queue Handle */
typedef VIP_UINT32	VIPK_CQ_HANDLE;

/** M-VIA Kernel Agent VI Handle */
typedef VIP_UINT32	VIPK_VI_HANDLE;

/** M-VIA Kernel Agent NIC Handle */
typedef VIP_UINT32	VIPK_NIC_HANDLE;

/** M-VIA Kernel Agent Connection Handle. */
typedef VIP_UINT32	VIPK_CONN_HANDLE;


/* integer type with same size as user handles */
/* XXX: is sizeof(void *) == sizeof(unsigned long) on ALL architectures? */
typedef unsigned long	VIPK_UINTPTR;


/** Contains translation between a hostname and a hardware address. */
typedef struct _VIP_NS_ENTRY {
    struct _VIP_NS_ENTRY *Next;
    VIP_CHAR		*HostName;
    VIP_NET_MAX_ADDRESS Address;
} VIP_NS_ENTRY;

#ifndef __KERNEL__
/** 
 * Internal VIPL representation of a VIP_NIC_HANDLE. 
 *
 * \bug The NicAddr field is historical and is now only used
 * by the VipQueryNic() function.  Remove this attribute and 
 * modify VipQueryNic().
 */
typedef struct _VIP_NIC {
    /** Run-time type information */
    VIP_TYPE_ID		TypeId;

    /** file descriptor return by open() call to device node */
    int			DeviceDesc;

    /** M-VIA Kernel Agent NIC Handle */
    VIPK_NIC_HANDLE	KernNicHandle;

    /** Type of doorbell used by this NIC */
    VIP_DOORBELL	DoorbellType;

    /** Hardware address of the NIC */
    VIP_UINT8		NicAddr[VIP_NET_ADDR_MAX_SIZE];

    /** Linked list of hostname/address entries */
    VIP_NS_ENTRY	*NSList;

    /** Error handler thread */
    pthread_t		ErrorThread;

    /** User supplied context from VipErrorCallback() */
    VIP_PVOID		Context;

    /** User supplied handler from VipErrorCallback() */
    void 		(*ErrorCallback)(IN VIP_PVOID Context,
					 IN VIP_ERROR_DESCRIPTOR *ErrorDesc);

} VIP_NIC;
#endif

 
#ifndef __KERNEL__
/**  Commands for a {CQ,Send,Recv}Notify. */
typedef enum {
    MVIA_NOTIFY_RUN,
    MVIA_NOTIFY_IDLE,
    MVIA_NOTIFY_QUIT
} mvia_notify_cmd_t;

/**  Types for a {CQ,Send,Recv}Notify. */
typedef enum {
    MVIA_NOTIFY_CQ,
    MVIA_NOTIFY_RECV,
    MVIA_NOTIFY_SEND
} mvia_notify_type_t;

/** Internal M-VIA structure for a {CQ,Send,Recv}Notify request. */
typedef struct _MVIA_NOTIFY_REQ {
    VIP_PVOID			Context;
    VIP_PVOID			CallBack;
    struct _MVIA_NOTIFY_REQ	*Next;
} mvia_notify_req_t;

/** Internal M-VIA structure for a Notify. */
typedef struct mvia_notify_s {
    pthread_t		Thread;
    pthread_mutex_t	Mutex;
    pthread_cond_t	Wakeup;
    pthread_cond_t	Idle;
    VIP_BOOLEAN		IsIdle;
    VIP_PVOID		Handle;
    mvia_notify_req_t	*Head;
    mvia_notify_req_t	*Tail;
    mvia_notify_cmd_t	Command;
    void		(*Run)(struct mvia_notify_s *Notify);
} mvia_notify_t;
#endif


#ifndef __KERNEL__
/** Interal VIPL representation of a VIP_VI_HANDLE */
typedef struct _VIP_VI {
    /** Run-time type information */
    VIP_TYPE_ID		TypeId;

    /** VIPL NIC Handle the VI for this VI */
    VIP_NIC_HANDLE	NicHandle;

    /** M-VIA Kernel Agent NIC Handle for this VI */
    VIPK_NIC_HANDLE	KernNicHandle;

    /** M-VIA Kernel Agent VI Handle for this VI */
    VIPK_VI_HANDLE   	KernViHandle;

    /** Number of times the wait routines will spin before blocking. */
    VIP_UINT32		SpinCount;

    /** 
     * Type of doorbell used by this VI.
     * Replicated from VIP_NIC for performance.
     */
    VIP_DOORBELL	DoorbellType;

    /** If non-NULL, refers to the Completion Queue associated with 
     * the VI Send Work Queue.
     */
    VIP_CQ_HANDLE	SendCQHandle;

    /** If non-NULL, refers to the Completion Queue associated with the 
     * VI Receive Work Queue.
     */
    VIP_CQ_HANDLE	RecvCQHandle;

    /** If non-NULL, points to the first descriptor of the VI Receive
     * Work Queue.
     */
    VIP_DESCRIPTOR	*RecvQHead;

    /** If non-NULL, points to the last descriptor of the VI Recive 
     * Work Queue.
     */
    VIP_DESCRIPTOR	*RecvQTail;

    /** If non-NULL, points to the first descriptor of the 
     * VI Send Work Queue. 
     */
    VIP_DESCRIPTOR	*SendQHead;

    /** If non-NULL, points to the last descriptor of the VI
     * Receive Work Queue.
     */
    VIP_DESCRIPTOR	*SendQTail;

    /** If supported by the NIC, points to the receive Doorbell for this VI. */
    void 		*RecvRegister;

    /** If supported by the NIC, points to the send Doorbell for this VI. */
    void		*SendRegister;

    /** If non-NULL, points to the notifier for the Receive Work Queue */
    mvia_notify_t	*RecvNotify;

    /** If non-NULL, points to the notifier for the Send Work Queue */
    mvia_notify_t	*SendNotify;

    /** Arbitrary data belonging to the user application */
    VIP_PVOID64		AppData;
} VIP_VI;
#endif


/** Internal VIPL representation of a VIP_CONN_HANDLE */
typedef struct _VIP_CONN {
    /** Run-time type information */
    VIP_TYPE_ID		TypeId;

    /** VIPL NIC Handle associated with the connection request */
    VIP_NIC_HANDLE	NicHandle;

    /** M-VIA Kernel Agent Connection Handle for the connection request */
    VIPK_CONN_HANDLE	KernConnHandle;

    /* Temporary until spin times are determined dynamically, 
     * or provided by the kernel.  Needed because the local and
     * remote addresses of a vi are not known at accept time and
     * can not be queried.
     */
    VIP_BOOLEAN		Loopback;
} VIP_CONN;


/** \page cq_implementation Completion Queue Implementation
 * Completion queues. 
 */

/** \def VIP_CQ_STATUS_DONE 
 * Indicates that the M-VIA Kernel Agent has marked the Completion Queue
 * entry as complete.
 */
#define VIP_CQ_STATUS_DONE 0x00000001

/** \def VIP_CQ_STATUS_RECV
 * If VIP_TRUE, indicates that the completion was associate with the receive
 * queue of a VI.
 */
#define VIP_CQ_STATUS_RECV 0x00000002

/** A single Completion Queue entry. */
typedef struct {
    /** The VIPL VI Handle the completion event is associated with. */
    VIP_VI_HANDLE	Vi;
    /** The completion status.
     * @see #VIP_CQ_STATUS_DONE 
     * @see #VIP_CQ_STATUS_RECV
     */
    VIP_UINT32 		Status;
} VIP_CQ_ENTRY;

#ifndef __KERNEL__
/** VIPL Completion Queue structure.
 *
 * This is the VIPL control structure for a Completion Queue.  The 
 * M-VIA Kernel Agent modifies the VIP_CQ_ENTRY elements as descriptors
 * are completed.  See \ref cq_implementation for more details.
 */
typedef struct _VIP_CQ {
    /** Run-time type information */
    VIP_TYPE_ID			TypeId;
    /** Number of times the wait routines will spin before blocking. */
    VIP_UINT32			SpinCount;
    /** Shared circular queue of completion entries with M-VIA Kernel Agent. */
    VIP_CQ_ENTRY       		*Entry;
    /** Memory Handle for the completion entries. */
    VIP_MEM_HANDLE		MemHandle;
    /** Protection Tag for the completion entries. */
    VIP_PROTECTION_HANDLE 	Ptag;
    /** Number of entries in the Completion Queue. */
    VIP_UINT32			EntryCount;
    /** Next entry to pull from queue. */
    VIP_UINT32			Head;
    /** VIPL NIC Handle associated with the Completion Queue. */
    VIP_NIC_HANDLE		NicHandle;
    /** M-VIA Kernel Agent Completion Queue Handle */
    VIPK_CQ_HANDLE		KernCQHandle;
    /** If non-NULL, points to the notifier for the Completion Queue */
    mvia_notify_t		*CQNotify;
} VIP_CQ;
#endif

/** Open NIC arguments for ioctl. */    
typedef struct {
    VIP_NIC_HANDLE	NicUserHandle;
    VIPK_NIC_HANDLE	*NicKernHandle;
} VIP_OPEN_NIC_ARGS;

/** Create VI arguments for ioctl. */
typedef struct {
    VIP_VI_ATTRIBUTES	*ViAttribs;
    VIPK_CQ_HANDLE   	SendCQHandle;
    VIPK_CQ_HANDLE	RecvCQHandle;
    void 		**RecvRegister;
    void		**SendRegister;
    VIP_DOORBELL	*DoorbellType;
    VIP_VI_HANDLE      	UserViHandle;
    VIPK_VI_HANDLE    	*KernViHandle;
} VIP_CREATE_VI_ARGS;

/** Destroy VI arguments for ioctl. */
typedef struct {
    VIPK_VI_HANDLE	ViHandle;
} VIP_DESTROY_VI_ARGS;

/** ConnectWait arguments for ioctl. */
typedef struct {
    VIP_ULONG		Timeout;
    VIP_NET_MAX_ADDRESS	LocalAddr;
    VIP_NET_MAX_ADDRESS	RemoteAddr;
    VIP_VI_ATTRIBUTES	*RemoteViAttribs;
    VIPK_CONN_HANDLE  	*ConnHandle;
} VIP_CONNECT_WAIT_ARGS;

/** ConnectAccept arguments for ioctl. */
typedef struct {
    VIPK_VI_HANDLE    	ViHandle;
    VIPK_CONN_HANDLE   	ConnHandle;
} VIP_CONNECT_ACCEPT_ARGS;

/** ConnectReject arguments for ioctl. */
typedef struct {
    VIPK_CONN_HANDLE	ConnHandle;
} VIP_CONNECT_REJECT_ARGS;

/** ConnectRequest arguments for ioctl. */
typedef struct {
    VIPK_VI_HANDLE   	ViHandle;
    VIP_NET_MAX_ADDRESS	LocalAddr;
    VIP_NET_MAX_ADDRESS	RemoteAddr;
    VIP_ULONG		Timeout;
    VIP_VI_ATTRIBUTES	*RemoteViAttribs;
} VIP_CONNECT_REQUEST_ARGS;

/** Disconnect arguments for ioctl. */
typedef struct {
    VIPK_VI_HANDLE	ViHandle;
} VIP_DISCONNECT_ARGS;

/** ConnectPeerRequest arguments for ioctl. */
typedef struct {
    VIPK_VI_HANDLE   	ViHandle;
    VIP_NET_MAX_ADDRESS	LocalAddr;
    VIP_NET_MAX_ADDRESS	RemoteAddr;
    VIP_ULONG		Timeout;
} VIP_PEER_REQUEST_ARGS;

/** ConnectPeer{Done,Wait} arguments for ioctl. */
typedef struct {
    VIPK_VI_HANDLE   	ViHandle;
    VIP_VI_ATTRIBUTES	*RemoteViAttribs;
    VIP_BOOLEAN		Block;
} VIP_PEER_DONE_ARGS;

/** CreatePtag arguments for ioctl. */
typedef struct {
    VIP_PROTECTION_HANDLE	Ptag;
} VIP_CREATE_PTAG_ARGS;

/** DestroyPtag arguemts for ioctl. */
typedef struct {
    VIP_PROTECTION_HANDLE	Ptag;
} VIP_DESTROY_PTAG_ARGS;

/** RegisterMem arguments for ioctl. */
typedef struct {
    VIP_PVOID			VirtualAddress;
    VIP_ULONG			Length;
    VIP_MEM_ATTRIBUTES		MemAttribs;
    VIP_MEM_HANDLE		MemHandle;
} VIP_REGISTER_MEM_ARGS;

/** DeregisterMem arguments for ioctl. */
typedef struct {
    VIP_PVOID			VirtualAddress;
    VIP_MEM_HANDLE		MemHandle;
} VIP_DEREGISTER_MEM_ARGS;

/** Post descriptor arguments for ioctl. */
typedef struct {
    VIPK_VI_HANDLE     	ViHandle;
    VIP_DESCRIPTOR 	*Desc;
    VIP_MEM_HANDLE	MemHandle;
} VIP_POST_ARGS;

/** Pre-wait arguments for ioctl. */
typedef struct {
    VIPK_VI_HANDLE    	ViHandle;
    VIP_BOOLEAN		Recv;
} VIP_PRE_WAIT_ARGS;

/** RecvWait arguemtns for ioctl. */
typedef struct {
    VIPK_VI_HANDLE    	ViHandle;
    VIP_ULONG		Timeout;
} VIP_RECV_WAIT_ARGS;

/** SendWait arguments for ioctl */
typedef struct {
    VIPK_VI_HANDLE	ViHandle;
    VIP_ULONG		Timeout;
} VIP_SEND_WAIT_ARGS;

/** CreateCQ arguments for ioctl. */
typedef struct {
    VIP_CQ_ENTRY		*Entry;
    VIP_ULONG			EntryCount;
    VIP_MEM_HANDLE		MemHandle;
    VIPK_CQ_HANDLE		CQHandle;
    VIP_PROTECTION_HANDLE	Ptag;
} VIP_CREATE_CQ_ARGS;

/** DestroyCQ arguments for ioctl. */
typedef struct {
    VIPK_CQ_HANDLE	CQHandle;
} VIP_DESTROY_CQ_ARGS;

/** ResizeCQ arguments for ioctl. */
typedef struct {
    VIPK_CQ_HANDLE		CQHandle;
    VIP_CQ_ENTRY		*Entry;
    VIP_ULONG			EntryCount;
    VIP_MEM_HANDLE		MemHandle;
    VIP_PROTECTION_HANDLE	Ptag;
} VIP_RESIZE_CQ_ARGS;

/** CQPreWait arguments for ioctl. */    
typedef struct {
    VIPK_CQ_HANDLE	CQHandle;
} VIP_CQ_PRE_WAIT_ARGS;

/** CQWait arguments for ioctl. */
typedef struct {
    VIPK_CQ_HANDLE	CQHandle;
    VIP_ULONG		Timeout;
} VIP_CQ_WAIT_ARGS;

/** QueryNic arguments for ioctl. */    
typedef struct {
    VIP_NIC_ATTRIBUTES	*NicAttribs;
    VIP_UINT8		*NicAddr;
} VIP_QUERY_NIC_ARGS;

/** SetViAttribute arguments for ioctl. */
typedef struct {
    VIPK_VI_HANDLE	ViHandle;
    VIP_VI_ATTRIBUTES	Attribs;
} VIP_SET_VI_ATTRIBS_ARGS;

/** QueryVi arguments for ioctl. */
typedef struct {
    VIPK_VI_HANDLE	ViHandle;
    VIP_VI_STATE	*State;
    VIP_VI_ATTRIBUTES	*Attribs;
} VIP_QUERY_VI_ARGS;

/** SetMemAttribute arguments for ioctl. */
typedef struct {
    VIP_PVOID			Address;
    VIP_MEM_HANDLE		MemHandle;
    VIP_MEM_ATTRIBUTES		*MemAttribs;
} VIP_SET_MEM_ATTRIBS_ARGS;

/** QueryMem arguments for ioctl. */
typedef struct {
    VIP_PVOID			Address;
    VIP_MEM_HANDLE		MemHandle;
    VIP_MEM_ATTRIBUTES		*MemAttribs;
} VIP_QUERY_MEM_ARGS;

/** FetchError arguments for ioctl. */
typedef struct {
    VIP_ERROR_DESCRIPTOR	ErrorDesc;
    VIP_BOOLEAN			Found;
} VIP_FETCH_ERROR_ARGS;

#ifdef __STDC__
#define VIP_OPEN_NIC	_IOWR('V', 1, VIP_OPEN_NIC_ARGS)
#define VIP_CREATE_VI	_IOWR('V', 2, VIP_CREATE_VI_ARGS)
#define VIP_DESTROY_VI	_IOWR('V', 3, VIP_DESTROY_VI_ARGS)
#define VIP_CONNECT_WAIT _IOWR('V', 4, VIP_CONNECT_WAIT_ARGS)
#define VIP_CONNECT_ACCEPT _IOWR('V', 5, VIP_CONNECT_ACCEPT_ARGS)
#define VIP_CONNECT_REJECT _IOWR('V', 6, VIP_CONNECT_REJECT_ARGS)
#define VIP_CONNECT_REQUEST _IOWR('V', 7, VIP_CONNECT_REQUEST_ARGS)
#define VIP_DISCONNECT _IOWR('V', 8, VIP_DISCONNECT_ARGS)
#define VIP_CREATE_PTAG _IOWR('V', 9, VIP_CREATE_PTAG_ARGS)
#define VIP_DESTROY_PTAG _IOWR('V', 10, VIP_DESTROY_PTAG_ARGS)
#define VIP_REGISTER_MEM _IOWR('V', 11, VIP_REGISTER_MEM_ARGS)
#define VIP_DEREGISTER_MEM _IOWR('V', 12, VIP_DEREGISTER_MEM_ARGS)
#define VIP_POST_SEND	_IOW('V', 13, VIP_POST_ARGS)
#define VIP_POST_RECV	_IOW('V', 14, VIP_POST_ARGS)
#define VIP_SEND_WAIT	_IOWR('V', 15, VIP_SEND_WAIT_ARGS)
#define VIP_RECV_WAIT	_IOWR('V', 16, VIP_RECV_WAIT_ARGS)
#define VIP_CREATE_CQ	_IOWR('V', 17, VIP_CREATE_CQ_ARGS)
#define VIP_DESTROY_CQ	_IOWR('V', 18, VIP_DESTROY_CQ_ARGS)
#define VIP_CQ_WAIT	_IOWR('V', 19, VIP_CQ_WAIT_ARGS)
#define VIP_QUERY_NIC	_IOR('V', 20, VIP_QUERY_NIC_ARGS)
#define VIP_SET_VI_ATTRIBS _IOWR('V', 21, VIP_SET_VI_ATTRIBS_ARGS)
#define VIP_QUERY_VI 	_IOWR('V', 22, VIP_QUERY_VI_ARGS)
#define VIP_SET_MEM_ATTRIBS _IOWR('V', 23, VIP_SET_MEM_ATTRIBS_ARGS)
#define VIP_QUERY_MEM	_IOWR('V', 24, VIP_QUERY_MEM_ARGS)
#define VIP_FETCH_ERROR _IOWR('V', 25, VIP_FETCH_ERROR_ARGS)
#define VIP_PRE_WAIT _IOWR('V', 26, VIP_PRE_WAIT_ARGS)
#define VIP_CQ_PRE_WAIT	_IOWR('V', 27, VIP_CQ_WAIT_ARGS)
#define VIP_VALIDATE_NIC _IO('V', 28)
#define VIP_RESIZE_CQ	_IOWR('V', 29, VIP_RESIZE_CQ_ARGS)
#define VIP_PEER_REQUEST	_IOWR('V', 30, VIP_PEER_REQUEST_ARGS)
#define VIP_PEER_DONE	_IOWR('V', 31, VIP_PEER_DONE_ARGS)
#else /* __STDC__ */
#define VIP_OPEN_NIC	_IOWR(V, 1, VIP_OPEN_NIC_ARGS)
#define VIP_CREATE_VI	_IOWR(V, 2, VIP_CREATE_VI_ARGS)
#define VIP_DESTROY_VI	_IOWR(V, 3, VIP_DESTROY_VI_ARGS)
#define VIP_CONNECT_WAIT _IOWR(V, 4, VIP_CONNECT_WAIT_ARGS)
#define VIP_CONNECT_ACCEPT _IOWR(V, 5, VIP_CONNECT_ACCEPT_ARGS)
#define VIP_CONNECT_REJECT _IOWR(V, 6, VIP_CONNECT_REJECT_ARGS)
#define VIP_CONNECT_REQUEST _IOWR(V, 7, VIP_CONNECT_REQUEST_ARGS)
#define VIP_DISCONNECT _IOWR(V, 8, VIP_DISCONNECT_ARGS)
#define VIP_CREATE_PTAG _IOWR(V, 9, VIP_CREATE_PTAG_ARGS)
#define VIP_DESTROY_PTAG _IOWR(V, 10, VIP_DESTROY_PTAG_ARGS)
#define VIP_REGISTER_MEM _IOWR(V, 11, VIP_REGISTER_MEM_ARGS)
#define VIP_DEREGISTER_MEM _IOWR(V, 12, VIP_DEREGISTER_MEM_ARGS)
#define VIP_POST_SEND	_IOW(V, 13, VIP_POST_ARGS)
#define VIP_POST_RECV	_IOW(V, 14, VIP_POST_ARGS)
#define VIP_SEND_WAIT	_IOWR(V, 15, VIP_SEND_WAIT_ARGS)
#define VIP_RECV_WAIT	_IOWR(V, 16, VIP_RECV_WAIT_ARGS)
#define VIP_CREATE_CQ	_IOWR(V, 17, VIP_CREATE_CQ_ARGS)
#define VIP_DESTROY_CQ	_IOWR(V, 18, VIP_DESTROY_CQ_ARGS)
#define VIP_CQ_WAIT	_IOWR(V, 19, VIP_CQ_WAIT_ARGS)
#define VIP_QUERY_NIC	_IOR(V, 20, VIP_QUERY_NIC_ARGS)
#define VIP_SET_VI_ATTRIBS _IOWR(V, 21, VIP_SET_VI_ATTRIBS_ARGS)
#define VIP_QUERY_VI 	_IOWR(V, 22, VIP_QUERY_VI_ARGS)
#define VIP_SET_MEM_ATTRIBS _IOWR(V, 23, VIP_SET_MEM_ATTRIBS_ARGS)
#define VIP_QUERY_MEM	_IOWR(V, 24, VIP_QUERY_MEM_ARGS)
#define VIP_FETCH_ERROR _IOWR(V, 25, VIP_FETCH_ERROR_ARGS)
#define VIP_PRE_WAIT _IOWR(V, 26, VIP_PRE_WAIT_ARGS)
#define VIP_CQ_PRE_WAIT	_IOWR(V, 27, VIP_CQ_WAIT_ARGS)
#define VIP_VALIDATE_NIC _IO('V', 28, VIP_VALIDATE_NIC_ARGS)
#define VIP_RESIZE_CQ	_IOWR(V, 29, VIP_RESIZE_CQ_ARGS)
#define VIP_PEER_REQUEST	_IOWR(V, 30, VIP_PEER_REQUEST_ARGS)
#define VIP_PEER_DONE	_IOWR(V, 31, VIP_PEER_DONE_ARGS)
#endif /* __STDC__ */

/** 
 * Compares two host addresses for matching descriminators.
 *
 * @param Addr1	Pointer to first address
 * @param Addr2 Pointer to second address
 * @return 	\c VIP_TRUE - discriminators match.<br>
 *		\c VIP_FALSE - discriminators do not match.
 */
extern inline 
VIP_BOOLEAN              
VipAddrDiscrimEq(VIP_NET_ADDRESS	*Addr1, 
		 VIP_NET_ADDRESS	*Addr2)
{
    if(Addr1->DiscriminatorLen != Addr2->DiscriminatorLen) {
	return VIP_FALSE;
    }

    if(!memcmp(Addr1->HostAddress + Addr1->HostAddressLen, 
	       Addr2->HostAddress + Addr2->HostAddressLen,
	       Addr1->DiscriminatorLen)) {
	return VIP_TRUE;
    } else {
	return VIP_FALSE;
    }
}

/** 
 * Compares two host addresses.
 *
 * @param Addr1 Pointer to first address.
 * @param Addr2 Pointer to second address.
 * @return	\c VIP_TRUE - addresses match.<br>
 *		\c VIP_FALSE - addresses do not match.
 */
extern inline 
VIP_BOOLEAN              
VipAddrHostEq(VIP_NET_ADDRESS	*Addr1, 
	      VIP_NET_ADDRESS	*Addr2)
{
    if(Addr1->HostAddressLen != Addr2->HostAddressLen) {
	return VIP_FALSE;
    }

    if(!memcmp(Addr1->HostAddress,
	       Addr2->HostAddress,
	       Addr1->HostAddressLen)) {
	return VIP_TRUE;
    } else {
	return VIP_FALSE;
    }
}

/** 
 * Copies Src address to Dest address.
 *
 * @param Dest Destination address.
 * @param Src Source address.
 *
 * \warning The destination address must be large enough to hold
 * the source address.
 */
extern inline 
void 
VipAddrCopy(VIP_NET_ADDRESS *Dest, 
	    VIP_NET_ADDRESS *Src)
{
    Dest->HostAddressLen = Src->HostAddressLen;
    Dest->DiscriminatorLen = Src->DiscriminatorLen;
    memcpy(Dest->HostAddress, Src->HostAddress, 
	   Src->HostAddressLen + Src->DiscriminatorLen);
}

extern inline
void 
VipNicAddrCopy(VIP_NET_ADDRESS 		*Dest,
	       VIP_NIC_ATTRIBUTES	*NicAttrs)
{
    Dest->HostAddressLen = NicAttrs->NicAddressLen;
    Dest->DiscriminatorLen = 0;
    memcpy(Dest->HostAddress, 
	   NicAttrs->LocalNicAddress, NicAttrs->NicAddressLen);
}

/** 
 * Determines if a call into the M-VIA Kernel Agent resulted in a system error.
 * It is posssible that given a bad argument, the ioctl call will return
 * a system level error, i.e. an errno.h error code.  This function abstracts
 * the check for such system level errors.
 * Note, if a \e true VIP_RETURN error occurs, a system level error will
 * \e not have occured.
 *
 * @param Status Status returned by an ioctl call to the M-VIA Kernel Agent.
 * @return 	\c VIP_TRUE - a system level error occured.
 *		\c VIP_FALSE - a system level error did not occur.
 */
extern inline
VIP_RETURN
VipSystemError(int Status)
{
    return (Status < 0);
}

/** 
 * Convert the error code returned from an ioctl call to a VIP_RETURN
 * code.
 *
 * @param Status Status returned by an ioctl call to the M-VIA Kernel Agent.
 * @return The appropriate \c VIP_RETURN code.
 *
 * \bug
 * This function currently converts all system level errors into 
 * VIP_INVALID_PARAMETER errors.  There may be some cases in which a 
 * VIP_ERROR_RESOURCE would be more appropriate.
 */
extern inline 
VIP_RETURN
VipSystemReturn(int Status) 
{
    return (VipSystemError(Status) ? VIP_INVALID_PARAMETER : Status);
}

#ifndef __KERNEL__
/* Notify functions: */
extern mvia_notify_t *
mviaCreateNotify(void *Handle, mvia_notify_type_t Type);

extern void
mviaDestroyNotify(mvia_notify_t *Notify);

extern VIP_RETURN
mviaEnqueueNotify(mvia_notify_t	*Notify,
		  VIP_PVOID	Context,
		  VIP_PVOID	CallBack);

extern void
mviaIdleNotify(mvia_notify_t *Notify, pthread_t Self);

extern void
mviaUnidleNotify(mvia_notify_t *Notify, pthread_t Self);

extern void
mviaFlushViNotifies(VIP_VI_HANDLE Vi);
#endif

#endif
