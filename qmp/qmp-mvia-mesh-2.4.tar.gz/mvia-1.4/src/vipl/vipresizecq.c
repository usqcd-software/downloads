/* vipresizecq.c
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/ioctl.h>

#include "vipl_private.h"

VIP_RETURN 
VipResizeCQ(IN	VIP_CQ_HANDLE		CQHandle,
	    IN	VIP_ULONG		EntryCount)
{
    VIP_MEM_ATTRIBUTES	MemAttribs;
    VIP_MEM_HANDLE	OldMemHandle;
    VIP_RESIZE_CQ_ARGS 	VipResizeCQArgs;
    VIP_CQ_ENTRY	*NewEntry;
    VIP_CQ_ENTRY	*OldEntry;
    VIP_RETURN 		Status;

    /* XXX: SPEC: This needs to be trapped here because it will cause
     * VipRegisterMem to fail with a VIP_INVALID_PARAMETER rather
     * than VIP_ERROR_RESOURCE.  (This check is also made inside
     * the kernel agent.
     *
     * Vipconf expects VIP_ERROR_RESOURCE, but this is not consistent
     * with the semantics of other vipl resource allocation routines.
     * VIP_INVALID_PARAMETER seems to make more sense.
     */
    if(EntryCount == 0) {
	return VIP_ERROR_RESOURCE;
    }
    
    if(CQHandle->TypeId != VIP_TYPE_CQ_HANDLE) {
	return VIP_INVALID_PARAMETER;
    }

    if(CQHandle->EntryCount == EntryCount) {
	/* short cut */
	return VIP_SUCCESS;
    }

    NewEntry = (VIP_CQ_ENTRY *) calloc(EntryCount, sizeof(VIP_CQ_ENTRY));
    if(NewEntry == NULL) {
	Status = VIP_ERROR_RESOURCE;
	goto bad_malloc;
    }

    /* Reuse the Ptag of the existing queue */
    MemAttribs.Ptag = CQHandle->Ptag;
    MemAttribs.EnableRdmaWrite = VIP_FALSE;
    MemAttribs.EnableRdmaRead = VIP_FALSE;
    Status = VipRegisterMem(CQHandle->NicHandle, 
			    NewEntry, sizeof(VIP_CQ_ENTRY) * EntryCount, 
			    &MemAttribs, &VipResizeCQArgs.MemHandle);
    if(Status != VIP_SUCCESS) {
	goto bad_rm;
    }

    OldMemHandle = CQHandle->MemHandle;
    OldEntry = CQHandle->Entry;

    VipResizeCQArgs.CQHandle	= CQHandle->KernCQHandle;
    VipResizeCQArgs.Entry	= NewEntry;
    VipResizeCQArgs.EntryCount	= EntryCount;
    VipResizeCQArgs.Ptag	= CQHandle->Ptag;

    /* block Notifier while we work */
    if (CQHandle->CQNotify) {
	pthread_mutex_lock(&CQHandle->CQNotify->Mutex);
    }

    Status = ioctl(CQHandle->NicHandle->DeviceDesc,
		   VIP_RESIZE_CQ, &VipResizeCQArgs);
    if(Status != VIP_SUCCESS) {
	if(VipSystemError(Status)) {
	    Status = VipSystemReturn(Status);
	    PERROR("VipResizeCQ: ioctl");
	}
	goto bad_ioctl;
    }

    CQHandle->Head =		0;
    CQHandle->Entry =		NewEntry;
    CQHandle->EntryCount =	EntryCount;
    CQHandle->MemHandle =	VipResizeCQArgs.MemHandle;

    /* unblock Notifier */
    if (CQHandle->CQNotify) {
	pthread_mutex_unlock(&CQHandle->CQNotify->Mutex);
    }

    VipDeregisterMem(CQHandle->NicHandle, OldEntry, OldMemHandle);
    free(OldEntry);

    return VIP_SUCCESS;

bad_ioctl:
    if (CQHandle->CQNotify) {
	pthread_mutex_unlock(&CQHandle->CQNotify->Mutex);
    }
    VipDeregisterMem(CQHandle->NicHandle, NewEntry,
		     VipResizeCQArgs.MemHandle);
bad_rm:
    free(NewEntry);
bad_malloc:
    return Status;
}
