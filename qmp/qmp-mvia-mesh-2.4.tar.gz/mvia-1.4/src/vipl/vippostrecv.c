/* vippostrecv.c
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/ioctl.h>

#include "vipl_private.h"
#if MVIA_HAS_FAST_TRAP
# include "fast_trap.h"
#endif

/* XXX: flow path can be optimized */

VIP_RETURN 
VipPostRecv(IN 	VIP_VI_HANDLE	Vi,
	    IN	VIP_DESCRIPTOR 	*DescriptorPtr,
	    IN	VIP_MEM_HANDLE 	MemHandle)
{
    VIP_POST_ARGS ViaPostRecvArgs;

    if(Vi->TypeId != VIP_TYPE_VI_HANDLE) {
	return VIP_INVALID_PARAMETER;
    }
    
    /* Need to send a ConnLost if DescriptorPtr is NULL, so must still Post it in this case. 
     */
    if(DescriptorPtr) {
	DescriptorPtr->CS.Next.Address = NULL;
	DescriptorPtr->CS.Status = 0;
    }

    if(Vi->RecvQHead == NULL) {
	Vi->RecvQHead = DescriptorPtr;
    } else if(Vi->RecvQTail != NULL) {
	/* handle must be set first, explain */
	Vi->RecvQTail->CS.NextHandle = MemHandle;
	Vi->RecvQTail->CS.Next.Address = DescriptorPtr;
    }

    Vi->RecvQTail = DescriptorPtr;

    switch(Vi->DoorbellType) {
    case VIP_DOORBELL_REGISTER:
	printf("XXX: register\n");
#if 0
	*(Vi->NicRecvRegister) = VipVAtoDT(DescriptorPtr, MemoryHandle);
#endif
	/* not implemented yet */
	return VIP_INVALID_PARAMETER;
    case VIP_DOORBELL_FAST_TRAP:
#if MVIA_HAS_FAST_TRAP
	return VipPostRecvTrap(Vi, DescriptorPtr, MemHandle);
#else
	PERROR("VipPostRecv: Fast Traps not implemented/configured");
	return VIP_INVALID_PARAMETER;
#endif
    case VIP_DOORBELL_IOCTL:
	ViaPostRecvArgs.ViHandle = Vi->KernViHandle;
	ViaPostRecvArgs.Desc = DescriptorPtr;
	ViaPostRecvArgs.MemHandle = MemHandle;

	if(ioctl(Vi->NicHandle->DeviceDesc,
		 VIP_POST_RECV, &ViaPostRecvArgs) < 0) {
	    PERROR("VipPostRecv: ioctl");
	    return VIP_INVALID_PARAMETER;
	}

	return VIP_SUCCESS;
    }

    /* Dummy return for compiler warning */
    return VIP_INVALID_PARAMETER;
}
