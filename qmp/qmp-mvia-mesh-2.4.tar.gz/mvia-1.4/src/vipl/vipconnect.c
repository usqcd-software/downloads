/* vipconnect.c
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>

#include "vipl_private.h"

static VIP_RETURN
SetSpinCount(VIP_VI_HANDLE	ViHandle,
	     VIP_BOOLEAN	Loopback);

static int
GetNumCpu(void);

VIP_RETURN
VipConnectWait(IN 	VIP_NIC_HANDLE		NicHandle,
	       IN	VIP_NET_ADDRESS		*LocalAddr,
	       IN	VIP_ULONG		Timeout,
	       OUT	VIP_NET_ADDRESS		*RemoteAddr,
	       OUT	VIP_VI_ATTRIBUTES	*RemoteViAttribs,
	       OUT	VIP_CONN_HANDLE		*ConnHandle)
{
    VIP_CONNECT_WAIT_ARGS	VipConnectWaitArgs;
    VIP_CONN_HANDLE 		Conn;
    VIP_RETURN 			Status;

    Conn = (VIP_CONN_HANDLE) malloc(sizeof(VIP_CONN));
    if(Conn == NULL) {
	return VIP_ERROR_RESOURCE;
    }

    VipAddrCopy((VIP_NET_ADDRESS *)&VipConnectWaitArgs.LocalAddr, LocalAddr);
    VipConnectWaitArgs.Timeout = Timeout;
    VipConnectWaitArgs.RemoteViAttribs = RemoteViAttribs;
    VipConnectWaitArgs.ConnHandle = &Conn->KernConnHandle;

    Status = ioctl(NicHandle->DeviceDesc, VIP_CONNECT_WAIT,
		   &VipConnectWaitArgs);

    if(VipSystemError(Status)) {
	PERROR("VipConnectWait: ioctl");
	free(Conn);
	return VipSystemReturn(Status);
    }

    if(Status != VIP_SUCCESS) {
	free(Conn);
	return Status;
    }

    Conn->TypeId = VIP_TYPE_CONN_HANDLE;
    
    Conn->NicHandle = NicHandle;
    VipAddrCopy(RemoteAddr, (VIP_NET_ADDRESS *)&VipConnectWaitArgs.RemoteAddr);

    if(VipAddrHostEq(LocalAddr, RemoteAddr)) {
	Conn->Loopback = VIP_TRUE;
    } else {
	Conn->Loopback = VIP_FALSE;
    }
    
    *ConnHandle = Conn;
    return Status;
}

VIP_RETURN
VipConnectAccept(IN	VIP_CONN_HANDLE		ConnHandle,
		 IN	VIP_VI_HANDLE		ViHandle)
{
    VIP_CONNECT_ACCEPT_ARGS 	Args;
    VIP_RETURN			Status;

    if(ConnHandle->TypeId != VIP_TYPE_CONN_HANDLE) {
	return VIP_INVALID_PARAMETER;
    }

    if(ViHandle->TypeId != VIP_TYPE_VI_HANDLE) {
	return VIP_INVALID_PARAMETER;
    }
    
    if(ViHandle->NicHandle != ConnHandle->NicHandle) {
	return VIP_INVALID_PARAMETER;
    }

    Args.ConnHandle = ConnHandle->KernConnHandle;
    Args.ViHandle = ViHandle->KernViHandle;

    Status = ioctl(ConnHandle->NicHandle->DeviceDesc,
		   VIP_CONNECT_ACCEPT, &Args);

    if(VipSystemError(Status)) {
	PERROR("VipConnectAccept: ioctl");
	return VipSystemReturn(Status);
    }

    /* XXX: potential prob in spec, if this never succeeds, and user
     * never rejects a connection, a lot of outstanding connections will 
     * be wasting resources */
    if(Status == VIP_SUCCESS) {
	SetSpinCount(ViHandle, ConnHandle->Loopback);	
	ConnHandle->TypeId = VIP_TYPE_INVALID;
	free(ConnHandle);
    }

    return Status;
}

VIP_RETURN
VipConnectReject(IN VIP_CONN_HANDLE ConnHandle)
{
    VIP_CONNECT_REJECT_ARGS 	VipConnectRejectArgs;
    VIP_RETURN 			Status;

    if(ConnHandle->TypeId != VIP_TYPE_CONN_HANDLE) {
	return VIP_INVALID_PARAMETER;
    }
    
    VipConnectRejectArgs.ConnHandle = ConnHandle->KernConnHandle;


    Status = ioctl(ConnHandle->NicHandle->DeviceDesc,
		   VIP_CONNECT_REJECT, &VipConnectRejectArgs);

    if(VipSystemError(Status)) {
	PERROR("VipConnectReject: ioctl");
	return VipSystemReturn(Status);
    }

    if(Status == VIP_SUCCESS) {
	ConnHandle->TypeId = VIP_TYPE_INVALID;
	free(ConnHandle);
    }

    return Status;
}

VIP_RETURN
VipConnectRequest(IN 	VIP_VI_HANDLE 		ViHandle,
		  IN	VIP_NET_ADDRESS		*LocalAddr,
		  IN	VIP_NET_ADDRESS		*RemoteAddr,
		  IN	VIP_ULONG		Timeout,
		  OUT 	VIP_VI_ATTRIBUTES	*RemoteViAttribs)

{
    VIP_CONNECT_REQUEST_ARGS	Args;
    VIP_BOOLEAN			Loopback = VIP_FALSE;
    VIP_RETURN			Status;

    Args.ViHandle = ViHandle->KernViHandle;
    
    VipAddrCopy((VIP_NET_ADDRESS *)&Args.LocalAddr, LocalAddr);
    VipAddrCopy((VIP_NET_ADDRESS *)&Args.RemoteAddr, RemoteAddr);
    Args.Timeout = Timeout;
    Args.RemoteViAttribs = RemoteViAttribs;

    Status = ioctl(ViHandle->NicHandle->DeviceDesc, 
		   VIP_CONNECT_REQUEST, &Args);

    if(VipSystemError(Status)) {
	PERROR("VipConnectRequest: ioctl");
	return VipSystemReturn(Status);
    }

    if(Status == VIP_SUCCESS) {
	VipAddrCopy(RemoteAddr, (VIP_NET_ADDRESS *)&Args.RemoteAddr);
	if(VipAddrHostEq(LocalAddr, RemoteAddr)) {
	    Loopback = VIP_TRUE;
	}
	
	SetSpinCount(ViHandle, Loopback);
    }


    return Status;
}

VIP_RETURN
VipDisconnect(IN VIP_VI_HANDLE Vi)
{
    VIP_DISCONNECT_ARGS VipDisconnectArgs;
    VIP_RETURN		Status;
    mvia_notify_t	*RecvNotify;
    mvia_notify_t	*SendNotify;
    pthread_t		Me = pthread_self();

    if(Vi->TypeId != VIP_TYPE_VI_HANDLE) {
	return VIP_INVALID_PARAMETER;
    }

    /* Identify the Notifies */
    RecvNotify = Vi->RecvCQHandle ? Vi->RecvCQHandle->CQNotify
				  : Vi->RecvNotify;
    SendNotify = Vi->SendCQHandle ? Vi->SendCQHandle->CQNotify
				  : Vi->SendNotify;

    /* Stop the Notifies while the work queues are being flushed */
    mviaIdleNotify(RecvNotify, Me);
    mviaIdleNotify(SendNotify, Me);
    
    /* Tell the kernel to disconnect us */
    VipDisconnectArgs.ViHandle = Vi->KernViHandle;
    Status = ioctl(Vi->NicHandle->DeviceDesc,
		   VIP_DISCONNECT, &VipDisconnectArgs);

    if(Status != VIP_SUCCESS) {
	mviaUnidleNotify(RecvNotify, Me);
	mviaUnidleNotify(SendNotify, Me);

	if(VipSystemError(Status)) {
	    PERROR("VipDisconnect: ioctl");
	    return VipSystemReturn(Status);
	} else {
	    return Status;
	}
    }

    /* Descriptors will be flushed by the kernel if they can be, however,
     * a descriptor that had a bad memhandle or bad virtual address will
     * not have been marked done.  If in the middle of a linked chain,
     * the chain will be truncated.  However, if at the start, VIPL
     * needs to cut the chain itself.
     */
    if(Vi->RecvQHead && !(Vi->RecvQHead->CS.Status & VIP_STATUS_DONE)) {
	Vi->RecvQHead = NULL;
    }
    if(Vi->SendQHead && !(Vi->SendQHead->CS.Status & VIP_STATUS_DONE)) {
	Vi->SendQHead = NULL;
    }

    /* Resume the Notifies */
    mviaUnidleNotify(RecvNotify, Me);
    mviaUnidleNotify(SendNotify, Me);

    return Status;
}

VIP_RETURN
VipConnectPeerRequest(IN	VIP_VI_HANDLE	Vi,
		      IN	VIP_NET_ADDRESS	*LocalAddr,
		      IN	VIP_NET_ADDRESS	*RemoteAddr,
		      IN	VIP_ULONG	Timeout)
{
    VIP_PEER_REQUEST_ARGS	VipPeerRequestArgs;
    VIP_RETURN 			Status;

    if(Vi->TypeId != VIP_TYPE_VI_HANDLE) {
	return VIP_INVALID_PARAMETER;
    }

    VipPeerRequestArgs.ViHandle = Vi->KernViHandle;
    VipAddrCopy((VIP_NET_ADDRESS *)&VipPeerRequestArgs.LocalAddr, LocalAddr);
    VipAddrCopy((VIP_NET_ADDRESS *)&VipPeerRequestArgs.RemoteAddr, RemoteAddr);
    VipPeerRequestArgs.Timeout = Timeout;

    Status = ioctl(Vi->NicHandle->DeviceDesc, VIP_PEER_REQUEST,
		   &VipPeerRequestArgs);

    if(VipSystemError(Status)) {
	PERROR("VipConnectPeerRequest: ioctl");
	return VipSystemReturn(Status);
    }

    return Status;
}

VIP_RETURN
VipConnectPeerDone(IN	VIP_VI_HANDLE		Vi,
		   OUT	VIP_VI_ATTRIBUTES	*RemoteViAttribs)
{
    VIP_PEER_DONE_ARGS	VipPeerDoneArgs;
    VIP_RETURN 		Status;

    if(Vi->TypeId != VIP_TYPE_VI_HANDLE) {
	return VIP_INVALID_PARAMETER;
    }

    VipPeerDoneArgs.ViHandle = Vi->KernViHandle;
    VipPeerDoneArgs.RemoteViAttribs = RemoteViAttribs;
    VipPeerDoneArgs.Block = VIP_FALSE;

    Status = ioctl(Vi->NicHandle->DeviceDesc, VIP_PEER_DONE, &VipPeerDoneArgs);

    if(VipSystemError(Status)) {
	PERROR("VipConnectPeerDone: ioctl");
	return VipSystemReturn(Status);
    }

    return Status;
}

VIP_RETURN
VipConnectPeerWait(IN	VIP_VI_HANDLE		Vi,
		   OUT	VIP_VI_ATTRIBUTES	*RemoteViAttribs)
{
    VIP_PEER_DONE_ARGS	VipPeerDoneArgs;
    VIP_RETURN 		Status;

    if(Vi->TypeId != VIP_TYPE_VI_HANDLE) {
	return VIP_INVALID_PARAMETER;
    }

    VipPeerDoneArgs.ViHandle = Vi->KernViHandle;
    VipPeerDoneArgs.RemoteViAttribs = RemoteViAttribs;
    VipPeerDoneArgs.Block = VIP_TRUE;

    Status = ioctl(Vi->NicHandle->DeviceDesc, VIP_PEER_DONE, &VipPeerDoneArgs);

    if(VipSystemError(Status)) {
	PERROR("VipConnectPeerWait: ioctl");
	return VipSystemReturn(Status);
    }

    return Status;
}


static int num_cpu = 0;
#define min(a,b) ((a)<(b)?(a):(b))

/* eventually this will be based on round trip time.
 */
static VIP_RETURN
SetSpinCount(VIP_VI_HANDLE	ViHandle,
	     VIP_BOOLEAN	Loopback)
{
    VIP_UINT32 SpinCount = VIP_SPIN_COUNT;
    
    if(Loopback) {
	if(num_cpu == 0) {
	    num_cpu = GetNumCpu();
	}

	if(num_cpu == 1) {
	    SpinCount = 1;
	}
    }

    ViHandle->SpinCount = SpinCount;

    /* XXX: It is not clear what to do with CQ handle spin times.
     * The CQ could be associated with a loopback vi and a remote
     * vi.  
     */
    if(ViHandle->RecvCQHandle) {
	ViHandle->RecvCQHandle->SpinCount =
	    min(ViHandle->RecvCQHandle->SpinCount, SpinCount);
    }
    
    if(ViHandle->SendCQHandle) {
	ViHandle->SendCQHandle->SpinCount =
	    min(ViHandle->SendCQHandle->SpinCount, SpinCount);
    }
    
    return VIP_SUCCESS;
}

#define MAX_PROC_LINE 128
static int
GetNumCpu(void)
{
    FILE *fp_proc;
    char buf[MAX_PROC_LINE+2];
    int num_cpu = 0;

    if((fp_proc = fopen("/proc/cpuinfo", "r")) == NULL) {
	PERROR("Could not open /proc/cpuinfo");
	return 1;
    }

    while(!feof(fp_proc)) {
	fgets(buf, MAX_PROC_LINE, fp_proc);
	if(!strncmp(buf, "processor", 9)) {
	    num_cpu++;
	}
    }

    fclose(fp_proc);

    return num_cpu;
}
