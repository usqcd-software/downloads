/* mvianotify.c
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

#include "vipl_private.h"

/* How long (us) to sleep in mviaFlushViNotifies to allow notifies to work */
#define MVIA_NOTIFY_SLEEP 1000 /* 1 ms */

typedef
void(mvia_cq_callback_t)(IN VIP_PVOID      Context,
			 IN VIP_NIC_HANDLE NicHandle,
			 IN VIP_VI_HANDLE  ViHandle,
			 IN VIP_BOOLEAN    RecvQueue);

typedef
void(mvia_recv_callback_t)(IN VIP_PVOID      Context,
			   IN VIP_NIC_HANDLE NicHandle,
			   IN VIP_VI_HANDLE  ViHandle,
			   IN VIP_DESCRIPTOR *DescriptorPtr);

typedef
void(mvia_send_callback_t)(IN VIP_PVOID      Context,
			   IN VIP_NIC_HANDLE NicHandle,
			   IN VIP_VI_HANDLE  ViHandle,
			   IN VIP_DESCRIPTOR *DescriptorPtr);

/* Routines to dequeue a request and call the user's callback.
 * On entry to a Run routine:
 *	Notify->Mutex is held by the current thread
 *	Notify->IsIdle == VIP_TRUE
 *	Notify->Command == MVIA_NOTIFY_RUN
 * On exit from a Run routine:
 *	Notify->Mutex has been released
 *	Notify->IsIdle might have been changed to VIP_FALSE
 */
static void RunCQCallBack(mvia_notify_t *Notify);
static void RunRecvCallBack(mvia_notify_t *Notify);
static void RunSendCallBack(mvia_notify_t *Notify);

static void *NotifyHandler(void *Notify);

/* XXX:
 * In the future it may be a good idea to adjust the SpinCount for
 * loopback Vi's on multiprocessors to allow for the extra thread.
 * Would it be best to do this in the handler thread, reducing the 
 * SpinCount when it runs and restoring it when it blocks?
 *
 * Even more ambitious would be to track the number of "live" threads
 * (per NIC?) and use the large spin count for loopback VIs only
 * when (# CPU) >= (# live threads).  This would mean that spinning
 * functions would choose their spin counts dynamically.
 */

mvia_notify_t * 
mviaCreateNotify(void			*Handle,
		 mvia_notify_type_t	Type)
{
    mvia_notify_t	*Notify;

    /* Allocate and initialize a Notify structure.
     * It will normally be free()d by the notify thread. */
    Notify = (mvia_notify_t *)malloc(sizeof(mvia_notify_t));
    if(Notify) {
        pthread_mutex_init(&Notify->Mutex, NULL);
        pthread_cond_init(&Notify->Wakeup, NULL);
        pthread_cond_init(&Notify->Idle, NULL);
        Notify->IsIdle	= VIP_TRUE;
        Notify->Handle	= Handle;
        Notify->Head	= NULL;
        Notify->Tail	= NULL;
        Notify->Command	= MVIA_NOTIFY_RUN;
	switch(Type) {
	case MVIA_NOTIFY_CQ:
	    Notify->Run	= &RunCQCallBack;
	    break;

	case MVIA_NOTIFY_RECV:
	    Notify->Run	= &RunRecvCallBack;
	    break;

	case MVIA_NOTIFY_SEND:
	    Notify->Run	= &RunSendCallBack;
	    break;

	default:
	    PERROR("mviaCreateNotify: invalid type");
	    free(Notify);
	    return NULL;
	}
    } else {
	PERROR("mviaCreateNotify: malloc");
	return NULL;
    }

    /* Start the notify thread. */
    if(pthread_create(&Notify->Thread, NULL, NotifyHandler, Notify) != 0) {
	free(Notify);
	PERROR("mviaCreateNotify: pthread_create");
	return NULL;
    }
   
    return Notify;
}

void
mviaDestroyNotify(mvia_notify_t *Notify)
{
    if(Notify) {
	pthread_mutex_lock(&Notify->Mutex);
	Notify->Command = MVIA_NOTIFY_QUIT;
	pthread_cond_signal(&Notify->Wakeup);
	pthread_mutex_unlock(&Notify->Mutex);
	if(!pthread_equal(Notify->Thread, pthread_self())) {
	    pthread_join(Notify->Thread, NULL);
	}
    }
}

VIP_RETURN
mviaEnqueueNotify(mvia_notify_t		*Notify,
		  VIP_PVOID		Context,
		  VIP_PVOID		CallBack)
{
    mvia_notify_req_t	*Request;

    /* XXX: Should reuse requests from a pool? */
    /* Allocate and initialize a request structure.
     * It will normally be free()d by the notify thread. */
    Request = (mvia_notify_req_t *)malloc(sizeof(mvia_notify_req_t));
    if(Request) {
	Request->Context	= Context;
	Request->CallBack	= CallBack;
	Request->Next		= NULL;
    } else {
	PERROR("mviaEnqueueNotify: malloc");
	return VIP_ERROR_RESOURCE;
    }

    /* Enqueue the request for the Notify thread */
    pthread_mutex_lock(&Notify->Mutex);
    if(Notify->Head == NULL) {
	Notify->Head = Request;
	pthread_cond_signal(&Notify->Wakeup);
    } else {
	Notify->Tail->Next = Request;
    }
    Notify->Tail = Request;
    pthread_mutex_unlock(&Notify->Mutex);

    /* XXX:
     * In the future it may be a good idea to yield here if there is
     * a completed Descriptor on the work queue and the notify thread
     * is blocked on the condition variable but cannot wake up
     * immediately because we are running on a uniprocessor.
     *
     * More ambitious would be to yield based on the number of live
     * threads (i.e. yield if there is a completed Descriptor, the
     * notify thead is blocked, and (# live threads) >= (# CPU)).
     *
     * Either case should also consider that we don't want to yield
     * if called from the user's call back.
     */
   
    return VIP_SUCCESS;
}

void
mviaIdleNotify(mvia_notify_t	*Notify,
	       pthread_t	Self)
{
    if(Notify) {
	pthread_mutex_lock(&Notify->Mutex);
	Notify->Command = MVIA_NOTIFY_IDLE;
        if(Notify->Thread == Self) {
	    Notify->IsIdle = VIP_TRUE;
	} else {
	    while (!Notify->IsIdle) {
		pthread_cond_signal(&Notify->Wakeup);
		pthread_cond_wait(&Notify->Idle, &Notify->Mutex);
	    }
	}
	pthread_mutex_unlock(&Notify->Mutex);
    }
}

void
mviaUnidleNotify(mvia_notify_t	*Notify,
		 pthread_t	Self)
{
    if(Notify) {
	pthread_mutex_lock(&Notify->Mutex);
	Notify->Command = MVIA_NOTIFY_RUN;
        if(Notify->Thread == Self) {
	    Notify->IsIdle = VIP_FALSE;
	} else {
	    pthread_cond_signal(&Notify->Wakeup);
	}
	pthread_mutex_unlock(&Notify->Mutex);
    }
}

void
mviaFlushViNotifies(VIP_VI_HANDLE	Vi)
{
    pthread_t		Self;
    mvia_notify_t	*RecvNotify;
    mvia_notify_t	*SendNotify;

    Self = pthread_self();

    /*
     * PART I: Try to empty work queues which are served by callbacks.
     */

    /* Identify Notifies, avoiding deadlock by avoiding our own caller */
    RecvNotify = Vi->RecvCQHandle ? Vi->RecvCQHandle->CQNotify
				  : Vi->RecvNotify;
    if(RecvNotify && pthread_equal(RecvNotify->Thread, Self)) {
	RecvNotify = NULL;
    }
    SendNotify = Vi->SendCQHandle ? Vi->SendCQHandle->CQNotify
				  : Vi->SendNotify;
    if(SendNotify && pthread_equal(SendNotify->Thread, Self)) {
	SendNotify = NULL;
    }

    /* Try to flush the work queues */
    if(RecvNotify || SendNotify) {
	VIP_BOOLEAN	Done = VIP_FALSE;

	do {
	    /* Force RecvNotify and SendNotify to go to idle state. */
	    mviaIdleNotify(RecvNotify, 0);
	    mviaIdleNotify(SendNotify, 0);

	    /* We are done if:
	     *  1. Both work queues are now empty.
	     *   or
	     *  2. Both Notifies are out of callbacks and thus cannot
	     *     possibly make forward progress on the work queues.
	     */
	    if(/* Case 1: */ (!Vi->RecvQHead && !Vi->SendQHead) ||
	       /* Case 2: */ (!(RecvNotify && RecvNotify->Head) &&
			      !(SendNotify && SendNotify->Head))) {
		Done = VIP_TRUE;
	    }

	    /* Allow RecvNotify and SendNotify to go back to running state.  */
	    mviaUnidleNotify(RecvNotify, 0);
	    mviaUnidleNotify(SendNotify, 0);

	    /* Allow Notifies time to do some work */
	    if(!Done) {
		usleep(MVIA_NOTIFY_SLEEP);
	    }
	} while(!Done);
    }

    /*
     * PART II: Flush recv/send callback queues serving empty work queues
     */

    /* Ignore CQ callbacks */
    if(Vi->RecvCQHandle) {
	RecvNotify = NULL;
    }
    if(Vi->SendCQHandle) {
	SendNotify = NULL;
    }

    /* Try to flush the callback queues */
    if(RecvNotify || SendNotify) {
	VIP_BOOLEAN	Done = VIP_FALSE;

	do {
	    /* Force RecvNotify and SendNotify to go to idle state. */
	    mviaIdleNotify(RecvNotify, 0);
	    mviaIdleNotify(SendNotify, 0);

	    /* We are done when both Notifies are out of callbacks. */
	    if(!(RecvNotify && RecvNotify->Head) &&
	       !(SendNotify && SendNotify->Head)) {
		Done = VIP_TRUE;
	    }

	    /* Allow RecvNotify and SendNotify to go back to running state.  */
	    mviaUnidleNotify(RecvNotify, 0);
	    mviaUnidleNotify(SendNotify, 0);

	    /* Allow Notifies time to do some work */
	    if(!Done) {
		usleep(MVIA_NOTIFY_SLEEP);
	    }
	} while(!Done);
    }
}

static void *
NotifyHandler(void *arg)
{
    mvia_notify_t	*Notify		= (mvia_notify_t *)arg;
    pthread_mutex_t	*Mutex		= &Notify->Mutex;
    pthread_cond_t	*Wakeup		= &Notify->Wakeup;
    pthread_cond_t	*Idle		= &Notify->Idle;

    while(Notify->Command != MVIA_NOTIFY_QUIT) {
	/* Wait for something to do... */
	pthread_mutex_lock(Mutex);
	Notify->IsIdle = VIP_TRUE;
	pthread_cond_signal(Idle);
	while((Notify->Command == MVIA_NOTIFY_IDLE) ||
	      ((Notify->Command == MVIA_NOTIFY_RUN) &&
	       (Notify->Head == NULL))) {
	    pthread_cond_wait(Wakeup, Mutex);
	}

	/* ...and then do it. */
	if(Notify->Command == MVIA_NOTIFY_RUN) {
	    Notify->Run(Notify);
	} else {
	    pthread_mutex_unlock(Mutex);
	}
    }

    /* The CQ or Vi is being destroyed.  So, it's time to clean up. */
    while(Notify->Head != NULL) {
	mvia_notify_req_t *Temp = Notify->Head;
	Notify->Head = Notify->Head->Next;
	free(Temp);
    }
    free(Notify);

    return NULL;
}

static void
RunCQCallBack(mvia_notify_t	*Notify)
{
    mvia_notify_req_t	*Request;
    VIP_BOOLEAN		RecvQueue;
    VIP_VI_HANDLE	Vi;
    VIP_RETURN		Status;
    VIP_PVOID		Context;
    mvia_cq_callback_t	*CallBack;

    /* Dequeue the request for notification. */
    Request = Notify->Head;
    Notify->Head = Request->Next;
    pthread_mutex_unlock(&Notify->Mutex);
	
    /* Handle the request. */
    CallBack = Request->CallBack;
    Context  = Request->Context;
    free(Request);	/* XXX: Should reuse requests from a pool? */
    Status = VipCQWait(Notify->Handle, VIP_INFINITE, &Vi, &RecvQueue);
    if((Status == VIP_SUCCESS) ||
       (Status == VIP_DESCRIPTOR_ERROR)) {
	/* Mark thread non-idle as soon as permitted */
	pthread_mutex_lock(&Notify->Mutex);
	while(Notify->Command == MVIA_NOTIFY_IDLE) {
	    pthread_cond_wait(&Notify->Wakeup, &Notify->Mutex);
	}
    	Notify->IsIdle = VIP_FALSE;
	pthread_mutex_unlock(&Notify->Mutex);

	/* Run the callback */
	(*CallBack)(Context, Vi->NicHandle, Vi, RecvQueue);
    } else {
	PERROR("RunCQCallBack: VipCQWait");
    }
}

static void
RunRecvCallBack(mvia_notify_t	*Notify)
{
    mvia_notify_req_t		*Request;
    VIP_VI_HANDLE		Vi = Notify->Handle;
    VIP_DESCRIPTOR		*Descriptor;
    VIP_RETURN			Status;
    VIP_PVOID			Context;
    mvia_recv_callback_t	*CallBack;

    /* Dequeue the request for notification. */
    Request = Notify->Head;
    Notify->Head = Request->Next;

    /* Mark the thread as non-idle */
    Notify->IsIdle = VIP_FALSE;
    pthread_mutex_unlock(&Notify->Mutex);
	
    /* Handle the request. */
    CallBack = Request->CallBack;
    Context  = Request->Context;
    free(Request);	/* XXX: Should reuse requests from a pool? */
    Status = VipRecvWait(Vi, VIP_INFINITE, &Descriptor);
    if((Status == VIP_SUCCESS) ||
       (Status == VIP_DESCRIPTOR_ERROR)) {
	/* Run the callback */
	(*CallBack)(Context, Vi->NicHandle, Vi, Descriptor);
    } else {
	PERROR("RunRecvCallBack: VipRecvWait");
    }
}

static void
RunSendCallBack(mvia_notify_t	*Notify)
{
    mvia_notify_req_t		*Request;
    VIP_VI_HANDLE		Vi = Notify->Handle;
    VIP_DESCRIPTOR		*Descriptor;
    VIP_RETURN			Status;
    VIP_PVOID			Context;
    mvia_recv_callback_t	*CallBack;

    /* Dequeue the request for notification. */
    Request = Notify->Head;
    Notify->Head = Request->Next;

    /* Mark the thread as non-idle */
    Notify->IsIdle = VIP_FALSE;
    pthread_mutex_unlock(&Notify->Mutex);
	
    /* Handle the request. */
    CallBack = Request->CallBack;
    Context  = Request->Context;
    free(Request);	/* XXX: Should reuse requests from a pool? */
    Status = VipSendWait(Vi, VIP_INFINITE, &Descriptor);
    if((Status == VIP_SUCCESS) ||
       (Status == VIP_DESCRIPTOR_ERROR)) {
	/* Run the callback */
	(*CallBack)(Context, Vi->NicHandle, Vi, Descriptor);
    } else {
	PERROR("RunSendCallBack: VipSendWait");
    }
}
