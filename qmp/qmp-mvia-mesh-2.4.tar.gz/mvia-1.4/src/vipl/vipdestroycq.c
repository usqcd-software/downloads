/* vipdestroycq.c
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/ioctl.h>

#include "vipl_private.h"

VIP_RETURN 
VipDestroyCQ(IN	VIP_CQ_HANDLE  CQHandle)

{    
    VIP_DESTROY_CQ_ARGS	VipDestroyCQArgs;
    VIP_RETURN		Status;

    if(CQHandle->TypeId != VIP_TYPE_CQ_HANDLE) {
	return VIP_INVALID_PARAMETER;
    }

    VipDestroyCQArgs.CQHandle = CQHandle->KernCQHandle;

    Status = ioctl(CQHandle->NicHandle->DeviceDesc, 
		   VIP_DESTROY_CQ, &VipDestroyCQArgs);

    if(VipSystemError(Status)) {
	PERROR("VipDestroyCQ: ioctl");
        return VipSystemReturn(Status);
    }

    /* XXX: what do we do if Status failed? */
    if(Status == VIP_SUCCESS) {
	/* XXX: how should errors below be handled? */
	VipDeregisterMem(CQHandle->NicHandle, CQHandle->Entry, 
			 CQHandle->MemHandle);
	VipDestroyPtag(CQHandle->NicHandle, CQHandle->Ptag);

	mviaDestroyNotify(CQHandle->CQNotify);

	CQHandle->TypeId = VIP_TYPE_INVALID;
	
	free(CQHandle->Entry);
	free(CQHandle);
    }

    return Status;
}
