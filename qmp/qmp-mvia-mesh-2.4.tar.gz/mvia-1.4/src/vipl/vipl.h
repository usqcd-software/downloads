/** \file vipl.h 
 *  Contains the complete user interface to the VI Provider Library.
 *  This file is does not contain extensive documentation as the 
 *  <a href=
 *  "http://developer.intel.com/design/servers/vi/developer/ia_imp_guide.htm">
 *  Intel Virtual Interface Architecture Developer's Guide</a>
 *  should be used as the definitive reference for the VIPL API.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#ifndef _VIPL_H
#define _VIPL_H

#include <values.h>
#include <asm/types.h>

#ifndef __KERNEL__
#ifndef _REENTRANT
#error "M-VIA applications must be compiled with -D_REENTRANT and linked with the -lpthread flag.  See the release notes for more information."
#endif
#endif

/** \def VIP_DOORBELL_SHIFT
    Number of bits in Doorbell Token for Descriptor Offset.

    See the VI Architecture Specification 1.0 Section 11.2.1.2.
*/
#define VIP_DOORBELL_SHIFT 5

/* 
 * Basic vip types 
 */

/** Generic void * type. */
typedef void *		VIP_PVOID;

/** Generic boolean type. */
typedef int		VIP_BOOLEAN;

/** Generic char type. */
typedef char		VIP_CHAR;

/** Generic unsigned char type. */
typedef unsigned char	VIP_UCHAR;

/** Generic unsigned short type. */
typedef unsigned short	VIP_USHORT;

/** Generic unsigned long type. */
typedef unsigned long	VIP_ULONG;

/** Generic 8 bit type. 
    This definition is Linux specific. 
*/
typedef __u8		VIP_UINT8;

/** Generic 16 bit type. 
    This definition is Linux specific. 
*/
typedef __u16		VIP_UINT16;

/** Generic 32 bit type.
    This definition is Linux specific. 
*/
typedef __u32		VIP_UINT32;

/** Generic 64 bit type. 
    This definition is Linux specific. 
*/
typedef __u64 		VIP_UINT64;


/*
 * VI Handles 
 */

/** Opaque handle */
typedef struct _VIP_NIC	* 	VIP_NIC_HANDLE;

/** Opaque handle */
typedef struct _VIP_VI	* 	VIP_VI_HANDLE;

/** Opaque handle */
typedef struct _VIP_CONN * 	VIP_CONN_HANDLE;

/** Opaque handle */
typedef VIP_PVOID		VIP_PROTECTION_HANDLE;

/** Opaque handle */
typedef VIP_UINT32		VIP_MEM_HANDLE;

/** Opaque handle */
typedef struct _VIP_CQ * 	VIP_CQ_HANDLE;

typedef union {
    VIP_UINT64		AddressBits;
    VIP_PVOID		Address;
} VIP_PVOID64;


/* 
 * Boolean values 
 */

/** \def VIP_FALSE
    False constant used with VIP_BOOLEAN.
*/
#define VIP_FALSE	0

/** \def VIP_TRUE
    True constant used with VIP_BOOLEAN.
*/
#define VIP_TRUE	1

/** \def VIP_INFINITE
    Infinite timeout value.  
*/
#define VIP_INFINITE 	(~(VIP_ULONG) 0)

/** \def IN
    Specifies input arguments to VIPL functions.
*/
#define IN

/** \def OUT
    Specifies output arguments to VIPL functions.
*/
#define OUT

/** \def VIP_DESCRIPTOR_ALIGNMENT 
    Memory alignment required by the NIC for descriptors, in bytes.
*/
#define VIP_DESCRIPTOR_ALIGNMENT 64

/** Return codes from functions. 
    VIA-SPEC 9.10.1

    IDG 4.2
*/
typedef enum {
    VIP_SUCCESS,		
    VIP_NOT_DONE,		
    VIP_INVALID_PARAMETER,	
    VIP_ERROR_RESOURCE,		
    VIP_TIMEOUT,
    VIP_REJECT,
    VIP_INVALID_RELIABILITY_LEVEL,
    VIP_INVALID_MTU,
    VIP_INVALID_QOS,
    VIP_INVALID_PTAG,
    VIP_INVALID_RDMAREAD,
    VIP_DESCRIPTOR_ERROR, 
    VIP_INVALID_STATE,	
    VIP_ERROR_NAMESERVICE,
    VIP_NO_MATCH,
    VIP_NOT_REACHABLE
} VIP_RETURN;

/*
 * VI Descriptors.
 * VIA-SPEC 9.10.2
 * IDG 4.3 
 */

/* The Linux kernel defines CS and DS macros which clash with 
 * the coresponding field names in the VIP_DESCRIPTOR structure.
 * They need to be undefined in order to be used here.  This may lead
 * to complications with creating in-kernel VIPL binding for the Linux
 * kernel further down the road.
 */
#undef CS
#undef DS

/** Control portion of a descriptor. */
typedef struct {
    VIP_PVOID64		Next;
    VIP_MEM_HANDLE	NextHandle;
    VIP_UINT16		SegCount;
    VIP_UINT16		Control;
    VIP_UINT32		Reserved;
    VIP_UINT32		ImmediateData;
    VIP_UINT32		Length;
    VIP_UINT32		Status;
} VIP_CONTROL_SEGMENT;

/** Descriptor RDMA Segment. */
typedef struct {
    VIP_PVOID64		Data;
    VIP_MEM_HANDLE	Handle;
    VIP_UINT32		Reserved;
} VIP_ADDRESS_SEGMENT;

/** Descriptor Data Segment. */
typedef struct {
    VIP_PVOID64		Data;
    VIP_MEM_HANDLE	Handle;
    VIP_UINT32		Length;
} VIP_DATA_SEGMENT;

/** Segments within a VIP_DESCRIPTOR */
typedef union {
    VIP_ADDRESS_SEGMENT	Remote;
    VIP_DATA_SEGMENT	Local;
} VIP_DESCRIPTOR_SEGMENT;

/** Complete VI Descriptor */
typedef struct {
    VIP_CONTROL_SEGMENT		CS;
    VIP_DESCRIPTOR_SEGMENT 	DS[2];
} VIP_DESCRIPTOR;


/* 
 * Values for control field of the control segment 
 */
#define VIP_CONTROL_OP_SENDRECV		0x0000
#define VIP_CONTROL_OP_RDMAWRITE	0x0001
#define VIP_CONTROL_OP_RDMAREAD		0x0002
#define VIP_CONTROL_OP_RESERVED		0x0003
#define VIP_CONTROL_OP_MASK		0x0003
#define VIP_CONTROL_IMMEDIATE		0x0004
#define VIP_CONTROL_QFENCE		0x0008
#define VIP_CONTROL_RESERVED		0xFFF0

/* 
 * Values for the status field of the control segment 
 */
#define VIP_STATUS_DONE			0x00000001
#define VIP_STATUS_FORMAT_ERROR		0x00000002
#define VIP_STATUS_PROTECTION_ERROR	0x00000004
#define VIP_STATUS_LENGTH_ERROR		0x00000008
#define VIP_STATUS_PARTIAL_ERROR	0x00000010
#define VIP_STATUS_DESC_FLUSHED_ERROR	0x00000020
#define VIP_STATUS_TRANSPORT_ERROR	0x00000040
#define VIP_STATUS_RDMA_PROT_ERROR	0x00000080
#define VIP_STATUS_REMOTE_DESC_ERROR	0x00000100
#define VIP_STATUS_ERROR_MASK		0x000001FE

#define VIP_STATUS_OP_SEND		0x00000000
#define VIP_STATUS_OP_RECEIVE		0x00010000
#define VIP_STATUS_OP_RDMA_WRITE	0x00020000
#define VIP_STATUS_OP_REMOTE_RDMA_WRITE	0x00030000
#define VIP_STATUS_OP_RDMA_READ		0x00040000
#define VIP_STATUS_OP_MASK		0x00070000
#define VIP_STATUS_IMMEDIATE		0x00080000
#define VIP_STATUS_RESERVED		0xFFF0FE00

/* 
 * Error Descriptors
 * VIA-SPEC 9.10.3
 * IDG 4.4
 */

/** Values for ResourceCode in VIP_ERROR_DESCRIPTOR */
typedef enum {
    VIP_RESOURCE_NIC,
    VIP_RESOURCE_VI,
    VIP_RESOURCE_CQ,
    VIP_RESOURCE_DESCRIPTOR
} VIP_RESOURCE_CODE;

/** Values for ErrorCode in VIP_ERROR_DESCRIPTOR */
typedef enum {
    VIP_ERROR_POST_DESC,
    VIP_ERROR_CONN_LOST,
    VIP_ERROR_RECVQ_EMPTY,
    VIP_ERROR_VI_OVERRUN,
    VIP_ERROR_RDMAW_PROT,
    VIP_ERROR_RDMAW_DATA,
    VIP_ERROR_RDMAW_ABORT,
    VIP_ERROR_RDMAR_PROT,
    VIP_ERROR_COMP_PROT,
    VIP_ERROR_RDMA_TRANSPORT,
    VIP_ERROR_CATASTROPHIC
} VIP_ERROR_CODE;

/** Error descriptor for asynchoronous errors */
typedef struct {
    VIP_NIC_HANDLE	NicHandle;
    VIP_VI_HANDLE	ViHandle;
    VIP_CQ_HANDLE	CQHandle;
    VIP_DESCRIPTOR	*DescriptorPtr;
    VIP_ULONG		OpCode;
    VIP_RESOURCE_CODE	ResourceCode;
    VIP_ERROR_CODE	ErrorCode;
} VIP_ERROR_DESCRIPTOR;


/* 
 * NIC Attributes
 *
 * IDG 4.5 
 * VIA-SPEC 9.10.4. 
 */

/** Reliability level of VI connection */
typedef VIP_USHORT VIP_RELIABILITY_LEVEL;

/** \def VIP_SERVICE_UNRELIABLE 
    Unreliable delivery. 
*/
#define VIP_SERVICE_UNRELIABLE 		0x01

/** \def VIP_SERVICE_RELIABLE_DELIVERY 
    Reliable delivery.
*/
#define VIP_SERVICE_RELIABLE_DELIVERY	0x02

/** \def VIP_SERVICE_RELIABLE_RECEPTION 
    Reliable reception.
*/
#define VIP_SERVICE_RELIABLE_RECEPTION	0x04

/** NIC Attributes */
typedef struct {
    VIP_CHAR		Name[64];
    VIP_ULONG		HardwareVersion;
    VIP_ULONG		ProviderVersion;
    VIP_UINT16		NicAddressLen;
    const VIP_UINT8 	*LocalNicAddress;
    VIP_BOOLEAN		ThreadSafe;
    VIP_UINT16		MaxDiscriminatorLen;
    VIP_ULONG		MaxRegisterBytes;
    VIP_ULONG		MaxRegisterRegions;
    VIP_ULONG		MaxRegisterBlockBytes;
    VIP_ULONG		MaxVI;
    VIP_ULONG		MaxDescriptorsPerQueue;
    VIP_ULONG		MaxSegmentsPerDesc;
    VIP_ULONG		MaxCQ;
    VIP_ULONG		MaxCQEntries;
    VIP_ULONG		MaxTransferSize;
    VIP_ULONG		NativeMTU;
    VIP_ULONG		MaxPtags;
    VIP_RELIABILITY_LEVEL ReliabilityLevelSupport;
    VIP_RELIABILITY_LEVEL RDMAReadSupport;
} VIP_NIC_ATTRIBUTES;

/**
 * Quality of service.
 *
 * \bug Not used in VIA specification or IDG.
 */
typedef VIP_PVOID	VIP_QOS;

/** 
 * VI Attributes.
 *
 * IDG 4.6
 *
 * VIA-SPEC 9.10.5
 */
typedef struct {
    VIP_RELIABILITY_LEVEL	ReliabilityLevel;
    VIP_ULONG			MaxTransferSize;
    VIP_QOS			QoS;
    VIP_PROTECTION_HANDLE	Ptag;
    VIP_BOOLEAN			EnableRdmaWrite;
    VIP_BOOLEAN			EnableRdmaRead;
} VIP_VI_ATTRIBUTES;

/** 
 * Memory Attributes 
 * 
 * IDG 4.7 
 * 
 * VIA-SPEC 9.10.6. 
 */
typedef struct {
    VIP_PROTECTION_HANDLE	Ptag;
    VIP_BOOLEAN			EnableRdmaWrite;
    VIP_BOOLEAN			EnableRdmaRead;
} VIP_MEM_ATTRIBUTES;

/**
 * VI endpoint state.
 * 
 * IDG 4.8 
 *
 * VIA-SPEC 9.10.7
 */
typedef enum {
    VIP_STATE_IDLE,
    VIP_STATE_CONNECTED,
    VIP_STATE_CONNECT_PENDING,
    VIP_STATE_ERROR
} VIP_VI_STATE;

/** 
 * VI network address
 *
 * IDG 4.9
 *
 * VIA-SPEC 9.10.8.
 */
typedef struct {
    VIP_UINT16		HostAddressLen;
    VIP_UINT16		DiscriminatorLen;
    VIP_UINT8		HostAddress[1];
} VIP_NET_ADDRESS;

/**
 * QuerySystemManagementInfo InfoType values
 *
 * IDG 3.7.6
 */
#define VIP_SMI_AUTODISCOVERY	1

/**
 * VIP_SMI_AUTODISCOVERY data structure
 *
 * IDG 3.7.6
 */
typedef struct {
    VIP_ULONG		NumberOfHops;
    VIP_NET_ADDRESS	**ADAddrArray;
    VIP_ULONG		NumAdAddrs;
 } VIP_AUTODISCOVERY_LIST;


/*
 * VIPL API prototypes
 */

/** 
 * Open a VI Nic.
 * See IDG 3.1.1
 */
VIP_RETURN 
VipOpenNic(IN 	const VIP_CHAR 		*DeviceName,
	   OUT	VIP_NIC_HANDLE 		*NicHandle);

/** 
 * Close a VI Nic.
 * See IDG 3.1.2
 */
VIP_RETURN 
VipCloseNic(IN	VIP_NIC_HANDLE		NicHandle);

/** 
 * Create a VI.
 * See IDG 3.2.1
 */
VIP_RETURN 
VipCreateVi(IN	VIP_NIC_HANDLE		NicHandle,
	    IN	VIP_VI_ATTRIBUTES	*ViAttribs,
	    IN	VIP_CQ_HANDLE		SendCQHandle,
	    IN	VIP_CQ_HANDLE		RecvCQHandle,
	    OUT	VIP_VI_HANDLE	        *ViHandle);


/** 
 * Destroy a VI.
 * See IDG 3.2.2
 */
VIP_RETURN 
VipDestroyVi(IN	VIP_VI_HANDLE		ViHandle);

/** 
 * Wait for connection request on server side of connection.
 * See IDG 3.3.1
 */
VIP_RETURN 
VipConnectWait(IN	VIP_NIC_HANDLE		NicHandle,
	       IN	VIP_NET_ADDRESS		*LocalAddr,
	       IN	VIP_ULONG		Timeout,
	       OUT	VIP_NET_ADDRESS		*RemoteAddr,
	       OUT	VIP_VI_ATTRIBUTES	*RemoteViAttribs,
	       OUT	VIP_CONN_HANDLE		*ConnHandle);

/** 
 * Accept a connection request on server side of connection.
 * See IDG 3.3.2
 */
VIP_RETURN 
VipConnectAccept(IN	VIP_CONN_HANDLE		ConnHandle,
		 IN	VIP_VI_HANDLE		ViHandle);


/** 
 * Reject a connection request on server side of connection.
 * See IDG 3.3.3
 */
VIP_RETURN 
VipConnectReject(IN	VIP_CONN_HANDLE		ConnHandle);

/** 
 * Client's request for a connection with server.
 * See IDG 3.3.4
 */
VIP_RETURN 
VipConnectRequest(IN 	VIP_VI_HANDLE		ViHandle,
		  IN	VIP_NET_ADDRESS		*LocalAddr,
		  IN	VIP_NET_ADDRESS		*RemoteAddr,
		  IN	VIP_ULONG		Timeout,
		  OUT 	VIP_VI_ATTRIBUTES	*RemoteViAttribs);

/** 
 * Disconnect a connection 
 * See IDG 3.3.5
 */
VIP_RETURN 
VipDisconnect(IN  	VIP_VI_HANDLE		ViHandle);


/**
 * Request a peer-to-peer connection.
 *
 * See IDG 3.3.6
 */
VIP_RETURN
VipConnectPeerRequest(IN	VIP_VI_HANDLE	ViHandle,
		      IN	VIP_NET_ADDRESS	*LocalAddr,
		      IN	VIP_NET_ADDRESS	*RemoteAddr,
		      IN	VIP_ULONG	Timeout);

/**
 * Poll completion of a requested peer-to-peer connection.
 *
 * See IDG 3.3.7
 */
VIP_RETURN
VipConnectPeerDone(IN	VIP_VI_HANDLE		ViHandle,
		   OUT	VIP_VI_ATTRIBUTES	*RemoteViAttribs);

/**
 * Block waiting for completion of a requested peer-to-peer connection.
 *
 * See IDG 3.3.8
 */
VIP_RETURN
VipConnectPeerWait(IN	VIP_VI_HANDLE		ViHandle,
		   OUT	VIP_VI_ATTRIBUTES	*RemoteViAttribs);


/** 
 * Create a protection tag.
 * See IDG 3.4.1
 */
VIP_RETURN 
VipCreatePtag(IN	VIP_NIC_HANDLE		NicHandle,
	      OUT	VIP_PROTECTION_HANDLE	*ProtectionTag);


/** 
 * Destroy a protection tag.
 * See IDG 3.4.2
 */
VIP_RETURN 
VipDestroyPtag(IN	VIP_NIC_HANDLE		NicHandle,
	       IN	VIP_PROTECTION_HANDLE	ProtectionTag);

/** 
 * Register a memory region.
 * See IDG 3.4.3
 */
VIP_RETURN 
VipRegisterMem(IN	VIP_NIC_HANDLE		NicHandle,
	       IN	VIP_PVOID		VirtualAddress,
	       IN	VIP_ULONG		Length,
	       IN	VIP_MEM_ATTRIBUTES	*MemAttribs,
	       OUT	VIP_MEM_HANDLE		*MemoryHandle);

/** 
 * Deregister a memory region.
 * See IDG 3.4.4
 */
VIP_RETURN 
VipDeregisterMem(IN	VIP_NIC_HANDLE		NicHandle,
		 IN	VIP_PVOID		VirtualAddress,
		 IN	VIP_MEM_HANDLE		MemoryHandle);


/**
 * Post a send descriptor.
 * See IDG 3.5.1
 */
VIP_RETURN 
VipPostSend(IN 	VIP_VI_HANDLE		ViHandle,
	    IN	VIP_DESCRIPTOR		*DescriptorPtr,
	    IN	VIP_MEM_HANDLE		MemoryHandle);

/** 
 * Check for send descriptor completion.
 * See IDG 3.5.2
 */
VIP_RETURN 
VipSendDone(IN	VIP_VI_HANDLE		ViHandle,
	    OUT	VIP_DESCRIPTOR		**DescriptorPtr);

/** 
 * Block for send descriptor completion.
 * See IDG 3.5.3
 */
VIP_RETURN 
VipSendWait(IN	VIP_VI_HANDLE		ViHandle,
	    IN	VIP_ULONG		TimeOut,
	    OUT	VIP_DESCRIPTOR		**DescriptorPtr);

/** 
 * Post a receive descriptor.
 * See IDG 3.5.4
 */
VIP_RETURN 
VipPostRecv(IN	VIP_VI_HANDLE		ViHandle,
	    IN	VIP_DESCRIPTOR		*DescriptorPtr,
	    IN	VIP_MEM_HANDLE		MemoryHandle);

/** 
 * Check for receive descriptor completion.
 * See IDG 3.5.5
 */
VIP_RETURN 
VipRecvDone(IN	VIP_VI_HANDLE		ViHandle,
	    OUT	VIP_DESCRIPTOR		**DescriptorPtr);

/** 
 * Block for receive descriptor completion.
 * See IDG 3.5.6
 */
VIP_RETURN 
VipRecvWait(IN	VIP_VI_HANDLE		ViHandle,
	    IN	VIP_ULONG		TimeOut,
	    OUT	VIP_DESCRIPTOR		**DescriptorPtr);

/** 
 * Check queue for a completion entry.
 * See IDG 3.5.7
 */
VIP_RETURN 
VipCQDone(IN	VIP_CQ_HANDLE		CQHandle,
	  OUT	VIP_VI_HANDLE		*ViHandle,
	  OUT	VIP_BOOLEAN		*RecvQueue);

/** 
 * Block for a completion entry.
 * See IDG 3.5.8
 */
VIP_RETURN 
VipCQWait(IN	VIP_CQ_HANDLE		CQHandle,
	  IN	VIP_ULONG		TimeOut,
	  OUT	VIP_VI_HANDLE		*ViHandle,
	  OUT	VIP_BOOLEAN		*RecvQueue);

/** 
 * Request that a handler routine be called when a send descriptor completes.
 * See IDG 3.5.9.
 */
VIP_RETURN 
VipSendNotify(IN	VIP_VI_HANDLE		ViHandle,
	      IN	VIP_PVOID		Context,
	      IN	void(*Handler)(IN VIP_PVOID	 Context,
				       IN VIP_NIC_HANDLE NicHandle,
				       IN VIP_VI_HANDLE	 ViHandle,
				       IN VIP_DESCRIPTOR *DescriptorPtr));

/** 
 * Request that a handler routine be called when a receive 
 * descriptor completes.
 * 
 * See IDG 3.5.10.
 */
VIP_RETURN 
VipRecvNotify(IN	VIP_VI_HANDLE		ViHandle,
	      IN	VIP_PVOID		Context,
	      IN	void(*Handler)(IN VIP_PVOID	 Context,
				       IN VIP_NIC_HANDLE NicHandle,
				       IN VIP_VI_HANDLE	 ViHandle,
				       IN VIP_DESCRIPTOR *DescriptorPtr));

/** 
 * Request that a handler routine be called when a completion 
 * entry is pushed onto the completion queue.
 * 
 * See IDG 3.5.11.
 */
VIP_RETURN 
VipCQNotify(IN	VIP_CQ_HANDLE		CQHandle,
	    IN	VIP_PVOID		Context,
	    IN	void(*Handler)(IN VIP_PVOID		Context,
			       IN VIP_NIC_HANDLE	NicHandle,
			       IN VIP_VI_HANDLE		ViHandle,
			       IN VIP_BOOLEAN		RecvQueue));

/** 
 * Create a completion queue.
 *
 * See IDG 3.6.1
 */
VIP_RETURN 
VipCreateCQ(IN	VIP_NIC_HANDLE		NicHandle,
	    IN	VIP_ULONG		EntryCount,
	    OUT	VIP_CQ_HANDLE		*CQHandle);

/** 
 * Destroy a completion queue.
 *
 * See IDG 3.6.2
 */
VIP_RETURN 
VipDestroyCQ(IN	VIP_CQ_HANDLE		CQHandle);

/** 
 * Resize a completion queue.
 *
 * See IDG 3.6.3.
 *
 * /bug Unimplemented.
 */
VIP_RETURN 
VipResizeCQ(IN	VIP_CQ_HANDLE		CQHandle,
	    IN	VIP_ULONG		EntryCount);

/**
 * Query the status of a VI NIC.
 *
 * See IDG 3.7.1
 * \bug See comment regarding _VIP_NIC::NicAddr.
 */
VIP_RETURN 
VipQueryNic(IN	VIP_NIC_HANDLE		NicHandle,
	    OUT	VIP_NIC_ATTRIBUTES	*Attributes);

/** 
 * Modify the attributes of a VI.
 *
 * See IDG 3.7.2
 */
VIP_RETURN 
VipSetViAttributes(IN	VIP_VI_HANDLE		ViHandle,
		   IN	VIP_VI_ATTRIBUTES	*Attributes);

/**
 * Query the state of a VI.
 *
 * See IDG 3.7.3
 */
VIP_RETURN 
VipQueryVi(IN	VIP_VI_HANDLE		ViHandle,
	   OUT	VIP_VI_STATE		*State,
	   OUT	VIP_VI_ATTRIBUTES	*Attributes,
	   OUT	VIP_BOOLEAN		*ViSendQEmpty,
	   OUT	VIP_BOOLEAN		*ViRecvQEmpty);

/**
 * Modify the memory attributes of a registered memory region.
 *
 * See IDG 3.7.4
 */
VIP_RETURN 
VipSetMemAttributes(IN	VIP_NIC_HANDLE		NicHandle,
		    IN	VIP_PVOID		Address,
		    IN	VIP_MEM_HANDLE		MemHandle,
		    IN	VIP_MEM_ATTRIBUTES	*MemAttribs);

/**
 * Query the memory attributes of a registered memory region.
 *
 * See IDG 3.7.5
 */
VIP_RETURN 
VipQueryMem(IN	VIP_NIC_HANDLE		NicHandle,
	    IN	VIP_PVOID		Address,
	    IN	VIP_MEM_HANDLE		MemHandle,
	    OUT	VIP_MEM_ATTRIBUTES	*MemAttribs);

/**
 * See IDG 3.7.6.
 *
 * /bug Unimplemented (Always returns VIP_SUCCESS unless NicHandle is invalid).
 */
VIP_RETURN 
VipQuerySystemManagementInfo(IN	VIP_NIC_HANDLE	NicHandle,
			     IN	VIP_ULONG	InfoType,
			     OUT VIP_PVOID	*SysManInfo);

/** 
 * Register an asynchronous error handler.
 *
 * See IDG 3.8.1
 */
VIP_RETURN 
VipErrorCallback(IN	VIP_NIC_HANDLE		NicHandle,
		 IN	VIP_PVOID		Context,
		 IN	void(*Handler)(IN VIP_PVOID Context,
				       IN VIP_ERROR_DESCRIPTOR *ErrorDesc));

/** \page viplns VIPL Name Service Routines
 * XXX: this needs documentation
 */

/**
 * Initialize name service routines.
 *
 * The M-VIA implementation of VipNSInit uses a file-based host database.
 * The default database is during M-VIA configuration.  See the NSInitInfo
 * parameter on how to override the default setting.
 *
 * See IDG 3.9.1
 *
 * @param NicHandle 	The VI NIC context in which to 
 *			initialize the name service.
 * @param NSInitInfo 	A NULL terminated string containing the an alternate
 *			host file used to initialize the name service 
 *			routines.  A value of (VIP_PVOID)0 specifies
 *			the default host file.
 *
 * \bug Quick prototype for ethernet devices.  The parser of the host
 * name file can only handle 6 hex digit hardware addresses.
 *
 */
VIP_RETURN 
VipNSInit(VIP_NIC_HANDLE	NicHandle,
	  VIP_PVOID		NSInitInfo);

/**
 * Shutdown name service routines.
 *
 * See IDG 3.9.4
 */
VIP_RETURN 
VipNSShutdown(VIP_NIC_HANDLE	NicHandle);

/** 
 * Get a host address from its name.
 * 
 * See IDG 3.9.2
 */
VIP_RETURN 
VipNSGetHostByName(VIP_NIC_HANDLE	NicHandle,
		   VIP_CHAR		*Name,
		   VIP_NET_ADDRESS	*Address,
		   VIP_ULONG		NameIndex);

/** 
 * Get a host name from its address.
 *
 * See IDG 3.9.3.
 */
VIP_RETURN 
VipNSGetHostByAddr(VIP_NIC_HANDLE	NicHandle,
		   VIP_NET_ADDRESS	*Address,
		   VIP_CHAR		*Name,
		   VIP_ULONG		*NameLen);

/**
 * Set Application-Specific Data Stucture Pointer
 *
 * Not in IDG
 */
VIP_RETURN
mviaSetViAppData(IN	VIP_VI_HANDLE	ViHandle,
		 IN	VIP_PVOID64	AppData);

/**
 * Get Application-Specific Data Stucture Pointer
 *
 * Not in IDG
 */
VIP_RETURN
mviaGetViAppData(IN	VIP_VI_HANDLE	ViHandle,
		 OUT	VIP_PVOID64	*AppData);

#endif
