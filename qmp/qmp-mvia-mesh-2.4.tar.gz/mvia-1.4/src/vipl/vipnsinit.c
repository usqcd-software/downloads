/* vipnsinit.c
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>

#include "vipl_private.h"

/* 11/17/98: XXX This is still a temporary implementation, slightly more
   more robust than before, but not very general. Currently supports
   loopback and Ethernet, and recognizes Ethernet MAC addresses. 
*/

/* #define VIP_NS_DEBUG */

#define MAX_HOST_LINE 1024

VIP_RETURN 
VipNSInit(VIP_NIC_HANDLE	NicHandle,
	  VIP_PVOID		NSInitInfo)
{
    VIP_CHAR		*HostFileName = VIP_NS_DEFAULT_HOSTFILE;
    FILE 		*HostFile;
    VIP_NS_ENTRY	*NSEntry;
    VIP_NS_ENTRY	**PrevNext;
    int			i, nitems;
    char 		buf[MAX_HOST_LINE];
    char		*bufp;
    char		*nbufp;

    if(NicHandle->TypeId != VIP_TYPE_NIC_HANDLE) {
	return VIP_INVALID_PARAMETER;
    }
    
    if(NicHandle->NSList) {
	return VIP_ERROR_NAMESERVICE;
    }

    if(NSInitInfo) {
	HostFileName = (VIP_CHAR *) NSInitInfo;
    }

    HostFile = fopen(HostFileName, "r");

    if(HostFile == NULL) {
	PERROR("fopen");
	return VIP_ERROR_RESOURCE;
    }

    /* PrevNext is the next pointer of the previous NSEntry.  
     * Start off with the list of NSEntries in the NicHandle 
     */
    PrevNext = &NicHandle->NSList;
    *PrevNext = NULL;

    /* 
     * 0.9b2 Format of the host file is now 0 or more lines with one 
     * of the following forms:
     *     (#) (comment) 
     *     (low-level-address) (whitespace) (name) 
     *     (low-level-address) (whitespace) (name) (#) (comment)
     *     (empty)
     * . Leading and trailing white space are stripped. 
     * . Low level addresses are generally MAC addresses, but
     *   the magic name "loopback" means just that. 
     * . As a side-effect, neither names nor addresses may contain '#'
     * . Aside from being more robust, the format changes slightly from 
     *   0.9b1 in that loopback entries are now consistent with other entries.
     */ 

    while(fgets(buf, MAX_HOST_LINE, HostFile)) {
#ifdef VIP_NS_DEBUG
	printf("NS_DEBUG: got hostfile line: %s", buf);
#endif	

	/* strip any comment */
	bufp = index(buf, '#');
	if (bufp != NULL) *bufp = '\0';
	bufp = &buf[0];
      
	/* strip leading whitespace */
	while (isspace(*bufp)) bufp++;
      
	/* strip trailing whitespace */
	for (i = strlen(bufp) - 1; i >= 0; i--) {
	    if (isspace(bufp[i])) bufp[i] = '\0';
	    else break;
	}

	/* continue if we have a blank line or a comment */
	if (*bufp == '\0') continue;
      
      
	/* Allocate new entry for this line */
	if((NSEntry = malloc(sizeof(VIP_NS_ENTRY))) == NULL) {
	    PERROR("malloc");
	    fclose(HostFile);
	    /* delete what we have malloc'd so far */
	    VipNSShutdown(NicHandle);
	    return VIP_ERROR_RESOURCE;
	}


	NSEntry->Next = NULL;
	NSEntry->HostName = NULL;
	memset(&NSEntry->Address, 0, sizeof(VIP_NET_MAX_ADDRESS));

	/* At this point the buffer should contain an address and name, 
	   separated by whitespace, with no whitespace at beginning
	   of end.  Split up string into two parts. Afterwards,
	   bufp will point to null-terminated address and nbufp
	   to the null-terminated name. 
	*/

	/* find whitespace in middle */
	for (nbufp = bufp; *nbufp != '\0' && !isspace(*nbufp); nbufp++);

	/* make sure we have not reached the end of the string */
	if (*nbufp == '\0') goto BAD_HOSTFILE;

	/* terminate the address in the first part of the string */
	*nbufp = '\0'; 
	nbufp++;

	/* cross over whitespace */
	while (isspace(*nbufp)) nbufp++;

	/* check again to make sure we have two names on this line */
	if (*nbufp == '\0') goto BAD_HOSTFILE;
      
	/* address is in one of two formats (until we support more
	   NICs) "loopback" or "%x:%x:%x:%x:%x:%x" ethernet MAC address
	*/
	 
#ifdef VIP_NS_DEBUG
	printf("NS_DEBUG: found address \"%s\" host \"%s\"\n", bufp, nbufp);
#endif

	if (!strcmp(bufp, "loopback")) {
	    NSEntry->Address.HostAddressLen = 0;
	} else {
	    unsigned int addrs[6];
	    nitems = sscanf(bufp, "%x:%x:%x:%x:%x:%x",
			    &addrs[0],
			    &addrs[1],
			    &addrs[2],
			    &addrs[3],
			    &addrs[4],
			    &addrs[5]);
	    if (nitems != 6) goto BAD_HOSTFILE;

	    for (i = 0; i < 6; i++) {
		if (addrs[i] > 255) goto BAD_HOSTFILE;
		NSEntry->Address.HostAddressLen = 6;
		NSEntry->Address.HostAddress[i] = (VIP_UINT8)addrs[i];
	    }
	}
	
	/* We have the address. Now copy the hostname */
	if((NSEntry->HostName = strdup(nbufp)) == NULL) {
	    PERROR("strdup");
	    goto BAD_HOSTFILE;
	}


	/* Append the new entry and prepare to append to it next iter */
	*PrevNext = NSEntry;
	PrevNext = &NSEntry->Next;
    }
    fclose(HostFile);

    /* normal return */
    return VIP_SUCCESS;	

 BAD_HOSTFILE:
#ifdef VIP_NS_DEBUG
    printf("NS_DEBUG: buf = \"%s\"; bufp = \"%s\"; nbufp = \"%s\"\n",
	   buf, bufp, nbufp);
#endif
    free(NSEntry);
    fclose(HostFile);
    VipNSShutdown(NicHandle);
    return VIP_ERROR_NAMESERVICE;

}

    

    


