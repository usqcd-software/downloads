/** \file fast_trap.h
 *
 * Assembly code for fast-trap transition to the M-VIA device driver.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#ifndef _FAST_TRAP_H
#define _FAST_TRAP_H

#define VIP_INTR_VECTOR		0xf0

#ifndef __KERNEL__

#define VIP_INTR_CALL 		"int $0xf0"

#define VIP_TRAP_POST_SEND	0
#define VIP_TRAP_POST_RECV	1

#define VIP_INTR_CLOBBERS	"cx", "dx"

/*
 * Our calling convention for FastTraps on x86:
 *	EAX = KDev
 *	ECX = Op code
 *	EDX = Arg1 (optional)
 *	ESI = Arg2 (optional)
 *	EDI = Arg3 (optional)
 *	EBX = Arg4 (optional) (must be saved and restored if doing PIC.)
 *
 * Unused optinal arguments are simply not initialized.
 *
 * We use local vars (__op, __kdev, __argN) to preload all the registers.
 */

/*
 * GCC "asm" template for 4-argument Fast Trap.
 *
 * Two different versions depending on whether BX is needed for PIC.
 */
#ifndef __pic__
#define _VipFastTrap4(KDev, Op, Result, Arg1, Arg2, Arg3, Arg4)		\
do {									\
    register unsigned long __kdev __asm__ ("ax") = (unsigned long)KDev;	\
    register unsigned long __arg1 __asm__ ("dx") = (unsigned long)Arg1;	\
    register unsigned long __arg2 __asm__ ("si") = (unsigned long)Arg2;	\
    register unsigned long __arg3 __asm__ ("di") = (unsigned long)Arg3;	\
    register unsigned long __arg4 __asm__ ("bx") = (unsigned long)Arg4;	\
    register unsigned long __op   __asm__ ("cx") = (unsigned long)Op;	\
									\
    __asm__ __volatile__ (VIP_INTR_CALL					\
			/* Outputs: */					\
			  : "=a" (Result)		/* AX */	\
			/* Inputs: */					\
			  : "0" (__kdev),		/* AX */	\
			    "c" (__op),			/* CX */	\
			    "d" (__arg1),		/* DX */	\
			    "S" (__arg2),		/* SI */	\
			    "D" (__arg3),		/* DI */	\
			    "b" (__arg4)		/* BX */	\
			/* Clobbered registers: */			\
			  : VIP_INTR_CLOBBERS);		/* CX, DX */	\
} while(0)
#else
#define _VipFastTrap4(KDev, Op, Result, Arg1, Arg2, Arg3, Arg4)		\
do {									\
    register unsigned long __kdev __asm__ ("ax") = (unsigned long)KDev;	\
    register unsigned long __arg1 __asm__ ("dx") = (unsigned long)Arg1;	\
    register unsigned long __arg2 __asm__ ("si") = (unsigned long)Arg2;	\
    register unsigned long __arg3 __asm__ ("di") = (unsigned long)Arg3;	\
    register unsigned long __arg4 __asm__ ("cx") = (unsigned long)Arg4;	\
									\
    __asm__ __volatile__ (/* Doing PIC, so must save and restore BX */	\
			  "pushl %%ebx		/* Save BX    */\n\t"	\
			  "movl  %%ecx,%%ebx 	/* Arg4->BX   */\n\t"	\
			  "movl  %2,%%ecx   	/* Op->CX     */\n\t"	\
			  VIP_INTR_CALL "\n\t"				\
			  "popl  %%ebx		/* Restore BX */"	\
			/* Outputs: */					\
			  : "=a" (Result)		/* AX */	\
			/* Inputs: */					\
			  : "0" (__kdev),		/* AX */	\
			    "i" ((long) Op),		/* int->CX */	\
			    "d" (__arg1),		/* DX */	\
			    "S" (__arg2),		/* SI */	\
			    "D" (__arg3),		/* DI */	\
			    "c" (__arg4)		/* CX->BX */	\
			/* Clobbered registers: */			\
			  : VIP_INTR_CLOBBERS);		/* CX, DX */	\
} while(0)
#endif

/*
 * GCC "asm" template for 3-argument Fast Trap.
 */
#if __GNUC__>=3 && __GNUC_MINOR__>=3
#define _VipFastTrap3(KDev, Op, Result, Arg1, Arg2, Arg3)		\
do {									\
    register unsigned long __kdev __asm__ ("ax") = (unsigned long)KDev;	\
    register unsigned long __arg1 __asm__ ("dx") = (unsigned long)Arg1;	\
    register unsigned long __arg2 __asm__ ("si") = (unsigned long)Arg2;	\
    register unsigned long __arg3 __asm__ ("di") = (unsigned long)Arg3;	\
    register unsigned long __op   __asm__ ("cx") = (unsigned long)Op;	\
									\
    __asm__ __volatile__ (VIP_INTR_CALL					\
			/* Outputs: */					\
			  : "=a" (Result)		/* AX */	\
			/* Inputs: */					\
			  : "0" (__kdev),		/* AX */	\
			    "c" (__op),			/* CX */	\
			    "d" (__arg1),		/* DX */	\
			    "S" (__arg2),		/* SI */	\
			    "D" (__arg3));		/* DI */	\
} while(0)
#else
#define _VipFastTrap3(KDev, Op, Result, Arg1, Arg2, Arg3)		\
do {									\
    register unsigned long __kdev __asm__ ("ax") = (unsigned long)KDev;	\
    register unsigned long __arg1 __asm__ ("dx") = (unsigned long)Arg1;	\
    register unsigned long __arg2 __asm__ ("si") = (unsigned long)Arg2;	\
    register unsigned long __arg3 __asm__ ("di") = (unsigned long)Arg3;	\
    register unsigned long __op   __asm__ ("cx") = (unsigned long)Op;	\
									\
    __asm__ __volatile__ (VIP_INTR_CALL					\
			/* Outputs: */					\
			  : "=a" (Result)		/* AX */	\
			/* Inputs: */					\
			  : "0" (__kdev),		/* AX */	\
			    "c" (__op),			/* CX */	\
			    "d" (__arg1),		/* DX */	\
			    "S" (__arg2),		/* SI */	\
			    "D" (__arg3)		/* DI */	\
			/* Clobbered registers: */			\
			  : VIP_INTR_CLOBBERS);		/* CX, DX */	\
} while(0)
#endif

/*
 * GCC "asm" template for 2-argument Fast Trap.
 */
#define _VipFastTrap2(KDev, Op, Result, Arg1, Arg2)			\
do {									\
    register unsigned long __kdev __asm__ ("ax") = (unsigned long)KDev;	\
    register unsigned long __arg1 __asm__ ("dx") = (unsigned long)Arg1;	\
    register unsigned long __arg2 __asm__ ("si") = (unsigned long)Arg2;	\
    register unsigned long __op   __asm__ ("cx") = (unsigned long)Op;	\
									\
    __asm__ __volatile__ (VIP_INTR_CALL					\
			/* Outputs: */					\
			  : "=a" (Result)		/* AX */	\
			/* Inputs: */					\
			  : "0" (__kdev),		/* AX */	\
			    "c" (__op),			/* CX */	\
			    "d" (__arg1),		/* DX */	\
			    "S" (__arg2)		/* SI */	\
			/* Clobbered registers: */			\
			  : VIP_INTR_CLOBBERS);		/* CX, DX */	\
} while(0)

/*
 * GCC "asm" template for 1-argument Fast Trap.
 */
#define _VipFastTrap1(KDev, Op, Result, Arg1)				\
do {									\
    register unsigned long __kdev __asm__ ("ax") = (unsigned long)KDev;	\
    register unsigned long __arg1 __asm__ ("dx") = (unsigned long)Arg1;	\
    register unsigned long __op   __asm__ ("cx") = (unsigned long)Op;	\
									\
    __asm__ __volatile__ (VIP_INTR_CALL					\
			/* Outputs: */					\
			  : "=a" (Result)		/* AX */	\
			/* Inputs: */					\
			  : "0" (__kdev),		/* AX */	\
			    "c" (__op),			/* CX */	\
			    "d" (__arg1)		/* DX */	\
			/* Clobbered registers: */			\
			  : VIP_INTR_CLOBBERS);		/* CX, DX */	\
} while(0)

/*
 * GCC "asm" template for 0-argument Fast Trap.
 */
#define _VipFastTrap0(KDev, Op, Result)					\
do {									\
    register unsigned long __kdev __asm__ ("ax") = (unsigned long)KDev;	\
    register unsigned long __op   __asm__ ("cx") = (unsigned long)Op;	\
									\
    __asm__ __volatile__ (VIP_INTR_CALL					\
			/* Outputs: */					\
			  : "=a" (Result)		/* AX */	\
			/* Inputs: */					\
			  : "0" (__kdev),		/* AX */	\
			    "c" (__op)			/* CX */	\
			/* Clobbered registers: */			\
			  : VIP_INTR_CLOBBERS);		/* CX, DX */	\
} while(0)

extern inline VIP_RETURN
VipPostSendTrap(VIP_VI_HANDLE	ViHandle,
		VIP_DESCRIPTOR	*DescriptorPtr,
		VIP_MEM_HANDLE	MemHandle)
{
    VIP_RETURN Status;

    _VipFastTrap3(ViHandle->KernNicHandle,
		  VIP_TRAP_POST_SEND,
		  Status,
		  ViHandle->KernViHandle,
		  DescriptorPtr,
		  MemHandle);

    return Status;
}

extern inline VIP_RETURN
VipPostRecvTrap(VIP_VI_HANDLE	ViHandle,
		VIP_DESCRIPTOR	*DescriptorPtr,
		VIP_MEM_HANDLE	MemHandle)
{
    VIP_RETURN Status;

    _VipFastTrap3(ViHandle->KernNicHandle,
		  VIP_TRAP_POST_RECV,
		  Status,
		  ViHandle->KernViHandle,
		  DescriptorPtr,
		  MemHandle);

    return Status;
}

#else /* __KERNEL__ */

#include "modgate.h"

extern asmlinkage		void VipkFastTrap(void);
static struct desc_struct	vipk_orig_gate;

extern inline int
VipkInstallFastTrap(void)
{
    mod_save_gate(VIP_INTR_VECTOR, vipk_orig_gate);
    mod_set_system_gate(VIP_INTR_VECTOR, &VipkFastTrap);
    return 0;
}

extern inline void
VipkRemoveFastTrap(void)
{
    mod_restore_gate(VIP_INTR_VECTOR, vipk_orig_gate);
}

#endif /* __KERNEL__ */

#endif
