/** \file vipk_lo.h
 *
 * Definitions for M-VIA Loopback Device
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#ifndef _VIPK_LO_H
#define _VIPK_LO_H

#include <vipk.h>

#if MVIA_HAS_FAST_TRAP
#define VIPK_LO_DOORBELL VIP_DOORBELL_FAST_TRAP
#define VIPK_LO_FAST_OPS VIP_TRUE
#else
#define VIPK_LO_DOORBELL VIP_DOORBELL_IOCTL
#define VIPK_LO_FAST_OPS VIP_FALSE
#endif

#define VIPK_LO_HARDWARE_VERSION 0x00010002
#define VIPK_LO_PROVIDER_VERSION 0x00010002
#define VIPK_LO_MAX_DISCRIMINATOR_LEN 16
#define VIPK_LO_MAX_REGISTER_BYTES (VIPK_MAX_MAPPABLE_PAGES * PAGE_SIZE)
#define VIPK_LO_MAX_REGISTER_REGIONS VIPK_MAX_MAPPABLE_PAGES
#define VIPK_LO_RESERVED_PAGES 8 /* fudge factor for CQs in MTU computation */

/* This needs to be one less than the number of max mappable pages
 * in case a user registers the maximum amount of memory and it is not
 * page aligned.
 */
#define VIPK_LO_MAX_REGISTER_BLOCK_BYTES \
((VIPK_MAX_MAPPABLE_PAGES-1) * PAGE_SIZE)

#define VIPK_LO_MAX_VI 1024
#define	VIPK_LO_MAX_DESCRIPTORS_PER_QUEUE 1024
#define VIPK_LO_MAX_SEGMENTS_PER_DESC 1024
#define VIPK_LO_MAX_CQ 1024
#define VIPK_LO_MAX_CQ_ENTRIES 65536
#define VIPK_LO_MAX_TRANSFER_SIZE \
	((VIPK_MAX_MAPPABLE_PAGES-VIPK_LO_RESERVED_PAGES-VIPK_LO_MTU_COUNT) \
						* PAGE_SIZE / VIPK_LO_MTU_COUNT)
#define VIPK_LO_NATIVE_MTU VIPK_LO_MAX_TRANSFER_SIZE
#define VIPK_LO_MAX_PTAGS 1026	/* XXX: fudged to pass broken ConnOv test */

#define VIPK_LO_CONN_QUEUE_SIZE 256

#endif
