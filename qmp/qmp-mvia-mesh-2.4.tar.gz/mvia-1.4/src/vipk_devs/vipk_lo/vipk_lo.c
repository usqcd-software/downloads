/** \file vipk_lo.c
 *
 * Implementation of M-VIA Loopback Device
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */
#include <linux/config.h>
#include <linux/kernel.h>

#ifdef MODULE
#include <linux/module.h>
#include <linux/version.h>
#else
#define MOD_INC_USE_COUNT
#define MOD_DEC_USE_COUNT
#endif

#include <linux/fs.h>
#include <linux/errno.h>
#include <linux/slab.h>

#define VIPK_MAIN
#include <vipk_trace.h>

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
/**
 * The following two attributes are defined twice
 */
#ifdef __attribute_pure__
#undef __attribute_pure__
#endif

#ifdef __attribute_used__
#undef __attribute_used__
#endif

#endif

#include "vipk_lo.h"

/* VIPK_MAIN causes copyright to be included in object file */
#define VIPK_MAIN
#include <copyright.h>

#ifndef MODULE
#error "XXX: non-module version not supported yet"
#else

MODULE_AUTHOR("The Berkeley Lab M-VIA Team <via@nersc.gov>");
MODULE_DESCRIPTION("M-VIA Loopback Device");

#ifdef MVIA_LOOPBACK_MINOR
#define VIPK_LO_MINOR MVIA_LOOPBACK_MINOR
#else
#define VIPK_LO_MINOR 1
#endif

VIPK_DEVICE_PROTOTYPES(via_lo);

/* Loopback device nic attributes */
static VIPK_DEVICE 		LoopDev;
static VIP_CHAR			*LoopDevName = "via_lo";
static VIP_NIC_ATTRIBUTES	LoopDevNicAttribs;

static VIPK_DEVICE_OPERATIONS	LoopDevOps = VIPK_DEVICE_OPS_DEFAULT(via_lo);



static VIP_RETURN
VipkLoSendControl(VIPK_DEVICE		*Dev,
		  VIPK_CCHAN_PACKET	*Pkt)
{
    Dev->CChan.RecvControl(&Dev->CChan, Pkt);
    Dev->CChan.CompleteControl(&Dev->CChan, Pkt);
    return VIP_SUCCESS;
}

static VIP_RETURN
VipkLoConnectionLost(VIPK_DEVICE	*Dev,
		     VIPK_VI_HANDLE	ViHandle,
		     VIP_UINT32		Session,
		     VIP_UINT32		Sequence,
		     VIP_BOOLEAN	IsError)
{
    VIP_RETURN	Status;
    VIPK_VI	*Vi;

    Status  = VIP_SUCCESS;
    Vi = VipkViLookup(Dev, ViHandle);
    if(Vi == NULL) {
	Status = VIP_INVALID_PARAMETER;
    } else if(IsError) {
	if(!Vi->SendDesc) {
	    Status = VipkViConnectionLost(Dev, Vi, Session, Sequence);
	} else {
	    Vi->ConnectionLost = VIP_TRUE;
	    Vi->ConnLostSeq = Sequence;
	}
    }
    return Status;
}

static VIP_RETURN
VipkLoSendConnLost(VIPK_DEVICE	*Dev,
		   VIPK_VI	*Vi,
		   VIP_BOOLEAN	IsError)
{
    VipkLoConnectionLost(Dev, Vi->RemoteViHandle, Vi->Session,
			 Vi->RecvSeq - 1, IsError);
    return VIP_SUCCESS;
}

/*
 * init_module
 *
 * Returns:
 *	0 on success, error from errno.h on failure
 *
 * Parameters:
 *	None
 *
 * Notes:
 * 	Called when module is loaded.
 *	Needs to register itself with the main VI Kernel Agent
 *	framework driver.
 */
int
init_module(void)
{
    VIP_RETURN Status;
    VIP_NIC_ATTRIBUTES *NicAttribs = &LoopDevNicAttribs;

    printk(KERN_INFO "M-VIA Loopback Device\n%s\n", copyright);
    
    strncpy(NicAttribs->Name, LoopDevName, 64);
    NicAttribs->HardwareVersion 	= VIPK_LO_HARDWARE_VERSION;
    NicAttribs->ProviderVersion 	= VIPK_LO_PROVIDER_VERSION;
    NicAttribs->NicAddressLen 		= 0;
    NicAttribs->LocalNicAddress		= NULL;
    NicAttribs->ThreadSafe 		= VIP_FALSE;
    NicAttribs->MaxDiscriminatorLen 	= VIPK_LO_MAX_DISCRIMINATOR_LEN;
    NicAttribs->MaxRegisterBytes 	= VIPK_LO_MAX_REGISTER_BYTES;
    NicAttribs->MaxRegisterRegions 	= VIPK_LO_MAX_REGISTER_REGIONS;
    NicAttribs->MaxRegisterBlockBytes 	= VIPK_LO_MAX_REGISTER_BLOCK_BYTES;
    NicAttribs->MaxVI 			= VIPK_LO_MAX_VI;
    NicAttribs->MaxDescriptorsPerQueue 	= VIPK_LO_MAX_DESCRIPTORS_PER_QUEUE;
    NicAttribs->MaxSegmentsPerDesc 	= VIPK_LO_MAX_SEGMENTS_PER_DESC;
    NicAttribs->MaxCQ 			= VIPK_LO_MAX_CQ;
    NicAttribs->MaxCQEntries		= VIPK_LO_MAX_CQ_ENTRIES;
    NicAttribs->MaxTransferSize 	= VIPK_LO_MAX_TRANSFER_SIZE;
    NicAttribs->NativeMTU 		= VIPK_LO_NATIVE_MTU;
    NicAttribs->MaxPtags 		= VIPK_LO_MAX_PTAGS;
    NicAttribs->ReliabilityLevelSupport = VIP_SERVICE_UNRELIABLE |
					  VIP_SERVICE_RELIABLE_DELIVERY;
    NicAttribs->RDMAReadSupport 	= 0;

    LoopDevOps.SendConnLost 	= VipkLoSendConnLost;
    LoopDevOps.ConnectionLost 	= VipkLoConnectionLost;
    
    LoopDev.NicAttribs 		= NicAttribs;
    LoopDev.DoorbellType 	= VIPK_LO_DOORBELL;
    LoopDev.UsesFastOps 	= VIPK_LO_FAST_OPS;
    LoopDev.DeviceName 		= LoopDevName;
    LoopDev.DeviceOps 		= &LoopDevOps;
    LoopDev.MinorNum 		= VIPK_LO_MINOR;

    LoopDev.CChan 		= VipkCChanDefault;
    LoopDev.Cm 	       		= VipkCmDefault;
    
    if(LoopDev.Cm.Init(&LoopDev.Cm, 
		       &LoopDev.CChan,
		       VIPK_LO_CONN_QUEUE_SIZE) != VIP_SUCCESS) {
	return -ENOMEM;
    }

    if(LoopDev.CChan.Init(&LoopDev.CChan, 
			  &LoopDev,
			  &LoopDev.Cm,
			  VipkLoSendControl) != VIP_SUCCESS) {
	LoopDev.Cm.Destroy(&LoopDev.Cm);	
	return -ENOMEM;
	
    }
    
    Status = VipkRegisterDevice(&LoopDev);

    TRACE(VIPK_TRACE_REGDEV, "VipkRegisterDevice Status: %d", Status);
    return Status;
}


/*
 * cleanup_module
 *
 * Returns:
 *	None
 *
 * Parameters:
 *	None
 *
 * Notes:
 * 	Called when module is unloded.  Note, no need to check
 *	if module is in use.  The module framework verifies use
 * 	counts before calling cleanup_module.
 *
 *	Needs to deregister itself with the main VI Kernel Agent
 *	framework driver.
 */
void
cleanup_module(void)
{
    VIP_RETURN Status;

    Status = VipkDeregisterDevice(&LoopDev);

    TRACE(VIPK_TRACE_REGDEV, "VipkDeregisterDevice Status: %d", Status);

    LoopDev.Cm.Destroy(&LoopDev.Cm);
    LoopDev.CChan.Destroy(&LoopDev.CChan);
    
    printk(KERN_INFO "M-VIA Loopback Device unloaded\n");
}
#endif





