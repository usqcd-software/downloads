/* vipk_ering.h
 *
 * Interface for the Vipk Ethernet Ring devices
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#ifndef _VIPK_ERING_H
#define _VIPK_ERING_H

#include <linux/slab.h>
#include <linux/vmalloc.h>
#include <net/checksum.h>

#include <vipk.h>
#include <vipk_trace.h>
#include <vipk_cchan.h>

#ifdef MVIA_ERING_MINOR
#define VIPK_ERING_MINOR MVIA_ERING_MINOR
#else
#define VIPK_ERING_MINOR 10
#endif

#if MVIA_HAS_FAST_TRAP
#define VIPK_ERING_DOORBELL VIP_DOORBELL_FAST_TRAP
#define VIPK_ERING_FAST_OPS VIP_TRUE
#else
#define VIPK_ERING_DOORBELL VIP_DOORBELL_IOCTL
#define VIPK_ERING_FAST_OPS VIP_FALSE
#endif

#define VIPK_ERING_HARDWARE_VERSION	0x00010002
#define VIPK_ERING_PROVIDER_VERSION	0x00010002
#define VIPK_ERING_ADDR_LEN		6
#define VIPK_ERING_MAX_DISCRIMINATOR_LEN 16
#define VIPK_ERING_MAX_REGISTER_BYTES	(VIPK_MAX_MAPPABLE_PAGES * PAGE_SIZE)
#define VIPK_ERING_MAX_REGISTER_REGIONS VIPK_MAX_MAPPABLE_PAGES

/* This needs to be one less than the number of max mappable pages
 * in case a user registers the maximum amount of memory and it is not
 * page aligned.
 */
#define VIPK_ERING_MAX_REGISTER_BLOCK_BYTES	\
				((VIPK_MAX_MAPPABLE_PAGES-1) * PAGE_SIZE)
#define VIPK_ERING_MAX_VI		1024
#define	VIPK_ERING_MAX_DESCRIPTORS_PER_QUEUE 1024
#define VIPK_ERING_MAX_SEGMENTS_PER_DESC 256
#define VIPK_ERING_MAX_CQ		1024
#define VIPK_ERING_MAX_CQ_ENTRIES	65536

#define VIPK_ERING_MTU			1514 - sizeof(VIPK_ERING_DATA_HDR)

/*
#define VIPK_ERING_MTU			4092 - sizeof(VIPK_ERING_DATA_HDR)
*/

/*
#define VIPK_ERING_MAX_TRANSFER_SIZE	32768
*/
#define VIPK_ERING_MAX_TRANSFER_SIZE	65536

/* XXX: inc of NumPtags is to bypass a bug in the vipconf 0.5
 * conformance ConnOv test.  See bug report to Ed. G.  Remove this
 * when Intel fixes test.
 */
#define VIPK_ERING_MAX_PTAGS		1025 /* XXX 1024 */
#define VIPK_ERING_CONN_QUEUE_SIZE	256

#define VIPK_ERING_PROTOCOL	0x0660

#define VIPK_CONTROL_LAST_FRAG		0x0100
#define VIPK_CONTROL_FIRST_FRAG		0x0200
#define VIPK_CONTROL_IS_NACK		0x0400
#define VIPK_CONTROL_OP_CTRL		0x1000
#define VIPK_CONTROL_OP_ACK		0x2000
#define VIPK_CONTROL_OP_MASK		(VIPK_CONTROL_OP_CTRL | \
					 VIPK_CONTROL_OP_ACK  | \
					 VIP_CONTROL_OP_MASK)

#define VIPK_ERING_RD_TIMEOUT	(HZ/10)
#define VIPK_ERING_RD_LIMIT	(30*HZ/VIPK_ERING_RD_TIMEOUT)	/* 30 sec */

/**
 * Jie Chen: 5/10/2004 
 * Add checksum support to generic ering devices by adding a checksum field
 * to VIA ethernet data header at position of byte 16
 */
typedef struct {
    VIP_UINT8	DstAddr[6];	/* 0 */
    VIP_UINT8	SrcAddr[6];	/* 6 */
    VIP_UINT16	Protocol;	/* 12 */
    VIP_UINT16	Control;	/* 14 */
    VIP_UINT16  Csum;           /* 16 */
} VIPK_ERING_CTRL_HDR;

typedef struct {
    VIP_UINT8	DstAddr[6];	/*  0 -  5: All packets */
    VIP_UINT8	SrcAddr[6];	/*  6 - 11: All packets */
    VIP_UINT16	Protocol;	/* 12 - 13: All packets */
    VIP_UINT16	Control;	/* 14 - 15: All packets */
    VIP_UINT16  Csum;           /* 16 - 17: checksum    */
    VIP_UINT16	ViHandle;	/* 18 - 19: All packets */
    VIP_UINT16	AckSeq;		/* 20 - 21: All packets */
    VIP_UINT32	IData;		/* 22 - 25: Data packets only */
    VIP_UINT32	MemHandle;	/* 26 - 29: RDMA data packets only */
    union {
	VIP_UINT64	_64;
	VIP_UINT32	_32[2];
    }		UserPtr;	/* 30 - 37: RDMA data packets only*/
    VIP_UINT16	Sequence;	/* 38 - 39: Data packets only */
    VIP_UINT16	Offset;		/* 40 - 41: Data packets only */
    VIP_UINT16	Length;		/* 42 - 43: Data packets only */
} __attribute__((packed))	/* Don't let gcc pad end of struct */
VIPK_ERING_DATA_HDR;

typedef struct {
    VIP_UINT8	DstAddr[6];	/*  0 -  5 */
    VIP_UINT8	SrcAddr[6];	/*  6 - 11 */
    VIP_UINT16	Protocol;	/* 12 - 13 */
    VIP_UINT16	Control;	/* 14 - 15 */
    VIP_UINT16  Csum;           /* 16 - 17:     checksum           */
    VIP_UINT16	ViHandle;	/* 19 - 19:	On which Vi?       */
    VIP_UINT16	AckSeq;		/* 20 - 21:	Of which message?  */
    VIP_UINT16	AckOffset;	/* 22 - 23:	How much received? */
} VIPK_ERING_ACK_HDR;

/*
 * All must match up through Control field (bytes 0-13).
 * Data and Ack must match through ViHandle (bytes 0-17).
 */
typedef union {
    VIPK_ERING_CTRL_HDR		Ctrl;
    VIPK_ERING_DATA_HDR		Data;
    VIPK_ERING_ACK_HDR		Ack;
} VIPK_ERING_HDR;

typedef enum {
    VIPK_ERING_TX_TRADITIONAL,
    VIPK_ERING_TX_VIA_UR,
    VIPK_ERING_TX_VIA_RD,
    VIPK_ERING_TX_VIA_IGNORE,
    VIPK_ERING_TX_VIA_CONTROL
} VIPK_ERING_TX_TYPE;

/*
 * Information needed to complete a sent RD descriptor.
 */
typedef struct _VIPK_ERING_RD_INFO{
    VIPK_VI			*Vi;
    VIPK_NIC_INSTANCE		NicInstance;
    VIPK_RMM_HANDLE		RmmHandle;
    VIP_DESCRIPTOR		*Desc;
    VIP_MEM_HANDLE		MemHandle;
    VIP_PROTECTION_HANDLE	Ptag;
    VIP_UINT16			Sequence;
    VIP_UINT16			Offset;
    VIP_UINT16			ResendsLeft;
    atomic_t			RefCount;
    unsigned long		TimeStamp;
    struct _VIPK_ERING_RD_INFO	*Next;
} VIPK_ERING_RD_INFO;

typedef struct {
    VIPK_ERING_TX_TYPE		TxType;
    VIPK_VI			*Vi;
    VIPK_NIC_INSTANCE		NicInstance;
    VIPK_RMM_HANDLE		RmmHandle;
    VIP_DESCRIPTOR		*Desc;
    VIP_MEM_HANDLE		MemHandle;
    VIP_PROTECTION_HANDLE	Ptag;
    VIPK_CCHAN_PACKET		*Ctrl;
    VIPK_ERING_RD_INFO		*SendInfo;
} VIPK_ERING_TX_INFO;

typedef struct {
    VIP_PVOID			PrivateData;
    VIP_UINT32			TxRingSize;
    void			(*ResendTask)(void	*Arg);
    VIP_RETURN			(*SendAck)(VIPK_DEVICE	*DevicePtr,
					   VIPK_VI	*Vi,
					   VIP_UINT16	Sequence,
					   VIP_UINT16	Control);
} VIPK_ERING_DEV_PRIV;

typedef enum {
    VIPK_ERING_TX_STREAMING,	/* The normal state */
    VIPK_ERING_TX_RECOVERING,	/* Resending (presumably) lost data */
    VIPK_ERING_TX_DRAINING,	/* Draining TX queue before breaking conn */
    VIPK_ERING_TX_STOPPED	/* VI is no longer connected */
} VIPK_ERING_TX_STATE;

typedef struct {
    VIPK_ERING_HDR	*TxHdrs;
    spinlock_t		Lock;		/* protects following fields */
    atomic_t		DescCount;	/* Active Descriptors */
    VIPK_ERING_TX_STATE	TxState;
    condvar_t		TxStateChange;
    /* Used only by Reliable Delivery: */
    struct {
	VIP_BOOLEAN		RecvOK;		/* was last frame accepted? */
	struct timer_list	Timer;		/* timer to trigger resends */
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
        struct work_struct      Task;
#else
	struct tq_struct	Task;		/* task to perform resends */
#endif
	VIPK_ERING_RD_INFO	*SentHead;	/* queue of sent messages */
	VIPK_ERING_RD_INFO	*SentTail;	/* queue of sent messages */
	VIP_UINT16		AckSeq;		/* Next msg number to ACK */
    }			RD;
} VIPK_ERING_VI_PRIV;

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
#define queue_task(work, timer) (schedule_delayed_work(work, 1))
#endif


extern void
VipkERingInit(VIPK_DEVICE		**DevicePtr,
	      VIPK_DEVICE_OPERATIONS	*DefDevOps,
	      VIP_RETURN		(*SendControl) (VIPK_DEVICE *,
							VIPK_CCHAN_PACKET *),
	      VIP_RETURN		(*PostSend)	(VIPK_DEVICE *,
							 VIPK_VI_HANDLE,
							 VIP_DESCRIPTOR *,
							 VIP_MEM_HANDLE),
	      void			(*ResendTask)  (void *),
	      VIP_RETURN		(*SendAck)     (VIPK_DEVICE *,
							VIPK_VI *,
							VIP_UINT16,
							VIP_UINT16),
	      void			*DevPriv,
	      VIP_CHAR			*DevName,
	      VIP_UINT32		DevIndex,
	      VIP_UCHAR			*MacAddr,
	      VIP_UINT32		TxRingSize);

extern inline VIP_UINT32
VipkERingDevIndex(VIP_CHAR *DevName, VIP_CHAR *TextName) {
    return (DevName[strlen(TextName)]) - '0';
}

extern void
VipkERingRegister(VIPK_DEVICE	*DevicePtr);

extern void
VipkERingDeregister(VIPK_DEVICE	*DevicePtr);

extern void
VipkERingReleaseTx(VIPK_VI	*Vi);

#define VIPK_ERING_PROTOTYPES(DevName, DevType)				 \
VIP_RETURN								 \
VipkERing ## DevName ## SendControl(VIPK_DEVICE		*DevicePtr,	 \
				    VIPK_CCHAN_PACKET	*Pkt);		 \
VIP_RETURN								 \
VipkERing ## DevName ## PostSend(VIPK_DEVICE	*DevicePtr,		 \
				 VIPK_VI_HANDLE	ViHandle,		 \
				 VIP_DESCRIPTOR	*Desc,			 \
				 VIP_MEM_HANDLE	MemHandle);		 \
void									 \
VipkERing ## DevName ## ResendTask(void		*Arg);			 \
VIP_RETURN								 \
VipkERing ## DevName ## SendAck(VIPK_DEVICE	*DevicePtr,		 \
				VIPK_VI		*Vi,			 \
				VIP_UINT16	Sequence,		 \
				VIP_UINT16	Control);		 \
VIPK_DEVICE_PROTOTYPES(DevName);					 \
VIPK_DEVICE_OPERATIONS Vipk ## DevName ## DevOps =			 \
	VIPK_DEVICE_OPS_DEFAULT(DevName);



#define VIPK_ERING_SEND_COMPLETE_BEGIN(VipkDevicePtr, TxRingInfo, TxNum) \
do {									 \
    VIPK_ERING_TX_INFO	*TxInfo;					 \
    VIPK_ERING_TX_TYPE  TxType;						 \
									 \
    TxInfo = &TxRingInfo[TxNum];					 \
    TxType = TxInfo->TxType;						 \
    TxInfo->TxType = VIPK_ERING_TX_TRADITIONAL;				 \
									 \
    if(TxType == VIPK_ERING_TX_VIA_UR) {				 \
	VIP_DESCRIPTOR	*KernDesc;					 \
									 \
	KernDesc = VipkRmmKaddr(TxInfo->RmmHandle, TxInfo->Desc,	 \
				TxInfo->MemHandle, TxInfo->Ptag,	 \
				VIPK_RMM_MEM_FLAGS_WRITE,		 \
				TxInfo->NicInstance);			 \
									 \
	if(KernDesc) {							 \
	    VipkViSendComplete(VipkDevicePtr, TxInfo->Vi,		 \
			       KernDesc, VIP_STATUS_DONE);		 \
	}								 \
									 \
	VIPK_ERING_RELEASE_TX(TxInfo->Vi);				 \
    } else if(TxType == VIPK_ERING_TX_VIA_RD) {				 \
	VIPK_ERING_RELEASE_TX(TxInfo->Vi);				 \
    } else if(TxType == VIPK_ERING_TX_VIA_IGNORE) {			 \
	/* Ignore it, of course. */					 \
    } else if(TxType == VIPK_ERING_TX_VIA_CONTROL) {			 \
	VipkDevicePtr->CChan.CompleteControl(&VipkDevicePtr->CChan,	 \
					     TxInfo->Ctrl);		 \
    } else {


#define VIPK_ERING_SEND_COMPLETE_END()		\
    }						\
} while(0)

#define VIPK_ERING_INIT(Name, DevPriv, VipkDevicePtr, DevName,		\
			DevIndex, MacAddr, TxRingSize)			\
do {									\
    VipkERingInit(&VipkDevicePtr,					\
		  &Vipk ## Name ## DevOps,				\
		  VipkERing ## Name ## SendControl,			\
		  VipkERing ## Name ## PostSend,			\
		  VipkERing ## Name ## ResendTask,			\
		  VipkERing ## Name ## SendAck,				\
		  DevPriv, DevName, DevIndex,				\
		  MacAddr, TxRingSize);					\
} while(0)

#define VIPK_ERING_CLEANUP(VipkDevicePtr)			\
do {								\
    VipkDevicePtr->Cm.Destroy(&VipkDevicePtr->Cm);		\
    VipkDevicePtr->CChan.Destroy(&VipkDevicePtr->CChan);	\
    vfree(VipkDevicePtr->PrivateData);				\
    vfree(VipkDevicePtr->NicAttribs);				\
    vfree(VipkDevicePtr->DeviceOps);				\
    vfree(VipkDevicePtr);					\
} while(0)

/*
 * In the spirit of time_before() and time_after in linux/timer.h, these
 * calls take care of wrap-arond when comparing 16-bit sequence numbers.
 * The trick is to check only the sign bit after a subtraction.
 */
#define VIPK_ERING_SEQ_LT(a,b)  ((s16)((VIP_UINT16)(a) - (VIP_UINT16)(b)) < 0)
#define VIPK_ERING_SEQ_LE(a,b)	(!VIPK_ERING_SEQ_LT((b),(a)))
#define VIPK_ERING_SEQ_GT(a,b)  VIPK_ERING_SEQ_LT((b),(a))
#define VIPK_ERING_SEQ_GE(a,b)	(!VIPK_ERING_SEQ_LT((a),(b)))
/* and for completeness.. */
#define VIPK_ERING_SEQ_EQ(a,b)	((VIP_UINT16)(a)==(VIP_UINT16)(b))
#define VIPK_ERING_SEQ_NE(a,b)	((VIP_UINT16)(a)!=(VIP_UINT16)(b))

#define VIPK_ERING_SEND_ACK(DEV,VI,SEQ)					\
	((VIPK_ERING_DEV_PRIV *)(DEV)->PrivateData)->			\
	SendAck(DEV, VI, SEQ, VIPK_SWAB16(VIPK_CONTROL_OP_ACK))

#define VIPK_ERING_SEND_NACK(DEV,VI,SEQ)				\
	((VIPK_ERING_DEV_PRIV *)(DEV)->PrivateData)->			\
	SendAck(DEV, VI, SEQ, VIPK_SWAB16(VIPK_CONTROL_OP_ACK|		\
					  VIPK_CONTROL_IS_NACK))

#define VIPK_ERING_RELEASE_TX(VI)					\
	do {								\
	    VIPK_ERING_VI_PRIV *ViPriv =				\
	    		(VIPK_ERING_VI_PRIV *)(VI)->PrivateData;	\
									\
	    if(atomic_dec_and_test(&ViPriv->DescCount)) {		\
		VipkERingReleaseTx(VI);					\
	    }								\
	} while (0)							\

#define VIPK_ERING_RELEASE_RD(SENDINFO)					\
	do {								\
	    if(atomic_dec_and_test(&(SENDINFO)->RefCount)) {		\
		kfree(SENDINFO);					\
	    }								\
	} while (0)							\


static inline
void
VipkERingAckOne(VIPK_DEVICE		*DevicePtr,
		VIPK_VI			*Vi,
		VIPK_ERING_VI_PRIV	*ViPriv,
		VIPK_ERING_RD_INFO	*SendInfo)
{
    VIP_DESCRIPTOR	*KernDesc;

    KernDesc = VipkRmmKaddr(SendInfo->RmmHandle, SendInfo->Desc,
			    SendInfo->MemHandle, SendInfo->Ptag,
			    VIPK_RMM_MEM_FLAGS_WRITE,
			    SendInfo->NicInstance);

    if(KernDesc) {
	VipkViSendComplete(DevicePtr, Vi, KernDesc, VIP_STATUS_DONE);
    }

    ViPriv->RD.AckSeq = SendInfo->Sequence + 1;
}

/*
 * Receive a (N)ACK and complete the appropriate descriptors.
 * The Offset argument is only meaningful in a NACK.
 */
static inline
void
VipkERingRecvAck(VIPK_DEVICE	*DevicePtr,
		 VIPK_VI	*Vi,
		 VIP_UINT16	Sequence,
		 VIP_UINT16	Offset,
		 VIP_BOOLEAN	IsNAck)
{
    VIPK_ERING_VI_PRIV	*ViPriv;
    VIPK_ERING_RD_INFO	*Head;
    unsigned long	Flags;


    ViPriv = (VIPK_ERING_VI_PRIV *)Vi->PrivateData;

    /* This test is just an optimization and can safely be done without
     * locking because we can only error on the side of caution.  If we
     * lose a race to update AckSeq then we'll find out after we acquire
     * the lock.
     */
    if(VIPK_ERING_SEQ_LT(Sequence, ViPriv->RD.AckSeq)) {
	return;
    }

    spin_lock_irqsave(&ViPriv->Lock, Flags);
    Head = ViPriv->RD.SentHead;
    if(Head) {
	VIPK_ERING_RD_INFO	*Tail = Head;

	/* Process all implicit and explicit ACKs while lock is held */
	while(Tail && VIPK_ERING_SEQ_GT(Sequence, Tail->Sequence)) {
	    VipkERingAckOne(DevicePtr, Vi, ViPriv, Tail);
	    Tail = Tail->Next;
	}
	if(!IsNAck && Tail && VIPK_ERING_SEQ_EQ(Sequence, Tail->Sequence)) {
	    VipkERingAckOne(DevicePtr, Vi, ViPriv, Tail);
	    Tail = Tail->Next;
	}
	ViPriv->RD.SentHead = Tail;

	if(!IsNAck) {
	    /* (re)schedule resend task or wake blocked sender */
	    if(Tail) {
		unsigned long	When = Tail->TimeStamp + VIPK_ERING_RD_TIMEOUT;

		if(ViPriv->TxState == VIPK_ERING_TX_STREAMING &&
		   time_after(When, jiffies)) {
		    mod_timer(&ViPriv->RD.Timer, When);
		} else {
		    queue_task(&ViPriv->RD.Task, &tq_timer);
		}
	    } else {
		if(ViPriv->TxState == VIPK_ERING_TX_RECOVERING) {
		    ViPriv->TxState = VIPK_ERING_TX_STREAMING;
		    cond_signal(&ViPriv->TxStateChange);
		}

		del_timer(&ViPriv->RD.Timer);
	    }
	} else {
	    /* Process the NACK */
	    if(Tail && VIPK_ERING_SEQ_EQ(Sequence, Tail->Sequence)) {
		Tail->Offset = Offset;
		queue_task(&ViPriv->RD.Task, &tq_timer);
	    }
	}
	spin_unlock_irqrestore(&ViPriv->Lock, Flags);

	/* Now release SendInfo w/o holding any locks */
	while(Head != Tail) {
	    VIPK_ERING_RD_INFO	*Tmp;

	    Tmp = Head;
	    Head = Head->Next;
	    VIPK_ERING_RELEASE_RD(Tmp);
	}
    } else {
	spin_unlock_irqrestore(&ViPriv->Lock, Flags);
    }
}

static inline
VIP_BOOLEAN
VipkERingDoRecv(VIPK_DEVICE		*DevPtr,
		VIPK_ERING_DATA_HDR	*Hdr,
		VIPK_VI_HANDLE		ViHandle,
		VIP_UINT16		Adjust)
{
    VIP_UINT8		*Buf;
    VIP_UINT32		*IDataPtr;
    VIP_BOOLEAN		FirstFrag;
    VIP_BOOLEAN		LastFrag;
    VIP_UINT16		Op;
    VIP_UINT16		Length;

    Buf = (VIP_UINT8 *)Hdr + sizeof(VIPK_ERING_DATA_HDR) + Adjust;
    IDataPtr = ((Hdr->Control & VIPK_SWAB16(VIP_CONTROL_IMMEDIATE))
							? &Hdr->IData : NULL);
    FirstFrag = Hdr->Control & VIPK_SWAB16(VIPK_CONTROL_FIRST_FRAG);
    LastFrag = Hdr->Control & VIPK_SWAB16(VIPK_CONTROL_LAST_FRAG);
    Op = Hdr->Control & VIPK_SWAB16(VIPK_CONTROL_OP_MASK);
    Length = VIPK_SWAB16(Hdr->Length) - Adjust;

    if(Op == VIPK_SWAB16(VIP_CONTROL_OP_SENDRECV)) {
	return VipkRecv(DevPtr, ViHandle, Buf, Length,
			IDataPtr, FirstFrag, LastFrag);
    } else if(Op == VIPK_SWAB16(VIP_CONTROL_OP_RDMAWRITE)) {
	VIP_MEM_HANDLE	MemHandle;
	VIP_PVOID	UserPtr;

#if (BITS_PER_LONG == 64)
	/* Need all 64 bits of the field */
	UserPtr = (VIP_PVOID)
		(Adjust + VIPK_SWAB64(get_unaligned(&Hdr->UserPtr._64)));
#elif (BITS_PER_LONG == 32) && defined(VIPK_LITTLE_ENDIAN)
	/* Need only the first 32 bits of the field */
	UserPtr = (VIP_PVOID)
		(Adjust + VIPK_SWAB32(get_unaligned(&Hdr->UserPtr._32[0])));
#elif (BITS_PER_LONG == 32) && defined(VIPK_BIG_ENDIAN)
	/* Need only the last 32 bits of the field */
	UserPtr = (VIP_PVOID)
		(Adjust + VIPK_SWAB32(get_unaligned(&Hdr->UserPtr._32[1])));
#else
#	error "Unknown wordsize and/or byteorder"
#endif
	MemHandle = (VIP_MEM_HANDLE)VIPK_SWAB32(get_unaligned(&Hdr->MemHandle));

	return VipkRecvRdmaWrite(DevPtr, ViHandle, Buf, Length,
				 UserPtr, MemHandle,
				 IDataPtr, FirstFrag, LastFrag);
    } else {
	/* Ignore the bogus frame */
	return VIP_FALSE;
    }
}

static inline
VIP_BOOLEAN
VipkERingCheckSeqUR(VIPK_DEVICE		*DevPtr,
		    VIPK_ERING_DATA_HDR	*Hdr,
		    VIPK_VI		*Vi)
{
    if(VIPK_ERING_SEQ_EQ(VIPK_SWAB16(Hdr->Sequence), Vi->RecvSeq)) {
	VIP_UINT16	Offset;

	Offset = VIPK_SWAB16(Hdr->Offset);

	if(Offset == Vi->RecvXferLen) {
	    return VIP_TRUE;	/* Normal case */
	} else if(Offset < Vi->RecvXferLen) {
	    /* Ignore duplicate frame */
	    return VIP_FALSE;
	} else {
	    /* Frame is part of the current VIA message, but beyond the
	     * current window. So fall through to failure.
	     */
	}
    } else if(VIPK_ERING_SEQ_LT(VIPK_SWAB16(Hdr->Sequence), Vi->RecvSeq)) {
	/* Sequence number is smaller than desired.
	 * Ignore duplicate frame or trailing garbage
	 */
	return VIP_FALSE;
    } else {
	/* Frame is beyond the current VIA message.
	 * So fall through to failure.
	 */
    }

    /* We received a frame beyond the current window, so try to resync */
    if(Hdr->Control & VIPK_SWAB16(VIPK_CONTROL_FIRST_FRAG)) {
	/* resync on first fragment bit */
	printk(KERN_WARNING
	       "VipkERingRecv(UR): %s ViHandle 0x%x lost %d message(s).\n",
	       DevPtr->DeviceName, VIPK_SWAB16(Hdr->ViHandle),
	       (VIPK_SWAB16(Hdr->Sequence) - (VIP_UINT16)Vi->RecvSeq) & 0xfff);
	TRACE(VIPK_TRACE_RECV, "expected 0x%04x/0x%04x",
	      (VIP_UINT16)Vi->RecvSeq, Vi->RecvXferLen);
	TRACE(VIPK_TRACE_RECV, "received 0x%04x/0x%04x",
	      VIPK_SWAB16(Hdr->Sequence), VIPK_SWAB16(Hdr->Offset));

	Vi->RecvSeq = VIPK_SWAB16(Hdr->Sequence);
	Vi->RecvXferLen = 0;
	return VIP_TRUE;
    } else {
	return VIP_FALSE;
    }
}

/* XXX: The use of RecvOK to limit back-to-back sends of NACKs and resends
 * of ACKs is very simplistic.  A more intelligent method might allow the
 * sending to resume again at some point.
 */
static inline
VIP_BOOLEAN
VipkERingCheckSeqRD(VIPK_DEVICE		*DevPtr,
		    VIPK_ERING_DATA_HDR	*Hdr,
		    VIPK_VI		*Vi)
{
    VIPK_ERING_VI_PRIV	*ViPriv;

    ViPriv = (VIPK_ERING_VI_PRIV *)Vi->PrivateData;

    if(VIPK_ERING_SEQ_EQ(VIPK_SWAB16(Hdr->Sequence), Vi->RecvSeq)) {
	VIP_UINT16	Offset;

	Offset = VIPK_SWAB16(Hdr->Offset);

	if(Offset <= Vi->RecvXferLen) {
	    /* LastFrag automatically passes window check.  This is the
	     * only case in which a zero-byte recv may occur.
	     */
	    if(Hdr->Control & VIPK_SWAB16(VIPK_CONTROL_LAST_FRAG)) {
		/* process piggybacked ACK */
		VipkERingRecvAck(DevPtr, Vi, VIPK_SWAB16(Hdr->AckSeq),
				 0, VIP_FALSE);

		ViPriv->RD.RecvOK = VIP_TRUE;
		return VIP_TRUE;	/* Normal case 1 */
	    } else if(Offset + VIPK_SWAB16(Hdr->Length) > Vi->RecvXferLen) {
		ViPriv->RD.RecvOK = VIP_TRUE;
		return VIP_TRUE;	/* Normal case 2 */
	    } else {
		return VIP_FALSE;
	    }
	} else {
	    /* Frame is part of the current VIA message, but beyond the
	     * current window. So fall through to NACK.
	     */
	}
    } else if(VIPK_ERING_SEQ_LT(VIPK_SWAB16(Hdr->Sequence), Vi->RecvSeq)) {
	/* Ignore resends of completed VIA messages.  However we send an
	 * ACK because the sender may have missed one.
	 * Check RecvOK to avoid back-to-back ACKs.
	 */
	if(ViPriv->RD.RecvOK ||
	   (Hdr->Control & VIPK_SWAB16(VIPK_CONTROL_FIRST_FRAG))) {
	    VIPK_ERING_SEND_ACK(DevPtr, Vi, Vi->RecvSeq - 1);
	    ViPriv->RD.RecvOK = VIP_FALSE;
	}
	return VIP_FALSE;
    } else {
	/* Frame is beyond the current VIA message.
	 * So fall through to NACK.
	 */
    }

    /* We received a frame beyond the current window, so send a NACK.
     * Use RecvOK to prevent NACKing every subsequent frame.
     */
    if(ViPriv->RD.RecvOK) {
	VIPK_ERING_SEND_NACK(DevPtr, Vi, Vi->RecvSeq);
	ViPriv->RD.RecvOK = VIP_FALSE;
    }
    TRACE(VIPK_TRACE_RECV,
	   "VipkERingRecv(RD): %s ViHandle 0x%x "
	   "expected 0x%04x/0x%04x received 0x%04x/0x%04x\n",
	   DevPtr->DeviceName, VIPK_SWAB16(Hdr->ViHandle),
	   (VIP_UINT16)Vi->RecvSeq, Vi->RecvXferLen,
	   VIPK_SWAB16(Hdr->Sequence), VIPK_SWAB16(Hdr->Offset));

    return VIP_FALSE;
}

/**
 * Jie Chen: 5/10/2004
 * Check sum offset from the beginning of the buffer.
 * Check sum starts after csum member of a ethernet header
 *
 * The following routines are for software checksum if there is
 * no capability of hardware checksum
 */
#define VIPK_ERING_CSUM_VALUE_OFFSET 16
#define VIPK_ERING_CSUM_OFFSET 18

#if 0
static inline
VIP_UINT32 
VipkERingChecksumHdr (const VIP_UINT8 *hdr, int len)
{
  VIP_UINT32 sumres;

  sumres = 0;
  if (len > VIPK_ERING_CSUM_OFFSET) 
    sumres = csum_partial(hdr + VIPK_ERING_CSUM_OFFSET, 
			  len - VIPK_ERING_CSUM_OFFSET, 0);
  return sumres;
}

static inline
VIP_UINT32 
VipkERingChecksumData (const VIP_UINT8* buffer, int len,
		       VIP_UINT32 sum)
{
  VIP_UINT32 csumres;

  csumres = sum;
  if (len & 0x1) {
    /* Odd length */
    csumres = csum_partial(buffer, len - 1, csumres);
    csumres += ((buffer[len - 1] << 8) & 0xff00);
  }
  else
    csumres = csum_partial(buffer, len, sum);

  return csumres;
}

static inline
VIP_UINT32
VipkERingChecksumFold (VIP_UINT32 sum)
{
  return csum_fold (sum);
}
#endif

/**
 * Software via check sum on an incoming packet
 * This routine is called after the above
 *
 * @return: 1 VIA packet checksumed ok
 *          0 VIA packet checksum failed
 */
static inline int
VipkERingRecvCheckSum (VIPK_DEVICE	*DevPtr,
		       VIP_UINT8	*RxBuf,
		       VIP_UINT32       length)
{
  VIPK_ERING_HDR* hdr;
  VIP_UINT32 csum;

  hdr = (VIPK_ERING_HDR *)RxBuf;
  csum = 0;
  /* Checksum header and data buffer */
  /* Length - 4 is CRC appended 4 bytes  */
  if (length - 4 > VIPK_ERING_CSUM_OFFSET) 
    csum = csum_partial (RxBuf + VIPK_ERING_CSUM_OFFSET, 
			 length - VIPK_ERING_CSUM_OFFSET - 4, 0);
  csum = csum_fold (csum);

  if (csum != hdr->Ctrl.Csum) {
    if (csum == 0x0 && hdr->Ctrl.Csum == 0xffff) {
      /* Somehow sender hw checksum put 0xffff on the Csum field, but receiver
       * get 0x0 as the csum value: strange */
      ;
    }
    else {
      printk (KERN_ALERT "CheckSum Error Receiving checksum = 0x%x recevied csum = 0x%x length = %d\n",
	      csum, hdr->Ctrl.Csum, length - 4);
      return 0;
    }
  }
    
  return 1;
}

/**
 * We know len is an even and hdr start at even address
 */
static inline
VIP_UINT32 
VipkERingChecksumHdr (const VIP_UINT8 *hdr, int len)
{
  VIP_UINT32 sumres;
  register int i;

  sumres = 0;
  if (len > VIPK_ERING_CSUM_OFFSET) {
    for (i = VIPK_ERING_CSUM_OFFSET; i < len; i = i + 2)
      sumres += (((hdr[i + 1] << 8) & 0xFF00) + (hdr[i] & 0xFF));
  }
  return sumres;
}

/**
 * Check sum a data buffer with length of 'len'.
 * 
 * @param buffer    memory address
 * @param len       buffer length
 * @param aliagned  1 means this buffer starts at low byte
 *                  0 this buffer starts at high byte.
 * @param sum       previous checksum value
 * @return checksum value in 32bit
 */
static inline
VIP_UINT32 
VipkERingChecksumData (const VIP_UINT8* buffer, int len, int aligned,
		       VIP_UINT32 sum)
{
  VIP_UINT32 csumres;
  register int i;

  csumres = sum;
  /**
   * if this buffer starts out not aligned due to a previous
   * buffer with length of odd number
   */
  if (!aligned) {
    csumres += ((buffer[0] << 8) & 0xFF00);
    len = len - 1;
    buffer++;
  }
  
  if (len & 0x1) {
    /* Odd length */
    for (i = 0; i < len - 1; i = i + 2) 
      csumres += (((buffer[i + 1] << 8) & 0xFF00) + (buffer[i] & 0xFF));
    csumres += (buffer[len - 1] & 0xFF);
  }
  else
    for (i = 0; i < len; i = i + 2) 
      csumres += (((buffer[i + 1] << 8) & 0xFF00) + (buffer[i] & 0xFF));

  return csumres;
}

/**
 * Return checksum value from 32bit to 16bit and 1's complement value
 */
static inline
VIP_UINT32
VipkERingChecksumFold (VIP_UINT32 sum)
{
  /* keep only the last 16 bits of the 32 bit calculated 
   * sum and add the carries
   */ 
  while (sum>>16)
    sum = (sum & 0xFFFF)+(sum >> 16);
 
  /* Take the one's complement of sum */
  sum = ~sum;

  return sum;
}

/**
 * Check whether a packet is a VIA packet
 */
static inline int
VipkERingViaPacket (VIP_UINT8	*RxBuf,
		    VIP_UINT32   length)
{
  VIPK_ERING_HDR* hdr;

  hdr = (VIPK_ERING_HDR *)RxBuf;
  if(hdr->Ctrl.Protocol == htons(VIPK_ERING_PROTOCOL)) 
    return 1;

  return 0;
}

static inline
VIP_BOOLEAN
VipkERingRecv(VIPK_DEVICE	*DevPtr,
	      VIP_UINT8		*RxBuf)
{
    VIPK_VI		*Vi;
    VIPK_ERING_HDR	*Hdr;
    VIP_UINT16		ViHandle;
    VIP_UINT16		Op;

    Hdr = (VIPK_ERING_HDR *) RxBuf;

    if(Hdr->Ctrl.Protocol == htons(VIPK_ERING_PROTOCOL)) {
	Op = Hdr->Ctrl.Control & VIPK_SWAB16(VIPK_CONTROL_OP_MASK);

	if(Op == VIPK_SWAB16(VIPK_CONTROL_OP_CTRL)) {
	    DevPtr->CChan.RecvControl(&DevPtr->CChan,
				      (VIPK_CCHAN_PACKET *)
				      (RxBuf+sizeof(VIPK_ERING_CTRL_HDR)));
	    return VIP_TRUE;
	}

	ViHandle = VIPK_SWAB16(Hdr->Data.ViHandle);
	Vi = VipkViLookup(DevPtr, ViHandle);
	if(Vi == NULL) {
	    return VIP_TRUE;
	}

	if(Vi->ViAttribs.ReliabilityLevel == VIP_SERVICE_UNRELIABLE) {
	    if(VipkERingCheckSeqUR(DevPtr, &Hdr->Data, Vi)) {
		VipkERingDoRecv(DevPtr, &Hdr->Data, ViHandle, 0);
	    }
	} else if(Vi->ViAttribs.ReliabilityLevel ==
					VIP_SERVICE_RELIABLE_DELIVERY) {
	    if(Op != VIPK_SWAB16(VIPK_CONTROL_OP_ACK)) {
		if(VipkERingCheckSeqRD(DevPtr, &Hdr->Data, Vi)) {
		    VIP_UINT16	Adjust;

		    Adjust = Vi->RecvXferLen - VIPK_SWAB16(Hdr->Data.Offset);
		    if(!VipkERingDoRecv(DevPtr, &Hdr->Data,
					ViHandle, Adjust)) {
			VIPK_ERING_SEND_ACK(DevPtr, Vi, Vi->RecvSeq - 1);
		    }
		}
	    } else {
		VipkERingRecvAck(DevPtr, Vi,
				 VIPK_SWAB16(Hdr->Ack.AckSeq),
				 VIPK_SWAB16(Hdr->Ack.AckOffset),
				 (VIP_BOOLEAN)(Hdr->Ack.Control &
					VIPK_SWAB16(VIPK_CONTROL_IS_NACK)));
	    }
	} else {
	    /* XXX: Bad Reliability Level!! */
	}

	return VIP_TRUE;
    } else {
	return VIP_FALSE;
    }
}



/*
 * This big messy macro defines the device-dependent send entry points.
 */
#define VIPK_ERING_FUNCTIONS(DevName, PrivType, PrivName, TxPost, TxSeq)    \
									    \
VIP_RETURN								    \
VipkERing ## DevName ## SendControl(VIPK_DEVICE		*DevicePtr,	    \
				    VIPK_CCHAN_PACKET	*Pkt)		    \
{									    \
    int			SegDev;						    \
    PrivType		PrivName = ((PrivType)((VIPK_ERING_DEV_PRIV *)	    \
					       DevicePtr->PrivateData)	    \
				    ->PrivateData);			    \
    VIPK_ERING_CTRL_HDR *EthHdr;					    \
    VIPK_ERING_SEND_VARS;						    \
									    \
    if(__VipkAddrNicHostEq(DevicePtr, (VIP_NET_ADDRESS *) &Pkt->DstAddr)) { \
	DevicePtr->CChan.RecvControl(&DevicePtr->CChan, Pkt);		    \
	DevicePtr->CChan.CompleteControl(&DevicePtr->CChan, Pkt);	    \
	return VIP_SUCCESS;						    \
    }									    \
									    \
    EthHdr = (VIPK_ERING_CTRL_HDR *) Pkt->u.DevHdr;			    \
    memcpy(EthHdr->DstAddr, Pkt->DstAddr.HostAddress, 6);		    \
    memcpy(EthHdr->SrcAddr, DevicePtr->NicAttribs->LocalNicAddress, 6);	    \
    EthHdr->Protocol = htons(VIPK_ERING_PROTOCOL);			    \
    EthHdr->Control = VIPK_SWAB16(VIPK_CONTROL_OP_CTRL);		    \
    VIPK_ERING_SEND_HDR(EthHdr, sizeof(VIPK_ERING_CTRL_HDR), SegDev);	    \
    TxPost[(TxSeq)].TxType = VIPK_ERING_TX_VIA_IGNORE;			    \
    VIPK_ERING_SEND_SEG(Pkt, offsetof(VIPK_CCHAN_PACKET,u), 0);		    \
    TxPost[(TxSeq)].TxType = VIPK_ERING_TX_VIA_CONTROL;			    \
    TxPost[(TxSeq)].Ctrl = Pkt;						    \
    VIPK_ERING_SEND_END(1);						    \
									    \
    return VIP_SUCCESS;							    \
}									    \
									    \
/* This macro expands to an inline function which includes the code	     \
 * which is common to both the PostSend and ResendTask functions.	     \
 *									     \
 * The IsResend argument will be a constant at compile time and so the	     \
 * code in if(IsResend) or if(!IsResend) will only appear in one of	     \
 * PostSend or ResendTask.						     \
 *									     \
 * The IsReliable argument will also be constatn at compile time.	     \
 *									     \
 * returns:								     \
 *   VIP_SUCCESS:		Queued the entire message to the device.     \
 *   VIP_ERROR_RESOURCE:	Queued part of the message to the device.    \
 *				This happens to avoid blocking when	     \
 *				in_interrupt() and is hidden inside the	     \
				VIPK_ERING_SEND_HDR macro.		     \
 *   VIP_NOT_DONE:		Encountered an error before queuing the	     \
 *				entire message.  May or may not have	     \
 *				queued anything.			     \
 */									     \
static inline								     \
VIP_RETURN								     \
VipkERing ## DevName ## SendCore(VIPK_DEVICE		*DevicePtr,	     \
				 VIPK_VI		*Vi,		     \
				 VIP_DESCRIPTOR		*Desc,		     \
				 VIP_MEM_HANDLE		MemHandle,	     \
				 VIP_UINT16		Sequence,	     \
				 VIPK_ERING_RD_INFO	*SendInfo,	     \
				 VIP_BOOLEAN		IsResend,	     \
				 VIP_BOOLEAN		IsReliable)	     \
{									     \
    VIP_DESCRIPTOR	*KernDesc;					     \
									     \
    VIP_UINT32		FrameXferLen;					     \
    VIP_UINT32		TotalXferLen;					     \
    VIP_UINT32		Count;						     \
    VIPK_ERING_HDR	*TxHdrs;					     \
    VIPK_ERING_DATA_HDR	*TxHdr;						     \
									     \
    VIP_UINT32		RemoteMemHandle = 0;				     \
    VIP_UINT64		RemoteUserPtr = 0;				     \
									     \
    PrivType		PrivName = ((PrivType)((VIPK_ERING_DEV_PRIV *)	     \
					       DevicePtr->PrivateData)	     \
				    ->PrivateData);			     \
    VIPK_ERING_SEND_VARS						     \
									     \
    VIP_UINT16		AckSeq;						     \
    VIP_UINT16		Control;					     \
    VIP_UINT16		Offset;						     \
									     \
    VIP_UINT16		SegIndex;					     \
    VIP_UINT16		DevSegsSent;					     \
    VIP_UINT16		SegCnt;						     \
    VIP_UINT16		SegRem;						     \
    VIP_UINT16		SegDev;						     \
									     \
									     \
    TRACE(VIPK_TRACE_POSTS, "%s", DevicePtr->DeviceName);		     \
									     \
    KernDesc = VipkRmmKaddr(DevicePtr->RmmHandle, Desc,			     \
			    MemHandle, Vi->ViAttribs.Ptag,		     \
			    IsResend ? VIPK_RMM_MEM_FLAGS_READ :	     \
				       VIPK_RMM_MEM_FLAGS_WRITE,	     \
			    Vi->FilePtr->NicInstance);			     \
									     \
    if(KernDesc == NULL) {						     \
	goto err_bad_kaddr;						     \
    }									     \
									     \
    if(((KernDesc->CS.Control & VIP_CONTROL_OP_MASK)			     \
					== VIP_CONTROL_OP_RDMAREAD) ||	     \
       VipkDescFormatError(KernDesc)) {					     \
	goto err_bad_format;						     \
    }									     \
									     \
    /*									     \
     * Initialize various lengths, counters and header fields		     \
     */									     \
    Control = VIPK_SWAB16(KernDesc->CS.Control);			     \
    AckSeq = VIPK_SWAB16(Vi->RecvSeq - 1);				     \
    Sequence = VIPK_SWAB16(Sequence);					     \
    Offset = 0; /* avoid compiler warning */				     \
    if(IsResend) {							     \
	Offset = SendInfo->Offset;					     \
    }									     \
									     \
    SegCnt = SegRem = KernDesc->CS.SegCount;				     \
    SegIndex = 0;							     \
									     \
    FrameXferLen = 0;							     \
    TotalXferLen = 0;							     \
    DevSegsSent = 0;							     \
									     \
    Count = KernDesc->CS.Length;					     \
									     \
    /* Get the per-Vi Ethernet header location */			     \
    TxHdrs = ((VIPK_ERING_VI_PRIV *)Vi->PrivateData)->TxHdrs;		     \
									     \
    /*									     \
     * Prepare the header						     \
     *									     \
     * Note, we have to do this outside the segment loop in the		     \
     * event that the user requests a transfer of 0 segments.		     \
     */									     \
    TRACE(VIPK_TRACE_POSTS, "%s Asking for SEND_HDR",			     \
	  DevicePtr->DeviceName);					     \
									     \
    VIPK_ERING_SEND_HDR(&TxHdrs[(TxSeq)].Data,				     \
			sizeof(VIPK_ERING_DATA_HDR), SegDev);		     \
									     \
    /* We only want to mark the descriptor complete on the		     \
     * final segment of the final frame.  All intermediate		     \
     * frames/segments should be ignored by the interrupt		     \
     * handler.								     \
     */									     \
    TxPost[(TxSeq)].TxType = VIPK_ERING_TX_VIA_IGNORE;			     \
    TxHdr = &(TxHdrs[(TxSeq)].Data);					     \
    TxHdr->AckSeq = AckSeq;						     \
    TxHdr->Sequence = Sequence;						     \
    if(IsResend && Offset) {						     \
	TxHdr->Control = Control;					     \
	TxHdr->Offset = VIPK_SWAB16(Offset);				     \
    } else {								     \
	TxHdr->Control = Control | VIPK_SWAB16(VIPK_CONTROL_FIRST_FRAG);     \
	TxHdr->Offset = VIPK_SWAB16(0);					     \
    }									     \
									     \
    if(!IsResend) {							     \
	/* Initialize the Status field, if rdma, will be overridden later    \
	 */								     \
	KernDesc->CS.Status = VIP_STATUS_OP_SEND;			     \
    }									     \
									     \
    /* If this is a remote operation, then the first addr is the remote	     \
     * addr.  Save it off and then loop over the remaining local data	     \
     * segments.							     \
     */									     \
    if(Control & VIPK_SWAB16(VIP_CONTROL_OP_RDMAWRITE)) {		     \
	const VIP_DESCRIPTOR_SEGMENT *KernSeg;				     \
									     \
	TRACE(VIPK_TRACE_POSTS, "%s setting up RDMA Write",		     \
	      DevicePtr->DeviceName);					     \
									     \
	if(!IsResend) {							     \
	    KernDesc->CS.Status = VIP_STATUS_OP_RDMA_WRITE;		     \
	}								     \
									     \
	KernSeg = (VIP_DESCRIPTOR_SEGMENT *)				     \
	    VipkRmmKaddr(DevicePtr->RmmHandle,				     \
			 &Desc->DS[0],					     \
			 MemHandle,					     \
			 Vi->ViAttribs.Ptag,				     \
			 VIPK_RMM_MEM_FLAGS_READ,			     \
			 Vi->FilePtr->NicInstance);			     \
									     \
	if(KernSeg == NULL) {						     \
	    goto err_bad_kseg;						     \
	}								     \
									     \
	/* save these so they can be put into the header later */	     \
	RemoteMemHandle = VIPK_SWAB32((VIP_UINT32)KernSeg->Remote.Handle);   \
	RemoteUserPtr = KernSeg->Remote.Data.AddressBits;		     \
									     \
	TxHdr->UserPtr._64 = VIPK_SWAB64(RemoteUserPtr);		     \
	TxHdr->MemHandle = RemoteMemHandle;				     \
									     \
	SegRem--;							     \
	SegIndex++;							     \
    }									     \
									     \
    /*									     \
     * This check must be performed after the rmda check under the	     \
     * current error handling logic.  This is so that the correct	     \
     * STATUS_OP will be set						     \
     */									     \
    if(Count > Vi->ViAttribs.MaxTransferSize) {				     \
	goto err_bad_len1;						     \
    }									     \
    if(SegCnt > VIPK_ERING_MAX_SEGMENTS_PER_DESC) {			     \
	goto err_bad_len2;						     \
    }									     \
									     \
    /* loop over all the segments in the descriptor */			     \
    if(SegRem == 0) {							     \
	goto done;							     \
    }									     \
    do {								     \
	const VIP_DESCRIPTOR_SEGMENT	*KernSeg;			     \
	VIP_PVOID			Ptr;				     \
	VIP_UINT32			SegLen;				     \
									     \
	KernSeg = (VIP_DESCRIPTOR_SEGMENT *)				     \
	    VipkRmmKaddr(DevicePtr->RmmHandle,				     \
			 &Desc->DS[SegIndex],				     \
			 MemHandle,					     \
			 Vi->ViAttribs.Ptag,				     \
			 VIPK_RMM_MEM_FLAGS_READ,			     \
			 Vi->FilePtr->NicInstance);			     \
									     \
	if(KernSeg == NULL) {						     \
	    goto err_bad_kseg;						     \
	}								     \
									     \
	SegRem--;							     \
	SegIndex++;							     \
	Ptr = (caddr_t) KernSeg->Local.Data.Address;			     \
	SegLen = KernSeg->Local.Length;					     \
									     \
	if(SegLen == 0) {						     \
	    continue;							     \
	}								     \
	if(SegLen > Count) {						     \
	    goto err_bad_len3;						     \
	}								     \
									     \
	/* skip unwanted chunks on resend */				     \
	if(IsResend && (TotalXferLen < Offset)) {			     \
	    VIP_UINT32 Delta = Offset - TotalXferLen;			     \
									     \
	    if(SegLen <= Delta) {					     \
		/* skip the entire segment */				     \
		TotalXferLen += SegLen;					     \
		Count -= SegLen;					     \
		RemoteUserPtr += SegLen;				     \
		continue;						     \
	    } else {							     \
		/* skip only part of the segment */			     \
		TotalXferLen += Delta;					     \
		Count -= Delta;						     \
		RemoteUserPtr += Delta;					     \
		Ptr += Delta;						     \
		SegLen -= Delta;					     \
	    }								     \
            /* Now I need update remote user address to reflect offset       \
	     * Jie Chen: 2-28-2005                                           \
	     */                                                              \
	    TxHdr->UserPtr._64 = VIPK_SWAB64(RemoteUserPtr);		     \
	}								     \
									     \
	/* loop over data in segment in page chunks/mtu size */		     \
	do {								     \
	    const caddr_t KPtr = VipkRmmKaddr(DevicePtr->RmmHandle,	     \
					      Ptr,			     \
					      KernSeg->Local.Handle,	     \
					      Vi->ViAttribs.Ptag,	     \
					      VIPK_RMM_MEM_FLAGS_READ,	     \
					      Vi->FilePtr->NicInstance);     \
									     \
	    const unsigned long PageBreak = PAGE_SIZE -			     \
		((unsigned long) Ptr & ~PAGE_MASK);			     \
									     \
	    const VIP_UINT32 SegXferLen =				     \
		min(min(PageBreak, SegLen),				     \
		    VIPK_ERING_MTU - FrameXferLen);			     \
									     \
	    if(KPtr == NULL) {						     \
		goto err_bad_kptr;					     \
	    }								     \
									     \
	    TotalXferLen += SegXferLen;					     \
	    FrameXferLen += SegXferLen;					     \
	    Count -= SegXferLen;					     \
	    RemoteUserPtr += SegXferLen;				     \
	    Ptr += SegXferLen;						     \
	    SegLen -= SegXferLen;					     \
									     \
	    TRACE(VIPK_TRACE_POSTS,					     \
		  "%s Asking for SEND_SEG SegXLen %d "			     \
		  "FrameXfer %d Seg %d",				     \
		  DevicePtr->DeviceName,				     \
		  SegXferLen, FrameXferLen, DevSegsSent);		     \
									     \
	    VIPK_ERING_SEND_SEG(KPtr, SegXferLen, DevSegsSent);		     \
	    DevSegsSent++;						     \
	    SegDev--;							     \
	    TxPost[(TxSeq)].TxType = VIPK_ERING_TX_VIA_IGNORE;		     \
									     \
	    /* If we have finished a complete frame, but are not done	     \
	     * processing the descriptor, then send as an intermediate	     \
	     * frame.  If we are done, we will complete the frame	     \
	     * when we leave the descriptor loop.			     \
	     */								     \
	    if((FrameXferLen == VIPK_ERING_MTU || SegDev == 0)		     \
	       && (SegLen || SegRem)) {					     \
		TxHdr->Length = VIPK_SWAB16(FrameXferLen);		     \
									     \
		TRACE(VIPK_TRACE_POSTS,					     \
		      "%s Asking for intermediate SEND_END "		     \
		      "SegXLen %d FrameXfer %d Control: 0x%x",		     \
		      DevicePtr->DeviceName,				     \
		      SegXferLen, FrameXferLen,				     \
		      VIPK_SWAB16(TxHdr->Control));			     \
									     \
		FrameXferLen = 0;					     \
		DevSegsSent = 0;					     \
									     \
		/* Issue a send, but we don't need a send complete	     \
		 * interrupt from the device (i.e. give it a 0)		     \
		 * unless we are waiting for more segments.		     \
		 */							     \
		VIPK_ERING_SEND_END(!SegDev);				     \
									     \
		/* Record partial progress. */				     \
		if(IsResend) {						     \
		    SendInfo->Offset = TotalXferLen;			     \
		}							     \
									     \
		/* Build the header for the next packet.		     \
		 */							     \
		TRACE(VIPK_TRACE_POSTS, "%s Asking for SEND_HDR 2",	     \
		      DevicePtr->DeviceName);				     \
									     \
		VIPK_ERING_SEND_HDR(&TxHdrs[(TxSeq)].Data,		     \
				    sizeof(VIPK_ERING_DATA_HDR), SegDev);    \
									     \
		TxPost[(TxSeq)].TxType = VIPK_ERING_TX_VIA_IGNORE;	     \
		TxHdr = &TxHdrs[(TxSeq)].Data;				     \
		TxHdr->Control = Control;				     \
		TxHdr->AckSeq = AckSeq;					     \
		TxHdr->Sequence = Sequence;				     \
		TxHdr->Offset = VIPK_SWAB16(TotalXferLen);		     \
									     \
		/* This may be unecessary for non-rdma, but		     \
		 * just do it rather than branching again.		     \
		 */							     \
		TxHdr->UserPtr._64 = VIPK_SWAB64(RemoteUserPtr);	     \
		TxHdr->MemHandle = RemoteMemHandle;			     \
	    }								     \
	} while(SegLen);						     \
    } while(SegRem);							     \
									     \
 done:									     \
    if(Count) {								     \
	goto err_bad_len4;						     \
    }									     \
									     \
    TxHdr->Length = VIPK_SWAB16(FrameXferLen);				     \
									     \
    TxHdr->Control |= VIPK_SWAB16(VIPK_CONTROL_LAST_FRAG);		     \
    TxHdr->IData = KernDesc->CS.ImmediateData;				     \
									     \
    if(!IsReliable) {							     \
	/* Provide the necessary info to mark the descriptor complete.	     \
	 */								     \
	TxPost[(TxSeq)].TxType = VIPK_ERING_TX_VIA_UR;			     \
									     \
	TxPost[(TxSeq)].Vi = Vi;					     \
	TxPost[(TxSeq)].NicInstance = Vi->FilePtr->NicInstance;		     \
	TxPost[(TxSeq)].RmmHandle = DevicePtr->RmmHandle;		     \
	TxPost[(TxSeq)].Desc = Desc;					     \
	TxPost[(TxSeq)].MemHandle = MemHandle;				     \
	TxPost[(TxSeq)].Ptag = Vi->ViAttribs.Ptag;			     \
    } else {								     \
	TxPost[(TxSeq)].TxType = VIPK_ERING_TX_VIA_RD;			     \
									     \
	TxPost[(TxSeq)].Vi = Vi;					     \
	TxPost[(TxSeq)].SendInfo = SendInfo;				     \
    }									     \
									     \
    TRACE(VIPK_TRACE_POSTS,						     \
	  "%s Asking for final SEND_END 2 FrmXfer %d Seg %d Ctrl: 0x%x",     \
	  DevicePtr->DeviceName,					     \
	  FrameXferLen, DevSegsSent, VIPK_SWAB16(TxHdr->Control));	     \
									     \
    /* Send it on its journey.  Ask for a completion interrupt */	     \
    VIPK_ERING_SEND_END(1);						     \
									     \
    if(IsResend) {							     \
	/* undo partial progress */					     \
	SendInfo->Offset = Offset;					     \
    } else {								     \
	Vi->SendSeq++;							     \
    }									     \
									     \
    return VIP_SUCCESS;							     \
									     \
 err_bad_kaddr:								     \
    TRACE(VIPK_TRACE_POSTS, "%s MemHandle/Descriptor not valid",	     \
	  DevicePtr->DeviceName);					     \
    VipkPostDescError(Vi, Desc, VIP_RESOURCE_DESCRIPTOR,		     \
		      VIP_ERROR_POST_DESC);				     \
    if(!IsResend) {							     \
	VIPK_ERING_RELEASE_TX(Vi);					     \
    }									     \
    return VIP_NOT_DONE;						     \
									     \
 err_bad_format:							     \
    TRACE(VIPK_TRACE_POSTS, "%s Descriptor Format Error",		     \
	  DevicePtr->DeviceName);					     \
    KernDesc->CS.Status |= VIP_STATUS_FORMAT_ERROR;			     \
    goto err_out;							     \
									     \
 err_bad_len1:								     \
    TRACE(VIPK_TRACE_POSTS, "%s Bad Length (CS.Length > MTS)",		     \
	  DevicePtr->DeviceName);					     \
    KernDesc->CS.Status |= VIP_STATUS_LENGTH_ERROR;			     \
    goto err_whdr_out;							     \
									     \
 err_bad_len2:								     \
    TRACE(VIPK_TRACE_POSTS, "%s Bad Seg Count", DevicePtr->DeviceName);	     \
    KernDesc->CS.Status |= VIP_STATUS_LENGTH_ERROR;			     \
    goto err_whdr_out;							     \
									     \
 err_bad_len3:								     \
    TRACE(VIPK_TRACE_POSTS, "%s Bad Length (CS.Length < Segs)",		     \
	  DevicePtr->DeviceName);					     \
    KernDesc->CS.Status |= VIP_STATUS_LENGTH_ERROR;			     \
    goto err_whdr_out;							     \
									     \
 err_bad_len4:								     \
    TRACE(VIPK_TRACE_POSTS, "%s Bad Length (CS.Length > Segs)",		     \
	  DevicePtr->DeviceName);					     \
    KernDesc->CS.Status |= VIP_STATUS_LENGTH_ERROR;			     \
    goto err_whdr_out;							     \
									     \
 err_bad_kseg:								     \
    TRACE(VIPK_TRACE_POSTS, "%s Segment/MemHandle not valid",		     \
	  DevicePtr->DeviceName);					     \
    KernDesc->CS.Status |= VIP_STATUS_PROTECTION_ERROR;			     \
    goto err_whdr_out;							     \
									     \
 err_bad_kptr:								     \
    TRACE(VIPK_TRACE_POSTS, "%s DataAddr/DataHandle not valid",		     \
	  DevicePtr->DeviceName);					     \
    KernDesc->CS.Status |= VIP_STATUS_PROTECTION_ERROR;			     \
    goto err_whdr_out;							     \
									     \
/* errors that are generated after a hdr preparation			     \
 * need to exit via here to release the device before			     \
 * proceedng to the wake up code.					     \
 */									     \
 err_whdr_out:								     \
    VIPK_ERING_SEND_ABORT;						     \
    goto err_out;							     \
									     \
/* errors exit via here to wake up anyone waiting on the send. */	     \
 err_out:								     \
    if(!IsResend) {							     \
	Vi->SendSeq++;							     \
    }									     \
									     \
    VipkViSendCompleteErr(Vi, KernDesc);				     \
									     \
    if(!IsResend) {							     \
	VIPK_ERING_RELEASE_TX(Vi);					     \
    }									     \
    return VIP_NOT_DONE;						     \
}									     \
									     \
VIP_RETURN								     \
VipkERing ## DevName ## PostSend(VIPK_DEVICE	*DevicePtr,		     \
				 VIPK_VI_HANDLE	ViHandle,		     \
				 VIP_DESCRIPTOR	*Desc,			     \
				 VIP_MEM_HANDLE	MemHandle)		     \
{									     \
    VIPK_VI		*Vi;						     \
    VIPK_ERING_VI_PRIV	*ViPriv;					     \
    VIP_RETURN		Status;						     \
    unsigned long	Flags;						     \
									     \
    TRACE(VIPK_TRACE_POSTS, "[%d] %s", current->pid,			     \
	  DevicePtr->DeviceName);					     \
									     \
    Vi = VipkViLookup(DevicePtr, ViHandle);				     \
    if(Vi == NULL || !VipkViVerifyOwner(Vi)) {				     \
	goto err_bad_vi;						     \
    }									     \
									     \
    /* If this VI has been setup for loopback, just let the default	     \
     * send routines take care of it.					     \
     */									     \
    if(Vi->Loopback) {							     \
	return VipkPostSend(DevicePtr, ViHandle, Desc, MemHandle);	     \
    }									     \
									     \
    if(Vi->SendDesc == NULL) {						     \
	TRACE(VIPK_TRACE_POSTS, "[%d] %s Setting SendDesc: 0x%p",	     \
	      current->pid, DevicePtr->DeviceName, (void *)Desc);	     \
	Vi->SendDesc = Desc;						     \
	Vi->SendMemHandle = MemHandle;					     \
    } else {								     \
	TRACE(VIPK_TRACE_POSTS, "[%d] %s SendDesc already set to: 0x%p",     \
	      current->pid, DevicePtr->DeviceName, (void *)Vi->SendDesc);    \
    }									     \
									     \
    /* Reject preposted sends */					     \
    if(Vi->State != VIP_STATE_CONNECTED) {				     \
	goto err_bad_state;						     \
    }									     \
									     \
    if((VIP_ULONG) Desc & (VIP_DESCRIPTOR_ALIGNMENT-1)) {		     \
	goto err_bad_align;						     \
    }									     \
									     \
    ViPriv = (VIPK_ERING_VI_PRIV *)Vi->PrivateData;			     \
    spin_lock_irqsave(&ViPriv->Lock, Flags);				     \
    if(ViPriv->TxState != VIPK_ERING_TX_STREAMING) {			     \
	goto check_state;						     \
    }									     \
 check_state_done:							     \
    atomic_inc(&ViPriv->DescCount);					     \
    spin_unlock_irqrestore(&ViPriv->Lock, Flags);			     \
									     \
    if(Vi->ViAttribs.ReliabilityLevel > VIP_SERVICE_UNRELIABLE) {	     \
	VIPK_ERING_RD_INFO	*SendInfo;				     \
									     \
	/* XXX: should preallocate these structures! */			     \
	SendInfo = kmalloc(sizeof(VIPK_ERING_RD_INFO), GFP_KERNEL);	     \
	if(SendInfo == NULL) {						     \
	    goto err_no_mem;						     \
	}								     \
									     \
	SendInfo->Vi		= Vi;					     \
	SendInfo->NicInstance	= Vi->FilePtr->NicInstance;		     \
	SendInfo->RmmHandle	= DevicePtr->RmmHandle;			     \
	SendInfo->Desc		= Desc;					     \
	SendInfo->MemHandle	= MemHandle;				     \
	SendInfo->Ptag		= Vi->ViAttribs.Ptag;			     \
	SendInfo->Sequence	= Vi->SendSeq;				     \
	SendInfo->Offset	= 0;					     \
	SendInfo->ResendsLeft	= VIPK_ERING_RD_LIMIT;			     \
	atomic_set(&SendInfo->RefCount, 2);				     \
	SendInfo->TimeStamp	= jiffies;				     \
	SendInfo->Next		= NULL;					     \
									     \
	spin_lock_irqsave(&ViPriv->Lock, Flags);			     \
	if(ViPriv->RD.SentHead == NULL) {				     \
	    ViPriv->RD.SentHead = SendInfo;				     \
	    mod_timer(&ViPriv->RD.Timer,				     \
		      SendInfo->TimeStamp + VIPK_ERING_RD_TIMEOUT);	     \
	} else {							     \
	    ViPriv->RD.SentTail->Next = SendInfo;			     \
	}								     \
	ViPriv->RD.SentTail = SendInfo;					     \
	spin_unlock_irqrestore(&ViPriv->Lock, Flags);			     \
									     \
	Status = VipkERing ## DevName ## SendCore(DevicePtr, Vi, Desc,	     \
						  MemHandle, Vi->SendSeq,    \
						  SendInfo,		     \
						  VIP_FALSE, VIP_TRUE);	     \
									     \
	VIPK_ERING_RELEASE_RD(SendInfo);				     \
    } else {								     \
	Status = VipkERing ## DevName ## SendCore(DevicePtr, Vi, Desc,	     \
						  MemHandle, Vi->SendSeq,    \
						  NULL,			     \
						  VIP_FALSE, VIP_FALSE);     \
    }									     \
									     \
    return VIP_SUCCESS;							     \
									     \
 err_bad_vi:								     \
    TRACE(VIPK_TRACE_POSTS, "[%d] %s Bad ViHandle",			     \
	  current->pid, DevicePtr->DeviceName);				     \
    return VIP_INVALID_PARAMETER;					     \
									     \
 err_bad_state:								     \
    TRACE(VIPK_TRACE_POSTS, "[%d] %s Invalid Vi State(%d)",		     \
	  current->pid, DevicePtr->DeviceName, Vi->State);		     \
    VipkViFlushDescs(DevicePtr, Vi, VIP_FALSE);				     \
    return VIP_SUCCESS;							     \
									     \
 err_bad_align:								     \
    TRACE(VIPK_TRACE_POSTS, "[%d] %s Bad descriptor alignment 0x%p",	     \
	  current->pid, DevicePtr->DeviceName, (void *)Desc);		     \
    VipkPostDescError(Vi, Desc, VIP_RESOURCE_DESCRIPTOR,		     \
		      VIP_ERROR_POST_DESC);				     \
    return VIP_SUCCESS;							     \
									     \
 err_no_mem:								     \
    printk(KERN_WARNING "NO MEM FOR SENDINFO\n");			     \
    return VIP_ERROR_RESOURCE;						     \
									     \
 check_state:								     \
    /* new sends must block behind resends */				     \
    while(ViPriv->TxState == VIPK_ERING_TX_RECOVERING &&		     \
	  !signal_pending(current)) {					     \
	unsigned long KernTimeout = MAX_SCHEDULE_TIMEOUT;		     \
									     \
	cond_wait_interruptible(&ViPriv->TxStateChange,			     \
				&ViPriv->Lock,				     \
				&KernTimeout);				     \
    }									     \
									     \
    /* (re)check for signals or lost connection */			     \
    if(signal_pending(current) ||					     \
       ViPriv->TxState != VIPK_ERING_TX_STREAMING) {			     \
	spin_unlock_irqrestore(&ViPriv->Lock, Flags);			     \
	return VIP_SUCCESS;						     \
    }									     \
    goto check_state_done;						     \
}									     \
									     \
/*									     \
 * This task handles resends regardless of whether initiated by a timer	     \
 * expiration or by a NACK.						     \
 *									     \
 * XXX: Should we try to resend ALL the over-due messages at once?	     \
 */									     \
void									     \
VipkERing ## DevName ## ResendTask(void	*Arg)				     \
{									     \
    VIPK_VI		*Vi = Arg;					     \
    VIP_RETURN		Status;						     \
    VIPK_ERING_VI_PRIV	*ViPriv;					     \
    VIPK_ERING_RD_INFO	*SendInfo;					     \
    unsigned long	Flags;						     \
									     \
    ViPriv = (VIPK_ERING_VI_PRIV *)Vi->PrivateData;			     \
									     \
    spin_lock_irqsave(&ViPriv->Lock, Flags);				     \
    if(Vi->State == VIP_STATE_CONNECTED &&				     \
       ViPriv->TxState <= VIPK_ERING_TX_RECOVERING) {			     \
	SendInfo = ViPriv->RD.SentHead;					     \
									     \
	if(SendInfo) {							     \
	    if(SendInfo->ResendsLeft == 0) {				     \
		goto over_limit;					     \
	    }								     \
									     \
	    ViPriv->TxState = VIPK_ERING_TX_RECOVERING;			     \
	    /* nobody cares: cond_signal(&ViPriv->TxStateChange); */	     \
									     \
            printk (KERN_ALERT "%s resend a packet offset = %d sequence = %d.\n",\
		    Vi->DevicePtr->DeviceName,                               \
		    SendInfo->Offset, SendInfo->Sequence);                   \
                                                                             \
	    Status = VipkERing ## DevName ## SendCore(Vi->DevicePtr, Vi,     \
						      SendInfo->Desc,	     \
						      SendInfo->MemHandle,   \
						      SendInfo->Sequence,    \
						      SendInfo,		     \
						      VIP_TRUE, VIP_TRUE);   \
									     \
	    if(Status == VIP_SUCCESS) {					     \
		atomic_inc(&ViPriv->DescCount);				     \
		SendInfo->ResendsLeft--;				     \
		mod_timer(&ViPriv->RD.Timer,				     \
			  jiffies + VIPK_ERING_RD_TIMEOUT);		     \
	    } else {							     \
		queue_task(&ViPriv->RD.Task, &tq_timer);		     \
	    }								     \
	} else {							     \
	    del_timer(&ViPriv->RD.Timer);				     \
	}								     \
    }									     \
    spin_unlock_irqrestore(&ViPriv->Lock, Flags);			     \
    return;								     \
									     \
 over_limit:								     \
    spin_unlock_irqrestore(&ViPriv->Lock, Flags);			     \
    printk(KERN_WARNING "VipkERingPostSend(RD): %s Vi 0x%p declaring "	     \
			"connection lost\n", Vi->DevicePtr->DeviceName,	     \
			(void *)Vi);					     \
    VipkPostError(Vi, VIP_RESOURCE_VI, VIP_ERROR_CONN_LOST);		     \
    return;								     \
}									     \
									     \
VIP_RETURN								     \
VipkERing ## DevName ## SendAck(VIPK_DEVICE	*DevicePtr,		     \
				VIPK_VI		*Vi,			     \
				VIP_UINT16	Sequence,		     \
				VIP_UINT16	Control)		     \
{									     \
    int			SegDev;						     \
    PrivType		PrivName = ((PrivType)((VIPK_ERING_DEV_PRIV *)	     \
					       DevicePtr->PrivateData)	     \
				    ->PrivateData);			     \
    VIPK_ERING_HDR	*Hdr;						     \
    VIPK_ERING_SEND_VARS						     \
									     \
    if(Vi->State != VIP_STATE_CONNECTED) {				     \
	return VIP_INVALID_STATE;					     \
    }									     \
									     \
    if(Vi->Loopback) {							     \
	VIPK_VI	*RemoteVi;						     \
									     \
	RemoteVi = VipkViLookup(DevicePtr, Vi->RemoteViHandle);		     \
	if(RemoteVi != NULL) {						     \
	    VipkERingRecvAck(DevicePtr, RemoteVi,			     \
			     Vi->RecvSeq, Vi->RecvXferLen,		     \
			     (Control & VIPK_SWAB16(VIPK_CONTROL_IS_NACK))); \
	}								     \
	return VIP_SUCCESS;						     \
    }									     \
									     \
    Hdr = ((VIPK_ERING_VI_PRIV *)Vi->PrivateData)->TxHdrs;		     \
    VIPK_ERING_SEND_HDR(&Hdr[(TxSeq)].Ack,				     \
			sizeof(VIPK_ERING_ACK_HDR), SegDev);		     \
    Hdr[(TxSeq)].Ack.Control = Control;					     \
    Hdr[(TxSeq)].Ack.AckSeq = VIPK_SWAB16(Sequence);			     \
    Hdr[(TxSeq)].Ack.AckOffset = VIPK_SWAB16(Vi->RecvXferLen);		     \
    TxPost[(TxSeq)].TxType = VIPK_ERING_TX_VIA_IGNORE;			     \
									     \
    VIPK_ERING_SEND_END(0);						     \
									     \
    return VIP_SUCCESS;							     \
}


#endif
