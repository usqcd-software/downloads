/* vipk/vipk_ering.c
 * 
 * Implementation of the generalized Vipk Ethernet Ring device
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

/* XXX: this is a mess... merge all the various send control
 * functions into a single function with a operation argument
 */

#ifdef MODULE
#define EXPORT_SYMTAB
#include <linux/module.h> 
#endif

#include <linux/kernel.h>
#include <linux/types.h>

#include <linux/errno.h>
#include <linux/slab.h>
#include <linux/vmalloc.h>
#include <asm/uaccess.h>

#include <linux/interrupt.h>

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
/**
 * The following two attributes are defined twice
 */
#ifdef __attribute_pure__
#undef __attribute_pure__
#endif
 
#ifdef __attribute_used__
#undef __attribute_used__
#endif

#endif

#include <vipk_ering.h>
#include <vipk_cchan.h>
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0))
#include <vipk_2_2_compat.h>
#endif

/* VIPK_MAIN causes copyright to be included in object file */
#define VIPK_MAIN
#include <copyright.h>

static VIP_RETURN
VipkERingSendConnLost(VIPK_DEVICE       *DevicePtr,
		      VIPK_VI		*Vi,
		      VIP_BOOLEAN	IsError);

static VIP_RETURN
VipkERingConnectionLost(VIPK_DEVICE 		*DevicePtr,
			VIPK_VI_HANDLE		ViHandle,
			VIP_UINT32		Session,
			VIP_UINT32		Sequence,
			VIP_BOOLEAN		IsError);

static void
VipkERingConnected(VIPK_DEVICE 		*DevicePtr,
		   VIPK_VI		*Vi);

static VIP_RETURN
VipkERingCreateVi(VIPK_DEVICE		*DevicePtr,
		  VIPK_FILE		*FilePtr,
		  VIP_CREATE_VI_ARGS	*UserArgs);

static VIP_RETURN
VipkERingDestroyVi(VIPK_DEVICE 		*DevicePtr,
		   VIPK_VI_HANDLE	ViHandle);

static VIP_RETURN
VipkERingDisconnect(VIPK_DEVICE 	*DevicePtr,
		    VIPK_VI_HANDLE	ViHandle);

static void
VipkERingResendTimer(unsigned long Arg);

EXPORT_SYMBOL(VipkERingSendConnLost);
EXPORT_SYMBOL(VipkERingDeregister);
EXPORT_SYMBOL(VipkERingInit);
EXPORT_SYMBOL(VipkERingRegister);
EXPORT_SYMBOL(VipkERingReleaseTx);
EXPORT_SYMBOL(VipkERingRecv);


#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
static int vipk_ering_init_m (void)
#else
int
init_module(void)
#endif
{
    printk(KERN_INFO "M-VIA Ethernet Device Class\n%s\n", copyright);
    return 0;
}

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
static void vipk_ering_cleanup_m (void)
#else
void
cleanup_module(void)
#endif
{
    printk(KERN_INFO "M-VIA Ethernet Device Class unloaded.\n");
}

/* XXX handle malloc errors */
void 
VipkERingInit(VIPK_DEVICE		**DevicePtr,
	      VIPK_DEVICE_OPERATIONS 	*DefDevOps,
	      VIP_RETURN 		(*SendControl)	(VIPK_DEVICE *,
							 VIPK_CCHAN_PACKET *),
	      VIP_RETURN 		(*PostSend)	(VIPK_DEVICE *,
							 VIPK_VI_HANDLE,
							 VIP_DESCRIPTOR *,
							 VIP_MEM_HANDLE),
	      void			(*ResendTask)	(void *),
	      VIP_RETURN		(*SendAck)	(VIPK_DEVICE *,
							 VIPK_VI *,
							 VIP_UINT16,
							 VIP_UINT16),
	      void			*DevPriv,
	      VIP_CHAR			*DevName,
	      VIP_UINT32		DevIndex,
	      VIP_UCHAR			*MacAddr,
	      VIP_UINT32		TxRingSize)
{
    VIPK_DEVICE			*DevPtr;
    VIP_NIC_ATTRIBUTES		*NicAttribs;
    VIPK_ERING_DEV_PRIV		*ERingDevPriv;
    VIPK_DEVICE_OPERATIONS	*DevOps;

    /* 
     * Init device operations
     *
     * Tap into the Vi create/destroy to 
     * allocate the per vi ethernet headers 
     */
    DevOps = vmalloc(sizeof(VIPK_DEVICE_OPERATIONS));
    if(DevOps == NULL) {
	goto out;
    }

    *DevOps = *DefDevOps;
    DevOps->SendConnLost	= VipkERingSendConnLost;
    DevOps->ConnectionLost	= VipkERingConnectionLost;
    DevOps->Connected 		= VipkERingConnected;
    DevOps->VipkPostSend	= PostSend;
    DevOps->VipkCreateVi 	= VipkERingCreateVi;
    DevOps->VipkDestroyVi 	= VipkERingDestroyVi;
    DevOps->VipkDisconnect 	= VipkERingDisconnect;

    /* 
     * Init nic attributes
     */
    NicAttribs = vmalloc(sizeof(VIP_NIC_ATTRIBUTES));
    if(NicAttribs == NULL) {
	goto bad_nic_attrs;
    }
    strncpy(NicAttribs->Name, DevName, 64);
    NicAttribs->HardwareVersion 	= VIPK_ERING_HARDWARE_VERSION;
    NicAttribs->ProviderVersion 	= VIPK_ERING_PROVIDER_VERSION;
    NicAttribs->NicAddressLen 		= VIPK_ERING_ADDR_LEN;
    NicAttribs->LocalNicAddress		= MacAddr;
    NicAttribs->ThreadSafe 		= VIP_FALSE;
    NicAttribs->MaxDiscriminatorLen 	= VIPK_ERING_MAX_DISCRIMINATOR_LEN;
    NicAttribs->MaxRegisterBytes 	= VIPK_ERING_MAX_REGISTER_BYTES;
    NicAttribs->MaxRegisterRegions 	= VIPK_ERING_MAX_REGISTER_REGIONS;
    NicAttribs->MaxRegisterBlockBytes	= VIPK_ERING_MAX_REGISTER_BLOCK_BYTES;
    NicAttribs->MaxVI 			= VIPK_ERING_MAX_VI;
    NicAttribs->MaxDescriptorsPerQueue 	= VIPK_ERING_MAX_DESCRIPTORS_PER_QUEUE;
    NicAttribs->MaxSegmentsPerDesc 	= VIPK_ERING_MAX_SEGMENTS_PER_DESC;
    NicAttribs->MaxCQ 			= VIPK_ERING_MAX_CQ;
    NicAttribs->MaxCQEntries		= VIPK_ERING_MAX_CQ_ENTRIES;
    NicAttribs->MaxTransferSize 	= VIPK_ERING_MAX_TRANSFER_SIZE;
    NicAttribs->NativeMTU 		= VIPK_ERING_MTU;
    NicAttribs->MaxPtags 		= VIPK_ERING_MAX_PTAGS;
    NicAttribs->ReliabilityLevelSupport = VIP_SERVICE_UNRELIABLE |
					  VIP_SERVICE_RELIABLE_DELIVERY;
    NicAttribs->RDMAReadSupport 	= 0;

    /*
     * Init ERing private device attributes 
     */
    ERingDevPriv = vmalloc(sizeof(VIPK_ERING_DEV_PRIV));
    if(ERingDevPriv == NULL) {
	goto bad_ering_priv;
    }
    memset(ERingDevPriv, 0, sizeof(VIPK_ERING_DEV_PRIV));
    ERingDevPriv->TxRingSize = TxRingSize;
    ERingDevPriv->PrivateData = DevPriv;
    ERingDevPriv->ResendTask = ResendTask;
    ERingDevPriv->SendAck = SendAck;

    /* 
     * Init device structure
     */
    DevPtr = vmalloc(sizeof(VIPK_DEVICE));
    if(DevPtr == NULL) {
	goto bad_dev_ptr;
    }
    memset(DevPtr, 0, sizeof(VIPK_DEVICE));

    DevPtr->CChan 		= VipkCChanDefault;
    DevPtr->Cm 	       		= VipkCmDefault;

    DevPtr->PrivateData 	= ERingDevPriv;
    DevPtr->DeviceOps 		= DevOps;    
    DevPtr->NicAttribs 		= NicAttribs;
    DevPtr->DoorbellType 	= VIPK_ERING_DOORBELL;
    DevPtr->UsesFastOps 	= VIPK_ERING_FAST_OPS;
    DevPtr->DeviceName 		= DevName;
    DevPtr->MinorNum 		= VIPK_ERING_MINOR + DevIndex;

    if(DevPtr->Cm.Init(&DevPtr->Cm, 
		       &DevPtr->CChan,
		       VIPK_ERING_CONN_QUEUE_SIZE) != VIP_SUCCESS) {
	goto bad_cm;
    }

    if(DevPtr->CChan.Init(&DevPtr->CChan, 
			  DevPtr,
			  &DevPtr->Cm,
			  SendControl) != VIP_SUCCESS) {
	goto bad_cchan;
    }

    *DevicePtr = DevPtr;

    goto out;

 bad_cchan:
    DevPtr->Cm.Destroy(&DevPtr->Cm);
 bad_cm:
    vfree(DevPtr);
 bad_dev_ptr:
    vfree(ERingDevPriv);
 bad_ering_priv:
    vfree(NicAttribs);
 bad_nic_attrs:
    vfree(DevOps);

 out:
    return;
    
}

void
VipkERingRegister(VIPK_DEVICE	*DevicePtr)
{
    VipkRegisterDevice(DevicePtr);
    return;
}

void 
VipkERingDeregister(VIPK_DEVICE	*DevicePtr)
{
    VipkDeregisterDevice(DevicePtr);
    return;
}

/*
 * VikpERingReleaseTx
 *
 * Called when the count of active desriptors reaches zero so that
 * any pending ConnLost is processed and the Tx state advanced.
 */
void
VipkERingReleaseTx(VIPK_VI	*Vi)
{
    VIPK_ERING_VI_PRIV	*ViPriv;
    unsigned long	Flags;

    /* wake any blocked VipPostSend or VipDisconnect */
    ViPriv = (VIPK_ERING_VI_PRIV *)Vi->PrivateData;
    spin_lock_irqsave(&ViPriv->Lock, Flags);
    ViPriv->TxState = VIPK_ERING_TX_STOPPED;
    cond_signal(&ViPriv->TxStateChange);
    spin_unlock_irqrestore(&ViPriv->Lock, Flags);
}

static VIP_BOOLEAN
VipkERingStopTx(VIPK_VI	*Vi)
{
    VIPK_ERING_VI_PRIV	*ViPriv = (VIPK_ERING_VI_PRIV *) Vi->PrivateData;

    del_timer(&ViPriv->RD.Timer);

    if(ViPriv->TxState < VIPK_ERING_TX_DRAINING) {
	if(atomic_dec_and_test(&ViPriv->DescCount)) {
	    ViPriv->TxState = VIPK_ERING_TX_STOPPED;
	} else {
	    ViPriv->TxState = VIPK_ERING_TX_DRAINING;
	}

	cond_signal(&ViPriv->TxStateChange);
    }

    return (ViPriv->TxState == VIPK_ERING_TX_STOPPED) ? VIP_TRUE : VIP_FALSE;
}

VIP_RETURN
VipkERingConnectionLost(VIPK_DEVICE 	*DevicePtr,
			VIPK_VI_HANDLE	ViHandle,
			VIP_UINT32	Session,
			VIP_UINT32	Sequence,
			VIP_BOOLEAN	IsError)
{
    VIPK_VI		*Vi;
    VIPK_ERING_VI_PRIV	*ViPriv;
    unsigned long	Flags;

    Vi = VipkViLookup(DevicePtr, ViHandle);
    if(Vi == NULL) {
	return VIP_INVALID_PARAMETER;
    }

    if(Vi->State == VIP_STATE_CONNECTED && Vi->Session == Session) {
	if(Vi->ViAttribs.ReliabilityLevel > VIP_SERVICE_UNRELIABLE) {
	    /* Treat the Sequence from the CONNLOST as a piggybacked ACK */
	    VipkERingRecvAck(DevicePtr, Vi, Sequence, 0, VIP_FALSE);
	}
	ViPriv = (VIPK_ERING_VI_PRIV *) Vi->PrivateData;
	spin_lock_irqsave(&ViPriv->Lock, Flags);
	VipkERingStopTx(Vi);
	spin_unlock_irqrestore(&ViPriv->Lock, Flags);
	if (IsError) {
	    VipkViConnectionLost(DevicePtr, Vi, Session, Sequence);
	}
    }

    return VIP_SUCCESS;
}

void
VipkERingConnected(VIPK_DEVICE 	*DevicePtr,
		   VIPK_VI	*Vi)
{
    VIPK_ERING_DEV_PRIV	*DevPriv;
    VIPK_ERING_VI_PRIV	*ViPriv;
    VIPK_ERING_HDR	*TxHdr;

    VIP_UINT32		i;
    VIP_UINT32		TxRingSize;

    DevPriv = (VIPK_ERING_DEV_PRIV *)DevicePtr->PrivateData;
    ViPriv = (VIPK_ERING_VI_PRIV *)Vi->PrivateData;
    TxHdr = ViPriv->TxHdrs;

    if(VipkAddrNicHostEq(DevicePtr, (VIP_NET_ADDRESS *) &Vi->RemoteAddr)) {
       Vi->Loopback = VIP_TRUE;
    }

    TxRingSize = DevPriv->TxRingSize;

    for(i=0; i < TxRingSize; i++) {
	memcpy(&TxHdr[i].Data.DstAddr, Vi->RemoteAddr.HostAddress,
	       DevicePtr->NicAttribs->NicAddressLen);
	memcpy(&TxHdr[i].Data.SrcAddr, DevicePtr->NicAttribs->LocalNicAddress,
	       DevicePtr->NicAttribs->NicAddressLen);
	TxHdr[i].Data.Protocol = htons(VIPK_ERING_PROTOCOL);
	TxHdr[i].Data.ViHandle = VIPK_SWAB16(Vi->RemoteViHandle);
    }

    atomic_set(&ViPriv->DescCount, 1);
    ViPriv->TxState = VIPK_ERING_TX_STREAMING;
    ViPriv->RD.RecvOK = VIP_TRUE;
    ViPriv->RD.AckSeq = Vi->SendSeq;
}
    

/* XXX: this needs some explanation... */
static VIP_RETURN
VipkERingCreateVi(VIPK_DEVICE		*DevicePtr,
		  VIPK_FILE		*FilePtr,
		  VIP_CREATE_VI_ARGS	*UserArgs)
{
    VIPK_VI_HANDLE	ViHandle;
    VIPK_VI		*Vi;
    VIPK_ERING_VI_PRIV	*Priv;
    VIPK_ERING_DEV_PRIV	*DevPriv;
    VIP_RETURN 		Status;

    TRACE(VIPK_TRACE_CREATE_VI, "%s", DevicePtr->DeviceName);
    
    Status = VipkCreateVi(DevicePtr, FilePtr, UserArgs);

    /* Grab the ViHandle that was passed to the user by VipkCreateVi */
    if(Status == VIP_SUCCESS) {
	VIP_CREATE_VI_ARGS	Args;
	VIP_ULONG		AllocSize;
	VIPK_ERING_HDR		*TxHdr;	
	VIP_UINT32		TxRingSize;

	copy_from_user_ret(&Args, UserArgs,
		       sizeof(VIP_CREATE_VI_ARGS), VIP_INVALID_PARAMETER);

	/* XXX: not the safest thing to do... fix this. */
	get_user_ret(ViHandle, Args.KernViHandle, VIP_INVALID_PARAMETER);
	Vi = &DevicePtr->Vi[ViHandle];

	Priv = kmalloc(sizeof(VIPK_ERING_VI_PRIV), GFP_KERNEL);

	if(Priv == NULL) {
	    VipkDestroyVi(DevicePtr, ViHandle);
	    return VIP_ERROR_RESOURCE;
	}

	TxRingSize = ((VIPK_ERING_DEV_PRIV *)
		      DevicePtr->PrivateData)->TxRingSize;

	AllocSize = TxRingSize * sizeof(VIPK_ERING_HDR); 

	TxHdr = kmalloc(AllocSize, GFP_KERNEL);
	
	if(TxHdr == NULL) {
	    VipkDestroyVi(DevicePtr, ViHandle);
	    kfree(Priv);
	    return VIP_ERROR_RESOURCE;
	}
	memset(TxHdr, 0, AllocSize);

	Priv->TxHdrs = TxHdr;

	spin_lock_init(&Priv->Lock);
	atomic_set(&Priv->DescCount, 1);
	Priv->TxState = VIPK_ERING_TX_STOPPED;
	cond_init(&Priv->TxStateChange);

	init_timer(&Priv->RD.Timer);
	Priv->RD.Timer.function = VipkERingResendTimer;
	Priv->RD.Timer.data = (unsigned long) Vi;

	DevPriv = (VIPK_ERING_DEV_PRIV *)DevicePtr->PrivateData;
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
	/* Declaring 2.6 work struct */
	INIT_WORK(&(Priv->RD.Task), (void (*)(void *))DevPriv->ResendTask,
		  (void *)Vi);
#else
	Priv->RD.Task.sync = 0;
	Priv->RD.Task.routine = DevPriv->ResendTask;
	Priv->RD.Task.data = (void *) Vi;
#endif

	Priv->RD.SentHead = NULL;
	Priv->RD.SentTail = NULL;

	Vi->PrivateData = (VIP_PVOID) Priv;
    }

    return Status;
}

static VIP_RETURN
VipkERingDestroyVi(VIPK_DEVICE 		*DevicePtr,
		   VIPK_VI_HANDLE	ViHandle)
{
    VIPK_ERING_VI_PRIV	*Priv;
    VIPK_VI		*Vi;
    VIP_RETURN		Status;

    Vi = VipkViLookup(DevicePtr, ViHandle);
    if(Vi == NULL) {
	return VIP_INVALID_PARAMETER;
    }

    Priv = (VIPK_ERING_VI_PRIV *) Vi->PrivateData;
    
    Status = VipkDestroyVi(DevicePtr, ViHandle);
    if(Status == VIP_SUCCESS) {
	kfree(Priv->TxHdrs);
	kfree(Priv);
    }

    return Status;
}

static VIP_RETURN
VipkERingDisconnect(VIPK_DEVICE 	*DevicePtr,
		    VIPK_VI_HANDLE	ViHandle)
{
    VIP_RETURN		Status;
    VIPK_ERING_VI_PRIV	*ViPriv;
    VIPK_VI		*Vi;
    VIPK_ERING_RD_INFO	*SendInfo;
    VIPK_ERING_RD_INFO	*Next;
    unsigned long	Flags;

    Vi = VipkViLookup(DevicePtr, ViHandle);
    if(Vi == NULL) {
	return VIP_INVALID_PARAMETER;
    }

    ViPriv = (VIPK_ERING_VI_PRIV *) Vi->PrivateData;
    spin_lock_irqsave(&ViPriv->Lock, Flags);
    
    /* Stop the RD engine, starts the queue draining */
    VipkERingStopTx(Vi);

    /* Wait for queue to drain
     *
     * Because we are called to cleanup if the process is killed by a
     * signal, we cannot give up when signal_pending(current) is true.
     *
     * XXX: should have a timeout before declaring device hung.
     */
    while(ViPriv->TxState != VIPK_ERING_TX_STOPPED) {
	cond_wait(&ViPriv->TxStateChange, &ViPriv->Lock);
    }

    /* Free any remaining entries which are pending ACKs */
    SendInfo = ViPriv->RD.SentHead;
    while(SendInfo) {
	Next = SendInfo->Next;
	kfree(SendInfo);
	SendInfo = Next;
    }
    ViPriv->RD.SentHead = NULL;
    ViPriv->RD.SentTail = NULL;

    spin_unlock_irqrestore(&ViPriv->Lock, Flags);

    Status = VipkDisconnect(DevicePtr, ViHandle);

    /* Advance sequence number by 1/4 the full range to ensure
     * that we ignore any late arrivals on this Vi
     */
    Vi->RecvSeq += (2<<14);

    return Status;
}

static VIP_RETURN
VipkERingSendConnLost(VIPK_DEVICE       *DevicePtr,
		      VIPK_VI		*Vi,
		      VIP_BOOLEAN	IsError)
{
    VIPK_CCHAN_PACKET   *Pkt;
    VIP_RETURN		Status;
    
    if(Vi->Loopback) {
	VipkERingConnectionLost(DevicePtr, Vi->RemoteViHandle,
				Vi->Session, Vi->RecvSeq - 1, IsError);
	return VIP_SUCCESS;
    } else {
	Status = DevicePtr->CChan.GetPacket(&DevicePtr->CChan, &Pkt);
	if(Status != VIP_SUCCESS) {
	    return Status;
	}

	Pkt->Op = IsError ? VIPK_CCHAN_OP_CONNLOST : VIPK_CCHAN_OP_DISCO;
	VipNicAddrCopy((VIP_NET_ADDRESS *) &Pkt->SrcAddr, 
		       DevicePtr->NicAttribs);  
	VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->DstAddr,
		    (VIP_NET_ADDRESS *) &Vi->RemoteAddr);
	Pkt->ViHandle = Vi->RemoteViHandle;
	Pkt->Session = Vi->Session;

	/* This is a piggybacked ACK: */
	Pkt->Sequence = Vi->RecvSeq - 1;

	return DevicePtr->CChan.SendControl(&DevicePtr->CChan, VIP_FALSE, Pkt);
    } 
}

static void
VipkERingResendTimer(unsigned long Arg)
{
    VIPK_VI		*Vi;
    VIPK_ERING_VI_PRIV	*ViPriv;

    Vi = (VIPK_VI *)Arg;
    ViPriv = (VIPK_ERING_VI_PRIV *)Vi->PrivateData;

    /* XXX: perhaps run it rather than just queing it? */
    queue_task(&ViPriv->RD.Task, &tq_timer);
}


#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
module_init(vipk_ering_init_m);
module_exit(vipk_ering_cleanup_m);

MODULE_LICENSE("JLAB HPC BSD/GPL");
#endif
