/* modgate.h
 *
 * Routines to allow loadable kernel modules to modify entries in the
 * idt table.
 *
 * Since the idt is not exported by the linux kernel, we get the contents 
 * of the idt register from the processor using sidt (store idt).  
 * 
 * To modify an entry, we then set writable the page containing the 
 * vector we want to modify, set the vector, restore the correct rw 
 * status to the page, and return.  
 *
 * The macro expansion is a bit complicated, but it saves having 
 * four different copies of the same code.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#ifndef _MODGATE_H
#define _MODGATE_H

#include <asm/system.h>
#include <linux/pagemap.h>

/* The newer kernels do not define the *_trap_gate macros */
#ifndef set_trap_gate
#include <asm/desc.h>
#define _set_gate(gate_addr,type,dpl,addr) \
do { \
  int __d0, __d1; \
  __asm__ __volatile__ ("movw %%dx,%%ax\n\t" \
        "movw %4,%%dx\n\t" \
        "movl %%eax,%0\n\t" \
        "movl %%edx,%1" \
        :"=m" (*((long *) (gate_addr))), \
         "=m" (*(1+(long *) (gate_addr))), "=&a" (__d0), "=&d" (__d1) \
        :"i" ((short) (0x8000+(dpl<<13)+(type<<8))), \
         "3" ((char *) (addr)),"2" (__KERNEL_CS << 16)); \
} while (0)

#define set_trap_gate(n, addr)			\
    _set_gate(idt_table+n,15,0,addr);


#define set_system_gate(n, addr)		\
    _set_gate(idt_table+n,15,3,addr);

#define set_call_gate(a, addr)			\
    _set_gate(a,12,3,addr);
#else
#define idt_table idt
#endif

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0))
#  define PMD_PSE(PMD)		(pmd_val(PMD) & _PAGE_PSE)
#  define PT_LOCK		spin_lock(&init_mm.page_table_lock)
#  define PT_UNLOCK		spin_unlock(&init_mm.page_table_lock)
#  define PAGE_ADDR(PTE)	((unsigned long)page_address(pte_page(PTE)))
#else
#  define PMD_PSE(PMD)		(pmd_val(PMD) & _PAGE_4M)
#  define PT_LOCK		do {} while (0)
#  define PT_UNLOCK		do {} while (0)
#  define PAGE_ADDR(PTE)	(page_address((struct page *)pte_page(PTE)))
#endif

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
/*
 * We depend on the facts that the idt_table is 4KB aligned and
 * (with a max of 256 entries of 8 bytes each) fits on a single page.
 */
#define _mod_set_gate(index, op)					\
{									\
    struct Xgt_desc_struct idt_desc_reg;				\
    struct desc_struct *idt_table;					\
									\
    unsigned long page;							\
    pgd_t *pgd;								\
    pmd_t *pmd;								\
    pte_t *ptep, pte;    						\
									\
    __asm__ __volatile__ ("sidt %0" : : "m" (idt_desc_reg));		\
    page = idt_desc_reg.address;					\
									\
    /*									\
     * If we are not using PSE and the idt_table is mapped		\
     * read-only then the f00f bug work-around is being used.		\
     * Then we must locate the original (writtable) idt_table.		\
     */									\
    PT_LOCK;								\
    pgd = pgd_offset_k(page);						\
    pmd = pmd_offset(pgd, page);					\
    /** 2.6 change pte_offset to pte_offset_map to handle high          \
     *  memory. We must do pte_unmap also */                            \
    ptep = pte_offset_map(pmd, page);					\
    pte = *ptep;                                                        \
    if(!PMD_PSE(*pmd) && !pte_write(pte)) {				\
	/*								\
	 * XXX: Since I don't actually have an old enough machine	\
	 * this code has not actually been tested out.			\
	 */								\
	page = PAGE_ADDR(pte);						\
    }									\
    pte_unmap (ptep);                                                   \
    PT_UNLOCK;								\
									\
    idt_table = (struct desc_struct *)page;				\
    op;									\
}
#else
/*
 * We depend on the facts that the idt_table is 4KB aligned and
 * (with a max of 256 entries of 8 bytes each) fits on a single page.
 */
#define _mod_set_gate(index, op)					\
{									\
    struct Xgt_desc_struct idt_desc_reg;				\
    struct desc_struct *idt_table;					\
									\
    unsigned long page;							\
    pgd_t *pgd;								\
    pmd_t *pmd;								\
    pte_t *pte; 							\
									\
    __asm__ __volatile__ ("sidt %0" : : "m" (idt_desc_reg));		\
    page = idt_desc_reg.address;					\
									\
    /*									\
     * If we are not using PSE and the idt_table is mapped		\
     * read-only then the f00f bug work-around is being used.		\
     * Then we must locate the original (writtable) idt_table.		\
     */									\
    PT_LOCK;								\
    pgd = pgd_offset_k(page);						\
    pmd = pmd_offset(pgd, page);					\
    pte = pte_offset(pmd, page);					\
    if(!PMD_PSE(*pmd) && !pte_write(*pte)) {				\
	/*								\
	 * XXX: Since I don't actually have an old enough machine	\
	 * this code has not actually been tested out.			\
	 */								\
	page = PAGE_ADDR(*pte);						\
    }									\
    PT_UNLOCK;								\
									\
    idt_table = (struct desc_struct *)page;				\
    op;									\
}
#endif

#define mod_set_system_gate(index, addr) 	\
    _mod_set_gate(index, set_system_gate(index, addr))

#define mod_set_intr_gate(index, addr)		\
    _mod_set_gate(index, set_intr_gate(index, addr))

#define mod_set_call_gate(index, addr)		\
    _mod_set_gate(index, set_call_gate(index, addr))


#define mod_save_gate(index, desc) 				\
{								\
    struct Xgt_desc_struct idt_desc_reg;			\
								\
    __asm__ __volatile__ ("sidt %0" : : "m" (idt_desc_reg));	\
    desc = ((struct desc_struct *)idt_desc_reg.address)[index];	\
}

#define mod_restore_gate(index, desc)			\
{							\
    _mod_set_gate(index, idt_table[index]=desc);	\
}

#endif






