/** \file vipk_trace.h
 *
 * Macros to conditionally compile debuging info for M-VIA.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */
#ifndef _VIPK_TRACE_H
#define _VIPK_TRACE_H

#if 0
#define TRACE
#endif

#ifndef TRACE
#define TRACE(args...)
#else

#undef TRACE

#define VIPK_TRACE_REGDEV	0x00000001
#define VIPK_TRACE_FILE		0x00000002
#define VIPK_TRACE_IOCTL	0x00000004
#define VIPK_TRACE_NIC_OPS	0x00000008
#define VIPK_TRACE_EQ		0x00000010
#define VIPK_TRACE_PTM		0x00000020
#define VIPK_TRACE_RMM		0x00000040
#define VIPK_TRACE_CQM		0x00000080
#define VIPK_TRACE_CM		0x00000100
#define VIPK_TRACE_POSTR	0x00000200
#define VIPK_TRACE_POSTS	0x00000400
#define VIPK_TRACE_RECV		0x00000800
#define VIPK_TRACE_WAIT		0x00001000
#define VIPK_TRACE_CREATE_VI	0x00002000
#define VIPK_TRACE_DESTROY_VI	0x00004000
#define VIPK_TRACE_DISCONNECT	0x00008000
#define VIPK_TRACE_CCHAN	0x00010000
#define VIPK_TRACE_DEVICE	0x00020000
#ifdef __ARM_ARCH_4__
#define VIPK_TRACE_TIMING	0x00040000
#define VIPK_TRACE_RECV_ERROR	0x00080000
#define VIPK_TRACE_POSTR_ERROR	0x00100000
#define VIPK_TRACE_POSTS_ERROR	0x00200000
#endif /* __ARM_ARCH_4__ */

#define VIPK_TRACE_NONE		0x00000000
#define VIPK_TRACE_ALL		0xFFFFFFFF

#define TRACE(trace, args...)				\
if(vipk_trace & (trace)) {				\
    VipkTrace(__FILE__, __LINE__, __FUNCTION__, args);	\
}

extern unsigned int vipk_trace;

extern void VipkTrace(const char *file, int line, const char *func,
		      const char * fmt, ...)
	__attribute__ ((format (printf, 4, 5)));

#endif
#endif
