/* vipk_ptag.c
 * 
 * Implementation of a protection tag manager for the generalized
 * VI Kernel Agent.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#include <linux/vmalloc.h>

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
/**
 * The following two attributes are defined twice
 */
#ifdef __attribute_pure__
#undef __attribute_pure__
#endif
 
#ifdef __attribute_used__
#undef __attribute_used__
#endif

#endif

#include "vipk_ptm.h"
#include "vipk_trace.h"

VIP_RETURN
VipkPtmCreate(VIP_UINT32	NumPtags,
	      VIPK_PTM_HANDLE	*PtmHandle)
{
    VIPK_PTM 		*PtmPtr;
    VIP_UINT32		AllocSize;
    VIP_RETURN		Status;

    AllocSize = sizeof(VIPK_PTM) + (NumPtags-1) * sizeof(VIPK_PTAG);

    TRACE(VIPK_TRACE_PTM, "Initializing NumPtags: %d AllocSize: %d", 
	  NumPtags, AllocSize);

    PtmPtr = vmalloc(AllocSize);
    if(PtmPtr == NULL) {
	TRACE(VIPK_TRACE_PTM, "Failed to allocate Ptag Manager");
	Status = VIP_ERROR_RESOURCE;
    } else {
	memset(PtmPtr, 0, AllocSize);
	spin_lock_init(&PtmPtr->Lock);
	PtmPtr->NumPtags = NumPtags;
	Status = VIP_SUCCESS;
    }

    *PtmHandle = PtmPtr;
    return Status;
}

VIP_RETURN
VipkPtmDestroy(VIPK_PTM_HANDLE PtmHandle)
{
    TRACE(VIPK_TRACE_PTM, "Destroying");
    vfree(PtmHandle);
    return VIP_SUCCESS;
}

VIP_RETURN
VipkPtmCreatePtag(VIPK_PTM_HANDLE		PtmHandle,
		  VIP_PROTECTION_HANDLE		*PtagHandle,
		  VIPK_NIC_INSTANCE		NicInstance)
{
    VIP_RETURN Status;
    VIPK_UINTPTR i;

    TRACE(VIPK_TRACE_PTM, "[%d]", current->pid);
    
    Status = VIP_ERROR_RESOURCE;

    spin_lock(&PtmHandle->Lock);
    if(PtmHandle->NumInUse < PtmHandle->NumPtags) {
	for(i=0; i < PtmHandle->NumPtags; i++) {
	    if(VipkPtagIsFree(&PtmHandle->Ptag[i])) {
		VipkPtagIncUsage(&PtmHandle->Ptag[i]);
		*PtagHandle = (VIP_PROTECTION_HANDLE)i;
		PtmHandle->Ptag[i].NicInstance = NicInstance;
		PtmHandle->NumInUse++;
		TRACE(VIPK_TRACE_PTM, "[%d] PtagHandle: 0x%p Index: %lu",
		      current->pid, *PtagHandle, i);	    
		Status = VIP_SUCCESS;
		break;
	    }	
	}
    } else {
	TRACE(VIPK_TRACE_PTM, "[%d] No more free Ptags", current->pid);
    }
    spin_unlock(&PtmHandle->Lock);

    return Status;
}

VIP_RETURN
VipkPtmUsePtag(VIPK_PTM_HANDLE		PtmHandle,
	       VIP_PROTECTION_HANDLE	PtagHandle,
	       VIPK_NIC_INSTANCE	NicInstance)
{
    VIPK_PTAG *Ptag;

    TRACE(VIPK_TRACE_PTM, "[%d] PtagHandle: 0x%p", current->pid, PtagHandle);
    
    if(!VipkPtmPtagValid(PtmHandle, PtagHandle, NicInstance)) {
	return VIP_INVALID_PTAG;
    }

    Ptag = &PtmHandle->Ptag[(VIPK_UINTPTR)PtagHandle];

    VipkPtagIncUsage(Ptag);
    
    TRACE(VIPK_TRACE_PTM, "[%d] PtagHandle: 0x%p count: %d",
	  current->pid, PtagHandle, Ptag->UseCnt);
    
    return VIP_SUCCESS;
}

VIP_RETURN
VipkPtmReleasePtag(VIPK_PTM_HANDLE		PtmHandle,
		   VIP_PROTECTION_HANDLE	PtagHandle,
		   VIPK_NIC_INSTANCE		NicInstance)
{
    VIPK_PTAG *Ptag;

    TRACE(VIPK_TRACE_PTM, "[%d] PtagHandle: 0x%p", current->pid, PtagHandle);
    
    if(!VipkPtmPtagValid(PtmHandle, PtagHandle, NicInstance)) {
	return VIP_INVALID_PTAG;
    }

    Ptag = &PtmHandle->Ptag[(VIPK_UINTPTR)PtagHandle];

    VipkPtagDecUsage(Ptag);

    TRACE(VIPK_TRACE_PTM, "[%d] PtagHandle: 0x%p count: %d",
	  current->pid, PtagHandle, Ptag->UseCnt);
    
    return VIP_SUCCESS;
}

VIP_RETURN
VipkPtmDestroyPtag(VIPK_PTM_HANDLE		PtmHandle,
		   VIP_PROTECTION_HANDLE	PtagHandle,
		   VIPK_NIC_INSTANCE		NicInstance)
{
    VIPK_PTAG *Ptag;

    TRACE(VIPK_TRACE_PTM, "[%d] PtagHandle: 0x%p",
	  current->pid, PtagHandle);
    
    if(!VipkPtmPtagValid(PtmHandle, PtagHandle, NicInstance)) {
	TRACE(VIPK_TRACE_PTM, "[%d] PtagHandle: 0x%p invalid",
	      current->pid, PtagHandle);
	return VIP_INVALID_PARAMETER;
    }

    Ptag = &PtmHandle->Ptag[(VIPK_UINTPTR)PtagHandle];
    
    if(VipkPtagIsFree(Ptag)) {
	TRACE(VIPK_TRACE_PTM, "[%d] PtagHandle: 0x%p index: %lu is free",
	      current->pid, PtagHandle, (VIPK_UINTPTR)PtagHandle); 
	return VIP_INVALID_PARAMETER;
    }

    if(VipkPtagInUse(Ptag)) {
	TRACE(VIPK_TRACE_PTM, "[%d] PtagHandle: 0x%p index: %lu in use",
	      current->pid, PtagHandle, (VIPK_UINTPTR)PtagHandle); 
	return VIP_ERROR_RESOURCE;
    }
	
    spin_lock(&PtmHandle->Lock);
    Ptag->NicInstance = 0; /* invalidates the Ptag */
    VipkPtagDecUsage(Ptag);
    PtmHandle->NumInUse--;
    spin_unlock(&PtmHandle->Lock);

    TRACE(VIPK_TRACE_PTM, 
	  "[%d] PtagHandle: 0x%p index: %lu successfully destroyed",
	  current->pid, PtagHandle, (VIPK_UINTPTR)PtagHandle);    
    return VIP_SUCCESS;
}

VIP_RETURN
VipkPtmDestroyPtagNic(VIPK_PTM_HANDLE	PtmHandle,
		      VIPK_NIC_INSTANCE	NicInstance)
{
    VIP_RETURN Status;
    VIPK_UINTPTR i;

    TRACE(VIPK_TRACE_PTM, "[%d]", current->pid);
    
    Status = VIP_SUCCESS;
    for(i=0; i < PtmHandle->NumPtags; i++) {
	if(PtmHandle->Ptag[i].NicInstance == NicInstance) {
	    /* XXX: this is a hack to fix the problem of
	     * ptags not being released properly by all resources
	     * on vipk_close.  A bit of redesign between managers
	     * is necessary to fix this.
	     */
	    PtmHandle->Ptag[i].UseCnt = 1;
	    if(VipkPtmDestroyPtag(PtmHandle,
				  (VIP_PROTECTION_HANDLE)i,
				  NicInstance) != VIP_SUCCESS) {
		Status = VIP_ERROR_RESOURCE;
	    }
	}
    }

    TRACE(VIPK_TRACE_PTM,
	  "[%d] all Ptags destroyed", current->pid);
    return Status;
}
	

    

    


    

    
		
	    
	    
	    

    

    
