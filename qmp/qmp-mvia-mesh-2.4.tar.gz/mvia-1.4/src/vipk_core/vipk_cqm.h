/* \file vipk_cqm.h
 *
 * Interface for VI Kernel Agent Completion Queue Management
 * 
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#ifndef _VIPK_CQM_H
#define _VIPK_CQM_H

#include <linux/kernel.h>
#include <linux/sched.h>

#include "condvar.h"
#include "condvar.h"

#include <vipl.h>

typedef struct _VIPK_CQM *VIPK_CQM_HANDLE;

/* XXX: only for NicInstance, rework headers */
#include "vipk.h"


/** M-VIA Kernel Agent half of completion queue structure. */
typedef struct {
    /** Owner of the completion queue. */
    VIPK_OWNER		Owner;		
    /** Unique NIC instance ID which owns the completion queue. */
    VIPK_NIC_INSTANCE	NicInstance;
    /** Size of completion queue. */
    VIP_UINT32		EntryCount;
    /** Index of tail in circular queue. */
    VIP_UINT32		Tail;
    /** Current and old count.  
     * Used to determine if an entry has completed since waiting. 
     */
    VIP_UINT32		Count;
    VIP_UINT32		OldCount;
    /** Completion queue entries in user address space. */
    VIP_CQ_ENTRY	*UserEntry;
    /** Memory handle of the registered memory region 
     * conaining the UserEntries 
     */
    VIP_MEM_HANDLE	MemHandle;	
    /** Protection Tag of the UserEntries. */
    VIP_PROTECTION_HANDLE Ptag;		
    /** Mutex lock for the completion queue. */
    spinlock_t		Lock;
    /** Condition variable to signal a non-empty condition of the queue. */
    condvar_t		NonEmpty;

    /** Number of VIs using the completion queue. */
    VIP_UINT32		UseCount;
} VIPK_CQ;

/** M-VIA Kernel Agent Completion Queue Manager. */
typedef struct _VIPK_CQM {
    /** Number of supported completion queues. */
    VIP_UINT32		NumQueues;
    /** Maximum number entries allowed in a completion queue. */
    VIP_UINT32		MaxCQEntries;
    /** Lock for concurent access. */
    spinlock_t		Lock;
    /** The array of completion queues. */
    VIPK_CQ		Cq[1];
} VIPK_CQM;

/** 
 * Create a Completion Queue Manager 
 *
 * @param NumQueues		Number of completion queues to allocate.
 * @param MaxCQEntries		Maximum number of entries allowed in a 
 *				completion queue.
 * @param CqmHandle		The newly created completion queue manager.
 * @return 	\c VIP_SUCCESS - The completion queue manager was 
 *		successfully created.<br>
 *	       	\c VIP_ERROR_RESOURCE - Insufficient resources to create
 *		the completion queue manager.
 */
extern VIP_RETURN 
VipkCqmCreate(VIP_UINT32	NumQueues, 
	      VIP_UINT32	MaxCQEntries,
	      VIPK_CQM_HANDLE	*CqmHandle);

/**
 * Destroy a Completion Queue Manager.
 *
 * @param CqmHandle		The completion queue manager to destroy.
 *
 * @return	\c VIP_SUCCESS - The completion queue manager was 
 *		successfully destroyed.
 *
 * \warning No error checking is performed by this function.  Considering it
 * is being called from withing the kernel, the caller should be 
 * "doing-the-right-thing" already, but some sanity checks would be 
 * beneficial.
 */
extern VIP_RETURN 
VipkCqmDestroy(VIPK_CQM_HANDLE CqmHandle);

/**
 * Create a completion queue.
 *
 * @param CqmHandle		Completion queue manager to create the 
 *				completion queue in.
 * @param UserEntry		Circular array of CQ entries in user space.
 * @param EntryCount		Number of entries in the new CQ.
 * @param MemHandle		Memory handle of the completion queue in 
 *				user memory.
 * @param Ptag			Protection tag of the memory region 
 *				containing the CQ in user memory
 * @param NicInstance		Unique ID of the NIC instance creating the CQ.
 * @param Owner			Owner of the process creating the CQ
 *
 * @return 	\c VIP_SUCCESS - The completion queue was 
 *		successfully created.<br>
 *	       	\c VIP_ERROR_RESOURCE - Insufficient resources to create
 *		the completion queue manager, or EntryCount of 0 was specified.
 */
extern VIP_RETURN 
VipkCqmCreateCq(VIPK_CQM_HANDLE		CqmHandle,
		VIP_CQ_ENTRY		*UserEntry,
		VIP_ULONG		EntryCount,
		VIP_MEM_HANDLE		MemHandle,
		VIP_PROTECTION_HANDLE	Ptag,
		VIPK_CQ_HANDLE		*CqHandle,
		VIPK_NIC_INSTANCE	NicInstance,
		VIPK_OWNER		Owner);

/**
 * Destroy a completion queue.
 *
 * @param CqmHandle		Completion queue manager from which to destroy
 *				the completion queue.
 * @param CqHandle		Completion queue to destroy.
 * @param NicInstance		Unique ID of the NIC instance 
 *				destroying the CQ.
 * @param Owner			Owner of the process destroying the CQ.
 *
 * @return 	\c VIP_SUCCESS - The completion queue was 
 *		successfully destroyed.
 *		\c VIP_INVALID_PARAMETER - The completion queue handle was 
 *		invalid.<br>
 *	       	\c VIP_ERROR_RESOURCE - The completion queue was still in 
 * 		use by a VI work queue.
 */
extern VIP_RETURN 
VipkCqmDestroyCq(VIPK_CQM_HANDLE	CqmHandle,
		 VIPK_CQ_HANDLE		CqHandle,
		 VIPK_NIC_INSTANCE	NicInstance,
		 VIPK_OWNER		Owner);

/** 
 * Pre-wait on a completion queue event.
 *
 * @param CqmHandle		Completion queue manager on which to pre-wait.
 * @param CqHandle		Completion queue on which to pre-wait.
 * @param NicInstance		Unique ID of the NIC instance pre-waiting on
 *				the completion queue.
 * @param Owner			Owner of the process pre-waiting on the 
 *				completion queue.
 * @return 	\c VIP_SUCCESS - The pre-wait completed successfully..<br>
 *		\c VIP_INVALID_PARAMETER - The completion queue handle was 
 *		invalid.
 */
extern VIP_RETURN
VipkCqmPreWait(VIPK_CQM_HANDLE		CqmHandle,
	       VIPK_CQ_HANDLE		CqHandle,
	       VIPK_NIC_INSTANCE	NicInstance,
	       VIPK_OWNER		Owner);

/** 
 * Wait on a completion queue event.
 *
 * @param CqmHandle		Completion queue manager on which to wait.
 * @param CqHandle		Completion queue on which to wait.
 * @param Timeout		Timeout value, in msec, or VIP_INFINITE.
 * @param NicInstance		Unique ID of the NIC instance waiting on
 *				the completion queue.
 * @param Owner			Owner of the process pre-waiting on the 
 *				completion queue.
 * @return 	\c VIP_SUCCESS - The wait was successfull.<br>
 *		\c VIP_INVALID_PARAMETER - The completion queue handle was 
 *		invalid.<br>
 *		\c VIP_TIMEOUT -  The wait timed out.
 */
extern VIP_RETURN 
VipkCqmWait(VIPK_CQM_HANDLE	CqmHandle,
	    VIPK_CQ_HANDLE	CqHandle,
	    VIP_ULONG		*Timeout,
	    VIPK_NIC_INSTANCE	NicInstance,
	    VIPK_OWNER		Owner);

/**
 * Enqueue a completion queue entry.
 *
 * @param CQ			Completion queue mananger containing the 
 *				completion queue.
 * @param RmmHandle		Registered Memory Manager handle to 
 *				validate the completion queue against.
 * @param UserViHandle		The VIPL VIP_VI_HANDLE to place in 
 *				the completion queue.
 * @param Recv			If \c VIP_TRUE, indicates a receive descriptor
 *				has completed, otherwise, a send descriptor 
 *				completed.
 * @return 	\c VIP_SUCCESS - The entry was successfully enqueued.<br>
 *		\c VIP_INVALID_PARAMETER - The completion queue handle was 
 *		invalid.<br>
 */
/* XXX: the functional dependance between the CQM and the RMM is too high */
extern VIP_RETURN
VipkCqEnqueue(VIPK_CQ		*Cq,
	      VIPK_RMM_HANDLE	RmmHandle,
	      VIP_VI_HANDLE	UserViHandle,
	      VIP_BOOLEAN	Recv);

/**
 * Increment the competion queue usage count.
 *
 * @param Cq Completion queue to increment the usage count on.
 */
/* XXX: why isn't this using CQM Handles? */
extern void
VipkCqIncUsage(VIPK_CQ *Cq);

/** Decrement the completion queue usage count.
 *
 * @param Cq Completion queue to decrement the usage count on.
 */
/* XXX: why isn't this using CQM Handles? */
extern void
VipkCqDecUsage(VIPK_CQ *Cq);

/** 
 * Destroy all the completion queues associated with a give Nic instance. 
 *
 * @param CqmHandle		Completion queue manager from which to 
 *				delete the completion queues.
 * @param NicInstance		The unique Nic instance ID to delete the
 *				completion queues for.
 * @return \c VIP_SUCCESS - This function never fails.
 */
extern VIP_RETURN 
VipkCqmDestroyCqNic(VIPK_CQM_HANDLE	CqmHandle,
		    VIPK_NIC_INSTANCE	NicInstance);

/**
 * Convert a completion queue handle to a completion queue pointer.
 *
 * @param CqmHandle 		Completion queue manager containing the 
 *				completion queue.
 * @param CqHandle		Completion queue handle to convert to 
 *				a pointer.
 * @param CqPtr			Address to store the CQ pointer.
 * @param NicInstance		Unique ID of the NIC instance requesting 
 *				the translation.
 * @param Owner			Owner of the process requesting the translation
 * 
 * @return 	\c VIP_SUCCESS - The completion queue pointer was successfully 
 *	   	returned.<br>
 *		\c VIP_INVALID_PARAMETER - The completion queue handle was 
 *		invalid.
 */
extern VIP_RETURN
VipkCqmGetCq(VIPK_CQM		*CqmPtr,
	     VIPK_CQ_HANDLE	CqHandle,
	     VIPK_CQ		**CqPtr,
	     VIPK_NIC_INSTANCE	NicInstance,
	     VIPK_OWNER		Owner);

/**
 * Resize a CQ.  Done atomicly with respect to completions.
 *
 * @param CqmHandle 		Completion queue manager containing the 
 *				completion queue to resize.
 * @param RmmHandle		Registered Memory Manager handle to 
 *				validate the completion queue against.
 * @param CqHandle		Completion queue to resize.
 * @param NewUserEntry		New circular array of CQ entries in user space.
 * @param NewEntryCount		New number of entries in the CQ.
 * @param NewMemHandle		Memory handle of the completion queue in 
 *				user memory.
 * @param NewPtag		Protection tag of the memory region 
 *				containing the CQ in user memory
 * @param NicInstance		Unique ID of the NIC instance requesting 
 *				the translation.
 * @param Owner			Owner of the process requesting the resize.
 * 
 * @return 	\c VIP_SUCCESS - The completion queue was successfully
 *		resized.<br>
 *		\c VIP_INVALID_PARAMETER - The completion queue handle was 
 *		invalid.<br>
 *		\c VIP_ERROR_RESOURCE - The requested size was invalid because
 *		it was zero, larger than the completion queue manager's maximum
 *		or insufficient to hold the entries currently on the queue.
 */
extern VIP_RETURN
VipkCqmResizeCq(VIPK_CQM_HANDLE		CqmHandle,
		VIPK_RMM_HANDLE		RmmHandle,
		VIPK_CQ_HANDLE		CqHandle,
		VIP_CQ_ENTRY		*NewUserEntry,
		VIP_ULONG		NewEntryCount,
		VIP_MEM_HANDLE		NewMemHandle,
		VIP_PROTECTION_HANDLE	NewPtag,
		VIPK_NIC_INSTANCE	NicInstance,
		VIPK_OWNER		Owner);

#endif
