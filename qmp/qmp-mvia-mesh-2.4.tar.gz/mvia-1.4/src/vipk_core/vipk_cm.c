/* \file vipk_cm.c
 *
 * Default connection manager for the M-VIA Kernel Agent.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#include <linux/kernel.h>
#include <linux/vmalloc.h>

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
/**
 * The following two attributes are defined twice
 */
#ifdef __attribute_pure__
#undef __attribute_pure__
#endif
 
#ifdef __attribute_used__
#undef __attribute_used__
#endif

#endif

#include "vipk.h"
#include "vipk_cm.h"
#include "vipk_trace.h"

#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/list.h>

#include <vipl_private.h>
#include "condvar.h"

/* XXX: This will be removed in the future. The VI needs to be
 * made more general.
 */
#include "vipk.h"


/* XXX: get packet and send control can't fail or we break the
 * semantics of these routines... handle this.
 */

/** The states a connection entry may be in. */
typedef enum {
    /** The connection entry is free and may be used to queue
     * VipConnectWait requests. */
    VIPK_CM_CONN_STATE_FREE,

    /** A VipConnectWait has been performed on this entry. */
    VIPK_CM_CONN_STATE_SERVER_WAIT,

    /** An incoming client connect request message has been received
     * and is awaiting a VipConnectReject or VipConnectAccept.
     */
    VIPK_CM_CONN_STATE_SERVER_MATCH,

    /** The server called VipConnectAccept, but we have not
     * finalized with the client.
     */
    VIPK_CM_CONN_STATE_SERVER_ACCEPTED,

    /** The client has called VipConnectRequest and is waiting for
     * a response from the server.
     */
    VIPK_CM_CONN_STATE_CLIENT_WAIT,

    /** The client has received a VipConnectAccept message and is
     * wating for finalization of the connection.
     */
    VIPK_CM_CONN_STATE_CLIENT_ACCEPTED,

    /** The connect request was received on the server, but there was
     * no matching VipConnectWait */
    VIPK_CM_CONN_STATE_CLIENT_NO_MATCH,

    /** The client has received a VipConnectReject message. */
    VIPK_CM_CONN_STATE_CLIENT_REJECT,

    /** The peer has sent a request and is waiting for a reply. */
    VIPK_CM_CONN_STATE_PEER_WAIT,

    /** The peer has received an accept in reply to its request. */
    VIPK_CM_CONN_STATE_PEER_IS_PEER1,

    /** The peer has received a request matching one it sent. */
    VIPK_CM_CONN_STATE_PEER_IS_PEER2,

    /** The peer is PEER1 and has sent the PEER1CMP message. */
    VIPK_CM_CONN_STATE_PEER_PEER1CMP,

    /** The peer is PEER2 and has received the PEER1CMP message. */
    VIPK_CM_CONN_STATE_PEER_PEER2CMP,

    /** The request has timed out either locally or remotely. */
    VIPK_CM_CONN_STATE_TIMEOUT,

    /** The connection has been established. */
    VIPK_CM_CONN_STATE_CONNECTED

} VIPK_CM_CONN_STATE;

/** A single connection manager entry.  This is the private Kernel Agent
 * state for a Connection Handle.
 */
typedef struct {
    /** Pointers in a linked list. */
    struct list_head	List;

    /** ID of the NIC instance which owns this connection entry. */
    VIPK_NIC_INSTANCE	NicInstance;

    /** The state of the connection entry. */
    VIPK_CM_CONN_STATE	State;

    /** A process can block here to await a state change. */
    condvar_t		StateChange;

    /** Session number.  Also yields Vi session and initial sequence #'s. */
    VIP_UINT32		Session;

    /** The Connection Handle on the other end, acts like a port number. */
    VIPK_CONN_HANDLE	RemoteConnHandle;

    /** The local address of the server, including discriminator */
    VIP_NET_MAX_ADDRESS	LocalAddr;

    /** The remote address of the client, coresponding to the LocalAddr
     * argument supplied to VipConnectRequest.
     */
    VIP_NET_MAX_ADDRESS	RemoteAddr;

    /** The remote VI Handle requesting a connection. */
    VIPK_VI_HANDLE	RemoteViHandle;

    /** The remote VI attributes of the client */
    VIP_VI_ATTRIBUTES	RemoteViAttribs;

    /** The remote VI's initial sequence number */
    VIP_UINT32		RemoteSequence;

    /* The following are for peer-to-peer only: */

    /** Indication whether this request can timeout */
    VIP_BOOLEAN		Expires;

    /** The expiration time for a peer connection request */
    unsigned long	TimeOut;

    /** Peer-to-peer connection must negotiate which end's session to use. */
    VIP_UINT32		MySession;

    /** The local VI Handle requesting a connection. */
    VIPK_VI_HANDLE	LocalViHandle;

    /** The local VI requesting a connection. */
    VIPK_VI		*LocalVi;
} VIPK_CM_CONN;

typedef struct {
    VIPK_CCHAN *CChan;

    /** Size of the connection manager queue. */
    VIP_UINT32	NumEntries;

    /** Mutex lock for connection mananger. */
    spinlock_t	Lock;

    /** Generator for unique session IDs */
    VIP_UINT32	NextSession;

    /** The connection handle table. */
    VIPK_CM_CONN *Conn;

    /** Lock for the free list */
    spinlock_t		FreeLock;

    /** LIFO (stack) of ...STATE_FREE connection handles (singly-linked) */
    struct list_head	*FreeList;

    /** Doubly linked list of ...STATE_SERVER_WAIT connections */
    struct list_head	CSWaiting;

    /** Doubly linked list of matched, but pending, client/server connections */
    struct list_head	CSPending;

    /** Doubly linked list of requested peer-to-peer connections */
    struct list_head	PPWaiting;

    /** Doubly linked list of matched, but pending, peer-to-peer connections */
    struct list_head	PPPending;
} VIPK_CM_PRIV;

static VIP_RETURN
VipkCmInit(VIPK_CM		*Cm,
	   VIPK_CCHAN		*CChan,
	   VIP_UINT32		NumEntries);

static VIP_RETURN
VipkCmDestroy(VIPK_CM		*Cm);

static VIP_RETURN
VipkCmWait(VIPK_CM		*Cm,
	   VIPK_NIC_INSTANCE	NicInstance,
	   VIP_NET_ADDRESS	*LocalAddr,
	   VIP_ULONG		Timeout,
	   VIP_NET_ADDRESS	*RemoteAddr,
	   VIP_VI_ATTRIBUTES	*RemoteViAttribs,
	   VIPK_CONN_HANDLE	*ConnHandle);

static VIP_RETURN
VipkCmAccept(VIPK_CM		*Cm,
	     VIPK_CONN_HANDLE	ConnHandle,
	     VIPK_NIC_INSTANCE	NicInstance,
	     VIPK_VI_HANDLE	LocalViHandle,
	     VIPK_VI		*Vi);

static VIP_RETURN
VipkCmReject(VIPK_CM		*Cm,
	     VIPK_CONN_HANDLE	ConnHandle,
	     VIPK_NIC_INSTANCE	NicInstance);


static VIP_RETURN
VipkCmRequest(VIPK_CM		*Cm,
	      VIPK_NIC_INSTANCE	NicInstance,
	      VIPK_VI_HANDLE	LocalViHandle,
	      VIPK_VI		*Vi,
	      VIP_NET_ADDRESS	*LocalAddr,
	      VIP_NET_ADDRESS	*RemoteAddr,
	      VIP_ULONG		Timeout);

static VIP_RETURN
VipkCmPeerRequest(VIPK_CM		*Cm,
		  VIPK_NIC_INSTANCE	NicInstance,
		  VIPK_VI_HANDLE	LocalViHandle,
		  VIPK_VI		*Vi,
		  VIP_NET_ADDRESS	*LocalAddr,
		  VIP_NET_ADDRESS	*RemoteAddr,
		  VIP_ULONG		Timeout);

static VIP_RETURN
VipkCmPeerDone(VIPK_CM			*Cm,
	       VIPK_NIC_INSTANCE	NicInstance,
	       VIPK_VI			*Vi,
	       VIP_BOOLEAN		Block);

static VIP_RETURN
VipkCmDisconnect(VIPK_CM		*Cm,
		 VIPK_NIC_INSTANCE	NicInstance,
		 VIPK_VI		*Vi);

static VIP_RETURN
VipkCmDestroyNic(VIPK_CM		*Cm,
		 VIPK_NIC_INSTANCE	NicInstance);

static void
VipkCmRecvControl(VIPK_CM		*Cm,
		  VIPK_CCHAN_PACKET	*Pkt);

static VIP_RETURN
VipkCmRecvCONNREQ(VIPK_CM		*Cm,
		  VIP_NET_ADDRESS	*LocalAddr,
		  VIP_NET_ADDRESS	*RemoteAddr,
		  VIPK_VI_HANDLE	RemoteViHandle,
		  VIP_VI_ATTRIBUTES	*RemoteViAttribs,
		  VIP_UINT32		RemoteSequence,
		  VIPK_CONN_HANDLE	RemoteConnHandle,
		  VIP_UINT32		Session);

static VIP_RETURN
VipkCmRecvCONNACC(VIPK_CM		*Cm,
		  VIPK_CONN_HANDLE	ConnHandle,
		  VIP_UINT32		Session,
		  VIP_NET_ADDRESS	*LocalAddr,
		  VIP_NET_ADDRESS	*RemoteAddr,
		  VIPK_VI_HANDLE	RemoteViHandle,
		  VIP_VI_ATTRIBUTES	*RemoteViAttribs,
		  VIP_UINT32		RemoteSequence,
		  VIPK_CONN_HANDLE	RemoteConnHandle);

static VIP_RETURN
VipkCmRecvCONNREJ(VIPK_CM		*Cm,
		  VIPK_CONN_HANDLE	ConnHandle,
		  VIP_UINT32		Session);

static VIP_RETURN
VipkCmRecvCONNCCMP(VIPK_CM		*Cm,
		   VIPK_CONN_HANDLE	ConnHandle,
		   VIP_UINT32		Session);

static VIP_RETURN
VipkCmRecvCONNSCMP(VIPK_CM		*Cm,
		   VIPK_CONN_HANDLE	ConnHandle,
		   VIP_UINT32		Session);

static VIP_RETURN
VipkCmRecvCONNTO(VIPK_CM		*Cm,
		 VIPK_CONN_HANDLE	ConnHandle,
		 VIP_UINT32		Session);

static VIP_RETURN
VipkCmRecvCONNNOM(VIPK_CM		*Cm,
		  VIPK_CONN_HANDLE	ConnHandle,
		  VIP_UINT32		Session);

static VIP_RETURN
VipkCmRecvPEERREQ(VIPK_CM		*Cm,
		  VIP_NET_ADDRESS	*LocalAddr,
		  VIP_NET_ADDRESS	*RemoteAddr,
		  VIPK_VI_HANDLE	RemoteViHandle,
		  VIP_VI_ATTRIBUTES	*RemoteViAttribs,
		  VIP_UINT32		RemoteSequence,
		  VIPK_CONN_HANDLE	RemoteConnHandle,
		  VIP_UINT32		Session);

static VIP_RETURN
VipkCmRecvPEERACC(VIPK_CM		*Cm,
		  VIPK_CONN_HANDLE	ConnHandle,
		  VIP_UINT32		Session,
		  VIP_NET_ADDRESS	*LocalAddr,
		  VIP_NET_ADDRESS	*RemoteAddr,
		  VIPK_VI_HANDLE	RemoteViHandle,
		  VIP_VI_ATTRIBUTES	*RemoteViAttribs,
		  VIP_UINT32		RemoteSequence,
		  VIPK_CONN_HANDLE	RemoteConnHandle);

static VIP_RETURN
VipkCmRecvPEERTO(VIPK_CM		*Cm,
		 VIPK_CONN_HANDLE	ConnHandle,
		 VIP_UINT32		Session);

static VIP_RETURN
VipkCmRecvPEER1CMP(VIPK_CM		*Cm,
		   VIPK_CONN_HANDLE	ConnHandle,
		   VIP_UINT32		Session);

static VIP_RETURN
VipkCmRecvPEER2CMP(VIPK_CM		*Cm,
		   VIPK_CONN_HANDLE	ConnHandle,
		   VIP_UINT32		Session);

static VIP_RETURN
VipkCmConnectClient(VIPK_CM_PRIV	*CmPriv,
		    VIPK_CM_CONN	*Conn);

static void
VipkCmFreeConn(VIPK_CM_PRIV	*CmPriv,
	       VIPK_CM_CONN	*Conn);

static VIP_RETURN
VipkCmFindFree(VIPK_CM_PRIV		*CmPriv,
	       VIPK_CONN_HANDLE		*ConnHandle);

static VIP_RETURN
VipkCmLookup(VIPK_CM_PRIV		*CmPriv,
	     VIPK_CONN_HANDLE		ConnHandle,
	     VIPK_CM_CONN		**Conn);

static VIP_RETURN
VipkCmLookupSession(VIPK_CM_PRIV		*CmPriv,
		    VIPK_CONN_HANDLE		ConnHandle,
		    VIPK_CM_CONN		**Conn,
		    VIP_UINT32			Session);

static VIP_RETURN
VipkCmValidate(VIPK_CM_CONN	*Conn,
	       VIPK_VI		*Vi);

static VIP_RETURN
VipkCmFinalize(VIPK_CM_CONN	*Conn,
	       VIPK_VI		*Vi);

const VIPK_CM VipkCmDefault = {
    NULL,
    VipkCmInit,
    VipkCmDestroy,
    VipkCmWait,
    VipkCmAccept,
    VipkCmReject,
    VipkCmRequest,
    VipkCmPeerRequest,
    VipkCmPeerDone,
    VipkCmDisconnect,
    VipkCmDestroyNic,
    VipkCmRecvControl
};

VIP_RETURN
VipkCmInit(VIPK_CM	*Cm,
	   VIPK_CCHAN	*CChan,
	   VIP_UINT32	NumEntries)
{
    VIPK_CM_PRIV	*CmPriv;
    int			i;

    CmPriv = vmalloc(sizeof(VIPK_CM_PRIV));

    if(CmPriv == NULL) {
	TRACE(VIPK_TRACE_CM, "Failed to allocate Conn Manager");
	return VIP_ERROR_RESOURCE;
    }

    CmPriv->NextSession = jiffies; /* random */

    CmPriv->Conn = vmalloc(NumEntries * sizeof(VIPK_CM_CONN));

    if(CmPriv->Conn == NULL) {
	TRACE(VIPK_TRACE_CM, "Failed to allocate Conn Queue");
	return VIP_ERROR_RESOURCE;
    }

    CmPriv->NumEntries = NumEntries;
    CmPriv->CChan = CChan;
    spin_lock_init(&CmPriv->Lock);
    spin_lock_init(&CmPriv->FreeLock);

    memset(CmPriv->Conn, 0, NumEntries * sizeof(VIPK_CM_CONN));

    for(i=0; i < NumEntries; i++) {
	VIPK_CM_CONN *Conn = &CmPriv->Conn[i];

	cond_init(&Conn->StateChange);
	Conn->State = VIPK_CM_CONN_STATE_FREE;
	Conn->List.next = &((Conn + 1)->List);
    }
    CmPriv->Conn[NumEntries-1].List.next = NULL;
    CmPriv->FreeList = &(CmPriv->Conn[0].List);

    INIT_LIST_HEAD(&CmPriv->CSWaiting);
    INIT_LIST_HEAD(&CmPriv->CSPending);
    INIT_LIST_HEAD(&CmPriv->PPWaiting);
    INIT_LIST_HEAD(&CmPriv->PPPending);

    Cm->Private = CmPriv;

    return VIP_SUCCESS;
}

VIP_RETURN
VipkCmDestroy(VIPK_CM *Cm)
{
    VIPK_CM_PRIV *CmPriv;

    TRACE(VIPK_TRACE_CM, "Destroying CmHandle 0x%p", (void *)Cm);

    CmPriv = (VIPK_CM_PRIV *) Cm->Private;
    /* XXX: need consistancy checking here? */
    vfree(CmPriv->Conn);
    vfree(CmPriv);
    return VIP_SUCCESS;
}

VIP_RETURN
VipkCmWait(VIPK_CM		*Cm,
	   VIPK_NIC_INSTANCE	NicInstance,
	   VIP_NET_ADDRESS	*LocalAddr,
	   VIP_ULONG		Timeout,
	   VIP_NET_ADDRESS	*RemoteAddr,
	   VIP_VI_ATTRIBUTES	*RemoteViAttribs,
	   VIPK_CONN_HANDLE	*ConnHandle)
{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN	*Conn;
    VIP_RETURN		Status;

    VIPK_CONN_HANDLE	ConnH;
    unsigned long	Flags;
    unsigned long	KernTimeout;

    CmPriv = (VIPK_CM_PRIV *) Cm->Private;
    spin_lock_irqsave(&CmPriv->Lock, Flags);

    KernTimeout = VipkLinuxTimeout(Timeout);

    Status = VipkCmFindFree(CmPriv, &ConnH);
    if(Status != VIP_SUCCESS) {
	TRACE(VIPK_TRACE_CM,
	      "[%d] Could not find free conn handle", current->pid);
	spin_unlock_irqrestore(&CmPriv->Lock, Flags);
	return Status;
    }

    TRACE(VIPK_TRACE_CM,
	  "[%d] Found empty conn handle: 0x%x", current->pid, ConnH);

    VipkCmLookup(CmPriv, ConnH, &Conn);
    VipAddrCopy((VIP_NET_ADDRESS *) &Conn->LocalAddr, LocalAddr);
    Conn->NicInstance = NicInstance;
    Conn->State = VIPK_CM_CONN_STATE_SERVER_WAIT;
    list_add(&Conn->List, &CmPriv->CSWaiting);

    while(Conn->State == VIPK_CM_CONN_STATE_SERVER_WAIT &&
	  KernTimeout && !signal_pending(current)) {
	cond_wait_interruptible(&Conn->StateChange,
				&CmPriv->Lock, &KernTimeout);
    }

    switch(Conn->State) {
    case VIPK_CM_CONN_STATE_SERVER_MATCH:
	TRACE(VIPK_TRACE_CM,
	      "[%d] Server matched ConnHandle 0x%x", current->pid, ConnH);
	VipAddrCopy(RemoteAddr, (VIP_NET_ADDRESS *)&Conn->RemoteAddr);
	*RemoteViAttribs = Conn->RemoteViAttribs;
	*ConnHandle = ConnH;
	Status = VIP_SUCCESS;
	break;
    case VIPK_CM_CONN_STATE_SERVER_WAIT:
	TRACE(VIPK_TRACE_CM, "[%d] Timed out or signal", current->pid);
	VipkCmFreeConn(CmPriv, Conn);
	Status = VIP_TIMEOUT;
	break;
    default:
	TRACE(VIPK_TRACE_CM, "[%d] Invalid state", current->pid);
	VipkCmFreeConn(CmPriv, Conn);
	break;
    }

    spin_unlock_irqrestore(&CmPriv->Lock, Flags);

    return Status;
}

VIP_RETURN
VipkCmAccept(VIPK_CM		*Cm,
	     VIPK_CONN_HANDLE	ConnHandle,
	     VIPK_NIC_INSTANCE	NicInstance,
	     VIPK_VI_HANDLE	LocalViHandle,
	     VIPK_VI		*Vi)
{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN	*Conn;
    VIPK_CCHAN_PACKET	*Pkt;
    VIP_RETURN		Status;

    unsigned long	Flags;
    unsigned long	KernTimeout;

    TRACE(VIPK_TRACE_CM, "[%d] ConnHandle: 0x%x", current->pid, ConnHandle);
    CmPriv = (VIPK_CM_PRIV *) Cm->Private;

    spin_lock_irqsave(&Vi->Lock, Flags);
    if(Vi->State != VIP_STATE_IDLE) {
	TRACE(VIPK_TRACE_CM,
	      "[%d] ViState != IDLE", current->pid);
	spin_unlock_irqrestore(&Vi->Lock, Flags);
	return VIP_INVALID_STATE;
    }
    Vi->State = VIP_STATE_CONNECT_PENDING;
    spin_unlock_irqrestore(&Vi->Lock, Flags);


    spin_lock_irqsave(&CmPriv->Lock, Flags);

    if(VipkCmLookup(CmPriv, ConnHandle, &Conn) != VIP_SUCCESS) {
	TRACE(VIPK_TRACE_CM, "[%d] Invalid ConnHandle", current->pid);
	Status = VIP_INVALID_PARAMETER;
	goto cm_accept_out;
    }

    if(Conn->NicInstance != NicInstance) {
	TRACE(VIPK_TRACE_CM,
	      "[%d] ConnHandle not owned by this Nic", current->pid);
	spin_lock(&Vi->Lock);
	Vi->State = VIP_STATE_IDLE;
	spin_unlock(&Vi->Lock);
	Status = VIP_INVALID_PARAMETER;
	goto cm_accept_out;
    }

    if(Conn->State != VIPK_CM_CONN_STATE_SERVER_MATCH) {
	TRACE(VIPK_TRACE_CM,
	      "[%d] ConnHandle not in state SERVER_MATCH", current->pid);
	spin_lock(&Vi->Lock);
	Vi->State = VIP_STATE_IDLE;
	spin_unlock(&Vi->Lock);
	Status = VIP_INVALID_PARAMETER;
	goto cm_accept_out;
    }

    Status = VipkCmValidate(Conn, Vi);
    if(Status != VIP_SUCCESS) {
	spin_lock(&Vi->Lock);
	Vi->State = VIP_STATE_IDLE;
	spin_unlock(&Vi->Lock);
	goto cm_accept_out;
    }

    Conn->State = VIPK_CM_CONN_STATE_SERVER_ACCEPTED;

    Status = CmPriv->CChan->GetPacket(CmPriv->CChan, &Pkt);
    if(Status != VIP_SUCCESS) {
	VipkCmFreeConn(CmPriv, Conn);
	spin_lock(&Vi->Lock);
	Vi->State = VIP_STATE_IDLE;
	spin_unlock(&Vi->Lock);
	goto cm_accept_out;
    }

    Pkt->Op = VIPK_CCHAN_OP_CONNACC;

    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->SrcAddr,
		(VIP_NET_ADDRESS *) &Conn->LocalAddr);
    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->DstAddr,
		(VIP_NET_ADDRESS *) &Conn->RemoteAddr);
    Pkt->SrcConnHandle = ConnHandle;
    Pkt->DstConnHandle = Conn->RemoteConnHandle;
    Pkt->ViHandle = LocalViHandle;
    VipkEncodeAttribs(Pkt, &Vi->ViAttribs);
    Pkt->Sequence = Vi->RecvSeq;
    Pkt->Session = Conn->Session;

    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    Status = CmPriv->CChan->SendControl(CmPriv->CChan, VIP_TRUE, Pkt);
    spin_lock_irqsave(&CmPriv->Lock, Flags);

    if(Status != VIP_SUCCESS) {
	/* XXX: assert that it is not reachable */
	if(Vi->ViAttribs.ReliabilityLevel > VIP_SERVICE_UNRELIABLE) {
	    spin_lock(&Vi->Lock);
	    Vi->State = VIP_STATE_ERROR;
	    spin_unlock(&Vi->Lock);
	    VipkCmFreeConn(CmPriv, Conn);
	}
	goto cm_accept_out;
    }

    /* XXX: there should be a real timeout here (10 sec?) */
    KernTimeout = MAX_SCHEDULE_TIMEOUT;
    while(Conn->State == VIPK_CM_CONN_STATE_SERVER_ACCEPTED &&
	  KernTimeout && !signal_pending(current)) {
	cond_wait_interruptible(&Conn->StateChange,
				&CmPriv->Lock, &KernTimeout);
    }

    switch(Conn->State) {
    case VIPK_CM_CONN_STATE_CONNECTED:
	TRACE(VIPK_TRACE_CM, "[%d] 0x%x received connect message from: 0x%x",
	      current->pid, LocalViHandle, Conn->RemoteViHandle);

	VipkCmFinalize(Conn, Vi);

	Status = CmPriv->CChan->GetPacket(CmPriv->CChan, &Pkt);
	if(Status != VIP_SUCCESS) {
	    goto cm_accept_out;
	}

	Pkt->Op = VIPK_CCHAN_OP_CONNSCMP;

	VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->SrcAddr,
		    (VIP_NET_ADDRESS *) &Conn->LocalAddr);
	VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->DstAddr,
		    (VIP_NET_ADDRESS *) &Conn->RemoteAddr);
	Pkt->DstConnHandle = Conn->RemoteConnHandle;
	Pkt->Session = Conn->Session;

	spin_unlock_irqrestore(&CmPriv->Lock, Flags);
	TRACE(VIPK_TRACE_CM,
	      "[%d] Sending completion message to client", current->pid);
	Status = CmPriv->CChan->SendControl(CmPriv->CChan, VIP_TRUE, Pkt);
	spin_lock_irqsave(&CmPriv->Lock, Flags);

	if(Status != VIP_SUCCESS) {
	    /* XXX: assert that it is not reachable */
	    if(Vi->ViAttribs.ReliabilityLevel > VIP_SERVICE_UNRELIABLE) {
		spin_lock(&Vi->Lock);
		Vi->State = VIP_STATE_ERROR;
		spin_unlock(&Vi->Lock);
		VipkCmFreeConn(CmPriv, Conn);
	    }
	    goto cm_accept_out;
	}

	TRACE(VIPK_TRACE_CM,
	      "[%d] 0x%x connected to RemoteViHandle: 0x%x",
	      current->pid, LocalViHandle, Conn->RemoteViHandle);

	Status = VIP_SUCCESS;
	break;

    case VIPK_CM_CONN_STATE_SERVER_ACCEPTED:
    case VIPK_CM_CONN_STATE_TIMEOUT:
	TRACE(VIPK_TRACE_CM, "[%d] Timeout", current->pid);
	spin_lock(&Vi->Lock);
	Vi->State = VIP_STATE_IDLE;
	spin_unlock(&Vi->Lock);
	Status = VIP_TIMEOUT;
	break;

    default:
	TRACE(VIPK_TRACE_CM, "[%d] Invalid state", current->pid);
	spin_lock(&Vi->Lock);
	Vi->State = VIP_STATE_IDLE;
	spin_unlock(&Vi->Lock);
	break;
    }

    VipkCmFreeConn(CmPriv, Conn);

cm_accept_out:
    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    return Status;
}

VIP_RETURN
VipkCmReject(VIPK_CM		*Cm,
	     VIPK_CONN_HANDLE	ConnHandle,
	     VIPK_NIC_INSTANCE	NicInstance)
{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN	*Conn;
    VIPK_CCHAN_PACKET	*Pkt;
    VIP_RETURN		Status;

    unsigned long	Flags;

    CmPriv = (VIPK_CM_PRIV *) Cm->Private;
    spin_lock_irqsave(&CmPriv->Lock, Flags);

    if(VipkCmLookup(CmPriv, ConnHandle, &Conn) != VIP_SUCCESS) {
	TRACE(VIPK_TRACE_CM, "[%d] Invalid ConnHandle", current->pid);
	Status = VIP_INVALID_PARAMETER;
	goto cm_reject_out;
    }

    if(Conn->NicInstance != NicInstance) {
	TRACE(VIPK_TRACE_CM,
	      "[%d] ConnHandle not owned by this Nic", current->pid);
	Status = VIP_INVALID_PARAMETER;
	goto cm_reject_out;
    }

    if(Conn->State != VIPK_CM_CONN_STATE_SERVER_MATCH) {
	TRACE(VIPK_TRACE_CM, "[%d] ConnHandle not matched", current->pid);
	Status = VIP_INVALID_PARAMETER;
	goto cm_reject_out;
    }

    Status = CmPriv->CChan->GetPacket(CmPriv->CChan, &Pkt);
    if(Status != VIP_SUCCESS) {
	/* XXX: spec unclear what to do if error resource, is the
	 * conn handle still valid?
	 */
	VipkCmFreeConn(CmPriv, Conn);
	goto cm_reject_out;
    }

    Pkt->Op = VIPK_CCHAN_OP_CONNREJ;

    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->SrcAddr,
		(VIP_NET_ADDRESS *) &Conn->LocalAddr);
    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->DstAddr,
		(VIP_NET_ADDRESS *) &Conn->RemoteAddr);
    Pkt->DstConnHandle = Conn->RemoteConnHandle;
    Pkt->Session = Conn->Session;

    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    Status = CmPriv->CChan->SendControl(CmPriv->CChan, VIP_TRUE, Pkt);
    spin_lock_irqsave(&CmPriv->Lock, Flags);

    VipkCmFreeConn(CmPriv, Conn);

cm_reject_out:
    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    return Status;
}

VIP_RETURN
VipkCmRequest(VIPK_CM		*Cm,
	      VIPK_NIC_INSTANCE	NicInstance,
	      VIPK_VI_HANDLE	LocalViHandle,
	      VIPK_VI		*Vi,
	      VIP_NET_ADDRESS	*LocalAddr,
	      VIP_NET_ADDRESS	*RemoteAddr,
	      VIP_ULONG		Timeout)
{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN_HANDLE	ConnHandle;
    VIPK_CM_CONN	*Conn;
    VIPK_CCHAN_PACKET	*Pkt;
    VIP_RETURN		Status;

    unsigned long	Flags;
    unsigned long	KernTimeout;

    CmPriv = (VIPK_CM_PRIV *) Cm->Private;

    spin_lock_irqsave(&Vi->Lock, Flags);
    if(Vi->State != VIP_STATE_IDLE) {
	TRACE(VIPK_TRACE_CM, "[%d] Bad VI state", current->pid);
	spin_unlock_irqrestore(&Vi->Lock, Flags);
	return VIP_INVALID_PARAMETER;
    }
    Vi->State = VIP_STATE_CONNECT_PENDING;
    spin_unlock_irqrestore(&Vi->Lock, Flags);

    spin_lock_irqsave(&CmPriv->Lock, Flags);

    KernTimeout = VipkLinuxTimeout(Timeout);

    Status = VipkCmFindFree(CmPriv, &ConnHandle);
    if(Status != VIP_SUCCESS) {
	TRACE(VIPK_TRACE_CM,
	      "[%d] Could not find free queue entry", current->pid);
	spin_lock(&Vi->Lock);
	Vi->State = VIP_STATE_IDLE;
	spin_unlock(&Vi->Lock);
	spin_unlock_irqrestore(&CmPriv->Lock, Flags);
	return Status;
    }

    TRACE(VIPK_TRACE_CM,
	  "[%d] Found empty conn handle: 0x%x", current->pid, ConnHandle);

    VipkCmLookup(CmPriv, ConnHandle, &Conn);

    Conn->State = VIPK_CM_CONN_STATE_CLIENT_WAIT;
    Conn->NicInstance = NicInstance;
    VipAddrCopy((VIP_NET_ADDRESS *) &Conn->LocalAddr, LocalAddr);
    VipAddrCopy((VIP_NET_ADDRESS *) &Conn->RemoteAddr, RemoteAddr);
    Conn->Session = CmPriv->NextSession++;

    Status = CmPriv->CChan->GetPacket(CmPriv->CChan, &Pkt);
    if(Status != VIP_SUCCESS) {
	/* XXX: spec unclear what to do if error resource, is the
	 * conn handle still valid?
	 */
	spin_lock(&Vi->Lock);
	Vi->State = VIP_STATE_IDLE;
	spin_unlock(&Vi->Lock);
	VipkCmFreeConn(CmPriv, Conn);
	goto cm_request_out;
    }

    Pkt->Op = VIPK_CCHAN_OP_CONNREQ;

    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->SrcAddr, LocalAddr);
    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->DstAddr, RemoteAddr);
    Pkt->ViHandle = LocalViHandle;
    VipkEncodeAttribs(Pkt, &Vi->ViAttribs);
    Pkt->Sequence = Vi->RecvSeq;
    Pkt->SrcConnHandle = ConnHandle;
    Pkt->Session = Conn->Session;

    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    TRACE(VIPK_TRACE_CM, "[%d] Sending request message", current->pid);
    Status = CmPriv->CChan->SendControl(CmPriv->CChan, VIP_TRUE, Pkt);
    spin_lock_irqsave(&CmPriv->Lock, Flags);
    if(Status != VIP_SUCCESS) {
	/* XXX: assert not reachable */
	if(Vi->ViAttribs.ReliabilityLevel > VIP_SERVICE_UNRELIABLE) {
	    VipkCmFreeConn(CmPriv, Conn);
	    spin_lock(&Vi->Lock);
	    Vi->State = VIP_STATE_IDLE;
	    spin_unlock(&Vi->Lock);
	}
	goto cm_request_out;
    }

    TRACE(VIPK_TRACE_CM, "[%d] Waiting for server response", current->pid);

    while(Conn->State == VIPK_CM_CONN_STATE_CLIENT_WAIT &&
	  KernTimeout && !signal_pending(current)) {
	cond_wait_interruptible(&Conn->StateChange,
				&CmPriv->Lock, &KernTimeout);
    }

    switch(Conn->State) {
    case VIPK_CM_CONN_STATE_CLIENT_ACCEPTED:
	TRACE(VIPK_TRACE_CM, "[%d] Finalizing connection", current->pid);

	VipkCmFinalize(Conn, Vi);

	spin_unlock_irqrestore(&CmPriv->Lock, Flags);
	Status = VipkCmConnectClient(CmPriv, Conn);
	spin_lock_irqsave(&CmPriv->Lock, Flags);

	if(Status == VIP_SUCCESS) {
	    TRACE(VIPK_TRACE_CM,
		  "[%d] 0x%x connected to RemoteViHandle: 0x%x",
		  current->pid, LocalViHandle, Conn->RemoteViHandle);
	} else {
	    spin_lock(&Vi->Lock);
	    Vi->State = VIP_STATE_ERROR;
	    spin_unlock(&Vi->Lock);
	}

	break;

    case VIPK_CM_CONN_STATE_CLIENT_WAIT:
	spin_lock(&Vi->Lock);
	Vi->State = VIP_STATE_IDLE;
	spin_unlock(&Vi->Lock);
	Status = VIP_TIMEOUT;
	break;

    case VIPK_CM_CONN_STATE_CLIENT_REJECT:
	spin_lock(&Vi->Lock);
	Vi->State = VIP_STATE_IDLE;
	spin_unlock(&Vi->Lock);
	Status = VIP_REJECT;
	break;

    case VIPK_CM_CONN_STATE_CLIENT_NO_MATCH:
	spin_lock(&Vi->Lock);
	Vi->State = VIP_STATE_IDLE;
	spin_unlock(&Vi->Lock);
	Status = VIP_NO_MATCH;
	break;

    default:
	spin_lock(&Vi->Lock);
	Vi->State = VIP_STATE_IDLE;
	spin_unlock(&Vi->Lock);
	TRACE(VIPK_TRACE_CM, "[%d] logic error", current->pid);
	Status = VIP_TIMEOUT;
    }

    VipkCmFreeConn(CmPriv, Conn);

 cm_request_out:
    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    return Status;
}

VIP_RETURN
VipkCmPeerRequest(VIPK_CM		*Cm,
		  VIPK_NIC_INSTANCE	NicInstance,
		  VIPK_VI_HANDLE	LocalViHandle,
		  VIPK_VI		*Vi,
		  VIP_NET_ADDRESS	*LocalAddr,
		  VIP_NET_ADDRESS	*RemoteAddr,
		  VIP_ULONG		Timeout)
{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN	*Conn;
    VIPK_CONN_HANDLE	ConnH;
    VIP_RETURN		Status;
    VIPK_CCHAN_PACKET	*Pkt;

    unsigned long	Flags;

    CmPriv = (VIPK_CM_PRIV *) Cm->Private;

    spin_lock_irqsave(&Vi->Lock, Flags);
    if(Vi->State != VIP_STATE_IDLE) {
	TRACE(VIPK_TRACE_CM,
	      "[%d] ViState != IDLE", current->pid);
	spin_unlock_irqrestore(&Vi->Lock, Flags);
	return VIP_INVALID_STATE;
    }
    Vi->State = VIP_STATE_CONNECT_PENDING;
    spin_unlock_irqrestore(&Vi->Lock, Flags);

    spin_lock_irqsave(&CmPriv->Lock, Flags);
    Status = VipkCmFindFree(CmPriv, &ConnH);
    if(Status != VIP_SUCCESS) {
	TRACE(VIPK_TRACE_CM,
	      "[%d] Could not find free conn handle", current->pid);
	spin_unlock_irqrestore(&CmPriv->Lock, Flags);
	return Status;
    }

    TRACE(VIPK_TRACE_CM,
	  "[%d] Found empty conn handle: 0x%x", current->pid, ConnH);

    VipkCmLookup(CmPriv, ConnH, &Conn);
    Vi->CmPrivate = Conn;
    Conn->State = VIPK_CM_CONN_STATE_PEER_WAIT;
    Conn->NicInstance = NicInstance;
    VipAddrCopy((VIP_NET_ADDRESS *) &Conn->LocalAddr, LocalAddr);
    VipAddrCopy((VIP_NET_ADDRESS *) &Conn->RemoteAddr, RemoteAddr);
    Conn->MySession = Conn->Session = CmPriv->NextSession++;
    Conn->LocalViHandle = LocalViHandle;
    Conn->LocalVi = Vi;

    if (Timeout == VIP_INFINITE) {
	Conn->Expires = VIP_FALSE;
    } else {
	Conn->Expires = VIP_TRUE;
	Conn->TimeOut = jiffies + VipkLinuxTimeout(Timeout);
    }

    Status = CmPriv->CChan->GetPacket(CmPriv->CChan, &Pkt);
    if(Status != VIP_SUCCESS) {
	/* XXX: Is this right? */
	VipkCmFreeConn(CmPriv, Conn);
	spin_lock(&Vi->Lock);
	Vi->State = VIP_STATE_IDLE;
	spin_unlock(&Vi->Lock);
	goto cm_peerreq_out;
    }

    Pkt->Op = VIPK_CCHAN_OP_PEERREQ;
    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->SrcAddr, LocalAddr);
    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->DstAddr, RemoteAddr);

    Pkt->ViHandle = LocalViHandle;
    Pkt->SrcConnHandle = ConnH;
    VipkEncodeAttribs(Pkt, &Vi->ViAttribs);
    Pkt->Sequence = Vi->RecvSeq;
    Pkt->Session = Conn->Session;

    list_add(&Conn->List, &CmPriv->PPWaiting);

    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    Status = CmPriv->CChan->SendControl(CmPriv->CChan, VIP_FALSE, Pkt);
    spin_lock_irqsave(&CmPriv->Lock, Flags);

    if(Status != VIP_SUCCESS) {
	/* XXX: assert that it is not reachable */
	if(Vi->ViAttribs.ReliabilityLevel > VIP_SERVICE_UNRELIABLE) {
	    spin_lock(&Vi->Lock);
	    Vi->State = VIP_STATE_ERROR;
	    spin_unlock(&Vi->Lock);
	}
	VipkCmFreeConn(CmPriv, Conn);
	goto cm_peerreq_out;
    }

  cm_peerreq_out:
    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    return Status;
}

static VIP_RETURN
VipkCmPeerDone(VIPK_CM			*Cm,
	       VIPK_NIC_INSTANCE	NicInstance,
	       VIPK_VI			*Vi,
	       VIP_BOOLEAN		Block)
{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN	*Conn;
    VIPK_CCHAN_PACKET	*Pkt;
    VIP_RETURN		Status;
    VIPK_CM_CONN_STATE	State;

    unsigned long	Flags;
    unsigned long	KernTimeout;

    spin_lock_irqsave(&Vi->Lock, Flags);
    if(Vi->State != VIP_STATE_CONNECT_PENDING) {
	TRACE(VIPK_TRACE_CM, "[%d] ViState != CONNECT_PENDING", current->pid);
	spin_unlock_irqrestore(&Vi->Lock, Flags);
	return VIP_INVALID_STATE;
    }
    Conn = Vi->CmPrivate;
    spin_unlock_irqrestore(&Vi->Lock, Flags);

    CmPriv = (VIPK_CM_PRIV *) Cm->Private;

    spin_lock_irqsave(&CmPriv->Lock, Flags);

    if(!Conn || Conn->LocalVi != Vi) {
	spin_unlock_irqrestore(&CmPriv->Lock, Flags);
	return VIP_INVALID_PARAMETER;
    }

    Status = VIP_SUCCESS;
    while(Conn->State != VIPK_CM_CONN_STATE_CONNECTED) {
	switch(Conn->State) {
	case VIPK_CM_CONN_STATE_TIMEOUT:
	    Status = VIP_TIMEOUT;
	    goto cm_peer_done_out;

	case VIPK_CM_CONN_STATE_PEER_WAIT:
	    /* Check for timeout: */
	    if(Conn->Expires && time_after_eq(jiffies, Conn->TimeOut)) {
		Status = VIP_TIMEOUT;
		goto cm_peer_done_out;
	    } else if(!Block) {
		Status = VIP_NOT_DONE;
		goto cm_peer_done_out;
	    }
	    TRACE(VIPK_TRACE_CM, "[%d] Waiting on peer-to-peer completion",
		  current->pid);
	    break;

	case VIPK_CM_CONN_STATE_PEER_IS_PEER2:
	    Status = VipkCmValidate(Conn, Vi);
	    if(Status != VIP_SUCCESS) {
		goto cm_peer_done_out;
	    } else if(!Block) {
		Status = VIP_NOT_DONE;
		goto cm_peer_done_out;
	    }
	    /* 4/6/2004: Jie Chen. When second phase message
	     * never make to here due to node crash or process exiting,
	     * This kernel code will loop forever resulting hanging node
	     */
	    if(Conn->Expires && time_after_eq(jiffies, Conn->TimeOut)) {
	        TRACE(VIPK_TRACE_CM, "[%d] Waiting on peer-to-peer completion timeout",
		      current->pid);
		Status = VIP_TIMEOUT;
		goto cm_peer_done_out;
	    }
	    TRACE(VIPK_TRACE_CM, "[%d] Waiting on peer-to-peer completion",
		  current->pid);
	    break;

	case VIPK_CM_CONN_STATE_PEER_IS_PEER1:
	    Status = VipkCmValidate(Conn, Vi);
	    if(Status != VIP_SUCCESS) {
		goto cm_peer_done_out;
	    }
	    VipkCmFinalize(Conn, Vi);

	    Status = CmPriv->CChan->GetPacket(CmPriv->CChan, &Pkt);
	    if(Status != VIP_SUCCESS) {
		/* XXX: what now? */
		goto cm_peer_done_out;
	    }

	    Pkt->Op = VIPK_CCHAN_OP_PEER1CMP;

	    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->SrcAddr,
			(VIP_NET_ADDRESS *) &Conn->LocalAddr);
	    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->DstAddr,
			(VIP_NET_ADDRESS *) &Conn->RemoteAddr);
	    Pkt->Session = Conn->Session;
	    Pkt->DstConnHandle = Conn->RemoteConnHandle;

	    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
	    Status = CmPriv->CChan->SendControl(CmPriv->CChan, VIP_FALSE, Pkt);
	    spin_lock_irqsave(&CmPriv->Lock, Flags);
	    if(Status != VIP_SUCCESS) {
		/* XXX: what now? */
	    }

	    Conn->State = VIPK_CM_CONN_STATE_PEER_PEER1CMP;
	    break;

	case VIPK_CM_CONN_STATE_PEER_PEER2CMP:
	    VipkCmFinalize(Conn, Vi);

	    Status = CmPriv->CChan->GetPacket(CmPriv->CChan, &Pkt);
	    if(Status != VIP_SUCCESS) {
		/* XXX: what now? */
		goto cm_peer_done_out;
	    }

	    Pkt->Op = VIPK_CCHAN_OP_PEER2CMP;

	    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->SrcAddr,
			(VIP_NET_ADDRESS *) &Conn->LocalAddr);
	    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->DstAddr,
			(VIP_NET_ADDRESS *) &Conn->RemoteAddr);
	    Pkt->Session = Conn->Session;
	    Pkt->DstConnHandle = Conn->RemoteConnHandle;

	    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
	    Status = CmPriv->CChan->SendControl(CmPriv->CChan, VIP_FALSE, Pkt);
	    spin_lock_irqsave(&CmPriv->Lock, Flags);
	    if(Status != VIP_SUCCESS) {
		/* XXX: what now? */
	    }

	    Conn->State = VIPK_CM_CONN_STATE_CONNECTED;
	    goto cm_peer_done_out;
	    break;

	case VIPK_CM_CONN_STATE_PEER_PEER1CMP:
	    /* False wakeup, just block again */
	    break;

	default:
	    /* XXX: LOGIC ERROR */
            break;
	}

	State = Conn->State;
	if(!Conn->Expires || State == VIPK_CM_CONN_STATE_PEER_PEER1CMP) {
	    /* Wait forever for signal or for state change */
	    while(Conn->State == State && !signal_pending(current)) {
		KernTimeout = MAX_SCHEDULE_TIMEOUT;
		cond_wait_interruptible(&Conn->StateChange,
					&CmPriv->Lock, &KernTimeout);
	    }
	} else if(time_before(jiffies, Conn->TimeOut)) {
	    /* Wait for signal, state change or timeout */
	    KernTimeout = Conn->TimeOut - jiffies;

	    while(Conn->State == State && KernTimeout &&
		  !signal_pending(current)) {
		cond_wait_interruptible(&Conn->StateChange,
					&CmPriv->Lock, &KernTimeout);
	    }
	} else {
	    /* We've already timed out! */
	}

	if(signal_pending(current)) {
	    Status = VIP_ERROR_RESOURCE;
	    break;
	}
    }

cm_peer_done_out:
    if(Status != VIP_NOT_DONE) {
	VipkCmFreeConn(CmPriv, Conn);
	if(Status != VIP_SUCCESS) {
	    spin_lock(&Vi->Lock);
	    Vi->State = VIP_STATE_IDLE;
	    spin_unlock(&Vi->Lock);
	}
    }

    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    return Status;
}

VIP_RETURN
VipkCmDisconnect(VIPK_CM		*Cm,
		 VIPK_NIC_INSTANCE	NicInstance,
		 VIPK_VI		*Vi)
{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN	*Conn;
    unsigned long	Flags;

    CmPriv = (VIPK_CM_PRIV *) Cm->Private;

    spin_lock_irqsave(&CmPriv->Lock, Flags);
    spin_lock(&Vi->Lock);

    Conn = Vi->CmPrivate;
    if(Vi->State == VIP_STATE_CONNECT_PENDING &&
       Conn && Conn->LocalVi == Vi &&
       Conn->State != VIPK_CM_CONN_STATE_FREE) {
	VipkCmFreeConn(CmPriv, Conn);
	Vi->CmPrivate = NULL;
    }

    spin_unlock(&Vi->Lock);
    spin_unlock_irqrestore(&CmPriv->Lock, Flags);

    return VIP_SUCCESS;
}


VIP_RETURN
VipkCmDestroyNic(VIPK_CM		*Cm,
		 VIPK_NIC_INSTANCE	NicInstance)
{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN	*Conn;

    int			i;
    unsigned long	Flags;

    CmPriv = (VIPK_CM_PRIV *) Cm->Private;

    spin_lock_irqsave(&CmPriv->Lock, Flags);

    for(i=0; i < CmPriv->NumEntries; i++) {
	Conn = &CmPriv->Conn[i];

	if(Conn->NicInstance == NicInstance &&
	   Conn->State != VIPK_CM_CONN_STATE_FREE) {

	    CmPriv->Conn[i].State = VIPK_CM_CONN_STATE_FREE;
	    cond_signal(&Conn->StateChange);
	}
    }

    spin_unlock_irqrestore(&CmPriv->Lock, Flags);

    return VIP_SUCCESS;
}

void
VipkCmRecvControl(VIPK_CM		*Cm,
		  VIPK_CCHAN_PACKET	*Pkt)
{
    VIP_VI_ATTRIBUTES	ViAttribs;

    TRACE(VIPK_TRACE_CM, "PSN: %d Op: %d", Pkt->PSN, Pkt->Op);

    switch(Pkt->Op) {
    case VIPK_CCHAN_OP_CONNREQ:
	/* server recvd request message */
	VipkDecodeAttribs(&ViAttribs, Pkt);
	VipkCmRecvCONNREQ(Cm,
			  (VIP_NET_ADDRESS *)&Pkt->DstAddr,
			  (VIP_NET_ADDRESS *)&Pkt->SrcAddr,
			  Pkt->ViHandle,
			  &ViAttribs,
			  Pkt->Sequence,
			  Pkt->SrcConnHandle,
			  Pkt->Session);
	break;

    case VIPK_CCHAN_OP_CONNCCMP:
	/* server recvd finalize message */
	VipkCmRecvCONNCCMP(Cm, Pkt->DstConnHandle, Pkt->Session);
	break;

    case VIPK_CCHAN_OP_CONNACC:
	/* client recvd accept message */
	VipkDecodeAttribs(&ViAttribs, Pkt);
	VipkCmRecvCONNACC(Cm,
			  Pkt->DstConnHandle,
			  Pkt->Session,
			  (VIP_NET_ADDRESS *)&Pkt->DstAddr,
			  (VIP_NET_ADDRESS *)&Pkt->SrcAddr,
			  Pkt->ViHandle,
			  &ViAttribs,
			  Pkt->Sequence,
			  Pkt->SrcConnHandle);
	break;

    case VIPK_CCHAN_OP_CONNTO:
	/* server recvd timeout message */
	VipkCmRecvCONNTO(Cm, Pkt->DstConnHandle, Pkt->Session);
	break;

    case VIPK_CCHAN_OP_CONNREJ:
	/* client recvd reject message */
	VipkCmRecvCONNREJ(Cm, Pkt->DstConnHandle, Pkt->Session);
	break;

    case VIPK_CCHAN_OP_CONNSCMP:
	/* client recvd finalize message */
	VipkCmRecvCONNSCMP(Cm, Pkt->DstConnHandle, Pkt->Session);
	break;

    case VIPK_CCHAN_OP_CONNNOM:
	/* client recvd no match message */
	VipkCmRecvCONNNOM(Cm, Pkt->DstConnHandle, Pkt->Session);
	break;

    case VIPK_CCHAN_OP_PEERREQ:
	/* peer recvd request message */
	VipkDecodeAttribs(&ViAttribs, Pkt);
	VipkCmRecvPEERREQ(Cm,
			  (VIP_NET_ADDRESS *)&Pkt->DstAddr,
			  (VIP_NET_ADDRESS *)&Pkt->SrcAddr,
			  Pkt->ViHandle,
			  &ViAttribs,
			  Pkt->Sequence,
			  Pkt->SrcConnHandle,
			  Pkt->Session);
	break;

    case VIPK_CCHAN_OP_PEERACC:
	/* peer recvd accept message */
	VipkDecodeAttribs(&ViAttribs, Pkt);
	VipkCmRecvPEERACC(Cm,
			  Pkt->DstConnHandle,
			  Pkt->Session,
			  (VIP_NET_ADDRESS *)&Pkt->DstAddr,
			  (VIP_NET_ADDRESS *)&Pkt->SrcAddr,
			  Pkt->ViHandle,
			  &ViAttribs,
			  Pkt->Sequence,
			  Pkt->SrcConnHandle);
	break;

    case VIPK_CCHAN_OP_PEERTO:
	/* peer recvd timeout message */
	VipkCmRecvPEERTO(Cm, Pkt->DstConnHandle, Pkt->Session);
	break;

    case VIPK_CCHAN_OP_PEER1CMP:
	/* peer #2 recvd finalize message */
	VipkCmRecvPEER1CMP(Cm, Pkt->DstConnHandle, Pkt->Session);
	break;

    case VIPK_CCHAN_OP_PEER2CMP:
	/* peer #1 recvd finalize message */
	VipkCmRecvPEER2CMP(Cm, Pkt->DstConnHandle, Pkt->Session);
	break;

    default:
	/* XXX: error */
	break;
    }
}

static VIP_RETURN
VipkCmRecvCONNREQ(VIPK_CM		*Cm,
		    VIP_NET_ADDRESS	*LocalAddr,
		    VIP_NET_ADDRESS	*RemoteAddr,
		    VIPK_VI_HANDLE	RemoteViHandle,
		    VIP_VI_ATTRIBUTES	*RemoteViAttribs,
		    VIP_UINT32		RemoteSequence,
		    VIPK_CONN_HANDLE	RemoteConnHandle,
		    VIP_UINT32		Session)
{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN	*Conn;
    VIPK_CCHAN_PACKET	*Pkt;
    VIP_RETURN		Status;
    struct list_head	*Head;
    struct list_head	*Entry;

    unsigned long	Flags;

    CmPriv = (VIPK_CM_PRIV *) Cm->Private;

    TRACE(VIPK_TRACE_CM, "SrcConnHandle: %d", RemoteConnHandle);

    spin_lock_irqsave(&CmPriv->Lock, Flags);

    /* First scan Pending list to identify duplicate packets. */
    Head = &CmPriv->CSPending;
    for(Entry = Head->next; Entry != Head; Entry = Entry->next) {
	Conn = list_entry(Entry, VIPK_CM_CONN, List);

	if(Conn->Session == Session &&
	   VipAddrHostEq(RemoteAddr, (VIP_NET_ADDRESS *)(&Conn->RemoteAddr)) &&
	   VipAddrDiscrimEq(LocalAddr,
			    (VIP_NET_ADDRESS *)(&Conn->LocalAddr))) {
	    /* Duplicate request was received */
	    TRACE(VIPK_TRACE_CM, "duplicate msg ignored");
	    Status = VIP_SUCCESS;
	    goto cm_request_server_out;
	}
    }

    /* Now scan the Waiting list for a valid match. */
    Head = &CmPriv->CSWaiting;
    for(Entry = Head->next; Entry != Head; Entry = Entry->next) {
	Conn = list_entry(Entry, VIPK_CM_CONN, List);

	if(VipAddrDiscrimEq(LocalAddr,
			    (VIP_NET_ADDRESS *)(&Conn->LocalAddr))) {
	    TRACE(VIPK_TRACE_CM, "Server matched");
	    Conn->RemoteViHandle = RemoteViHandle;
	    Conn->RemoteViAttribs = *RemoteViAttribs;
	    Conn->RemoteSequence = RemoteSequence;
	    VipAddrCopy((VIP_NET_ADDRESS *)&Conn->RemoteAddr, RemoteAddr);
	    Conn->RemoteConnHandle = RemoteConnHandle;
	    Conn->Session = Session;

	    list_del(Entry);
	    list_add(Entry, &CmPriv->CSPending);
	    Conn->State = VIPK_CM_CONN_STATE_SERVER_MATCH;
	    cond_signal(&Conn->StateChange);
	    Status = VIP_SUCCESS;
	    goto cm_request_server_out;
	}
    }

    TRACE(VIPK_TRACE_CM, "Sending NoMatch to client");

    Status = CmPriv->CChan->GetPacket(CmPriv->CChan, &Pkt);
    if(Status != VIP_SUCCESS) {
	goto cm_request_server_out;
    }

    Pkt->Op = VIPK_CCHAN_OP_CONNNOM;

    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->SrcAddr, LocalAddr);
    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->DstAddr, RemoteAddr);
    Pkt->DstConnHandle = RemoteConnHandle;
    Pkt->Session = Session;

    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    return CmPriv->CChan->SendControl(CmPriv->CChan, VIP_FALSE, Pkt);

 cm_request_server_out:
    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    return Status;
}

/**
 * Receive connect reject request from a server node.
 *
 * @param DevicePtr Pointer to device structure.
 * @param ViHandle ViHandle that had its connection request rejected.
 * @return \c VIP_SUCCESS - This function should not fail.
 *
 * \bug There is the potential to receive stale rejection messages.  See
 * comment in code regarding the need to add session ids to connections.
 */
static VIP_RETURN
VipkCmRecvCONNREJ(VIPK_CM		*Cm,
		  VIPK_CONN_HANDLE	ConnHandle,
		  VIP_UINT32		Session)
{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN	*Conn;
    VIP_RETURN		Status;

    unsigned long	Flags;

    CmPriv = (VIPK_CM_PRIV *) Cm->Private;
    spin_lock_irqsave(&CmPriv->Lock, Flags);

    Status = VipkCmLookupSession(CmPriv, ConnHandle, &Conn, Session);
    if(Status == VIP_SUCCESS &&
       Conn->State == VIPK_CM_CONN_STATE_CLIENT_WAIT) {

	Conn->State = VIPK_CM_CONN_STATE_CLIENT_REJECT;
	cond_signal(&Conn->StateChange);

	TRACE(VIPK_TRACE_CM, "msg processed");
    } else {
	/* XXX: no remote send of error? */
	Status = VIP_INVALID_PARAMETER;
	TRACE(VIPK_TRACE_CM, "bad msg ignored");
    }

    spin_unlock_irqrestore(&CmPriv->Lock, Flags);

    return Status;
}

/**
 * Receive a ConnectAccept message from a server node.
 *
 * @param DevicePtr	Pointer to device structure.
 * @param ViHandle	ViHandle that had its connection request accepted.
 * @param RemoteViHandle Remote server Vi.
 * @param RemoteViAttribs Attributes of the server Vi.
 * @return	\c VIP_SUCCESS - The accept completed normally.<br>
 *		\c VIP_INVALID_PARAMETER - The VI handle was invalid.
 *
 * \bug There is the potential to receive stale accept messages.  See
 * comment in code regarding the need to add session ids to connections.
 */
static VIP_RETURN
VipkCmRecvCONNACC(VIPK_CM		*Cm,
		  VIPK_CONN_HANDLE	ConnHandle,
		  VIP_UINT32		Session,
		  VIP_NET_ADDRESS	*LocalAddr,
		  VIP_NET_ADDRESS	*RemoteAddr,
		  VIPK_VI_HANDLE	RemoteViHandle,
		  VIP_VI_ATTRIBUTES	*RemoteViAttribs,
		  VIP_UINT32		RemoteSequence,
		  VIPK_CONN_HANDLE	RemoteConnHandle)
{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN	*Conn;
    VIPK_CCHAN_PACKET	*Pkt;
    VIP_RETURN		Status;
    unsigned long	Flags;

    TRACE(VIPK_TRACE_CM, "ConnHandle: 0x%x", ConnHandle);

    CmPriv = (VIPK_CM_PRIV *) Cm->Private;
    spin_lock_irqsave(&CmPriv->Lock, Flags);

    Status = VipkCmLookupSession(CmPriv, ConnHandle, &Conn, Session);

    if(Status == VIP_SUCCESS) {
	if(Conn->State == VIPK_CM_CONN_STATE_CLIENT_WAIT) {
	    Conn->RemoteViHandle = RemoteViHandle;
	    Conn->RemoteViAttribs = *RemoteViAttribs;
	    Conn->RemoteSequence = RemoteSequence;
	    Conn->RemoteConnHandle = RemoteConnHandle;
	    Conn->State = VIPK_CM_CONN_STATE_CLIENT_ACCEPTED;
	    cond_signal(&Conn->StateChange);

	    TRACE(VIPK_TRACE_CM, "msg processed");
	} else if(Conn->State == VIPK_CM_CONN_STATE_CLIENT_ACCEPTED ||
		  Conn->State == VIPK_CM_CONN_STATE_CONNECTED) {
	    TRACE(VIPK_TRACE_CM, "duplicate msg ignored");
	} else {
	    TRACE(VIPK_TRACE_CM, "bad msg ignored");
	}
    } else {
	Status = CmPriv->CChan->GetPacket(CmPriv->CChan, &Pkt);
	if(Status == VIP_SUCCESS) {
	    Pkt->Op = VIPK_CCHAN_OP_CONNTO;

	    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->SrcAddr, LocalAddr);
	    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->DstAddr, RemoteAddr);
	    Pkt->Session = Session;
	    Pkt->DstConnHandle = RemoteConnHandle;

	    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
	    Status = CmPriv->CChan->SendControl(CmPriv->CChan, VIP_FALSE, Pkt);
	    spin_lock_irqsave(&CmPriv->Lock, Flags);
	    TRACE(VIPK_TRACE_CM, "Send TIMEOUT");
	} else {
	    TRACE(VIPK_TRACE_CM, "GetPacket failed.  Unable to send TIMEOUT");
	}
    }

    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    return Status;
}

/**
 * Complete connection establishment on server node.
 *
 * @param DevicePtr		Pointer to device structure.
 * @param ViHandle		Vi handle to finalize connection for.
 * @return	\c VIP_SUCCESS - Connection successfully completed.<br>
 *		\c VIP_INVALID_PARAMETER - The ViHandle was bad.
 */
static VIP_RETURN
VipkCmRecvCONNCCMP(VIPK_CM		*Cm,
		   VIPK_CONN_HANDLE	ConnHandle,
		   VIP_UINT32		Session)
{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN	*Conn;

    VIP_RETURN		Status;
    unsigned long	Flags;

    CmPriv = (VIPK_CM_PRIV *) Cm->Private;
    spin_lock_irqsave(&CmPriv->Lock, Flags);

    Status = VipkCmLookupSession(CmPriv, ConnHandle, &Conn, Session);
    if(Status == VIP_SUCCESS &&
       Conn->State == VIPK_CM_CONN_STATE_SERVER_ACCEPTED) {

	Conn->State = VIPK_CM_CONN_STATE_CONNECTED;
	cond_signal(&Conn->StateChange);

	TRACE(VIPK_TRACE_CM, "msg processed");
    } else {
	TRACE(VIPK_TRACE_CM, "bad msg ignored");
	/* XXX: send error back to client */
    }

    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    return Status;
}

static VIP_RETURN
VipkCmRecvCONNSCMP(VIPK_CM		*Cm,
		   VIPK_CONN_HANDLE	ConnHandle,
		   VIP_UINT32		Session)
{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN	*Conn;

    VIP_RETURN		Status;
    unsigned long	Flags;

    CmPriv = (VIPK_CM_PRIV *) Cm->Private;
    spin_lock_irqsave(&CmPriv->Lock, Flags);

    Status = VipkCmLookupSession(CmPriv, ConnHandle, &Conn, Session);
    if(Status == VIP_SUCCESS) {
	if(Conn->State == VIPK_CM_CONN_STATE_CLIENT_ACCEPTED) {

	    Conn->State = VIPK_CM_CONN_STATE_CONNECTED;
	    cond_signal(&Conn->StateChange);

	    TRACE(VIPK_TRACE_CM, "msg processed");
	} else {
	    TRACE(VIPK_TRACE_CM, "duplicate msg ignored");
	}
    } else {
	TRACE(VIPK_TRACE_CM, "bad msg ignored");
	/* XXX: send error back to server */
    }

    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    return Status;
}


/**
 * Receive a connection timeout message from a client node.
 *
 * A timeout message is receive after a server has tried to accept a connection
 * with a client that has already timedout.
 *
 * @param DevicePtr	Pointer to device structure.
 * @param ViHandle	Server Vi Handle that is receiving the remote timeout.
 * @return	\c VIP_SUCCESS - The accept completed normally.<br>
 *		\c VIP_INVALID_PARAMETER - The VI handle was invalid.
 */
static VIP_RETURN
VipkCmRecvCONNTO(VIPK_CM		*Cm,
		 VIPK_CONN_HANDLE	ConnHandle,
		 VIP_UINT32		Session)

{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN	*Conn;

    VIP_RETURN		Status;
    unsigned long	Flags;

    CmPriv = (VIPK_CM_PRIV *) Cm->Private;
    spin_lock_irqsave(&CmPriv->Lock, Flags);

    Status = VipkCmLookupSession(CmPriv, ConnHandle, &Conn, Session);
    if(Status == VIP_SUCCESS &&
       Conn->State == VIPK_CM_CONN_STATE_SERVER_ACCEPTED) {

	Conn->State = VIPK_CM_CONN_STATE_TIMEOUT;
	cond_signal(&Conn->StateChange);

	TRACE(VIPK_TRACE_CM, "msg processed");
    } else {
	TRACE(VIPK_TRACE_CM, "bad msg ignored");
	/* XXX: send error back to client */
    }

    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    return Status;
}


/**
 * Receive a VIP_NO_MATCH message on a client node.
 *
 * Occurs if a server is up but not waiting for a request with the
 * specified disriminator.
 *
 * @param DevicePtr	Pointer to device structure.
 * @param ViHandle	Server Vi Handle that is receiving the remote timeout.
 * @return	\c VIP_SUCCESS - The message was received successfully.<br>
 *		\c VIP_INVALID_PARAMETER - The VI handle was invalid.
 */
static VIP_RETURN
VipkCmRecvCONNNOM(VIPK_CM		*Cm,
		  VIPK_CONN_HANDLE	ConnHandle,
		  VIP_UINT32		Session)
{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN	*Conn;

    VIP_RETURN		Status;
    unsigned long	Flags;

    CmPriv = (VIPK_CM_PRIV *) Cm->Private;
    spin_lock_irqsave(&CmPriv->Lock, Flags);

    Status = VipkCmLookupSession(CmPriv, ConnHandle, &Conn, Session);
    if(Status == VIP_SUCCESS &&
       Conn->State == VIPK_CM_CONN_STATE_CLIENT_WAIT) {

	Conn->State = VIPK_CM_CONN_STATE_CLIENT_NO_MATCH;
	cond_signal(&Conn->StateChange);

	TRACE(VIPK_TRACE_CM, "msg processed");
    } else {
	TRACE(VIPK_TRACE_CM, "bad msg ignored");
    }

    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    return Status;
}

static VIP_RETURN
VipkCmRecvPEERREQ(VIPK_CM		*Cm,
		  VIP_NET_ADDRESS	*LocalAddr,
		  VIP_NET_ADDRESS	*RemoteAddr,
		  VIPK_VI_HANDLE	RemoteViHandle,
		  VIP_VI_ATTRIBUTES	*RemoteViAttribs,
		  VIP_UINT32		RemoteSequence,
		  VIPK_CONN_HANDLE	RemoteConnHandle,
		  VIP_UINT32		Session)
{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN	*Conn;
    VIPK_CCHAN_PACKET	*Pkt;
    VIPK_VI		*Vi;
    VIP_RETURN		Status;
    struct list_head	*Head;
    struct list_head	*Entry;
    struct list_head	*Next;

    unsigned long	Flags;

    Status = VIP_SUCCESS;	/* Success is most likely case. */
    CmPriv = (VIPK_CM_PRIV *) Cm->Private;

    TRACE(VIPK_TRACE_CM, "SrcConnHandle: %d", RemoteConnHandle);

    spin_lock_irqsave(&CmPriv->Lock, Flags);

    /* First scan Pending list to identify duplicate packets. */
    Head = &CmPriv->PPPending;
    for(Entry = Head->next; Entry != Head; Entry = Entry->next) {
	Conn = list_entry(Entry, VIPK_CM_CONN, List);

	if(Conn->Session == Session &&
	   VipAddrHostEq(RemoteAddr, (VIP_NET_ADDRESS *)(&Conn->RemoteAddr)) &&
	   VipAddrDiscrimEq(LocalAddr,
			    (VIP_NET_ADDRESS *)(&Conn->RemoteAddr))) {
	    /* Duplicate request was received */
	    TRACE(VIPK_TRACE_CM, "duplicate msg ignored");
	    goto cm_peerreq_out;
	}
    }

    /* Now scan the Waiting list for a valid match. */
    Head = &CmPriv->PPWaiting;
    for(Entry = Head->next; Entry != Head; Entry = Next) {
	Conn = list_entry(Entry, VIPK_CM_CONN, List);
	Next = Entry->next;

	if(Conn->Expires && time_after_eq(jiffies, Conn->TimeOut)) {
	    /* This request has timedout, so don't match against it.
	     * Remove it from the waiting list so we don't keep checking it.
	     * The timeout will be reported later by PeerDone.
	     */
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0))
	    list_del_init(Entry);
#else
	    list_del(Entry);
	    INIT_LIST_HEAD(Entry);
#endif
	    Conn->State = VIPK_CM_CONN_STATE_TIMEOUT;
	    cond_signal(&Conn->StateChange);
	} else if(VipAddrHostEq(RemoteAddr,
				(VIP_NET_ADDRESS *)(&Conn->RemoteAddr)) &&
		  VipAddrDiscrimEq(LocalAddr,
				   (VIP_NET_ADDRESS *)(&Conn->RemoteAddr))) {

	    /* check for, and skip, self-match in loopback case */
	    if(VipAddrHostEq(RemoteAddr, LocalAddr) &&
	       Session == Conn->Session) {
		continue;
	    }

	    TRACE(VIPK_TRACE_CM, "Peer matched ConnHandle=%d",
		  (int)(Conn - CmPriv->Conn));

	    Conn->RemoteViHandle = RemoteViHandle;
	    Conn->RemoteViAttribs = *RemoteViAttribs;
	    Conn->RemoteSequence = RemoteSequence;
	    Conn->RemoteConnHandle = RemoteConnHandle;
	    Conn->Session = Session;

	    list_del(Entry);
	    list_add(Entry, &CmPriv->PPPending);
	    Conn->State = VIPK_CM_CONN_STATE_PEER_IS_PEER2;
	    cond_signal(&Conn->StateChange);

	    Vi = Conn->LocalVi;

	    Status = CmPriv->CChan->GetPacket(CmPriv->CChan, &Pkt);
	    if(Status != VIP_SUCCESS) {
		/* XXX: Is this right? */
		spin_lock(&Vi->Lock);
		Vi->State = VIP_STATE_IDLE;
		spin_unlock(&Vi->Lock);
		goto cm_peerreq_out;
	    }

	    Pkt->Op = VIPK_CCHAN_OP_PEERACC;

	    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->SrcAddr,
			(VIP_NET_ADDRESS *) &Conn->LocalAddr);
	    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->DstAddr,
			(VIP_NET_ADDRESS *) &Conn->RemoteAddr);
	    Pkt->SrcConnHandle = (Conn - CmPriv->Conn);
	    Pkt->DstConnHandle = Conn->RemoteConnHandle;
	    Pkt->ViHandle = Conn->LocalViHandle;
	    VipkEncodeAttribs(Pkt, &Vi->ViAttribs);
	    Pkt->Sequence = Vi->RecvSeq;
	    Pkt->Session = Conn->Session;

	    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
	    Status = CmPriv->CChan->SendControl(CmPriv->CChan, VIP_FALSE, Pkt);
	    spin_lock_irqsave(&CmPriv->Lock, Flags);

	    if(Status != VIP_SUCCESS) {
		/* XXX: is this right? */

		/* XXX: assert that it is not reachable */
		if(Vi->ViAttribs.ReliabilityLevel > VIP_SERVICE_UNRELIABLE) {
			spin_lock(&Vi->Lock);
			Vi->State = VIP_STATE_ERROR;
			spin_unlock(&Vi->Lock);
			VipkCmFreeConn(CmPriv, Conn);
		}
		goto cm_peerreq_out;
	    }
	goto cm_peerreq_out;
	}
    }

    TRACE(VIPK_TRACE_CM, "no match");
    goto cm_peerreq_out;

  cm_peerreq_out:
    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    return Status;
}

static VIP_RETURN
VipkCmRecvPEERACC(VIPK_CM		*Cm,
		  VIPK_CONN_HANDLE	ConnHandle,
		  VIP_UINT32		Session,
		  VIP_NET_ADDRESS	*LocalAddr,
		  VIP_NET_ADDRESS	*RemoteAddr,
		  VIPK_VI_HANDLE	RemoteViHandle,
		  VIP_VI_ATTRIBUTES	*RemoteViAttribs,
		  VIP_UINT32		RemoteSequence,
		  VIPK_CONN_HANDLE	RemoteConnHandle)
{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN	*Conn;
    VIPK_CCHAN_PACKET	*Pkt;
    VIP_RETURN		Status;
    unsigned long	Flags;

    TRACE(VIPK_TRACE_CM, "ConnHandle: 0x%x", ConnHandle);

    CmPriv = (VIPK_CM_PRIV *) Cm->Private;
    spin_lock_irqsave(&CmPriv->Lock, Flags);

    Status = VipkCmLookup(CmPriv, ConnHandle, &Conn);

    if(Status == VIP_SUCCESS) {
	/* Two cases:
	 * 1. A match in PEER_WAIT state ("normal case").
	 * 2. A match in PEER_IS_PEER2.  Compare sessions to resolve race.
	 */
	if(/* CASE 1: */
	   (Session == Conn->Session &&
	    Conn->State == VIPK_CM_CONN_STATE_PEER_WAIT) ||
	   /* CASE 2: */
	   (Session == Conn->MySession &&
	    Conn->State == VIPK_CM_CONN_STATE_PEER_IS_PEER2 &&
	    /* This is how we resolve the race: */
	    ((Session < Conn->Session) ||
	     ((Session == Conn->Session) &&
	      memcmp(LocalAddr->HostAddress, RemoteAddr->HostAddress,
		     LocalAddr->HostAddressLen) < 0)))) {

	    /* needed for case 1: */
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0))
	    list_del_init(&Conn->List);
#else
	    list_del(&Conn->List);
	    INIT_LIST_HEAD(&Conn->List);
#endif

	    /* XXX: Do we really want to check for timeout here?
	     * If we recv a ACC then the REQ was sent just 1 rtt ago.
	     */
	    if(Conn->Expires && time_after_eq(jiffies, Conn->TimeOut)) {
		Conn->State = VIPK_CM_CONN_STATE_TIMEOUT;

		Status = CmPriv->CChan->GetPacket(CmPriv->CChan, &Pkt);
		if(Status == VIP_SUCCESS) {
		    Pkt->Op = VIPK_CCHAN_OP_PEERTO;
		    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->SrcAddr, LocalAddr);
		    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->DstAddr, RemoteAddr);
		    Pkt->Session = Session;
		    Pkt->DstConnHandle = RemoteConnHandle;
		    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
		    Status = CmPriv->CChan->SendControl(CmPriv->CChan,
							VIP_FALSE, Pkt);
		    spin_lock_irqsave(&CmPriv->Lock, Flags);
		    if(Status != VIP_SUCCESS) {
			/* XXX: what now? */
		    }
		} else {
		    /* XXX: what now? */
		}
		Status = VIP_TIMEOUT;
	    } else {
		Conn->Session = Session;	/* needed for case 2 */
		Conn->RemoteViHandle = RemoteViHandle;
		Conn->RemoteViAttribs = *RemoteViAttribs;
		Conn->RemoteSequence = RemoteSequence;
		Conn->RemoteConnHandle = RemoteConnHandle;
		list_add(&Conn->List, &CmPriv->PPPending);
		Conn->State = VIPK_CM_CONN_STATE_PEER_IS_PEER1;
	    }
	    cond_signal(&Conn->StateChange);
	} else {
	    /* XXX: are we certain this is not a timeout case?
	     * The fact that a PeerDone call can reap the connection
	     * at any time can cause some confusion here.
	     */
	    TRACE(VIPK_TRACE_CM, "duplicate msg ignored");
	}
    } else {
	/* XXX: what happened?  */
	TRACE(VIPK_TRACE_CM, "bad msg ignored");
    }

    spin_unlock_irqrestore(&CmPriv->Lock, Flags);

    return Status;
}

static VIP_RETURN
VipkCmRecvPEERTO(VIPK_CM		*Cm,
		 VIPK_CONN_HANDLE	ConnHandle,
		 VIP_UINT32		Session)
{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN	*Conn;
    VIPK_CCHAN_PACKET	*Pkt;
    VIPK_VI		*Vi;
    VIP_RETURN		Status;
    unsigned long	Flags;

    TRACE(VIPK_TRACE_CM, "ConnHandle: 0x%x", ConnHandle);

    CmPriv = (VIPK_CM_PRIV *) Cm->Private;
    spin_lock_irqsave(&CmPriv->Lock, Flags);

    Status = VipkCmLookupSession(CmPriv, ConnHandle, &Conn, Session);

    if(Status == VIP_SUCCESS &&
       Conn->State == VIPK_CM_CONN_STATE_PEER_IS_PEER2) {

	/* Our PEERACC was too late; the other end was gone.
	 * Revert to a waiting state. */
	Conn->State = VIPK_CM_CONN_STATE_PEER_WAIT;
	Conn->Session = Conn->MySession;

	Vi = Conn->LocalVi;

	Status = CmPriv->CChan->GetPacket(CmPriv->CChan, &Pkt);
	if(Status != VIP_SUCCESS) {
	    /* XXX: Is this right? */
	    VipkCmFreeConn(CmPriv, Conn);
	    spin_lock(&Vi->Lock);
	    Vi->State = VIP_STATE_IDLE;
	    spin_unlock(&Vi->Lock);
	    goto cm_recvpeerto_out;
	}

	Pkt->Op = VIPK_CCHAN_OP_PEERREQ;
	VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->SrcAddr,
		    (VIP_NET_ADDRESS *) &Conn->LocalAddr);
	VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->DstAddr,
		    (VIP_NET_ADDRESS *) &Conn->RemoteAddr);

	Pkt->ViHandle = Conn->LocalViHandle;
	Pkt->SrcConnHandle = (Conn - CmPriv->Conn);
	VipkEncodeAttribs(Pkt, &Vi->ViAttribs);
	Pkt->Session = Conn->Session;

	list_del(&Conn->List);
	list_add(&Conn->List, &CmPriv->PPWaiting);

	spin_unlock_irqrestore(&CmPriv->Lock, Flags);
	Status = CmPriv->CChan->SendControl(CmPriv->CChan, VIP_FALSE, Pkt);
	spin_lock_irqsave(&CmPriv->Lock, Flags);

	if(Status != VIP_SUCCESS) {
	    /* XXX: assert that it is not reachable */
	    if(Vi->ViAttribs.ReliabilityLevel > VIP_SERVICE_UNRELIABLE) {
		spin_lock(&Vi->Lock);
		Vi->State = VIP_STATE_ERROR;
		spin_unlock(&Vi->Lock);
	    }
	    VipkCmFreeConn(CmPriv, Conn);
	    goto cm_recvpeerto_out;
	}

	TRACE(VIPK_TRACE_CM, "msg processed");
    } else {
	TRACE(VIPK_TRACE_CM, "bad msg ignored");
    }

  cm_recvpeerto_out:
    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    return Status;
}

static VIP_RETURN
VipkCmRecvPEER1CMP(VIPK_CM		*Cm,
		   VIPK_CONN_HANDLE	ConnHandle,
		   VIP_UINT32		Session)
{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN	*Conn;
    VIP_RETURN		Status;
    unsigned long	Flags;

    TRACE(VIPK_TRACE_CM, "ConnHandle: 0x%x", ConnHandle);

    CmPriv = (VIPK_CM_PRIV *) Cm->Private;
    spin_lock_irqsave(&CmPriv->Lock, Flags);

    Status = VipkCmLookupSession(CmPriv, ConnHandle, &Conn, Session);

    if(Status == VIP_SUCCESS &&
       Conn->State == VIPK_CM_CONN_STATE_PEER_IS_PEER2) {

	Conn->State = VIPK_CM_CONN_STATE_PEER_PEER2CMP;
	cond_signal(&Conn->StateChange);

	TRACE(VIPK_TRACE_CM, "msg processed");
    } else {
	TRACE(VIPK_TRACE_CM, "bad msg ignored");
	/* XXX: what now? */
    }

    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    return Status;
}

static VIP_RETURN
VipkCmRecvPEER2CMP(VIPK_CM		*Cm,
		   VIPK_CONN_HANDLE	ConnHandle,
		   VIP_UINT32		Session)
{
    VIPK_CM_PRIV	*CmPriv;
    VIPK_CM_CONN	*Conn;
    VIP_RETURN		Status;
    unsigned long	Flags;

    TRACE(VIPK_TRACE_CM, "ConnHandle: 0x%x", ConnHandle);

    CmPriv = (VIPK_CM_PRIV *) Cm->Private;
    spin_lock_irqsave(&CmPriv->Lock, Flags);

    Status = VipkCmLookupSession(CmPriv, ConnHandle, &Conn, Session);

    if(Status == VIP_SUCCESS &&
       Conn->State == VIPK_CM_CONN_STATE_PEER_PEER1CMP) {

	Conn->State = VIPK_CM_CONN_STATE_CONNECTED;
	cond_signal(&Conn->StateChange);

	TRACE(VIPK_TRACE_CM, "msg processed");
    } else {
	TRACE(VIPK_TRACE_CM, "bad msg ignored");
	/* XXX: what now? */
    }

    spin_unlock_irqrestore(&CmPriv->Lock, Flags);
    return Status;
}

static VIP_RETURN
VipkCmConnectClient(VIPK_CM_PRIV	*CmPriv,
		    VIPK_CM_CONN	*Conn)
{
    VIPK_CCHAN_PACKET	*Pkt;
    VIP_RETURN		Status;
    unsigned long	Flags;
    unsigned long	KernTimeout;

    /* XXX: this should be a real timeout, but something > than the
     * retrans time on the packet ariving from the server.
     */
    KernTimeout = MAX_SCHEDULE_TIMEOUT;

    Status = CmPriv->CChan->GetPacket(CmPriv->CChan, &Pkt);
    if(Status != VIP_SUCCESS) {
	return Status;
    }

    Pkt->Op = VIPK_CCHAN_OP_CONNCCMP;

    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->SrcAddr,
		(VIP_NET_ADDRESS *) &Conn->LocalAddr);
    VipAddrCopy((VIP_NET_ADDRESS *) &Pkt->DstAddr,
		(VIP_NET_ADDRESS *) &Conn->RemoteAddr);
    Pkt->DstConnHandle = Conn->RemoteConnHandle;
    Pkt->Session = Conn->Session;

    TRACE(VIPK_TRACE_CM,
	  "[%d] Sending client completion to server", current->pid);
    Status = CmPriv->CChan->SendControl(CmPriv->CChan, VIP_FALSE, Pkt);
    if(Status != VIP_SUCCESS) {
	return Status;
    }

    spin_lock_irqsave(&CmPriv->Lock, Flags);
    TRACE(VIPK_TRACE_CM, "[%d] Waiting on server completion", current->pid);
    while(Conn->State == VIPK_CM_CONN_STATE_CLIENT_ACCEPTED &&
	  KernTimeout && !signal_pending(current)) {

	cond_wait_interruptible(&Conn->StateChange,
				&CmPriv->Lock, &KernTimeout);
    }
    spin_unlock_irqrestore(&CmPriv->Lock, Flags);

    switch(Conn->State) {
    case VIPK_CM_CONN_STATE_CONNECTED:
	Status = VIP_SUCCESS;
	break;

    case VIPK_CM_CONN_STATE_CLIENT_ACCEPTED:
	TRACE(VIPK_TRACE_CM, "[%d] Unexpected timeout", current->pid);
	Status = VIP_TIMEOUT;
	break;

    default:
	TRACE(VIPK_TRACE_CM, "[%d] Timeout", current->pid);
	Status = VIP_TIMEOUT;
	break;
    }

    return Status;
}

void
VipkCmFreeConn(VIPK_CM_PRIV	*CmPriv,
	       VIPK_CM_CONN	*Conn)
{
    unsigned long Flags;

    Conn->State = VIPK_CM_CONN_STATE_FREE;
    spin_lock_irqsave(&CmPriv->FreeLock, Flags);
    list_del(&Conn->List);
    Conn->List.next = CmPriv->FreeList;
    CmPriv->FreeList = &(Conn->List);
    spin_unlock_irqrestore(&CmPriv->FreeLock, Flags);
}

static VIP_RETURN
VipkCmFindFree(VIPK_CM_PRIV	*CmPriv,
	       VIPK_CONN_HANDLE	*ConnHandle)
{
    VIPK_CM_CONN	*Conn;
    VIP_RETURN		Status;
    unsigned long Flags;

    Status = VIP_ERROR_RESOURCE;

    spin_lock_irqsave(&CmPriv->FreeLock, Flags);
    Conn = list_entry(CmPriv->FreeList, VIPK_CM_CONN, List);
    if(Conn != NULL) {
	CmPriv->FreeList = Conn->List.next;
	INIT_LIST_HEAD(&Conn->List);
	*ConnHandle = (Conn - CmPriv->Conn);
	Status = VIP_SUCCESS;
    }
    spin_unlock_irqrestore(&CmPriv->FreeLock, Flags);

    return Status;
}

static VIP_RETURN
VipkCmLookup(VIPK_CM_PRIV	*CmPriv,
	     VIPK_CONN_HANDLE	ConnHandle,
	     VIPK_CM_CONN	**Conn)
{

    unsigned int ConnIndex = ConnHandle;

    TRACE(VIPK_TRACE_CM, "Looking up ConnHandle: 0x%x", ConnHandle);

    if(ConnIndex >= CmPriv->NumEntries) {
	TRACE(VIPK_TRACE_CM, "[%d] Invalid ConnHandle", current->pid);
	return VIP_INVALID_PARAMETER;
    }

    *Conn = &CmPriv->Conn[ConnIndex];
    return VIP_SUCCESS;
}

static VIP_RETURN
VipkCmLookupSession(VIPK_CM_PRIV	*CmPriv,
		    VIPK_CONN_HANDLE	ConnHandle,
		    VIPK_CM_CONN	**Conn,
		    VIP_UINT32		Session)
{
    VIP_RETURN	Status;

    Status = VipkCmLookup(CmPriv, ConnHandle, Conn);
    if(Status == VIP_SUCCESS && (*Conn)->Session != Session) {
	TRACE(VIPK_TRACE_CM, "Invalid Session");
	Status = VIP_INVALID_PARAMETER;
    } else if((*Conn)->State == VIPK_CM_CONN_STATE_FREE) {
	TRACE(VIPK_TRACE_CM, "Matched to a free handle");
	Status = VIP_INVALID_PARAMETER;
    }

    return Status;
}

/* Check mismatched ViAttribs: */
static VIP_RETURN
VipkCmValidate(VIPK_CM_CONN	*Conn,
	       VIPK_VI		*Vi)
{
    VIP_RETURN	Status;

    if(Vi->ViAttribs.MaxTransferSize !=
       Conn->RemoteViAttribs.MaxTransferSize) {
	TRACE(VIPK_TRACE_CM, "[%d] MTUs don't match", current->pid);
	Status = VIP_INVALID_MTU;
#if QOS_DEFINED_IN_SPEC
    } else if(Local QOS != Remote QOS) {
	TRACE(VIPK_TRACE_CM, "[%d] QOS don't match");
	Status = VIP_INVALID_QOS;
#endif
    } else if(Vi->ViAttribs.ReliabilityLevel !=
		  Conn->RemoteViAttribs.ReliabilityLevel) {
	TRACE(VIPK_TRACE_CM,
	      "[%d] Reliablity levels don't match", current->pid);
	Status = VIP_INVALID_RELIABILITY_LEVEL;
    } else {
	Status = VIP_SUCCESS;
    }

    return Status;
}

static VIP_RETURN
VipkCmFinalize(VIPK_CM_CONN	*Conn,
	       VIPK_VI		*Vi)
{
    spin_lock(&Vi->Lock);
    Vi->State = VIP_STATE_CONNECTED;
    Vi->RemoteViHandle = Conn->RemoteViHandle;
    Vi->RemoteViAttribs = Conn->RemoteViAttribs;
    Vi->Session = Conn->Session;
    Vi->SendSeq = Conn->RemoteSequence;
    Vi->RecvXferLen = 0;
    VipAddrCopy((VIP_NET_ADDRESS *) &Vi->RemoteAddr,
		(VIP_NET_ADDRESS *) &Conn->RemoteAddr);
    Vi->CmPrivate = NULL;
    spin_unlock(&Vi->Lock);

    if(Vi->DevicePtr->DeviceOps->Connected) {
	/* XXX: must check for error */
	Vi->DevicePtr->DeviceOps->Connected(Vi->DevicePtr, Vi);
    }

    return VIP_SUCCESS;
}
