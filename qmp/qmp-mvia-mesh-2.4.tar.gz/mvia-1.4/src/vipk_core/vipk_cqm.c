/* \file vipk_cqm.c
 * 
 * Implementation of a completion queue manager for the generalized 
 * VI Kernel Agent.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/slab.h>
#include <linux/vmalloc.h>

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
/**
 * The following two attributes are defined twice
 */
#ifdef __attribute_pure__
#undef __attribute_pure__
#endif
 
#ifdef __attribute_used__
#undef __attribute_used__
#endif

#endif

#include "vipk.h"
#include "vipk_rmm.h"
#include "vipk_cqm.h"
#include "vipk_trace.h"

VIP_RETURN
VipkCqmCreate(VIP_UINT32	NumQueues,
	      VIP_UINT32	MaxCQEntries,
	      VIPK_CQM_HANDLE	*CqmHandle)
{
    VIPK_CQM	*CqmPtr;
    VIP_UINT32	AllocSize;
    VIP_RETURN	Status;
    int		i;

    AllocSize = sizeof(VIPK_CQM) + (NumQueues - 1) * sizeof(VIPK_CQ);

    TRACE(VIPK_TRACE_CQM, "Initializing NumQueues: %d AllocSize: %d", 
	  NumQueues, AllocSize);

    CqmPtr = vmalloc(AllocSize);

    if(CqmPtr == NULL) {
	TRACE(VIPK_TRACE_CQM, "Failed to allocate Cq Manager");
	Status = VIP_ERROR_RESOURCE;
    } else {
	memset(CqmPtr, 0, AllocSize);
	CqmPtr->MaxCQEntries = MaxCQEntries;
	CqmPtr->NumQueues = NumQueues;
	spin_lock_init(&CqmPtr->Lock);

	for(i=0; i < NumQueues; i++) {
	    CqmPtr->Cq[i].Owner = VIPK_NO_OWNER;
	}
	
	Status = VIP_SUCCESS;
    }

    *CqmHandle = CqmPtr;
    return Status;
}

VIP_RETURN 
VipkCqmDestroy(VIPK_CQM_HANDLE CqmHandle)
{
    TRACE(VIPK_TRACE_CQM, "Destroying");
    vfree(CqmHandle);
    
    return VIP_SUCCESS;
}

VIP_RETURN
VipkCqmCreateCq(VIPK_CQM_HANDLE		CqmHandle,
		VIP_CQ_ENTRY		*UserEntry,
		VIP_ULONG		EntryCount,
		VIP_MEM_HANDLE		MemHandle,
		VIP_PROTECTION_HANDLE	Ptag,
		VIPK_CQ_HANDLE		*CqHandle,
		VIPK_NIC_INSTANCE	NicInstance,
		VIPK_OWNER		Owner)
{
    VIP_UINT32 	i;

    /* XXX: need to check to make sure that this is aligned on a
     * CQ_ENTRY size so we don't go over a page boundry
     */
    TRACE(VIPK_TRACE_CQM, 
	  "[%d] UserEntry: 0x%p EntryCount: %ld MemHandle 0x%08x Ptag 0x%p",
	  current->pid, (void *)UserEntry, EntryCount, MemHandle, Ptag);

    if(EntryCount == 0 || EntryCount > CqmHandle->MaxCQEntries) {
	TRACE(VIPK_TRACE_CQM, "[%d] Bad EntryCount: %ld > %d",
	      current->pid, EntryCount, CqmHandle->MaxCQEntries);
	/* XXX: SPEC, vipconf expects this, but it is not consistent
	 * with the rest of the spec, seems like it really should be
	 * VIP_INVALID_PARAMETER
	 */
	return VIP_ERROR_RESOURCE;
    }
    
    spin_lock(&CqmHandle->Lock);
    for(i = 0; i < CqmHandle->NumQueues; i++) {
	if(CqmHandle->Cq[i].Owner == VIPK_NO_OWNER) {
	    TRACE(VIPK_TRACE_CQM, "[%d] found free CQ Handle 0x%x",
		  current->pid, i);

	    /* Init just enough to establish ownership, then drop the lock */
	    CqmHandle->Cq[i].Owner = Owner;
	    CqmHandle->Cq[i].NicInstance = NicInstance;	    
	    spin_unlock(&CqmHandle->Lock);

	    CqmHandle->Cq[i].EntryCount = EntryCount;
	    CqmHandle->Cq[i].Tail = 0;
	    CqmHandle->Cq[i].Count = 0;
	    CqmHandle->Cq[i].UserEntry = UserEntry;
	    CqmHandle->Cq[i].MemHandle = MemHandle;
	    CqmHandle->Cq[i].Ptag = Ptag;

	    spin_lock_init(&CqmHandle->Cq[i].Lock);
	    cond_init(&CqmHandle->Cq[i].NonEmpty);
	    *CqHandle = i;

	    return VIP_SUCCESS;
	}
    }
    spin_unlock(&CqmHandle->Lock);

    TRACE(VIPK_TRACE_CQM, "[%d] could not find a free CQ Handle",
	  current->pid);

    return VIP_ERROR_RESOURCE;
}

VIP_RETURN
VipkCqmDestroyCq(VIPK_CQM_HANDLE	CqmHandle,
		 VIPK_CQ_HANDLE		CqHandle,
		 VIPK_NIC_INSTANCE	NicInstance,		 
		 VIPK_OWNER		Owner)
{
    VIPK_CQ 	*Cq;
    VIP_RETURN	Status;
 
    TRACE(VIPK_TRACE_CQM, "[%d] Cq Handle: 0x%x", current->pid, CqHandle);

    if((Status = VipkCqmGetCq(CqmHandle, CqHandle,
			      &Cq, NicInstance, Owner)) != VIP_SUCCESS) {
	TRACE(VIPK_TRACE_CQM, "[%d] invalid Cq Handle", current->pid);
	return Status;
    }

    if(Cq->UseCount) {
	TRACE(VIPK_TRACE_CQM, "[%d] CQ is in use UseCount: %d", 
	      current->pid, Cq->UseCount);
	return VIP_ERROR_RESOURCE;
    }

    spin_lock(&CqmHandle->Lock);
    Cq->NicInstance = 0;
    Cq->Owner = VIPK_NO_OWNER;
    Cq->UserEntry = NULL;
    spin_unlock(&CqmHandle->Lock);

    TRACE(VIPK_TRACE_CQM, "[%d] CQ destroyed", current->pid);
    return VIP_SUCCESS;
}

VIP_RETURN
VipkCqmDestroyCqNic(VIPK_CQM_HANDLE	CqmHandle,
		    VIPK_NIC_INSTANCE	NicInstance)
{
    VIP_UINT32	i;

    TRACE(VIPK_TRACE_CQM, "[%d]", current->pid);

    for(i=0; i < CqmHandle->NumQueues; i++) {
	spin_lock(&CqmHandle->Lock);
	if(CqmHandle->Cq[i].NicInstance == NicInstance) {
	    spin_unlock(&CqmHandle->Lock);

	    VipkCqmDestroyCq(CqmHandle, i, NicInstance,
			     CqmHandle->Cq[i].Owner);
	} else {
	    spin_unlock(&CqmHandle->Lock);
	}
    }

    TRACE(VIPK_TRACE_CQM, "[%d] all CQs destroyed", current->pid);

    return VIP_SUCCESS;
}

extern VIP_RETURN
VipkCqmPreWait(VIPK_CQM_HANDLE		CqmHandle,
	       VIPK_CQ_HANDLE		CqHandle,
	       VIPK_NIC_INSTANCE	NicInstance,
	       VIPK_OWNER		Owner)
{
    VIPK_CQ	*Cq;
    VIP_RETURN	Status;
    
    unsigned long Flags;

    TRACE(VIPK_TRACE_CQM, "[%d]", current->pid);        
    Status = VipkCqmGetCq(CqmHandle, CqHandle, &Cq, NicInstance, Owner);
    if(Status != VIP_SUCCESS) {
	TRACE(VIPK_TRACE_CQM, "[%d] invalid Cq Handle", current->pid);
	return Status;
    }

    spin_lock_irqsave(&Cq->Lock, Flags);
    TRACE(VIPK_TRACE_CQM, "[%d] Cq: 0x%p OldCount: %d Count: %d",
	  current->pid, (void *)Cq, Cq->OldCount, Cq->Count);    
    Cq->OldCount = Cq->Count;
    spin_unlock_irqrestore(&Cq->Lock, Flags);

    return VIP_SUCCESS;
}

    

VIP_RETURN
VipkCqmWait(VIPK_CQM_HANDLE	CqmHandle,
	    VIPK_CQ_HANDLE	CqHandle,
	    VIP_ULONG		*Timeout,
	    VIPK_NIC_INSTANCE	NicInstance,
	    VIPK_OWNER		Owner)
{
    VIPK_CQ		*Cq;
    VIP_UINT32		OldCount;
    VIP_RETURN		Status;

    unsigned long Flags;
    unsigned long KernTimeout;

    TRACE(VIPK_TRACE_CQM, "[%d] Waiting CqHandle: 0x%x Timeout: %ld", 
	  current->pid, CqHandle, *Timeout);

    if((Status = VipkCqmGetCq(CqmHandle, CqHandle,
			      &Cq, NicInstance, Owner)) != VIP_SUCCESS) {
	TRACE(VIPK_TRACE_CQM, "[%d] invalid Cq Handle", current->pid);
	return Status;
    }

    KernTimeout = VipkLinuxTimeout(*Timeout);

    spin_lock_irqsave(&Cq->Lock, Flags);
    OldCount = Cq->OldCount;

    while(OldCount == Cq->Count
	  && KernTimeout && !signal_pending(current)) {
	TRACE(VIPK_TRACE_CQM,
	      "[%d] Waiting Cq: 0x%p OldCount: %d Cq->Count: %d Signal: 0x%d", 
	      current->pid, (void *)Cq, OldCount, Cq->Count,
	      signal_pending(current));
	cond_wait_interruptible(&Cq->NonEmpty, &Cq->Lock, &KernTimeout);
    }

    /* Don't need to distinguish timeout/signal/completion.
     * The vipl needs to check this for itself.
     */

    TRACE(VIPK_TRACE_CQM, "[%d] end", current->pid);

    spin_unlock_irqrestore(&Cq->Lock, Flags);

    *Timeout = VipkViaTimeout(KernTimeout);

    return Status;
}

void
VipkCqIncUsage(VIPK_CQ *Cq)
{
    Cq->UseCount++;
    TRACE(VIPK_TRACE_CQM, "[%d] UseCount: %d", current->pid, Cq->UseCount);    
}

void
VipkCqDecUsage(VIPK_CQ *Cq)
{
    Cq->UseCount--;
    TRACE(VIPK_TRACE_CQM, "[%d] UseCount: %d", current->pid, Cq->UseCount);
}

VIP_RETURN
VipkCqEnqueue(VIPK_CQ		*Cq,
	      VIPK_RMM_HANDLE	RmmHandle,
	      VIP_VI_HANDLE	UserViHandle,
	      VIP_BOOLEAN	Recv)
{
    VIP_CQ_ENTRY	*UserEntry;
    VIP_RETURN		Status;

    unsigned long Flags;

    spin_lock_irqsave(&Cq->Lock, Flags);
    
    UserEntry = (VIP_CQ_ENTRY *) VipkRmmKaddr(RmmHandle, 
					      &Cq->UserEntry[Cq->Tail],	
					      Cq->MemHandle, Cq->Ptag,
					      VIPK_RMM_MEM_FLAGS_WRITE,
					      Cq->NicInstance);

    if(UserEntry) {
	/* XXX: what is supposed to happen here? Do we keep the old ones
	 * or the new ones?
	 */
#if 0
	if(UserEntry->Status & VIP_CQ_STATUS_DONE) {
	    printk(KERN_DEBUG "XXX: CQ overflow\n");
	}
#endif

	TRACE(VIPK_TRACE_CQM,
	      "Pushing CQ: 0x%p UserViHandle: 0x%p Recv: %d",
	      (void *)Cq, (void *)UserViHandle, Recv);    

	/* be sure to write the Status last */
	UserEntry->Vi = UserViHandle;
	UserEntry->Status = 
	    (VIP_CQ_STATUS_DONE | (Recv ? VIP_CQ_STATUS_RECV : 0));

	Cq->Count++;
	Cq->Tail++;
	if(Cq->Tail == Cq->EntryCount) {
	    Cq->Tail = 0;
	}

	cond_signal(&Cq->NonEmpty);
	Status = VIP_SUCCESS;

    } else {
	Status = VIP_INVALID_PARAMETER;
    }

    spin_unlock_irqrestore(&Cq->Lock, Flags);
    
    return Status;
}

VIP_RETURN
VipkCqmGetCq(VIPK_CQM_HANDLE	CqmHandle,
	     VIPK_CQ_HANDLE	CqHandle,
	     VIPK_CQ		**CqPtr,
	     VIPK_NIC_INSTANCE	NicInstance,
	     VIPK_OWNER		Owner)
{
    VIPK_CQ	*Cq;

    if(CqHandle > CqmHandle->NumQueues) {
	TRACE(VIPK_TRACE_CQM, "[%d] Bad CqHandle", current->pid);
	return VIP_INVALID_PARAMETER;
    }

    Cq = &CqmHandle->Cq[CqHandle];

    if(Cq->Owner != Owner) {
	TRACE(VIPK_TRACE_CQM, "[%d] CQ is owned by: %d", current->pid,
	      Cq->Owner);
	return VIP_INVALID_PARAMETER;
    }

    if(Cq->NicInstance != NicInstance) {
	TRACE(VIPK_TRACE_CQM, "[%d] CQ is not from this NicInstance",
	      current->pid);
	return VIP_INVALID_PARAMETER;
    }

    *CqPtr = Cq;
    return VIP_SUCCESS;
}

VIP_RETURN
VipkCqmResizeCq(VIPK_CQM_HANDLE		CqmHandle,
		VIPK_RMM_HANDLE		RmmHandle,
		VIPK_CQ_HANDLE		CqHandle,
		VIP_CQ_ENTRY		*NewUserEntry,
		VIP_ULONG		NewEntryCount,
		VIP_MEM_HANDLE		NewMemHandle,
		VIP_PROTECTION_HANDLE	NewPtag,
		VIPK_NIC_INSTANCE	NicInstance,
		VIPK_OWNER		Owner)
{
    VIP_ULONG		Tail, Count, Tmp;
    VIPK_CQ 		*Cq;
    VIP_RETURN		Status;
    VIP_CQ_ENTRY	*OldEntry;
    VIP_CQ_ENTRY	*NewEntry;

    unsigned long	Flags;

    TRACE(VIPK_TRACE_CQM, 
	  "[%d] UserEntry: 0x%p EntryCount: %ld MemHandle 0x%08x Ptag 0x%p",
	  current->pid, (void *)NewUserEntry, NewEntryCount,
	  NewMemHandle, NewPtag);
    
    if((Status = VipkCqmGetCq(CqmHandle, CqHandle,
			      &Cq, NicInstance, Owner)) != VIP_SUCCESS) {
	TRACE(VIPK_TRACE_CQM, "[%d] invalid Cq Handle", current->pid);
	return Status;
    }

    /* XXX: need to check to make sure that this is aligned on a
     * CQ_ENTRY size so we don't go over a page boundry
     */
    if(NewEntryCount == 0 || NewEntryCount > CqmHandle->MaxCQEntries) {
	TRACE(VIPK_TRACE_CQM, "[%d] Bad EntryCount: %ld > %d",
	      current->pid, NewEntryCount, CqmHandle->MaxCQEntries);
	/* XXX: SPEC, vipconf expects this, but it is not consistent
	 * with the rest of the spec, seems like it really should be
	 * VIP_INVALID_PARAMETER
	 */
	return VIP_ERROR_RESOURCE;
    }


    spin_lock_irqsave(&Cq->Lock, Flags);

    /* Count DONE entries. */
    Count = 0;
    Tmp = ((Cq->Tail != 0) ? Cq->Tail : Cq->EntryCount) - 1;
    while(Count < Cq->EntryCount) {
	OldEntry = (VIP_CQ_ENTRY *) VipkRmmKaddr(RmmHandle,
						 &Cq->UserEntry[Tmp],
						 Cq->MemHandle, Cq->Ptag,
						 VIPK_RMM_MEM_FLAGS_READ,
						 Cq->NicInstance);
	if(OldEntry->Status & VIP_CQ_STATUS_DONE) {
		Tmp = ((Tmp != 0) ? Tmp : Cq->EntryCount) - 1;
		++Count;
	} else {
		break;
	}
    }
    if(Count > NewEntryCount) {
	/* XXX: What should we do if the new queue is too small? */
	spin_unlock_irqrestore(&Cq->Lock, Flags);
	return VIP_ERROR_RESOURCE;
    }

    /* Copy DONE entries, placing new head at 0. */
    Tail = 0;
    while(Tail < Count) {
	Tmp = (Tmp + 1) % Cq->EntryCount;
	OldEntry = (VIP_CQ_ENTRY *) VipkRmmKaddr(RmmHandle,
						 &Cq->UserEntry[Tmp],
						 Cq->MemHandle, Cq->Ptag,
						 VIPK_RMM_MEM_FLAGS_READ,
						 Cq->NicInstance);
	NewEntry = (VIP_CQ_ENTRY *) VipkRmmKaddr(RmmHandle,
						 &NewUserEntry[Tail],
						 NewMemHandle, NewPtag,
						 VIPK_RMM_MEM_FLAGS_WRITE,
						 Cq->NicInstance);
	*NewEntry = *OldEntry;
	++Tail;
    }

    /* Use new user entry array */
    Cq->Tail = Tail % NewEntryCount;
    Cq->EntryCount = NewEntryCount;
    Cq->UserEntry = NewUserEntry;
    Cq->MemHandle = NewMemHandle;
    Cq->Ptag = NewPtag;

    spin_unlock_irqrestore(&Cq->Lock, Flags);

    return VIP_SUCCESS;
}
