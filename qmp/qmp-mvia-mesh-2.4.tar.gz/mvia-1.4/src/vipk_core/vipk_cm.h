/** \file vipk_cm.h
 *
 * Interface for the M-VIA VI Kernel Agent Connection Manager
 * 
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#ifndef _VIPK_CM_H
#define _VIPK_CM_H

/* needs to be uint32 because it is being passed between machines, 
 * if left as void *, there could be a size mismatch.
 */
typedef VIP_UINT32 	VIPK_CM_CONN_HANDLE;

typedef struct _VIPK_CM VIPK_CM;

#include "vipk_types.h"
#include "vipk_cchan.h"

/** The M-VIA Kernel Agent Connection Manager structure */
struct _VIPK_CM {

    void *Private;

    /** 
     * Initialize a connection mananger.
     *
     * @param Cm	The newly created Connection Mananger.
     * @param CChan	The Control Channel to send conection packets over.
     * @param NumEntries Number of concurrent VipConnectWait requests which 
     *                      may be outstanding at one time.
     * @return	\c VIP_SUCCESS - Connection Manager successfully created.<br>
     *		\c VIP_ERROR_RESOURCE - Insufficient resources to create 
     *		the connection manager.
     */
    VIP_RETURN (*Init) (VIPK_CM		*Cm,
			VIPK_CCHAN	*CChan,
    			VIP_UINT32	NumEntries);
    
    /**
     * Destroy a connection manager.
     *
     * @param Cm	The connection mananger to destroy.
     *
     * @return      \c VIP_SUCCESS - No error checking is currently performed.
     *
     * \warning No error checking is performed by this function.  
     * Considering it is being called from withing the kernel, the caller 
     * should be "doing-the-right-thing" already, but some sanity checks 
     * would be beneficial.
     */
    VIP_RETURN (*Destroy) (VIPK_CM 	*Cm);

    /** 
     * Perform a VipConnectWait
     *
     * @param Cm 		Connection Manager to wait for connections on.
     * @param NicInstance	The unique ID of the NIC instance requesting 
     *				the connection to be accepted.
     * @param LocalAddr		Pointer to the local address of the NIC, 
     *				including the discriminator to wait on.
     * @param Timeout		Number of milliseconds to wait.
     * @param RemoteAddr	Address to store the remote address of the 
     * 				client requesting a connection.
     * @param RemoteViAttribs 	Address to store the remote VI attributs of the
     * 				client requesting a connection.
     * @param ConnHandle	Address to store the new connection handle.
     * @return 	\c VIP_SUCCESS - The connect wait completed successfully.<br>
     *	       	\c VIP_TIMEOUT - The connect wait timed out.
     */    
    VIP_RETURN (*Wait) (VIPK_CM			*Cm,
			VIPK_NIC_INSTANCE	NicInstance,
			VIP_NET_ADDRESS		*LocalAddr,
			VIP_ULONG		Timeout,
			VIP_NET_ADDRESS		*RemoteAddr,
			VIP_VI_ATTRIBUTES	*RemoteViAttribs,
			VIPK_CONN_HANDLE	*ConnHandle);

    /** 
     * Perform a VipConnectAccept
     *
     * @param Cm 		Connection Manager to accept the connection on.
     * @param ConnHandle	The connection handle to accept.
     * @param NicInstance	The unique ID of the NIC instance requesting 
     *				the connection to be accepted.
     * @param LocalViHandle	Handle of the local vi to be connected.
     * @param Vi		Pointer to the local vi to be connected.
     * @return 	\c VIP_SUCCESS - The connect accept completed successfully.<br>
     *	       	\c VIP_INVALID_PARAMETER - The connection handle 
     *		was invalid or not pending.<br>
     *		\c VIP_INVALID_MTU - The local and remote MTUs did 
     *		not match.<br>
     *		\c VIP_INVALID_QOS - The local and remote QoS did 
     *		not match.
     */
    VIP_RETURN (*Accept) (VIPK_CM		*Cm,
			  VIPK_CONN_HANDLE	ConnHandle,
			  VIPK_NIC_INSTANCE	NicInstance,
			  VIPK_VI_HANDLE	LocalViHandle,
			  VIPK_VI		*Vi);
    /** 
     * Perform a VipConnectRejct
     *
     * @param Cm 		Connection Manager to reject the connection on.
     * @param ConnHandle	The connection handle to reject.
     * @param NicInstance	The unique ID of the NIC instance requesting 
     * 				the connection be rejected.
     * @return	\c VIP_SUCCESS - The connect reject completed successfully.<br>
     *	       	\c VIP_INVALID_PARAMETER - The connection handle 
     *		was invalid or not pending.
     */
    VIP_RETURN (*Reject) (VIPK_CM		*Cm,
			  VIPK_CONN_HANDLE	ConnHandle,
			  VIPK_NIC_INSTANCE	NicInstance);

    /** 
     * Perform a VipConnectRequest
     *
     * @param Cm 		Connection Manager to request the connection on
     * @param NicInstance	The unique ID of the NIC instance requesting 
     * 				the connection.
     * @param LocalViHandle	Handle of the Vi requesting the connection.
     * @param Vi		Pointer to the Vi requesting the connection.
     * @param LocalAddr		Local address of this NIC, plus the
     *				discriminator for the connection.
     * @param RemoteAddr	Address of the remote VI.
     * @param Timeout		Number of microseconds to wait for a 
     *				connection.
     * @return	\c VIP_SUCCESS - The connect request completed 
     *		successfully.<br>
     *	       	\c VIP_NO_MATCH - No server is waiting on the requested
     *		discriminator.
     */
    VIP_RETURN (*Request)(VIPK_CM		*Cm,
			  VIPK_NIC_INSTANCE	NicInstance,
			  VIPK_VI_HANDLE	LocalViHandle,
			  VIPK_VI		*Vi,
			  VIP_NET_ADDRESS	*LocalAddr,
			  VIP_NET_ADDRESS	*RemoteAddr,
			  VIP_ULONG		Timeout);

    /** 
     * Perform a VipConnectPeerRequest
     *
     * @param Cm 		Connection Manager to request the connection on
     * @param NicInstance	The unique ID of the NIC instance requesting 
     * 				the connection.
     * @param LocalViHandle	Handle of the Vi requesting the connection.
     * @param Vi		Pointer to the Vi requesting the connection.
     * @param LocalAddr		Local address of this NIC.
     * @param RemoteAddr	Address of the remote peer, plus the
     *				discriminator for the connection.
     * @param Timeout		Number of microseconds to wait for a 
     *				connection.
     * @return	\c VIP_SUCCESS - The connect request has been initiated 
     *		successfully.<br>
     *		See IDG Section 3.3.6 for other return options.
     */
    VIP_RETURN (*PeerRequest)(VIPK_CM		*Cm,
			      VIPK_NIC_INSTANCE	NicInstance,
			      VIPK_VI_HANDLE	LocalViHandle,
			      VIPK_VI		*Vi,
			      VIP_NET_ADDRESS	*LocalAddr,
			      VIP_NET_ADDRESS	*RemoteAddr,
			      VIP_ULONG		Timeout);

    /** 
     * Perform a VipConnectPeerDone or VipConnectPeerWait
     *
     * @param Cm 		Connection Manager to request the connection on
     * @param NicInstance	The unique ID of the NIC instance requesting 
     * 				the connection.
     * @param Vi		Pointer to the Vi requesting the connection.
     * @param Block		TRUE=VipConnectPeerWait, FALSE=...Done
     * @return	\c VIP_SUCCESS - The connect request completed 
     *		successfully.<br>
     *		See IDG Sections 3.3.7 and 3.3.8 for other return options.
     */
    VIP_RETURN (*PeerDone)(VIPK_CM		*Cm,
			   VIPK_NIC_INSTANCE	NicInstance,
			   VIPK_VI		*Vi,
			   VIP_BOOLEAN		Block);

    /** 
     * Perform a VipDisconnect on a PENDING Vi
     *
     * @param Cm 		Connection Manager to disconnect.
     * @param NicInstance	The unique ID of the NIC instance.
     * @param Vi		Pointer to the Vi to disconnect.
     * @return	\c VIP_SUCCESS - The connect request completed successfully.
     */
    VIP_RETURN (*Disconnect)(VIPK_CM		*Cm,
			     VIPK_NIC_INSTANCE	NicInstance,
			     VIPK_VI		*Vi);

    /** 
     * Destroy all the connection handles associated with 
     * the specified NicInstance.
     *
     * @param Cm 		Connection Manager to accept the connection on.
     * @param NicInstance	The unique ID of the NIC instance requesting 
     * 				to have its connection handles destroyed.
     * @return	\c VIP_SUCCESS - This function can not fail.
     */
    VIP_RETURN 	(*DestroyNic)(VIPK_CM		*Cm,
			      VIPK_NIC_INSTANCE	NicInstance);

    void 	(*RecvControl)(VIPK_CM			*Cm,
			       VIPK_CCHAN_PACKET	*Pkt);

};

extern const VIPK_CM VipkCmDefault;
    
#endif



