/** \file vipk_ops.c
 *
 * Default device operations for VI Kernel Agent drivers.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 *
 */

#include <linux/config.h>
#include <linux/kernel.h>

#include <linux/vmalloc.h>
#include <asm/uaccess.h>


#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
/**
 * The following two attributes are defined twice
 */
#ifdef __attribute_pure__
#undef __attribute_pure__
#endif
 
#ifdef __attribute_used__
#undef __attribute_used__
#endif

#endif

#include "vipk.h"
#include "vipk_trace.h"

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0))
#include "vipk_2_2_compat.h"
#endif

/**
 * Perform Kernel Agent half of VipOpenNic.
 *
 * @param DevicePtr		Pointer to device structure
 * @param VipkFilePtr		Pointer to state per NIC open
 * @param NicUserHandle		Associated VIPL VIP_NIC_HANDLE.
 * @param DoorbellType		Pointer to doorbell type in user space.
 *				(i.e. MemoryMapped, FastTrap, etc.)
 * @return 			See IDG Section 3.1.1 for details.
 */
VIP_RETURN
VipkOpenNic(VIPK_DEVICE		*DevicePtr,
	    VIPK_FILE		*VipkFilePtr,
	    VIP_NIC_HANDLE	NicUserHandle,
	    VIPK_NIC_HANDLE	*NicKernHandle)
{
    TRACE(VIPK_TRACE_NIC_OPS, "[%d] %s", current->pid, DevicePtr->DeviceName);

    VipkFilePtr->NicUserHandle = NicUserHandle;
    put_user_ret(DevicePtr->DeviceIndex, NicKernHandle, VIP_INVALID_PARAMETER);

    return VIP_SUCCESS;
}

/**
 * Fetch an error for the VIPL asynchronous error handler thread for 
 * this NIC instance.
 *
 * If the NIC has been closed by the parent thread, UserFound will be set
 * to VIP_FALSE and the return code will be VIP_SUCCESS.
 * 
 * @param DevicePtr		Pointer to device structure
 * @param VipkFilePtr		Pointer to state per NIC open
 * @param UserFound		Flag in user space to indicate a valid 
 *				error is being returned.
 * @param UserErrorDesc		Pointer to error descriptor in user space.  
 *
 * @return 	\c VIP_SUCCESS - No errors attempting to fetch 
 *			error descriptor.<br>
 *		\c VIP_INVALID_PARAMETER - One of the parameters was invalid.
 *
 */
VIP_RETURN
VipkFetchError(VIPK_DEVICE		*DevicePtr,
	       VIPK_FILE		*VipkFilePtr,
	       VIP_BOOLEAN		*UserFound,
	       VIP_ERROR_DESCRIPTOR	*UserErrorDesc)
{
    VIP_BOOLEAN Found;
    VIP_ERROR_DESCRIPTOR ErrorDesc;

    TRACE(VIPK_TRACE_NIC_OPS, "[%d] %s", current->pid, DevicePtr->DeviceName);

    Found = VipkEQDequeue(VipkFilePtr->EQHandle, &ErrorDesc);
    put_user_ret(Found, UserFound, VIP_INVALID_PARAMETER);
    
    if(Found) {
	copy_to_user_ret(UserErrorDesc, &ErrorDesc, 
			 sizeof(VIP_ERROR_DESCRIPTOR), VIP_INVALID_PARAMETER);
    }

    return VIP_SUCCESS;
}

/**
 * Perform Kernel Agent half of VipCreatePtag.
 *
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param UserPtag		Pointer to new Ptag handle in user space.
 * @return			See IDG Section 3.4.1 for details.
 */
VIP_RETURN
VipkCreatePtag(VIPK_DEVICE		*DevicePtr,
	       VIPK_FILE		*FilePtr,
	       VIP_PROTECTION_HANDLE	*UserPtag)
{
    VIP_PROTECTION_HANDLE Ptag;
    VIP_RETURN Status;

    TRACE(VIPK_TRACE_NIC_OPS, "[%d] %s", current->pid, DevicePtr->DeviceName);

    Status = VipkPtmCreatePtag(DevicePtr->PtmHandle,
			       &Ptag, FilePtr->NicInstance);
    put_user_ret(Ptag, UserPtag, VIP_INVALID_PARAMETER);

    return Status;
}

/**
 * Perform Kernel Agent half of VipDestroyPtag.
 *
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param Ptag			Ptag handle to destroy
 * @return			See IDG Section 3.4.2 for details.
 */
VIP_RETURN
VipkDestroyPtag(VIPK_DEVICE		*DevicePtr,
		VIPK_FILE		*FilePtr,		
		VIP_PROTECTION_HANDLE	Ptag)
{
    VIP_RETURN Status;

    TRACE(VIPK_TRACE_NIC_OPS, "[%d] %s", current->pid, DevicePtr->DeviceName);

    Status = VipkPtmDestroyPtag(DevicePtr->PtmHandle,
				Ptag, FilePtr->NicInstance);

    return Status;
}

/**
 * Perform Kernel Agent half of VipRegisterMem
 *
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param VirtualAddress	Starting address of region to register.
 * @param Length		Length, in bytes, of region to register.
 * @param UserMemAttribs	The memory attributes to associate with
 *				the memory region.  In user space.
 * @param UserMemHandle		Handle of the newly registered region.
 * @return			See IDG Section 3.4.3 for details.
 *
 */
VIP_RETURN
VipkRegisterMem(VIPK_DEVICE		*DevicePtr,
		VIPK_FILE		*FilePtr,
		VIP_PVOID		VirtualAddress,
		VIP_ULONG		Length,
		VIP_MEM_ATTRIBUTES	*UserMemAttribs,
		VIP_MEM_HANDLE		*UserMemHandle)
{
    VIP_MEM_ATTRIBUTES MemAttribs;
    VIP_MEM_HANDLE MemHandle;
    VIP_RETURN	Status;

    TRACE(VIPK_TRACE_NIC_OPS, "[%d] %s", current->pid, DevicePtr->DeviceName);

    copy_from_user_ret(&MemAttribs, UserMemAttribs, 
		       sizeof(VIP_MEM_ATTRIBUTES), VIP_INVALID_PARAMETER);

    if(VipkPtmUsePtag(DevicePtr->PtmHandle, MemAttribs.Ptag,
		      FilePtr->NicInstance) != VIP_SUCCESS) {
	TRACE(VIPK_TRACE_CREATE_VI, "[%d] %s Invalid Ptag",
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_PTAG;
    }
    
    Status = VipkRmmRegister(DevicePtr->RmmHandle, 
			     VirtualAddress, 
			     Length,
			     &MemAttribs,
			     &MemHandle,
			     FilePtr->NicInstance);

    if(Status != VIP_SUCCESS) {
	VipkPtmReleasePtag(DevicePtr->PtmHandle, MemAttribs.Ptag,
			   FilePtr->NicInstance);
    }

    put_user_ret(MemHandle, UserMemHandle, VIP_INVALID_PARAMETER);

    return Status;
}

/**
 * Perform Kernel Agent half of VipDeregisterMem
 *
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param VirtualAddress	Starting address of region to deregister.
 * @param MemHandle		Memory handle to deregister.
 * @return			See IDG Section 3.4.4 for details.
 *
 * \warning The VirtualAddress must match the VirtualAddress provided
 * when this MemHandle was registered to the byte.  The spec is misleading 
 * on this matter, as it implies that memory registration granularity is 
 * page oriented.  The Intel VIA Conformance Tests perform deregister
 * memory within the page, expecting the request to fail.
 */
VIP_RETURN
VipkDeregisterMem(VIPK_DEVICE		*DevicePtr,
		  VIPK_FILE		*FilePtr,
		  VIP_PVOID		VirtualAddress,
		  VIP_MEM_HANDLE	MemHandle)
{
    VIP_MEM_ATTRIBUTES MemAttribs;
    VIP_RETURN Status;

    TRACE(VIPK_TRACE_NIC_OPS, "[%d] %s", current->pid, DevicePtr->DeviceName);

    Status = VipkRmmQueryMem(DevicePtr->RmmHandle,
			     VirtualAddress, MemHandle,
			     &MemAttribs,
			     FilePtr->NicInstance);
    
    if(Status != VIP_SUCCESS) {
	return Status;
    }
    
    Status = VipkRmmDeregister(DevicePtr->RmmHandle, 
			       VirtualAddress, MemHandle,
			       FilePtr->NicInstance);

    if(Status == VIP_SUCCESS) {
	VipkPtmReleasePtag(DevicePtr->PtmHandle, 
			   MemAttribs.Ptag, FilePtr->NicInstance);
    }
    
    return Status;
}


/**
 * Perform Kernel Agent half of VipCreateCQ
 *
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param UserEntry		Pointer to completion queue entry circular
 *				queue.  (In user space.)
 * @param NumEntries		Size of circular completion queue.
 * @param MemHandle		Memory handle of the registered memory
 *				region the completion queue entries reside in.
 * @param Ptag			Protection Tag of the completion queue entries.
 * @param UserCqHandle		Kernel Agent CQ Handle of newly 
 *				created completion queue.
 * @return			See IDG Section 3.6.1 for details.
 */
VIP_RETURN
VipkCreateCq(VIPK_DEVICE		*DevicePtr,
	     VIPK_FILE			*FilePtr,
	     VIP_CQ_ENTRY		*UserEntry,
	     VIP_ULONG			NumEntries,
	     VIP_MEM_HANDLE		MemHandle,
	     VIP_PROTECTION_HANDLE	Ptag,
	     VIPK_CQ_HANDLE		*UserCqHandle)
{
    VIPK_CQ_HANDLE	CqHandle;
    VIP_RETURN		Status;
    
    TRACE(VIPK_TRACE_NIC_OPS, "[%d] %s", current->pid, DevicePtr->DeviceName);

    Status = VipkCqmCreateCq(DevicePtr->CqmHandle, UserEntry, NumEntries,
			     MemHandle, Ptag, &CqHandle,
			     FilePtr->NicInstance,
			     VipkGetCurrentOwner());

    put_user_ret(CqHandle, UserCqHandle, VIP_INVALID_PARAMETER);

    return Status;
}

/** 
 * Perform Kernel Agent half of VipDestroyCQ
 * 
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param CqHandle		Kernel Agent CQ Handle to destroy
 * @return			See IDG Section 3.6.2 for details.
 */
VIP_RETURN
VipkDestroyCq(VIPK_DEVICE		*DevicePtr,
	      VIPK_FILE			*FilePtr,
	      VIPK_CQ_HANDLE		CqHandle)
{
    return VipkCqmDestroyCq(DevicePtr->CqmHandle, CqHandle,
			    FilePtr->NicInstance, VipkGetCurrentOwner());
}

/**
 * Perform Kernel Agent half of VipResizeCQ
 *
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param CqHandle		Kernel Agent CQ Handle to resize
 * @param NewUserEntry		Pointer to new completion queue entry circular
 *				queue.  (In user space.)
 * @param NewEntryCount		Size of new circular completion queue.
 * @param NewMemHandle		Memory handle of the registered memory region
 *				the new completion queue entries reside in.
 * @param NewPtag		Protection Tag of new the completion queue
 *				entries.
 * @return			See IDG Section 3.6.3 for details.
 */
VIP_RETURN
VipkResizeCq(VIPK_DEVICE		*DevicePtr,
	     VIPK_FILE			*FilePtr,
	     VIPK_CQ_HANDLE		CqHandle,
	     VIP_CQ_ENTRY		*NewUserEntry,
	     VIP_ULONG			NewEntryCount,
	     VIP_MEM_HANDLE		NewMemHandle,
	     VIP_PROTECTION_HANDLE	NewPtag)
{
    TRACE(VIPK_TRACE_NIC_OPS, "[%d] %s", current->pid, DevicePtr->DeviceName);

    return VipkCqmResizeCq(DevicePtr->CqmHandle, DevicePtr->RmmHandle,
			   CqHandle, NewUserEntry, NewEntryCount,
			   NewMemHandle, NewPtag,
			   FilePtr->NicInstance,
			   VipkGetCurrentOwner());
}

/** 
 * Performs a pre-wait on the completion queue.
 *
 * Pre-waits are used to avoid a race condition in the interaction between
 * the user level and kernel level queue handling.  
 *
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param CqHandle		Kernel Agent CQ Handle to pre-wait on.
 * @return 	\c VIP_SUCCESS - The pre-wait completed successfully.<br>
 * 		\c VIP_INVALID_PARAMETER - The CqHandle was invalid.
 *
 * @see VipCQWait()
 */
VIP_RETURN
VipkCqPreWait(VIPK_DEVICE	*DevicePtr,
	      VIPK_FILE		*FilePtr,
	      VIPK_CQ_HANDLE	CqHandle)
{
    return VipkCqmPreWait(DevicePtr->CqmHandle, CqHandle,
			  FilePtr->NicInstance, VipkGetCurrentOwner());
}

/**
 * Perform the Kernel Agent half of VipCQWait.
 *
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param CqHandle		Kernel Agent CQ Handle to wait on.
 * @return See IDG Section 3.5.8 for details.
 */
VIP_RETURN
VipkCqWait(VIPK_DEVICE		*DevicePtr,
	   VIPK_FILE		*FilePtr,
	   VIPK_CQ_HANDLE	CqHandle,
	   VIP_ULONG		*Timeout)
{
    return VipkCqmWait(DevicePtr->CqmHandle, CqHandle, Timeout,
		       FilePtr->NicInstance, VipkGetCurrentOwner());
}

/**
 * Check Vi Attributes to ensure that they may be set for a given Vi.
 *
 * @param DevicePtr		Pointer to device structure.
 * @param ViAttribs		Vi Attributes to be verified.
 * @return See IDG Section 3.7.2 and 3.2.1
 */
VIP_RETURN
VipkValidateViAttributes(VIPK_DEVICE		*DevicePtr,
			 VIPK_FILE		*FilePtr,
			 VIP_VI_ATTRIBUTES	*ViAttribs)
{
    if(ViAttribs->ReliabilityLevel 
       > DevicePtr->NicAttribs->ReliabilityLevelSupport) {
	TRACE(VIPK_TRACE_CREATE_VI, "[%d] %s Invalid reliability level", 
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_RELIABILITY_LEVEL;
    }

    if(ViAttribs->MaxTransferSize > DevicePtr->NicAttribs->MaxTransferSize) {
	TRACE(VIPK_TRACE_CREATE_VI, "[%d] %s Invalid MTU %ld > %ld", 
	      current->pid, DevicePtr->DeviceName,
	      ViAttribs->MaxTransferSize,
	      DevicePtr->NicAttribs->MaxTransferSize);
	return VIP_INVALID_MTU;
    }

    /* SPEC: vipconf requires that we check for invalid QOS, even though
     * it is not defined in the spec.  So, we will declare 0 to be the
     * only valid qos.
     */
    if(ViAttribs->QoS != 0) {
	TRACE(VIPK_TRACE_CREATE_VI, "[%d] %s Invalid QOS", 
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_QOS;
    }

    if(ViAttribs->EnableRdmaRead > DevicePtr->NicAttribs->RDMAReadSupport) {
	TRACE(VIPK_TRACE_CREATE_VI, "[%d] %s Invalid RDMA Read request",
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_RDMAREAD;
    }

    if(VipkPtmUsePtag(DevicePtr->PtmHandle, ViAttribs->Ptag,
		      FilePtr->NicInstance) != VIP_SUCCESS) {
	TRACE(VIPK_TRACE_CREATE_VI, "[%d] %s Invalid Ptag",
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_PTAG;
    }

    return VIP_SUCCESS;
}

/** 
 * Perform the Kernel Agent half of VipCreateVi
 *
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param UserArgs		Arguments from the ioctl structure.
 * @return See IDG Section 3.2.1 for details.
 *
 * \warning ViAttribs.QoS must be 0.  Although, QoS is not defined 
 * in the VIA Specification or the IDG, the Intel VIA Conformance Tests
 * require that provides define valid and invalid values for the QoS.
 * Therefore, we arbitrarily define 0 to be the only valid value.  (This
 * is based on the assumption that most users will memset the ViAttribute
 * structure to 0 before assigning values to it.)
 */
VIP_RETURN
VipkCreateVi(VIPK_DEVICE		*DevicePtr,
	     VIPK_FILE			*FilePtr,
	     VIP_CREATE_VI_ARGS		*UserArgs)
{
    VIP_VI_ATTRIBUTES	ViAttribs;
    VIP_RETURN		Status;

    VIP_CREATE_VI_ARGS	Args;

    VIPK_VI	*Vi;
    VIP_UINT32	ViHandle;

    TRACE(VIPK_TRACE_CREATE_VI, "[%d] %s",
	  current->pid, DevicePtr->DeviceName);

    copy_from_user_ret(&Args, UserArgs,
		       sizeof(VIP_CREATE_VI_ARGS), VIP_INVALID_PARAMETER);

    copy_from_user_ret(&ViAttribs, Args.ViAttribs,
		   sizeof(VIP_VI_ATTRIBUTES), VIP_INVALID_PARAMETER);

    Status = VipkValidateViAttributes(DevicePtr, FilePtr, &ViAttribs);
    if(Status != VIP_SUCCESS) {
	return Status;
    }
	
    /* All attributes and protection checks are out of the way, find
     * a free vi and set it up
     */

    Vi = NULL;
    spin_lock(&DevicePtr->Lock);
    for(ViHandle = 0; ViHandle < DevicePtr->NicAttribs->MaxVI; ViHandle++) {
	if(DevicePtr->Vi[ViHandle].Owner == VIPK_NO_OWNER) {
	    /*
	     * PHH: We perform just enough initialization to
	     * "own" the Vi so we can safely release the lock.
	     */
	    Vi = &DevicePtr->Vi[ViHandle];
	    memset(Vi, 0, sizeof(VIPK_VI));
	    Vi->Owner = VipkGetCurrentOwner();
	    Vi->FilePtr = FilePtr;
	    break;
	}
    }
    spin_unlock(&DevicePtr->Lock);

    if(Vi == NULL) {
	TRACE(VIPK_TRACE_CREATE_VI, "[%d] %s No more free VIs",
	      current->pid, DevicePtr->DeviceName);
	VipkPtmReleasePtag(DevicePtr->PtmHandle, ViAttribs.Ptag,
			   FilePtr->NicInstance);
	return VIP_ERROR_RESOURCE;
    }

    /* Remainder of initialization (outside of lock) */
    Vi->DevicePtr = DevicePtr;
    Vi->ViAttribs = ViAttribs;
    spin_lock_init(&Vi->Lock);

    if(Args.SendCQHandle != VIP_NO_CQ) {
	if(VipkCqmGetCq(DevicePtr->CqmHandle, Args.SendCQHandle, &Vi->SendCQ,
			FilePtr->NicInstance,
			VipkGetCurrentOwner()) != VIP_SUCCESS) {
	    TRACE(VIPK_TRACE_CREATE_VI, "[%d] %s Invalid SendCQHandle",
		  current->pid, DevicePtr->DeviceName);

	    goto out_cq_err;
	}
	VipkCqIncUsage(Vi->SendCQ);
    }

    
    if(Args.RecvCQHandle != VIP_NO_CQ) {
	if(VipkCqmGetCq(DevicePtr->CqmHandle, Args.RecvCQHandle, &Vi->RecvCQ,
			FilePtr->NicInstance,
			VipkGetCurrentOwner()) != VIP_SUCCESS) {
	    TRACE(VIPK_TRACE_CREATE_VI, "[%d] %s Invalid RecvCQHandle",
		  current->pid, DevicePtr->DeviceName);

	    goto out_cq_err;
	}
	VipkCqIncUsage(Vi->RecvCQ);	
    }

    
    Vi->State = VIP_STATE_IDLE;
    Vi->UserViHandle = Args.UserViHandle;

    cond_init(&Vi->Sent);
    cond_init(&Vi->Received);

    Vi->RecvSeq = jiffies;		/* not "random", just "arbitrary". */
    
    put_user_ret(ViHandle, Args.KernViHandle, VIP_INVALID_PARAMETER);
    put_user_ret(NULL, Args.RecvRegister, VIP_INVALID_PARAMETER);
    put_user_ret(NULL, Args.SendRegister, VIP_INVALID_PARAMETER);
    put_user_ret(DevicePtr->DoorbellType, Args.DoorbellType, 
		 VIP_INVALID_PARAMETER);

    TRACE(VIPK_TRACE_CREATE_VI, 
	  "[%d] %s returning KernViHandle: 0x%x",
	  current->pid, DevicePtr->DeviceName, ViHandle);
    
    return VIP_SUCCESS;

out_cq_err:
    VipkDestroyVi(DevicePtr, ViHandle);
    return VIP_INVALID_PARAMETER;
}

/**
 * Perform Kernel Agent half of VipDestroyVi.
 *
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param ViHandle		Kernel Agent VI Handle to destroy.
 * @return See IDG Section 3.2.1 for details.
 */
VIP_RETURN
VipkDestroyVi(VIPK_DEVICE 	*DevicePtr,
	      VIPK_VI_HANDLE	ViHandle)
{
    VIPK_VI *Vi;
    
    TRACE(VIPK_TRACE_DESTROY_VI, "[%d] %s ViHandle 0x%x", 
	  current->pid, DevicePtr->DeviceName, ViHandle);

    Vi = VipkViLookup(DevicePtr, ViHandle);
    if(Vi == NULL || !VipkViVerifyOwner(Vi)) {
	TRACE(VIPK_TRACE_DESTROY_VI, "[%d] %s Bad ViHandle",
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_PARAMETER;
    }

    if(Vi->State != VIP_STATE_IDLE || 
       Vi->RecvDesc != NULL ||
       Vi->SendDesc != NULL) {
	TRACE(VIPK_TRACE_DESTROY_VI, 
	      "[%d] %s Bad state: 0x%x RecvDesc 0x%p SendDesc 0x%p", 
	      current->pid, DevicePtr->DeviceName,
	      Vi->State, (void *)Vi->RecvDesc, (void *)Vi->SendDesc);
	return VIP_INVALID_STATE;
    }

    if(Vi->SendCQ) {
	VipkCqDecUsage(Vi->SendCQ);
    }

    if(Vi->RecvCQ) {
	VipkCqDecUsage(Vi->RecvCQ);
    }

    VipkPtmReleasePtag(DevicePtr->PtmHandle,
		       Vi->ViAttribs.Ptag,  Vi->FilePtr->NicInstance);
    
    spin_lock(&DevicePtr->Lock);
    Vi->Owner = VIPK_NO_OWNER;
    spin_unlock(&DevicePtr->Lock);
    
    TRACE(VIPK_TRACE_DESTROY_VI, 
	  "[%d] %s ViHandle: 0x%x destroyed",
	  current->pid, DevicePtr->DeviceName, ViHandle);

    return VIP_SUCCESS;
}

/**
 * Destroy all the VIs associated with a NicInstance.
 *
 * This is called when the system level close routine is called
 * on the NIC.  This must release the VI resources, regardless of the
 * state of the VI.
 *
 * @param DevicePtr		Pointer to device structure.
 * @param NicInstance		Unique id of the NIC instance being destroyed.
 * @return \c VIP_SUCCESS	This function must not fail.
 */  
VIP_RETURN
VipkDestroyViNic(VIPK_DEVICE		*DevicePtr,
		 VIPK_NIC_INSTANCE	NicInstance)
{
    VIPK_VI_HANDLE ViHandle;
    VIPK_VI *Vi;

    spin_lock(&DevicePtr->Lock);
    for(ViHandle = 0; ViHandle < DevicePtr->NicAttribs->MaxVI; ViHandle++) {
	Vi = &DevicePtr->Vi[ViHandle];
	if(VipkViVerifyOwner(Vi) && Vi->FilePtr->NicInstance == NicInstance) {
	    spin_unlock(&DevicePtr->Lock);

	    if(Vi->State == VIP_STATE_CONNECTED) {
		DevicePtr->DeviceOps->SendConnLost(DevicePtr, Vi, VIP_TRUE);
	    }

	    DevicePtr->DeviceOps->VipkDisconnect(DevicePtr, ViHandle);
	    DevicePtr->DeviceOps->VipkDestroyVi(DevicePtr, ViHandle);

	    spin_lock(&DevicePtr->Lock);
	}
    }
    spin_unlock(&DevicePtr->Lock);

    return VIP_SUCCESS;
}


/**
 * Post errors on all VIs for this device
 *
 * This is called when the low level driver encounter some physical
 * link level failure on the NIC.  
 *
 * @param DevicePtr		Pointer to device structure.
 */  
void
VipkPostDeviceError(VIPK_DEVICE		*DevicePtr)
{
    VIPK_VI_HANDLE ViHandle;
    VIPK_VI *Vi;

    spin_lock(&DevicePtr->Lock);
    for(ViHandle = 0; ViHandle < DevicePtr->NicAttribs->MaxVI; ViHandle++) {
	Vi = &DevicePtr->Vi[ViHandle];
	if(VipkViVerifyOwner(Vi)) 
	  VipkPostError (Vi, VIP_RESOURCE_NIC, VIP_ERROR_CATASTROPHIC);
    }
    spin_unlock(&DevicePtr->Lock);
}

/**
 * Perform Kernel Agent half of VipConnectWait.
 *
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param UserArgs		Arguments from the ioctl structure.
 * @return 			See IDG Section 3.3.1 for details.
 */
VIP_RETURN
VipkConnectWait(VIPK_DEVICE		*DevicePtr,
		VIPK_FILE		*VipkFilePtr,
		VIP_CONNECT_WAIT_ARGS	*UserArgs)
{
    VIP_CONNECT_WAIT_ARGS	Args;
    VIP_VI_ATTRIBUTES		RemoteViAttribs;
    VIPK_CONN_HANDLE		ConnHandle;
    VIP_RETURN 			Status;

    TRACE(VIPK_TRACE_NIC_OPS | VIPK_TRACE_CM, "[%d] %s",
	  current->pid, DevicePtr->DeviceName);

    copy_from_user_ret(&Args, UserArgs,
		       sizeof(VIP_CONNECT_WAIT_ARGS), VIP_INVALID_PARAMETER);

    if(VipkAddrVerifySize(DevicePtr,
			  (VIP_NET_ADDRESS *)&Args.LocalAddr) != VIP_SUCCESS) {
	TRACE(VIPK_TRACE_NIC_OPS | VIPK_TRACE_CM, "[%d] %s Bad Addr Size",
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_PARAMETER;
    }

    if(!VipkAddrNicHostEq(DevicePtr, (VIP_NET_ADDRESS *)&Args.LocalAddr)) {
	TRACE(VIPK_TRACE_NIC_OPS | VIPK_TRACE_CM, "[%d] %s Bad Local Addr",
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_PARAMETER;
    }

    /* Per email with Ed G. a timeout of 0 is not an error */

    Status = DevicePtr->Cm.Wait(&DevicePtr->Cm,
				VipkFilePtr->NicInstance,
				(VIP_NET_ADDRESS *)&Args.LocalAddr, 
				Args.Timeout, 
				(VIP_NET_ADDRESS *)&Args.RemoteAddr,
				&RemoteViAttribs, 
				&ConnHandle);

    copy_to_user_ret(Args.RemoteViAttribs, &RemoteViAttribs, 
		     sizeof(VIP_VI_ATTRIBUTES), VIP_INVALID_PARAMETER);

    copy_to_user_ret(&UserArgs->RemoteAddr, &Args.RemoteAddr,
		     sizeof(VIP_NET_MAX_ADDRESS), VIP_INVALID_PARAMETER);

    put_user_ret(ConnHandle, Args.ConnHandle, VIP_INVALID_PARAMETER);

    TRACE(VIPK_TRACE_NIC_OPS | VIPK_TRACE_CM, 
	  "[%d] %s Returning Status: %d ConnHandle 0x%x",
	  current->pid, DevicePtr->DeviceName, Status, ConnHandle);

    return Status;
}

/**
 * Perform Kernel Agent portion of VipConnectAccept on the server.
 *
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param ConnHandle		Connection Handle to accept the connection on.
 * @param ViHandle		Vi to accept the connection on.
 * @return 			See IDG Section 3.3.2 for details.
 *
 */
VIP_RETURN
VipkConnectAccept(VIPK_DEVICE		*DevicePtr,
		  VIPK_FILE		*VipkFilePtr,
		  VIPK_CONN_HANDLE	ConnHandle,
		  VIPK_VI_HANDLE	ViHandle)

{
    VIPK_VI	*Vi;
    VIP_RETURN	Status;

    TRACE(VIPK_TRACE_NIC_OPS | VIPK_TRACE_CM, "[%d] %s",
	  current->pid, DevicePtr->DeviceName);

    Vi = VipkViLookup(DevicePtr, ViHandle);
    if(Vi == NULL || !VipkViVerifyOwner(Vi)) {
	TRACE(VIPK_TRACE_NIC_OPS | VIPK_TRACE_CM, 
	      "[%d] %s ViHandle is invalid",
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_PARAMETER;
    }

    Status = DevicePtr->Cm.Accept(&DevicePtr->Cm, 
				  ConnHandle, 
				  VipkFilePtr->NicInstance,
				  ViHandle,
				  Vi);

    return Status;
}


/** 
 * Perform Kernel Agent portion of VipConnectReject on the server.
 *
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param ConnHandle		Connection handle to reject.
 * @return 			See IDG Section 3.3.3 for details.
 */
VIP_RETURN
VipkConnectReject(VIPK_DEVICE		*DevicePtr,
		  VIPK_FILE		*VipkFilePtr,
		  VIPK_CONN_HANDLE	ConnHandle)
{
    VIP_RETURN 		Status;

    TRACE(VIPK_TRACE_NIC_OPS | VIPK_TRACE_CM, "[%d] %s",
	  current->pid, DevicePtr->DeviceName);

    Status = DevicePtr->Cm.Reject(&DevicePtr->Cm,
				  ConnHandle,
				  VipkFilePtr->NicInstance);

    return Status;
}

/**
 * Perform Kernel Agent portion of VipConnectRequestClient on the client.
 *
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param UserArgs		Arguments from the ioctl structure.
 * @return 			See IDG Section 3.3.4 for details.
 *
 * \bug Can potentially not timeout as fast as it should.  There also 
 * exists the potential to receive stale accept messages.  See comments
 * in code about both, as well as bug section from VipkConnectRejectClient().
 * 
 */
VIP_RETURN
VipkConnectRequest(VIPK_DEVICE			*DevicePtr,
		   VIPK_FILE			*VipkFilePtr,
		   VIP_CONNECT_REQUEST_ARGS 	*UserArgs)
{
    VIPK_VI			*Vi;
    VIP_CONNECT_REQUEST_ARGS	Args;
    VIP_RETURN			Status = VIP_SUCCESS;

    TRACE(VIPK_TRACE_NIC_OPS | VIPK_TRACE_CM, "[%d] %s",
	  current->pid, DevicePtr->DeviceName);

    copy_from_user_ret(&Args, UserArgs,
		       sizeof(VIP_CONNECT_REQUEST_ARGS), 
		       VIP_INVALID_PARAMETER);

    Vi = VipkViLookup(DevicePtr, Args.ViHandle);
    if(Vi == NULL || !VipkViVerifyOwner(Vi)) {
	TRACE(VIPK_TRACE_NIC_OPS | VIPK_TRACE_CM, "[%d] %s VI is invalid",
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_PARAMETER;
    }

    if(VipkAddrVerifySize(DevicePtr,
                          (VIP_NET_ADDRESS *)&Args.LocalAddr) != VIP_SUCCESS) {
        TRACE(VIPK_TRACE_NIC_OPS | VIPK_TRACE_CM, "[%d] %s Bad local addr",
              current->pid, DevicePtr->DeviceName);
        return VIP_INVALID_PARAMETER;
    }

    if(VipkAddrVerifySize(DevicePtr,
                          (VIP_NET_ADDRESS *)&Args.RemoteAddr) != VIP_SUCCESS){
        TRACE(VIPK_TRACE_NIC_OPS | VIPK_TRACE_CM, "[%d] %s Bad local addr",
              current->pid, DevicePtr->DeviceName);
        return VIP_INVALID_PARAMETER;
    }


    if(!VipkAddrNicHostEq(DevicePtr, (VIP_NET_ADDRESS *)&Args.LocalAddr)) {
        TRACE(VIPK_TRACE_NIC_OPS | VIPK_TRACE_CM, "[%d] %s Bad local addr",
              current->pid, DevicePtr->DeviceName);
        return VIP_INVALID_PARAMETER;
    }

    if(Args.Timeout == 0) {
        return VIP_INVALID_PARAMETER;
    }

    Status = DevicePtr->Cm.Request(&DevicePtr->Cm,
				   VipkFilePtr->NicInstance,
				   Args.ViHandle,
				   Vi,
				   (VIP_NET_ADDRESS *) &Args.LocalAddr,
				   (VIP_NET_ADDRESS *) &Args.RemoteAddr,
				   Args.Timeout);

    if(Status == VIP_SUCCESS) {
	VipAddrCopy((VIP_NET_ADDRESS *) &Vi->RemoteAddr, 
		    (VIP_NET_ADDRESS *) &Args.RemoteAddr);
	
	/* XXX: assert state == connected */
	if(copy_to_user(Args.RemoteViAttribs,
			&Vi->RemoteViAttribs, 
			sizeof(VIP_VI_ATTRIBUTES))) {
	    VipkPostError(Vi, VIP_RESOURCE_VI, VIP_ERROR_CONN_LOST);
	    Status = VIP_INVALID_PARAMETER;
	}
    }

    return Status;
}

VIP_RETURN
VipkViConnectionLost(VIPK_DEVICE	*DevicePtr,
		     VIPK_VI		*Vi,
		     VIP_UINT32		Session,
		     VIP_UINT32		Sequence)
{
    unsigned long Flags;

    if(Vi == NULL) {
	return VIP_INVALID_PARAMETER;
    }

    spin_lock_irqsave(&Vi->Lock, Flags);    
    if(Vi->State == VIP_STATE_CONNECTED && Vi->Session == Session) {
	/* We don't just call VipkPostError() here because doing so would
	 * result in an extra ConnLost sent back to the remote node.
	 */
    
	Vi->State = VIP_STATE_ERROR;
	spin_unlock_irqrestore(&Vi->Lock, Flags);    

	/* Flush Recv queue */
	VipkViFlushDescs(Vi->DevicePtr, Vi, VIP_TRUE);

	/* Flush Send queue */
	VipkViFlushDescs(Vi->DevicePtr, Vi, VIP_FALSE);

	VipkEQEnqueue(Vi->FilePtr->EQHandle, 
		      Vi->FilePtr->NicUserHandle,
		      Vi->UserViHandle, 
		      NULL, /* CQ Handle */
		      NULL, /* DESC */
		      0, /* OP_CODE */
		      VIP_RESOURCE_VI,
		      VIP_ERROR_CONN_LOST);
    } else {
	spin_unlock_irqrestore(&Vi->Lock, Flags);    
    }
    
    return VIP_SUCCESS;
}

VIP_RETURN
VipkConnectionLost(VIPK_DEVICE		*DevicePtr,
		   VIPK_VI_HANDLE	ViHandle,
		   VIP_UINT32		Session,
		   VIP_UINT32		Sequence,
		   VIP_BOOLEAN		IsError)
{
    VIP_RETURN Status;

    Status = VIP_SUCCESS;
    if(IsError) {
	Status = VipkViConnectionLost(DevicePtr,
				      VipkViLookup(DevicePtr, ViHandle),
				      Session,
				      Sequence);
    }

    return Status;
}

/** 
 * Flush all Vi Descriptors regardless of the state of the VI.
 *
 * This function can not flush through a bad descriptor chain.  If a bad
 * descriptor is encountered, it will truncate the chain.
 * 
 * @param DevicePtr 	Pointer to device structure.
 * @param Vi		Vi to have its descriptors flushed.
 * @param Recv		If \c VIP_TRUE, indicates that it is the receive queue
 *			which should be flushed, otherwise flush the 
 *			send queue.
 */
void VipkViFlushDescs(VIPK_DEVICE	*DevicePtr,
		      VIPK_VI		*Vi,
		      VIP_BOOLEAN	Recv)

{
    VIP_DESCRIPTOR	*UserDesc;
    VIP_DESCRIPTOR	*KernDesc = NULL;
    VIP_DESCRIPTOR	*PrevKernDesc = NULL;
    VIP_MEM_HANDLE	MemHandle;

    if(Recv) {
	UserDesc = Vi->RecvDesc;
	MemHandle = Vi->RecvMemHandle;
    } else {
	UserDesc = Vi->SendDesc;
	MemHandle = Vi->SendMemHandle;
    }
    
    while(UserDesc) {
	KernDesc = NULL;

	if((VIP_ULONG) UserDesc & (VIP_DESCRIPTOR_ALIGNMENT-1)) {
	    break;
	}
	
	KernDesc = VipkRmmKaddr(DevicePtr->RmmHandle,
				UserDesc, MemHandle, Vi->ViAttribs.Ptag,
				VIPK_RMM_MEM_FLAGS_WRITE,
				Vi->FilePtr->NicInstance);

	if(KernDesc == NULL) {
	    break;
	}

	/* make sure we have not looped */
	if(KernDesc->CS.Status & VIP_STATUS_DESC_FLUSHED_ERROR) {
	    break;
	}

	if(Recv) {
	    /* STATUS_OP_RECEIVE won't clobber STATUS_OP_REMOTE_RDMA_WRITE */
	    VipkViRecvComplete(DevicePtr, Vi, KernDesc, NULL, 
			       VIP_STATUS_OP_RECEIVE |
			       VIP_STATUS_DESC_FLUSHED_ERROR |
			       VIP_STATUS_DONE);
	} else {
	    VIP_UINT32 StatusBits = VIP_STATUS_OP_SEND |
				    VIP_STATUS_DESC_FLUSHED_ERROR |
				    VIP_STATUS_DONE;
	    if((KernDesc->CS.Control & VIP_CONTROL_OP_MASK) ==
						VIP_CONTROL_OP_RDMAWRITE) {
		StatusBits |= VIP_STATUS_OP_RDMA_WRITE;
	    }
	    VipkViSendComplete(DevicePtr, Vi, KernDesc, StatusBits);
	}

	PrevKernDesc = KernDesc;
	UserDesc = KernDesc->CS.Next.Address;
	MemHandle = KernDesc->CS.NextHandle;
    }

    /* Truncate a chain if it is broken in the middle by a bad descriptor */
    if(KernDesc == NULL && PrevKernDesc) {
	PrevKernDesc->CS.Next.Address = NULL;
    }

    if(Recv) {
	Vi->RecvDesc = NULL;
    } else {
	Vi->SendDesc = NULL;
    }
}

/** 
 * Perform Kernel Agent half of VipDisconnect().
 *
 * @param DevicePtr 	Pointer to device structure.
 * @param ViHandle	Vi Handle to disconnect.
 * @return		See IDG Section 3.3.5 for details. 
 */
VIP_RETURN
VipkDisconnect(VIPK_DEVICE	*DevicePtr,
	       VIPK_VI_HANDLE	ViHandle)
{
    VIPK_VI	*Vi;
    unsigned long Flags;

    TRACE(VIPK_TRACE_DISCONNECT, "[%d] %s ViHandle: 0x%x", 
	  current->pid, DevicePtr->DeviceName, ViHandle);

    Vi = VipkViLookup(DevicePtr, ViHandle);
    if(Vi == NULL || !VipkViVerifyOwner(Vi)) {
	TRACE(VIPK_TRACE_DISCONNECT, "%s Bad ViHandle", DevicePtr->DeviceName);
	return VIP_INVALID_PARAMETER;
    }

    /*
     * Section 4.2 of says we may cause an async error (VIP_ERROR_CONN_LOST)
     * on the remote endpoint when we disconnect "but this feature is not
     * required." IDG Section 6.2 promotes this behavior to "recommended".
     * The down side is that with our default async error handler every
     * normal termination of a VI consumer will result in a message that
     * an "Asynchronous error occured" at one endpoint or the other.  So,
     * at least for now we send a non-error disconnect notice (the final
     * argument to SendConnLost is FALSE).
     */

    if(Vi->State == VIP_STATE_CONNECTED) {
	DevicePtr->DeviceOps->SendConnLost(DevicePtr, Vi, VIP_FALSE);
    } else if(Vi->State == VIP_STATE_CONNECT_PENDING) {
	VIP_RETURN	Status;

	Status = DevicePtr->Cm.Disconnect(&DevicePtr->Cm,
					  Vi->FilePtr->NicInstance,
					  Vi);
	if(Status != VIP_SUCCESS) {
	    return Status;
	}
    }

    Vi->ConnectionLost = VIP_FALSE;

    spin_lock_irqsave(&Vi->Lock, Flags);
    Vi->State = VIP_STATE_IDLE;
    spin_unlock_irqrestore(&Vi->Lock, Flags);

    /* Flush Recv queue */
    VipkViFlushDescs(DevicePtr, Vi, VIP_TRUE);

    /* Flush Send queue */
    VipkViFlushDescs(DevicePtr, Vi, VIP_FALSE);
    
    return VIP_SUCCESS;
}

/**
 * Perform Kernel Agent portion of VipConnectPeerRequest.
 *
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param UserArgs		Arguments from the ioctl structure.
 * @return 			See IDG Section 3.3.6 for details.
 */
VIP_RETURN
VipkConnectPeerRequest(VIPK_DEVICE		*DevicePtr,
		       VIPK_FILE		*VipkFilePtr,
		       VIP_PEER_REQUEST_ARGS	*UserArgs)
{
    VIPK_VI			*Vi;
    VIP_PEER_REQUEST_ARGS	Args;
    VIP_RETURN			Status = VIP_SUCCESS;

    TRACE(VIPK_TRACE_NIC_OPS | VIPK_TRACE_CM, "[%d] %s",
	  current->pid, DevicePtr->DeviceName);

    copy_from_user_ret(&Args, UserArgs,
		       sizeof(VIP_PEER_REQUEST_ARGS), 
		       VIP_INVALID_PARAMETER);

    Vi = VipkViLookup(DevicePtr, Args.ViHandle);
    if(Vi == NULL || !VipkViVerifyOwner(Vi)) {
	TRACE(VIPK_TRACE_NIC_OPS | VIPK_TRACE_CM, "[%d] %s VI is invalid",
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_PARAMETER;
    }

    if(VipkAddrVerifySize(DevicePtr,
			  (VIP_NET_ADDRESS *)&Args.LocalAddr) != VIP_SUCCESS) {
	TRACE(VIPK_TRACE_NIC_OPS | VIPK_TRACE_CM, "[%d] %s Bad local addr",
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_PARAMETER;
    }

    if(VipkAddrVerifySize(DevicePtr,
			  (VIP_NET_ADDRESS *)&Args.RemoteAddr) != VIP_SUCCESS){
	TRACE(VIPK_TRACE_NIC_OPS | VIPK_TRACE_CM, "[%d] %s Bad remote addr",
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_PARAMETER;
    }


    if(!VipkAddrNicHostEq(DevicePtr, (VIP_NET_ADDRESS *)&Args.LocalAddr)) {
	TRACE(VIPK_TRACE_NIC_OPS | VIPK_TRACE_CM, "[%d] %s Bad local addr",
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_PARAMETER;
    }

    if(Args.Timeout == 0) {
	TRACE(VIPK_TRACE_CM, "[%d] %s timeout of zero",
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_PARAMETER;
    }

    Status = DevicePtr->Cm.PeerRequest(&DevicePtr->Cm,
				       VipkFilePtr->NicInstance,
				       Args.ViHandle,
				       Vi,
				       (VIP_NET_ADDRESS *) &Args.LocalAddr,
				       (VIP_NET_ADDRESS *) &Args.RemoteAddr,
				       Args.Timeout);

    return Status;
}

/**
 * Perform Kernel Agent portion of VipConnectPeer{Done,Wait}.
 *
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param ViHandle		Vi Handle to check for connect completion on.
 * @param RemoteViAttrs		Pointer to VI attributes structure.
 * @param Block			TRUE=...Wait and FALSE=...Done
 * @return 			See IDG Sections 3.3.7 and 3.3.8 for details.
 */
VIP_RETURN
VipkConnectPeerDone(VIPK_DEVICE		*DevicePtr,
		    VIPK_FILE		*FilePtr,
		    VIPK_VI_HANDLE	ViHandle,
		    VIP_VI_ATTRIBUTES	*RemoteViAttrs,
		    VIP_BOOLEAN		Block)
{
    VIPK_VI		*Vi;
    VIP_RETURN		Status;

    TRACE(VIPK_TRACE_NIC_OPS | VIPK_TRACE_CM, "[%d] %s",
	  current->pid, DevicePtr->DeviceName);

    Vi = VipkViLookup(DevicePtr, ViHandle);
    if(Vi == NULL || !VipkViVerifyOwner(Vi)) {
	TRACE(VIPK_TRACE_NIC_OPS | VIPK_TRACE_CM, "[%d] %s VI is invalid",
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_PARAMETER;
    }

    Status = DevicePtr->Cm.PeerDone(&DevicePtr->Cm,
				    FilePtr->NicInstance, Vi, Block);

    if(Status == VIP_SUCCESS) {
	/* XXX: assert state == connected */
	if(copy_to_user(RemoteViAttrs,
			&Vi->RemoteViAttribs, 
			sizeof(VIP_VI_ATTRIBUTES))) {
	    VipkPostError(Vi, VIP_RESOURCE_VI, VIP_ERROR_CONN_LOST);
	    Status = VIP_INVALID_PARAMETER;
	}
    }

    return Status;
}

/** 
 * Perform Kernel Agent half of VipPostRecv for emulated VI NICs.
 *
 * Only set the descriptor pointer and memory handle information in 
 * the Vi state if the Vi receive queue is empty.  Otherwise, 
 * the descriptor chain will be followed directly in the user's address 
 * space while receiving data.
 *
 * @param DevicePtr 	Pointer to device structure.
 * @param ViHandle	Vi Handle to post the receive descriptor to.
 * @param Desc		Pointer to the receive descriptor in user space.
 * @param MemHandle	Memory Handle of the descriptor to be posted.
 * @return 		See IDG Section 3.5.4 for details.
 */
VIP_RETURN
VipkPostRecv(VIPK_DEVICE	*DevicePtr,
	     VIPK_VI_HANDLE	ViHandle,
	     VIP_DESCRIPTOR	*Desc,
	     VIP_MEM_HANDLE	MemHandle)
{
    VIPK_VI	*Vi;

    TRACE(VIPK_TRACE_POSTR,
	  "[%d] %s ViHandle: 0x%x Desc 0x%p MemHandle 0x%08x", 
	  current->pid, DevicePtr->DeviceName, ViHandle,
	  (void *)Desc, MemHandle);

    Vi = VipkViLookup(DevicePtr, ViHandle);
    if(Vi == NULL || !VipkViVerifyOwner(Vi)) {
	goto err_bad_vi;
    }

    if(Vi->RecvDesc == NULL) {
	TRACE(VIPK_TRACE_POSTR, "[%d] %s Setting RecvDesc: 0x%p", 
	      current->pid, DevicePtr->DeviceName, (void *)Desc);

	Vi->RecvDesc = Desc;
	Vi->RecvMemHandle = MemHandle;

	/* XXX: this is implied by conformance tests, but look in
	 * the spec to find out if it should really do this.
	 * Also, calling flush descs is a bit overkill.
	 */
	if(Vi->State == VIP_STATE_ERROR) {
	    VipkViFlushDescs(DevicePtr, Vi, VIP_TRUE);
	    return VIP_SUCCESS;
	}
    } else {
	TRACE(VIPK_TRACE_POSTR, "[%d] %s RecvDesc already set to: 0x%p",
	      current->pid, DevicePtr->DeviceName, (void *)Vi->RecvDesc);
    }

    if((VIP_ULONG) Desc & (VIP_DESCRIPTOR_ALIGNMENT-1)) {
	goto err_bad_align;
    }

    /* XXX: this should be wrapped in an ifdef in my opinion.  These
     * errors will be caught at recv time, as they MUST be rechecked
     * anyway.  These checks are required for the conformance tests
     * to differencitate between POST_DESC errors and COMP_PROT errors.
     */
    
    /* convert the user descriptor ptr to one in the kernel addr space */
    if(VipkRmmKaddr(DevicePtr->RmmHandle,
		    Desc, MemHandle,
		    Vi->ViAttribs.Ptag,
		    VIPK_RMM_MEM_FLAGS_WRITE,
		    Vi->FilePtr->NicInstance) == NULL) {

	goto err_bad_kdesc;
    }	

    return VIP_SUCCESS;

 err_bad_vi:
    TRACE(VIPK_TRACE_POSTR, "%s Bad ViHandle", DevicePtr->DeviceName);
    return VIP_INVALID_PARAMETER;

 err_bad_align:
    TRACE(VIPK_TRACE_POSTR, "[%d] %s Bad descriptor alignment 0x%p",
	  current->pid, DevicePtr->DeviceName, (void *)Desc);
    VipkPostDescError(Vi, Desc, VIP_RESOURCE_DESCRIPTOR, VIP_ERROR_POST_DESC);
    return VIP_SUCCESS;

 err_bad_kdesc:
    TRACE(VIPK_TRACE_POSTR, "%s MemHandle/Descriptor not valid", 
	  DevicePtr->DeviceName);
    VipkPostDescError(Vi, Desc, VIP_RESOURCE_DESCRIPTOR, VIP_ERROR_POST_DESC);
    return VIP_SUCCESS;
}

/** 
 * Perform Kernel Agent half of VipPostSend for emulated VI NICs.
 *
 * @param DevicePtr 	Pointer to device structure.
 * @param ViHandle	Vi Handle to post the send descriptor to.
 * @param Desc		Pointer to the receive descriptor in user space.
 * @param MemHandle	Memory Handle of the descriptor to be posted.
 * @return 		See IDG Section 3.5.4 for details.
 * 
 * Note that since all sends are synchronous on loopback, there is no
 * need to maintain SendSeq here.
 */
VIP_RETURN
VipkPostSend(VIPK_DEVICE	*DevicePtr,
	     VIPK_VI_HANDLE	ViHandle,
	     VIP_DESCRIPTOR	*Desc,
	     VIP_MEM_HANDLE	MemHandle)
{
    VIPK_VI 		*Vi;
    VIP_DESCRIPTOR	*KernDesc;

    VIP_UINT32		Count;

    VIP_UINT32		*IDataPtr = NULL;

    VIP_MEM_HANDLE	RemoteMemHandle = 0;
    VIP_PVOID		RemoteUserPtr = NULL;

    VIP_UINT16		Control;

    VIP_UINT16		SegIndex;
    VIP_UINT16		DevSegsSent;
    VIP_UINT16		SegCnt;
    VIP_UINT16		SegRem;

    VIP_BOOLEAN		RecvOK;
    VIP_BOOLEAN		FirstFrag;

    TRACE(VIPK_TRACE_POSTS, "[%d] %s", current->pid, DevicePtr->DeviceName);

    Vi = VipkViLookup(DevicePtr, ViHandle);
    if(Vi == NULL || !VipkViVerifyOwner(Vi)) {
	goto err_bad_vi;
    }

    if(Vi->SendDesc == NULL) {
	TRACE(VIPK_TRACE_POSTS, "[%d] %s Setting SendDesc: 0x%p", 
	      current->pid, DevicePtr->DeviceName, (void *)Desc);
	Vi->SendDesc = Desc;
	Vi->SendMemHandle = MemHandle;
    } else {
	TRACE(VIPK_TRACE_POSTS, "[%d] %s SendDesc already set to: 0x%p",
	      current->pid, DevicePtr->DeviceName, (void *)Vi->SendDesc);
    }

    /* Reject preposted sends */
    if(Vi->State != VIP_STATE_CONNECTED) {
	goto err_bad_state;
    }

    if((VIP_ULONG) Desc & (VIP_DESCRIPTOR_ALIGNMENT-1)) {
	goto err_bad_align;
    }

    KernDesc = VipkRmmKaddr(DevicePtr->RmmHandle, Desc, 
			    MemHandle, Vi->ViAttribs.Ptag,
			    VIPK_RMM_MEM_FLAGS_WRITE,
			    Vi->FilePtr->NicInstance);

    if(KernDesc == NULL) {
	goto err_bad_kaddr;
    }

    Control = KernDesc->CS.Control;
    if(((Control & VIP_CONTROL_OP_MASK) == VIP_CONTROL_OP_RDMAREAD) ||
       VipkDescFormatError(KernDesc)) {
	goto err_bad_format;
    }

    /*
     * Initialize various lengths and counters
     */
    SegCnt = SegRem = KernDesc->CS.SegCount;
    SegIndex = 0;

    DevSegsSent = 0;

    RecvOK = VIP_TRUE;
    FirstFrag = VIP_TRUE;

    Count = KernDesc->CS.Length;

    /*
     * Initialize the Status field, if rmda, will be overridden later
     */
    KernDesc->CS.Status = VIP_STATUS_OP_SEND;

    if(Control & VIP_CONTROL_IMMEDIATE) {
	IDataPtr = &KernDesc->CS.ImmediateData;
    }

    /* If this is a remote operation, then the first addr is the remote
     * addr.  Save it off and then loop over the remaining local data
     * segments.
     */
    if(Control & VIP_CONTROL_OP_RDMAWRITE) {
	const VIP_DESCRIPTOR_SEGMENT *KernSeg;

	TRACE(VIPK_TRACE_POSTS, "[%d] %s setting up RDMA Write",
	      current->pid, DevicePtr->DeviceName);

	KernDesc->CS.Status = VIP_STATUS_OP_RDMA_WRITE;
	
	KernSeg = (VIP_DESCRIPTOR_SEGMENT *)
	    VipkRmmKaddr(DevicePtr->RmmHandle, &Desc->DS[0],
			 MemHandle, Vi->ViAttribs.Ptag,
			 VIPK_RMM_MEM_FLAGS_READ,
			 Vi->FilePtr->NicInstance);

	if(KernSeg == NULL) {
	    goto err_bad_kseg;
	}

	RemoteMemHandle = KernSeg->Remote.Handle;	
#if (BITS_PER_LONG == 64)
	/* Need all 64 bits of the field */
	RemoteUserPtr = (VIP_PVOID)KernSeg->Remote.Data.AddressBits;
#elif (BITS_PER_LONG == 32)
        /* Need only the least significant 32 bits of the field */
	RemoteUserPtr = (VIP_PVOID)(VIP_UINT32)KernSeg->Remote.Data.AddressBits;
#else
#	error "Unknown wordsize"
#endif

	SegRem--;
	SegIndex++;
    }

    /*
     * These checks must be performed after the rmda check under the
     * current error handling logic.  This is so that the correct
     * STATUS_OP will be set
     */
    if(Count > Vi->ViAttribs.MaxTransferSize) {
	goto err_bad_len1;
    }
    if(SegCnt > DevicePtr->NicAttribs->MaxSegmentsPerDesc) {
	goto err_bad_len2;
    }

    /* loop over all the segments in the descriptor.
     * "if(X) do {Y} while(X)" has one less branch than "while(X) {Y}"
     */
    if(!SegRem) {
	goto done;
    }
    do {
	const VIP_DESCRIPTOR_SEGMENT 	*KernSeg;
	VIP_PVOID			Ptr;
	VIP_UINT32 			SegLen;
	
	KernSeg = (VIP_DESCRIPTOR_SEGMENT *)
	    VipkRmmKaddr(DevicePtr->RmmHandle,
			 &Desc->DS[SegIndex],
			 MemHandle,
			 Vi->ViAttribs.Ptag,
			 VIPK_RMM_MEM_FLAGS_READ,
			 Vi->FilePtr->NicInstance);

	if(KernSeg == NULL) {
	    goto err_bad_kseg;
	}

	SegRem--;
	SegIndex++;
	Ptr = (caddr_t) KernSeg->Local.Data.Address;
	SegLen = KernSeg->Local.Length;

	if(SegLen == 0) {
	    continue;
	}
	if(SegLen > Count) {
	    goto err_bad_len3;
	}

	/* loop over data in segment in page chunks/mtu size */
	do {
	    const caddr_t KPtr = VipkRmmKaddr(DevicePtr->RmmHandle,
					      Ptr,
					      KernSeg->Local.Handle,
					      Vi->ViAttribs.Ptag,
					      VIPK_RMM_MEM_FLAGS_READ,
					      Vi->FilePtr->NicInstance);

	    const unsigned long PageBreak = PAGE_SIZE -
		((unsigned long) Ptr & ~PAGE_MASK);

	    /* There is no real reason to honor the NativeMTU here.
	     * It is larger than PAGE_SIZE (and thus PageBreak) anyway.
	     */
	    const VIP_UINT32 SegXferLen = min(PageBreak, (unsigned long)SegLen);

	    if(KPtr == NULL) {
		goto err_bad_kptr;
	    }

	    Count -= SegXferLen;
	    Ptr += SegXferLen;
	    SegLen -= SegXferLen;

	    if(RecvOK) {
		if(Control & VIP_CONTROL_OP_RDMAWRITE) {
		    TRACE(VIPK_TRACE_POSTS, "[%d] %s RDMA Write len: %d",
			  current->pid, DevicePtr->DeviceName, SegXferLen);

		    RecvOK = VipkRecvRdmaWrite(DevicePtr, Vi->RemoteViHandle,
					       KPtr, SegXferLen, 
					       RemoteUserPtr, RemoteMemHandle,
					       IDataPtr, FirstFrag, VIP_FALSE);

		    RemoteUserPtr += SegXferLen;
		} else {
		    TRACE(VIPK_TRACE_POSTS, "[%d] %s Sending len: %d",
			  current->pid, DevicePtr->DeviceName, SegXferLen);

		    RecvOK = VipkRecv(DevicePtr, Vi->RemoteViHandle, 
				      KPtr, SegXferLen, IDataPtr,
				      FirstFrag, VIP_FALSE);
		}
	    } else {
		/* Vipk{Recv,RecvRdmaWrite} has indicated a remote error
		 * and so we should not send any more data across.
		 * However, we must continue to loop over the descriptors
		 * to look for errors which must be reported at this end.
		 */
	    }

	    FirstFrag = VIP_FALSE;
	    
	} while(SegLen);
    } while(SegRem);

 done:
    if(Count) {
	goto err_bad_len4;
    }

    VipkViSendComplete(DevicePtr, Vi, KernDesc, VIP_STATUS_DONE);

    /* Send a zero-length LastFrag to allow recv to complete */
    if(RecvOK) {
	if(Control & VIP_CONTROL_OP_RDMAWRITE) {
	    TRACE(VIPK_TRACE_POSTS, "[%d] %s RDMA Write done",
		  current->pid, DevicePtr->DeviceName);

	    VipkRecvRdmaWrite(DevicePtr, Vi->RemoteViHandle,
			      NULL, 0,
			      RemoteUserPtr, RemoteMemHandle,
			      IDataPtr, FirstFrag, VIP_TRUE);
	} else {
	    TRACE(VIPK_TRACE_POSTS, "[%d] %s Sending done",
		  current->pid, DevicePtr->DeviceName);

	    VipkRecv(DevicePtr, Vi->RemoteViHandle, 
		     NULL, 0, IDataPtr,
		     FirstFrag, VIP_TRUE);
	}
    }

    if(Vi->ConnectionLost) {
	VipkViConnectionLost(DevicePtr, Vi, Vi->Session, Vi->ConnLostSeq);
    }
    return VIP_SUCCESS;


 err_bad_vi:
    TRACE(VIPK_TRACE_POSTS, "[%d] %s Bad ViHandle",
	  current->pid, DevicePtr->DeviceName);
    return VIP_INVALID_PARAMETER;

 err_bad_state:
    TRACE(VIPK_TRACE_POSTS, "[%d] %s Invalid Vi State(%d)",
	  current->pid, DevicePtr->DeviceName, Vi->State);
    VipkViFlushDescs(DevicePtr, Vi, VIP_FALSE);
    return VIP_SUCCESS;

 err_bad_align:
    TRACE(VIPK_TRACE_POSTS, "[%d] %s Bad descriptor alignment 0x%p",
	  current->pid, DevicePtr->DeviceName, (void *)Desc);
    VipkPostDescError(Vi, Desc, VIP_RESOURCE_DESCRIPTOR, VIP_ERROR_POST_DESC);
    return VIP_SUCCESS;

 err_bad_kaddr:
    TRACE(VIPK_TRACE_POSTS, "[%d] %s MemHandle/Descriptor not valid",
	  current->pid, DevicePtr->DeviceName);
    VipkPostDescError(Vi, Desc, VIP_RESOURCE_DESCRIPTOR, VIP_ERROR_POST_DESC);
    return VIP_SUCCESS;

 err_bad_format:
    TRACE(VIPK_TRACE_POSTS, "[%d] %s Descriptor Format Error",
	  current->pid, DevicePtr->DeviceName);
    KernDesc->CS.Status |= VIP_STATUS_FORMAT_ERROR;
    goto err_out;

 err_bad_len1:
    TRACE(VIPK_TRACE_POSTS, "[%d] %s Bad Length (CS.Length > MTS)",
	  current->pid, DevicePtr->DeviceName);
    KernDesc->CS.Status |= VIP_STATUS_LENGTH_ERROR;
    goto err_out;

 err_bad_len2:
    TRACE(VIPK_TRACE_POSTS, "[%d] %s Bad Seg Count",
	  current->pid, DevicePtr->DeviceName);
    KernDesc->CS.Status |= VIP_STATUS_LENGTH_ERROR;
    goto err_out;

 err_bad_len3:
    TRACE(VIPK_TRACE_POSTS, "[%d] %s Bad Length (CS.Length < Segs)",
	  current->pid, DevicePtr->DeviceName);
    KernDesc->CS.Status |= VIP_STATUS_LENGTH_ERROR;
    goto err_out;

 err_bad_len4:
    TRACE(VIPK_TRACE_POSTS, "[%d] %s Bad Length (CS.Length > Segs)",
	  current->pid, DevicePtr->DeviceName);
    KernDesc->CS.Status |= VIP_STATUS_LENGTH_ERROR;
    goto err_out;

 err_bad_kseg:
    TRACE(VIPK_TRACE_POSTS, "[%d] %s Segment/MemHandle not valid",
	  current->pid, DevicePtr->DeviceName);
    KernDesc->CS.Status |= VIP_STATUS_PROTECTION_ERROR;
    goto err_out;

 err_bad_kptr:
    TRACE(VIPK_TRACE_POSTS, "[%d] %s DataAddr/DataHandle not valid",
	  current->pid, DevicePtr->DeviceName);
    KernDesc->CS.Status |= VIP_STATUS_PROTECTION_ERROR;
    goto err_out;

 err_out:
    VipkViSendCompleteErr(Vi, KernDesc);
    if(Vi->ConnectionLost) {
	VipkViConnectionLost(DevicePtr, Vi, Vi->Session, Vi->ConnLostSeq);
    }
    return VIP_SUCCESS;
}

/** 
 * Receive a potentially fragmented VIA packet for an emulated VI.
 *
 * This function is callable by all emulated VIA devices to receive 
 * VIA packets.
 *
 * @param DevicePtr 	Pointer to device structure.
 * @param ViHandle	Vi Handle to post the send descriptor to.
 * @param Buf		Buffer to receive the data from
 * @param Length	Length of data buffer.
 * @param IDataPtr	If non-NULL, points to immediate data to place in
 *			receive descriptor.
 * @param FirstFragment If \c VIP_TRUE, indicates this is the first packet.
 * @param LastFragment	If \c VIP_TRUE, indicates this is the last packet.
 * @return 	\c VIP_TRUE - The receive descriptor is capable of 
 *		receiving more data.<br>
 *		\c VIP_FALSE - The receive descriptor has been consumed or
 *		an error condition prevents reception.
 */
VIP_BOOLEAN
VipkRecv(VIPK_DEVICE	*DevicePtr,
	 VIPK_VI_HANDLE	ViHandle,
	 VIP_PVOID	Buf,
	 VIP_UINT32	Length,
	 VIP_UINT32	*IDataPtr,
	 VIP_BOOLEAN	FirstFragment,
	 VIP_BOOLEAN	LastFragment)
{
    VIPK_VI *Vi;

    VIP_DESCRIPTOR 	*KernDesc;
    VIP_UINT16		SegCount;
    VIP_UINT16		SegIndex;
    VIP_UINT32		SegLen;

    VIP_UINT32		OrigLen = Length;
    
    VIP_PVOID		Ptr;

    TRACE(VIPK_TRACE_RECV,
	  "%s ViHandle 0x%x Length %d FirstFrag: 0x%x LastFrag 0x%x", 
	  DevicePtr->DeviceName, ViHandle, Length,
	  FirstFragment, LastFragment);

    Vi = VipkViLookup(DevicePtr, ViHandle);
    if(Vi == NULL) {
	goto err_bad_vi;
    }

    /* XXX: Should we also check Vi->Session to be
     * sure this isn't just a very late arrival? */

    if(Vi->State != VIP_STATE_CONNECTED) {
	goto err_bad_state;
    }

    if(Vi->RecvDesc == NULL) {
	goto err_no_desc;
    }

    if((VIP_ULONG) Vi->RecvDesc & (VIP_DESCRIPTOR_ALIGNMENT-1)) {
	goto err_bad_align;
    }

    
    /* convert the user descriptor ptr to one in the kernel addr space */
    KernDesc = (VIP_DESCRIPTOR *) VipkRmmKaddr(DevicePtr->RmmHandle,
					       Vi->RecvDesc,
					       Vi->RecvMemHandle,
					       Vi->ViAttribs.Ptag,
					       VIPK_RMM_MEM_FLAGS_WRITE,
					       Vi->FilePtr->NicInstance);

    TRACE(VIPK_TRACE_RECV, "%s Desc: 0x%p KernDesc: 0x%p RecvXferLen: %d",
	  DevicePtr->DeviceName, (void *)Vi->RecvDesc,
	  (void *)KernDesc, Vi->RecvXferLen);

    if(KernDesc == NULL) {
	goto err_bad_kdesc;
    }

    if(FirstFragment) {
	Vi->RecvXferLen = 0;
	Vi->RecvSegIndex = 0;
	Vi->RecvSegLen = 0;
	Vi->RecvPtr = NULL;
    }

    KernDesc->CS.Status = VIP_STATUS_OP_RECEIVE;
    SegCount = KernDesc->CS.SegCount;
    SegIndex = Vi->RecvSegIndex;

    if(SegCount > DevicePtr->NicAttribs->MaxSegmentsPerDesc) {
	goto err_bad_segcnt;
    }
    
    /* Fast path 0 byte messages */
    if(Length == 0) {
	TRACE(VIPK_TRACE_RECV, "%s Length: %d SegIndex: %d",
	      DevicePtr->DeviceName, Length, SegIndex);
	goto out_done;
    }

    /* if we are in the middle of a segment use continuation values
     * these will be 0 and null otherwise
     */
    SegLen = Vi->RecvSegLen;
    Ptr = Vi->RecvPtr;

    /* loop over descriptors, picking up if we left off */
    do {
	const VIP_DESCRIPTOR_SEGMENT *KernSeg;

	/* Check for end of descriptor */
	if(SegIndex == SegCount) {
	    goto err_bad_length;
	}

	/* calc the kernel addr of the segment */
	KernSeg = (VIP_DESCRIPTOR_SEGMENT *)
	    VipkRmmKaddr(DevicePtr->RmmHandle, &(Vi->RecvDesc->DS[SegIndex]),
			 Vi->RecvMemHandle, Vi->ViAttribs.Ptag,
			 VIPK_RMM_MEM_FLAGS_READ,
			 Vi->FilePtr->NicInstance);

	if(KernSeg == NULL) {
	    goto err_bad_kseg;
	}

	/* if we are not continuing a fragmented receive in the middle
	 * of a descriptor segment, pull the values out of the segment
	 */
	if(!SegLen) {
	    SegLen = KernSeg->Local.Length;
	    Ptr = KernSeg->Local.Data.Address;
	}

	/* copy into buffer in page line chunks */
	do {
	    const VIP_PVOID KernPtr = VipkRmmKaddr(DevicePtr->RmmHandle,
						   Ptr,
						   KernSeg->Local.Handle,
						   Vi->ViAttribs.Ptag,
						   VIPK_RMM_MEM_FLAGS_WRITE,
						   Vi->FilePtr->NicInstance);

	    const unsigned long PageBreak = PAGE_SIZE - 
		((unsigned long) Ptr & ~PAGE_MASK);

	    const VIP_UINT32 SegXfer = min((unsigned long)SegLen, min(PageBreak, (unsigned long)Length));

	    TRACE(VIPK_TRACE_RECV,
		  "%s SegIndex %d SegLen: %d PB: %ld Len: %d",
		   DevicePtr->DeviceName, SegIndex, SegLen, PageBreak, Length);

	    if(KernPtr == NULL) {
	    TRACE(VIPK_TRACE_RECV, "%s Bad kseg", DevicePtr->DeviceName);
		goto err_bad_kptr;
	    }

	    TRACE(VIPK_TRACE_RECV,
		  "%s chunk Ptr: 0x%p KernPtr: 0x%p Buf: 0x%p SegXfer: %d",
		  DevicePtr->DeviceName, Ptr, KernPtr, Buf, SegXfer);
	    
	    memcpy(KernPtr, Buf, SegXfer);

	    Ptr += SegXfer;
	    Buf += SegXfer;
	    Length -= SegXfer;
	    SegLen -= SegXfer;

	    if (!SegLen) {
		SegIndex++;
		break;
	    }
	} while(Length);
    } while(Length);

    Vi->RecvXferLen += OrigLen;
    
    if(!LastFragment) {
	TRACE(VIPK_TRACE_RECV, "%s Data remaining in descriptor", 
	      DevicePtr->DeviceName);

	Vi->RecvSegIndex = SegIndex;
	Vi->RecvSegLen = SegLen;
	Vi->RecvPtr = Ptr;

	return VIP_TRUE;
    }

 out_done:
    VipkViRecvComplete(DevicePtr, Vi, KernDesc, IDataPtr, VIP_STATUS_DONE);
    return VIP_FALSE;


 err_bad_vi:
    TRACE(VIPK_TRACE_RECV, "%s Bad ViHandle", DevicePtr->DeviceName);
    return VIP_FALSE;

 err_bad_state:
    TRACE(VIPK_TRACE_RECV, "%s Vi not connected", DevicePtr->DeviceName);
    return VIP_FALSE;

 err_bad_align:
    TRACE(VIPK_TRACE_RECV, "%s Bad descriptor alignment 0x%p",
	  DevicePtr->DeviceName, (void *)Vi->RecvDesc);
    Vi->RecvSeq++;
    VipkPostDescError(Vi, Vi->RecvDesc, 
		      VIP_RESOURCE_DESCRIPTOR, VIP_ERROR_POST_DESC);
    return VIP_FALSE;

 err_no_desc:
    TRACE(VIPK_TRACE_RECV, "%s No receive descriptors available",
	  DevicePtr->DeviceName);
    Vi->RecvSeq++;
    if(Vi->ViAttribs.ReliabilityLevel > VIP_SERVICE_UNRELIABLE) {
	/* XXX: SPEC: acording to Error Table Suppliment, this is NOT
	 * posted to the caller for unreliable delivery.  This seems wrong.
	 */
	VipkPostError(Vi, VIP_RESOURCE_VI, VIP_ERROR_RECVQ_EMPTY);
    } else {
	Vi->RecvXferLen = 0;
    }
    return VIP_FALSE;

 err_bad_kdesc:
    TRACE(VIPK_TRACE_RECV, "%s MemHandle/Descriptor not valid", 
	  DevicePtr->DeviceName);
    Vi->RecvSeq++;
    VipkPostDescError(Vi, Vi->RecvDesc, VIP_RESOURCE_DESCRIPTOR,
		      VIP_ERROR_COMP_PROT);
    return VIP_FALSE;

 err_bad_segcnt:
    TRACE(VIPK_TRACE_RECV, "%s Bad Seg Length", DevicePtr->DeviceName);
    KernDesc->CS.Status |= VIP_STATUS_LENGTH_ERROR;
    goto err_out;
    
 err_bad_kseg:
    TRACE(VIPK_TRACE_RECV, "%s DataHandle/Data not valid", 
	  DevicePtr->DeviceName);
    KernDesc->CS.Status |= VIP_STATUS_PROTECTION_ERROR;
    goto err_out;

 err_bad_kptr:
    TRACE(VIPK_TRACE_RECV, "%s Data address/MemHandle not valid", 
	  DevicePtr->DeviceName);
    KernDesc->CS.Status |= VIP_STATUS_PROTECTION_ERROR;
    goto err_out;

 err_bad_length:
    TRACE(VIPK_TRACE_RECV, " %s Bad Length", DevicePtr->DeviceName);
    KernDesc->CS.Status |= VIP_STATUS_LENGTH_ERROR;
    goto err_out;

 err_out:
    VipkViRecvCompleteErr(Vi, KernDesc, IDataPtr);
    return VIP_FALSE;
}


/** 
 * Receive a potentially fragmented VIA RDMA packet for an emulated VI.
 *
 * This function is callable by all emulated VIA devices to receive 
 * VIA packets.
 *
 * @param DevicePtr 	Pointer to device structure.
 * @param ViHandle	Vi Handle to post the send descriptor to.
 * @param Buf		Buffer to receive the data from
 * @param Length	Length of data buffer.
 * @param UserPtr	User buffer to place the received data in.
 * @param MemHandle	Memory Handle of the UserPtr.
 * @param IDataPtr	If non-NULL, points to immediate data to place in
 *			receive descriptor.
 * @param FirstFragment If \c VIP_TRUE, indicates this is the first packet.
 * @param LastFragment	If \c VIP_TRUE, indicates this is the last packet.
 * @return 	\c VIP_TRUE - The receive is not complete.<br>
 *		\c VIP_FALSE - The receive is complete oran error condition
 * 		prevents reception.  If ImmediateData is present then a
 *		descriptor has been consumed.
 */
VIP_RETURN
VipkRecvRdmaWrite(VIPK_DEVICE		*DevicePtr, 
		  VIPK_VI_HANDLE	ViHandle,
		  VIP_PVOID		Buf,
		  VIP_UINT32		Len,
		  VIP_PVOID		UserPtr,
		  VIP_MEM_HANDLE	MemHandle,
		  VIP_UINT32		*IDataPtr,
		  VIP_BOOLEAN		FirstFragment,
		  VIP_BOOLEAN		LastFragment)

{
    VIPK_VI		*Vi;
    VIP_DESCRIPTOR	*KernDesc;
    
    TRACE(VIPK_TRACE_RECV, "%s", DevicePtr->DeviceName);

    Vi = VipkViLookup(DevicePtr, ViHandle);
    if(Vi == NULL) {
	goto err_bad_vi;
    }

    /* XXX: Should we also check Vi->Session to be
     * sure this isn't just a very late arrival? */

    if(Vi->State != VIP_STATE_CONNECTED) {
	goto err_bad_state;
    }

    TRACE(VIPK_TRACE_RECV,
	  "%s Len: %d UserPtr: 0x%p MemHandle: 0x%08x ID: 0x%p:0x%x "
	  "FF: 0x%x LF: 0x%x",
	  DevicePtr->DeviceName, Len, UserPtr, MemHandle, (void *)IDataPtr,
	  IDataPtr ? *IDataPtr : 0, FirstFragment, LastFragment);

    if(FirstFragment) {
	Vi->RecvXferLen = 0;
	Vi->RecvSegIndex = 0;
	Vi->RecvSegLen = 0;
	Vi->RecvPtr = NULL;
    }
    
    if(Vi->ViAttribs.EnableRdmaWrite == VIP_FALSE) {
	goto err_bad_vi_rdma;
    }

    /* copy in page line chunks */
    if(Len) {
	/* Avoid a jump at end by not coding as while(len) */
	while(1) {
	    const VIP_PVOID KernPtr =
		VipkRmmKaddr(DevicePtr->RmmHandle, UserPtr,
			     MemHandle, Vi->ViAttribs.Ptag,
			     VIPK_RMM_MEM_FLAGS_RDMA_WRITE,
			     Vi->FilePtr->NicInstance);

	    const unsigned long PageBreak = PAGE_SIZE -
		((unsigned long ) KernPtr & ~PAGE_MASK);

	    const VIP_UINT32 XferLen = min(PageBreak, (unsigned long)Len);

	    if(KernPtr == NULL) {
		goto err_bad_kptr;
	    }

	    TRACE(VIPK_TRACE_RECV,
		  "recv chunk UserPtr: 0x%p KernPtr: 0x%p Buf: 0x%p Len: %d",
		  UserPtr, KernPtr, Buf, XferLen);
	    
	    memcpy(KernPtr, Buf, XferLen);

	    Vi->RecvXferLen += XferLen;
	    Buf += XferLen;
	    UserPtr += XferLen;
	    Len -= XferLen;

	    if(!Len) {
		break;
	    }
	}
    }

    if(LastFragment) {
	if(IDataPtr) {
	    if(Vi->RecvDesc == NULL) {
		goto err_no_desc;
	    }

	    /* convert the user desc ptr to one in kernel addr space */
	    KernDesc = (VIP_DESCRIPTOR *)
		VipkRmmKaddr(DevicePtr->RmmHandle, Vi->RecvDesc,
			     Vi->RecvMemHandle, Vi->ViAttribs.Ptag,
			     VIPK_RMM_MEM_FLAGS_WRITE,
			     Vi->FilePtr->NicInstance);
	    
	    if(KernDesc == NULL) {
		goto err_bad_kdesc;
	    }

	    TRACE(VIPK_TRACE_RECV, "%s Done Idata: 0x%p:0x%x Length: %d",
		  DevicePtr->DeviceName, (void *)IDataPtr,
		  *IDataPtr, Vi->RecvXferLen);

	    KernDesc->CS.Status = VIP_STATUS_OP_REMOTE_RDMA_WRITE;
	    VipkViRecvComplete(DevicePtr, Vi, KernDesc, IDataPtr, 
			       VIP_STATUS_DONE);
	} else {
	    Vi->RecvSeq++;
	    Vi->RecvXferLen = 0;
	}

	TRACE(VIPK_TRACE_RECV, "%s end/done", DevicePtr->DeviceName);
	return VIP_FALSE;
    }

    TRACE(VIPK_TRACE_RECV, "%s end/not done", DevicePtr->DeviceName);
    return VIP_TRUE;


 err_bad_vi:
    TRACE(VIPK_TRACE_RECV, "%s ViHandle invalid", DevicePtr->DeviceName);
    return VIP_FALSE;

 err_bad_vi_rdma:
    TRACE(VIPK_TRACE_RECV, "%s RDMA not enabled for VI",
	  DevicePtr->DeviceName);
    goto err_bad_prot_out;
    
 err_bad_state:
    TRACE(VIPK_TRACE_RECV, "%s Vi not connected", DevicePtr->DeviceName);
    return VIP_FALSE;

 err_no_desc:
    TRACE(VIPK_TRACE_RECV, 
	  "%s No receive descriptors available for idata",
	  DevicePtr->DeviceName);
    Vi->RecvSeq++;
    if(Vi->ViAttribs.ReliabilityLevel > VIP_SERVICE_UNRELIABLE) {
	/* XXX: SPEC: acording to Error Table Suppliment, this is NOT
	 * posted to the caller for unreliable delivery.  This seems wrong.
	 */
	VipkPostError(Vi, VIP_RESOURCE_VI, VIP_ERROR_RECVQ_EMPTY);
    } else {
	Vi->RecvXferLen = 0;
    }
    return VIP_FALSE;

 err_bad_kdesc:
    TRACE(VIPK_TRACE_RECV, "%s MemHandle/Descriptor not valid", 
	  DevicePtr->DeviceName);
    /* XXX: SPEC since we are handling the send imediately, it really is not
     * clear which should be returned, POST_DESC, or COMP_PROT.
     */
    Vi->RecvSeq++;
    VipkPostDescError(Vi, Vi->RecvDesc, VIP_RESOURCE_DESCRIPTOR,
		      VIP_ERROR_COMP_PROT);
    return VIP_FALSE;

 err_bad_kptr:
    TRACE(VIPK_TRACE_RECV, "%s RecvBuf/MemHandle not valid", 
	  DevicePtr->DeviceName);
    goto err_bad_prot_out;

 err_bad_prot_out:
    TRACE(VIPK_TRACE_RECV, "%s Protection Error LF: 0x%x ID: 0x%p RD: 0x%p",
	  DevicePtr->DeviceName, LastFragment,
	  (void *)IDataPtr, (void *)Vi->RecvDesc);    
    if(IDataPtr && Vi->RecvDesc) {
	/* convert the user desc ptr to one in kernel addr space */
	KernDesc = (VIP_DESCRIPTOR *)
	    VipkRmmKaddr(DevicePtr->RmmHandle, Vi->RecvDesc,
			 Vi->RecvMemHandle, Vi->ViAttribs.Ptag,
			 VIPK_RMM_MEM_FLAGS_WRITE,
			 Vi->FilePtr->NicInstance);
	
	/* XXX: SPEC: hmm.. we lose the original error, if this
	 * is from a bad rdma op... is that ok?
	 */
	if(KernDesc == NULL) {
	    goto err_bad_kdesc;
	}

	KernDesc->CS.Status = (VIP_STATUS_PROTECTION_ERROR |
			       VIP_STATUS_OP_REMOTE_RDMA_WRITE);
	VipkViRecvCompleteErr(Vi, KernDesc, IDataPtr);
    } else {
	Vi->RecvSeq++;
	if(Vi->ViAttribs.ReliabilityLevel > VIP_SERVICE_UNRELIABLE) {
	    VipkPostError(Vi, VIP_RESOURCE_VI, VIP_ERROR_RDMAW_PROT);
	} else {
	    Vi->RecvXferLen = 0;
	}
    }
    return VIP_FALSE;
}

/** 
 * Performs a pre-wait on a VI work queue.
 *
 * Pre-waits are used to avoid a race condition in the interaction between
 * the user level and kernel level queue handling.  
 *
 * @param DevicePtr	Pointer to device structure.
 * @param ViHandle	Vi Handle to perform the pre-wait on.
 * @param Recv		If \c VIP_TRUE, indicates the pre-wait is to be
 *			performed on the receive queue.
 * @return 	\c VIP_SUCCESS - The pre-wait completed successfully.<br>
 * 		\c VIP_INVALID_PARAMETER - The CqHandle is invalid.<br>
 *		\c VIP_ERROR_RESOURCE - The requested work queue is
 *		associated with a Completion Queue.
 *
 * @see VipSendWait() and VipRecvWait()
 */
VIP_RETURN
VipkPreWait(VIPK_DEVICE		*DevicePtr,
	    VIPK_VI_HANDLE	ViHandle,
	    VIP_BOOLEAN		Recv)
{
    VIPK_VI *Vi;

    unsigned long Flags;

    TRACE(VIPK_TRACE_WAIT, "[%d] %s ViHandle: 0x%x Recv: 0x%x",
	  current->pid, DevicePtr->DeviceName, ViHandle, Recv);

    Vi = VipkViLookup(DevicePtr, ViHandle);
    if(Vi == NULL || !VipkViVerifyOwner(Vi)) {
	TRACE(VIPK_TRACE_WAIT, "[%d] %s ViHandle is invalid",
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_PARAMETER;
    }

    spin_lock_irqsave(&Vi->Lock, Flags);

    if(Recv) {
	if(Vi->RecvCQ) {
	    return VIP_ERROR_RESOURCE;
	}
	Vi->RecvCntOld = Vi->RecvCnt;
    } else {
	if(Vi->SendCQ) {
	    return VIP_ERROR_RESOURCE;
	}
	Vi->SendCntOld = Vi->SendCnt;
    }

    spin_unlock_irqrestore(&Vi->Lock, Flags);

    return VIP_SUCCESS;
}

/** 
 * Perform Kernel Agent half of VipRecvWait.
 *
 * @param DevicePtr		Pointer to device structure.
 * @param ViHandle		Vi Handle to wait for receive completion on.
 * @param Timeout		Timeout value, in msec, or VIP_TIMEOUT.
 * @return 			See IDG Section 3.5.6 for details.
 */
VIP_RETURN
VipkRecvWait(VIPK_DEVICE	*DevicePtr,
	     VIPK_VI_HANDLE	ViHandle,
	     VIP_ULONG		*Timeout)
{
    VIPK_VI *Vi;

    unsigned long Flags;
    unsigned long KernTimeout;

    TRACE(VIPK_TRACE_WAIT, "[%d] %s ViHandle: 0x%x Timeout: %ld",
	  current->pid, DevicePtr->DeviceName, ViHandle, *Timeout);

    Vi = VipkViLookup(DevicePtr, ViHandle);
    if(Vi == NULL || !VipkViVerifyOwner(Vi)) {
	TRACE(VIPK_TRACE_WAIT, "[%d] %s ViHandle is invalid",
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_PARAMETER;
    }

    KernTimeout = VipkLinuxTimeout(*Timeout);

    spin_lock_irqsave(&Vi->Lock, Flags);
    
    while(Vi->RecvCnt == Vi->RecvCntOld &&
	  KernTimeout && !signal_pending(current)) {
	TRACE(VIPK_TRACE_WAIT, "[%d] %s Waiting on ViHandle: 0x%x",
	      current->pid, DevicePtr->DeviceName, ViHandle);
	cond_wait_interruptible(&Vi->Received, &Vi->Lock, &KernTimeout);
    }

    /* Don't need to distinguish timeout/signal/completion.
     * The vipl needs to check this for itself.
     */

    TRACE(VIPK_TRACE_WAIT, "[%d] end", current->pid);

    spin_unlock_irqrestore(&Vi->Lock, Flags);

    *Timeout = VipkViaTimeout(KernTimeout);

    return VIP_SUCCESS;
}

/** 
 * Perform Kernel Agent half of VipSendWait.
 *
 * @param DevicePtr		Pointer to device structure.
 * @param ViHandle		Vi Handle to wait for send completion on.
 * @param Timeout		Timeout value, in msec, or VIP_TIMEOUT.
 * @return 			See IDG Section 3.5.3 for details.
 */
VIP_RETURN
VipkSendWait(VIPK_DEVICE	*DevicePtr,
	     VIPK_VI_HANDLE	ViHandle,
	     VIP_ULONG		*Timeout)
{
    VIPK_VI *Vi;

    unsigned long Flags;
    unsigned long KernTimeout;

    TRACE(VIPK_TRACE_WAIT, "[%d] %s ViHandle: 0x%x Timeout: %ld",
	  current->pid, DevicePtr->DeviceName, ViHandle, *Timeout);

    Vi = VipkViLookup(DevicePtr, ViHandle);
    if(Vi == NULL || !VipkViVerifyOwner(Vi)) {
	TRACE(VIPK_TRACE_WAIT, "[%d] %s ViHandle is invalid",
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_PARAMETER;
    }

    KernTimeout = VipkLinuxTimeout(*Timeout);

    spin_lock_irqsave(&Vi->Lock, Flags);

    while(Vi->SendCnt == Vi->SendCntOld && 
	  KernTimeout && !signal_pending(current)) {
	TRACE(VIPK_TRACE_WAIT, "[%d] %s Waiting on ViHandle: 0x%x",
	      current->pid, DevicePtr->DeviceName, ViHandle);
	cond_wait_interruptible(&Vi->Sent, &Vi->Lock, &KernTimeout);

    }

    /* Don't need to distinguish timeout/signal/completion.
     * The vipl needs to check this for itself.
     */

    TRACE(VIPK_TRACE_WAIT, "[%d] end", current->pid);

    spin_unlock_irqrestore(&Vi->Lock, Flags);

    *Timeout = VipkViaTimeout(KernTimeout);

    return VIP_SUCCESS;
}

/** 
 * Perform Kernel Agent half of VipQueryNic
 *
 * @param DevicePtr		Pointer to device structure.
 * @param UserNicAttribs	Pointer to Nic Attributes structure in 
 *				user space.
 * @param UserNicAddr		Pointer to net address structure in user space.
 * @return 			See IDG Section 3.7.1 for details.
 */
VIP_RETURN
VipkQueryNic(VIPK_DEVICE	*DevicePtr,
	     VIP_NIC_ATTRIBUTES	*UserNicAttribs,
	     VIP_UINT8		*UserNicAddr)
{
    TRACE(VIPK_TRACE_NIC_OPS, "[%d] %s", current->pid, DevicePtr->DeviceName);

    copy_to_user_ret(UserNicAttribs, DevicePtr->NicAttribs,
		     sizeof(VIP_NIC_ATTRIBUTES), VIP_INVALID_PARAMETER);

    copy_to_user_ret(UserNicAddr, DevicePtr->NicAttribs->LocalNicAddress,
		     DevicePtr->NicAttribs->NicAddressLen, 
		     VIP_INVALID_PARAMETER);

    return VIP_SUCCESS;
}


/**
 * Perform Kenrel Agent half of VipSetViAttributes
 *
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param ViHandle		Vi Handle to set attributes for.
 * @param UserAttribs		Pointer to Vi attributes structure in
 *				user space.
 * @return			See IDG Section 3.7.2 for details.
 */
VIP_RETURN
VipkSetViAttributes(VIPK_DEVICE		*DevicePtr,
		    VIPK_FILE		*FilePtr,
		    VIPK_VI_HANDLE	ViHandle,
		    VIP_VI_ATTRIBUTES	*UserAttribs)
{
    VIP_VI_ATTRIBUTES	ViAttribs;
    VIPK_VI		*Vi;
    VIP_RETURN		Status;
    
    TRACE(VIPK_TRACE_NIC_OPS, "[%d] %s", current->pid, DevicePtr->DeviceName);

    copy_from_user_ret(&ViAttribs, UserAttribs,
		       sizeof(VIP_VI_ATTRIBUTES), VIP_INVALID_PARAMETER);

    Vi = VipkViLookup(DevicePtr, ViHandle);
    if(Vi == NULL || !VipkViVerifyOwner(Vi)) {
	TRACE(VIPK_TRACE_NIC_OPS, "%s Bad ViHandle", DevicePtr->DeviceName);
	return VIP_INVALID_PARAMETER;
    }

    if(Vi->State != VIP_STATE_IDLE) {
	return VIP_INVALID_STATE;
    }
    
    Status = VipkValidateViAttributes(DevicePtr, FilePtr, &ViAttribs);
    if(Status != VIP_SUCCESS) {
	return Status;
    }

    VipkPtmReleasePtag(DevicePtr->PtmHandle, Vi->ViAttribs.Ptag,
		       FilePtr->NicInstance);
    
    Vi->ViAttribs = ViAttribs;
    return VIP_SUCCESS;
}

/** 
 * Perform Kernel Agent half of VipQueryVi
 *
 * @param DevicePtr		Pointer to device structure.
 * @param ViHandle		Vi Handle to query.
 * @param UserState		Pointer to Vi state structure in user space.
 * @param UserAttribs		Pointer to Vi attributes structure 
 * 				in user space.
 * @return 			See IDG Section 3.7.3 for details.
 */
VIP_RETURN
VipkQueryVi(VIPK_DEVICE		*DevicePtr,
	    VIPK_VI_HANDLE	ViHandle,
	    VIP_VI_STATE	*UserState,
	    VIP_VI_ATTRIBUTES	*UserAttribs)
{

    VIPK_VI *Vi;
    
    TRACE(VIPK_TRACE_NIC_OPS, "[%d] %s", current->pid, DevicePtr->DeviceName);
    
    Vi = VipkViLookup(DevicePtr, ViHandle);
    if(Vi == NULL || !VipkViVerifyOwner(Vi)) {
	TRACE(VIPK_TRACE_NIC_OPS, "[%d] %s ViHandle is invalid",
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_PARAMETER;
    }

    put_user_ret(Vi->State, UserState, VIP_INVALID_PARAMETER);

    copy_to_user_ret(UserAttribs, &Vi->ViAttribs,
		     sizeof(VIP_VI_ATTRIBUTES), VIP_INVALID_PARAMETER);

    return VIP_SUCCESS;
}

/**
 * Perform Kernel Agent half of VipQueryMem
 *
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param VirtualAddress	Starting address of region to query.
 * @param MemHandle		Memory handle to query.
 * @param UserAttrs		Space for query result.
 * @return			See IDG Section 3.7.5 for details.
 */
VIP_RETURN
VipkQueryMem(VIPK_DEVICE		*DevicePtr,
	     VIPK_FILE			*FilePtr,
	     VIP_PVOID			VirtualAddress,
	     VIP_MEM_HANDLE		MemHandle,
	     VIP_MEM_ATTRIBUTES		*UserAttribs)
{
    VIP_MEM_ATTRIBUTES MemAttribs;
    VIP_RETURN Status;

    TRACE(VIPK_TRACE_NIC_OPS, "[%d] %s", current->pid, DevicePtr->DeviceName);

    Status = VipkRmmQueryMem(DevicePtr->RmmHandle,
			     VirtualAddress, MemHandle,
			     &MemAttribs,
			     FilePtr->NicInstance);
    
    if(Status != VIP_SUCCESS) {
	return Status;
    }

    copy_to_user_ret(UserAttribs, &MemAttribs,
		     sizeof(VIP_MEM_ATTRIBUTES), VIP_INVALID_PARAMETER);
    
    return Status;
}

/**
 * Perform Kernel Agent half of VipSetMemAttributes
 *
 * @param DevicePtr		Pointer to device structure.
 * @param FilePtr		Pointer to state per NIC open.
 * @param VirtualAddress	Starting address of region to query.
 * @param MemHandle		Memory handle to query.
 * @param UserAttrs		Space for query result.
 * @return			See IDG Section 3.7.5 for details.
 */
VIP_RETURN
VipkSetMemAttributes(VIPK_DEVICE		*DevicePtr,
		     VIPK_FILE			*FilePtr,
		     VIP_PVOID			VirtualAddress,
		     VIP_MEM_HANDLE		MemHandle,
		     VIP_MEM_ATTRIBUTES		*UserAttribs)
{
    VIP_PROTECTION_HANDLE OldPtag;
    VIP_MEM_ATTRIBUTES MemAttribs;
    VIP_RETURN Status;

    TRACE(VIPK_TRACE_NIC_OPS, "[%d] %s", current->pid, DevicePtr->DeviceName);

    Status = VipkRmmQueryMem(DevicePtr->RmmHandle,
			     VirtualAddress, MemHandle,
			     &MemAttribs,
			     FilePtr->NicInstance);
    OldPtag = MemAttribs.Ptag;

    if(Status != VIP_SUCCESS) {
	return Status;
    }

    copy_from_user_ret(&MemAttribs, UserAttribs, 
		       sizeof(VIP_MEM_ATTRIBUTES), VIP_INVALID_PARAMETER);

    if(VipkPtmUsePtag(DevicePtr->PtmHandle, MemAttribs.Ptag,
		      FilePtr->NicInstance) != VIP_SUCCESS) {
	TRACE(VIPK_TRACE_CREATE_VI, "[%d] %s Invalid Ptag",
	      current->pid, DevicePtr->DeviceName);
	return VIP_INVALID_PTAG;
    }

    Status = VipkRmmSetMemAttributes(DevicePtr->RmmHandle,
				     VirtualAddress, MemHandle,
				     &MemAttribs,
				     FilePtr->NicInstance);

    if(Status != VIP_SUCCESS) {
	VipkPtmReleasePtag(DevicePtr->PtmHandle, MemAttribs.Ptag,
			   FilePtr->NicInstance);
	return Status;
    }

    VipkPtmReleasePtag(DevicePtr->PtmHandle, OldPtag,
		       FilePtr->NicInstance);
    
    return Status;
}

/** 
 * Post an asynchronous error to a VI.
 *
 * @param Vi		Vi to post the error to.
 * @param ResourceCode	Resource code of the error.
 * @param ErrorCode	Error code of the error.
 */
void
VipkPostError(VIPK_VI			*Vi,
	      VIP_RESOURCE_CODE		ResourceCode,
	      VIP_ERROR_CODE		ErrorCode)
{
    unsigned long Flags;

    if(ErrorCode != VIP_ERROR_CONN_LOST) {
	VipkEQEnqueue(Vi->FilePtr->EQHandle, 
		      Vi->FilePtr->NicUserHandle,
		      Vi->UserViHandle, 
		      NULL, /* CQ Handle */
		      NULL, /* DESC */
		      0, /* OP_CODE */
		      ResourceCode,
		      ErrorCode);
    }

    spin_lock_irqsave(&Vi->Lock, Flags);
    if(Vi->State == VIP_STATE_CONNECTED) {
	Vi->State = VIP_STATE_ERROR;
	spin_unlock_irqrestore(&Vi->Lock, Flags);

	/* send disconnect notification */
	Vi->DevicePtr->DeviceOps->SendConnLost(Vi->DevicePtr, Vi, VIP_TRUE);

	/* Flush Recv queue */
	VipkViFlushDescs(Vi->DevicePtr, Vi, VIP_TRUE);

	/* Flush Send queue */
	VipkViFlushDescs(Vi->DevicePtr, Vi, VIP_FALSE);

	VipkEQEnqueue(Vi->FilePtr->EQHandle, 
		      Vi->FilePtr->NicUserHandle,
		      Vi->UserViHandle, 
		      NULL, /* CQ Handle */
		      NULL, /* DESC */
		      0, /* OP_CODE */
		      VIP_RESOURCE_VI,
		      VIP_ERROR_CONN_LOST);

    } else {
	spin_unlock_irqrestore(&Vi->Lock, Flags);
    }
}

/** 
 * Post an asynchronous descriptor error to a VI.
 *
 * @param Vi		Vi to post the error to.
 * @param Desc		User pointer to the descriptor that generated
 *			the error.
 * @param ResourceCode	Resource code of the error.
 * @param ErrorCode	Error code of the error.
 *
 * \bug
 * SPEC: vipconf seems to require that descriptor errors
 * be returned with VIP_RESOURCE_VI rather than VIP_RESOURCE_DESCRIPTOR.
 * It also expects that the descriptor pointer be NULL.  This is just
 * not right.  
 */
void
VipkPostDescError(VIPK_VI		*Vi,
		  VIP_DESCRIPTOR	*Desc,
		  VIP_RESOURCE_CODE	ResourceCode,
		  VIP_ERROR_CODE	ErrorCode)
{
    VIP_RETURN Status;
    unsigned long Flags;

    Status = VipkEQEnqueue(Vi->FilePtr->EQHandle,
			   Vi->FilePtr->NicUserHandle,
			   Vi->UserViHandle,
			   NULL, /* CQ_HANDLE */
			   Desc,
			   0, /* OP_CODE */
			   ResourceCode,
			   ErrorCode);

    spin_lock_irqsave(&Vi->Lock, Flags);
    if(Vi->State == VIP_STATE_CONNECTED) {
	Vi->State = VIP_STATE_ERROR;
	spin_unlock_irqrestore(&Vi->Lock, Flags);

	/* send disconnect notification */
	Vi->DevicePtr->DeviceOps->SendConnLost(Vi->DevicePtr, Vi, VIP_TRUE);

	/* Flush Recv queue */
	VipkViFlushDescs(Vi->DevicePtr, Vi, VIP_TRUE);

	/* Flush Send queue */
	VipkViFlushDescs(Vi->DevicePtr, Vi, VIP_FALSE);
	
	Status = VipkEQEnqueue(Vi->FilePtr->EQHandle, 
			       Vi->FilePtr->NicUserHandle,
			       Vi->UserViHandle, 
			       NULL, /* CQ Handle */
			       NULL, /* DESC */
			       0, /* OP_CODE */
			       VIP_RESOURCE_VI,
			       VIP_ERROR_CONN_LOST);
    } else {
	spin_unlock_irqrestore(&Vi->Lock, Flags);
    }
}

/** 
 * Complete a receive operation on a VI in error.
 *
 * Invokes VipkViRecvComplete and also breaks the connection if
 * required by the Vi's reliability level.  Assumes the caller
 * has set all proper error bits in the descriptor.
 *
 * @param Vi		Pointer to the VI the completion event is occuring on.
 * @param KernDesc	Pointer to the descriptor in kernel address space.
 * @param IDataPtr	If non-NULL, points to immediate data to place in
 *			receive descriptor.
 */
void
VipkViRecvCompleteErr(VIPK_VI		*Vi,
		      VIP_DESCRIPTOR	*KernDesc,
		      VIP_UINT32	*IDataPtr)
{
    unsigned long Flags;

    spin_lock_irqsave(&Vi->Lock, Flags);
    if(Vi->State == VIP_STATE_CONNECTED) {
	if(Vi->ViAttribs.ReliabilityLevel == VIP_SERVICE_UNRELIABLE) {
	    spin_unlock_irqrestore(&Vi->Lock, Flags);

	    /* Simply complete the descriptor in error */
	    VipkViRecvComplete(Vi->DevicePtr, Vi, KernDesc,
			       IDataPtr, VIP_STATUS_DONE);
	} else {
	    /* Transition state before any descriptor is completed */
	    Vi->State = VIP_STATE_ERROR;
	    spin_unlock_irqrestore(&Vi->Lock, Flags);

	    /* Complete the descriptor in error */
	    VipkViRecvComplete(Vi->DevicePtr, Vi, KernDesc,
			       IDataPtr, VIP_STATUS_DONE);

	    /* send disconnect notification */
	    Vi->DevicePtr->DeviceOps->SendConnLost(Vi->DevicePtr, Vi, VIP_TRUE);

	    /* Flush (the remainder of) the Recv queue */
	    VipkViFlushDescs(Vi->DevicePtr, Vi, VIP_TRUE);

	    /* Flush the Send queue */
	    VipkViFlushDescs(Vi->DevicePtr, Vi, VIP_FALSE);

	    /* Post the async error */
	    VipkEQEnqueue(Vi->FilePtr->EQHandle,
			  Vi->FilePtr->NicUserHandle,
			  Vi->UserViHandle,
			  NULL, /* CQ Handle */
			  NULL, /* DESC */
			  0, /* OP_CODE */
			  VIP_RESOURCE_VI,
			  VIP_ERROR_CONN_LOST);
	}
    } else {
	spin_unlock_irqrestore(&Vi->Lock, Flags);
    }
}

/** 
 * Complete a send operation on a VI in error.
 *
 * Invokes VipkViSendComplete and also breaks the connection if
 * required by the Vi's reliability level.  Assumes the caller
 * has set all proper error bits in the descriptor.
 *
 * @param Vi		Pointer to the VI the completion event is occuring on.
 * @param KernDesc	Pointer to the descriptor in kernel space.
 */
void
VipkViSendCompleteErr(VIPK_VI		*Vi,
		      VIP_DESCRIPTOR	*KernDesc)
{
    unsigned long Flags;

    spin_lock_irqsave(&Vi->Lock, Flags);
    if(Vi->State == VIP_STATE_CONNECTED) {
	if(Vi->ViAttribs.ReliabilityLevel == VIP_SERVICE_UNRELIABLE) {
	    spin_unlock_irqrestore(&Vi->Lock, Flags);

	    /* Simply complete the descriptor in error */
	    VipkViSendComplete(Vi->DevicePtr, Vi, KernDesc, VIP_STATUS_DONE);
	} else {
	    /* Transition state before any descriptor is completed */
	    Vi->State = VIP_STATE_ERROR;
	    spin_unlock_irqrestore(&Vi->Lock, Flags);

	    /* Complete the descriptor in error */
	    VipkViSendComplete(Vi->DevicePtr, Vi, KernDesc, VIP_STATUS_DONE);

	    /* send disconnect notification */
	    Vi->DevicePtr->DeviceOps->SendConnLost(Vi->DevicePtr, Vi, VIP_TRUE);

	    /* Flush the Recv queue */
	    VipkViFlushDescs(Vi->DevicePtr, Vi, VIP_TRUE);

	    /* Flush (the remainder of) the Send queue */
	    VipkViFlushDescs(Vi->DevicePtr, Vi, VIP_FALSE);

	    /* Post the async error */
	    VipkEQEnqueue(Vi->FilePtr->EQHandle,
			  Vi->FilePtr->NicUserHandle,
			  Vi->UserViHandle,
			  NULL, /* CQ Handle */
			  NULL, /* DESC */
			  0, /* OP_CODE */
			  VIP_RESOURCE_VI,
			  VIP_ERROR_CONN_LOST);
	}
    } else {
	spin_unlock_irqrestore(&Vi->Lock, Flags);
    }
}

/** 
 * A invalid fast-trap operation handler.
 * This is the default fast-trap handler.
 */
VIP_RETURN
VipkBadOp()
{
    TRACE(VIPK_TRACE_NIC_OPS, "[%d]", current->pid);
    return VIP_INVALID_PARAMETER;
}

		
void
VipkAddrPrint(char *str, VIP_NET_ADDRESS *Addr)
{
    char buf[512];
    char *p = buf;
    int i;

    p += sprintf(p, "%s: Addr: %02x", str, Addr->HostAddress[0]);
    for (i=0; i<Addr->HostAddressLen+Addr->DiscriminatorLen; i++) {
	p += sprintf(p, ":%02x", Addr->HostAddress[i]);
    }

    printk("%s\n", buf);
}
       
    

 
