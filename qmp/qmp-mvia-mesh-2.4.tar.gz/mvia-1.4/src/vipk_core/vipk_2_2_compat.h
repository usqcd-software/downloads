#ifndef _VIPK_2_2_COMPAT_H
#define _VIPK_2_2_COMPAT_H

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0))
/* these macros were defined in asm/uaccess.h in Linux 2.2 but
   were removed in 2.4.  We re-define them here to preserve code
   compatability.
*/
#define put_user_ret(x,ptr,ret) ({ if (put_user(x,ptr)) return ret; })
#define get_user_ret(x,ptr,ret) ({ if (get_user(x,ptr)) return ret; })
#define __put_user_ret(x,ptr,ret) ({ if (__put_user(x,ptr)) return ret; })
#define __get_user_ret(x,ptr,ret) ({ if (__get_user(x,ptr)) return ret; })

#define copy_to_user_ret(to,from,n,retval) ({ if (copy_to_user(to,from,n)) return retval; })

#define copy_from_user_ret(to,from,n,retval) ({ if (copy_from_user(to,from,n)) return retval; })

#endif


#endif
