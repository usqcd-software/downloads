/* \file vipk_ptm.h
 *
 * Interface for VI Kernel Agent PTag management
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 * 
 */

#ifndef _VIPK_PTM_H
#define _VIPK_PTM_H

#include <linux/config.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0))
#include <linux/spinlock.h>
#else
#include <asm/spinlock.h>
#endif

#include "condvar.h"
#include <vipl.h>

typedef struct _VIPK_PTM *VIPK_PTM_HANDLE;

#include "vipk_types.h"

/** \def VIPK_PTAG_PER_PAGE
 * Number of Ptag entries to a page.
 */
#define VIPK_PTAG_PER_PAGE ((PAGE_SIZE - sizeof(VIPK_PTAG_MANAGER)) \
			    / sizeof(VIPK_PTAG) - 1)

/** 
 * Protection Tag.
 * This structure contains the internal state of a Kernel Agent Protection Tag
 */
typedef struct {
    /** The usage count of the Ptag.
     * If 0, the Ptag is free.<br>
     * If 1, the Ptag is is allocated to a NicInstace but is not
     * associated with any resources.<br>
     * If >1, the Ptag is allocated to a NicInstance, is associated
     * with resources, and may not be destroyed.
     */
    VIP_UINT32			UseCnt;
    /** The Nic instance associated with the Protection Tag. */
    VIPK_NIC_INSTANCE		NicInstance;
} VIPK_PTAG;

/**
 * Protection Tag Manager.
 */ 
typedef struct _VIPK_PTM {
    /** Protection for multiple access. */
    spinlock_t	Lock;
    /** Number of Ptags supported by the Protection Tag Manager. */
    VIP_UINT32	NumPtags;
    /** Number of Ptags currently in use by the Protection Tag Manager. */
    VIP_UINT32	NumInUse;
    /** Array of Protection Tags */
    VIPK_PTAG	Ptag[1];
} VIPK_PTM;


/** 
 * Create a Protection Tag Manager.
 *
 * @param NumPtags	Number of Ptags to be supported by 
 *			the Protection Tag Manager.
 * @param PtmHandle	The newly created Protection Tag Manager.
 * @return 	\c VIP_SUCCESS - The Protection Tag Manager 
 *		was successfully created.<br>
 * 		\c VIP_ERROR_RESOURCE - Insufficient resources to 
 *		create the Protection Tag Manager.
 */
extern VIP_RETURN 
VipkPtmCreate(VIP_UINT32	NumPtags,
	      VIPK_PTM_HANDLE	*PtmHandle);

/** 
 * Destroy a Protection Tag Manager.
 *
 * @param PtmHandle	The Protection Tag Manager to destroy.
 *
 * @return 		\c VIP_SUCCESS - The Protection Tag Manager was 
 *			successfully destroyed.
 */
extern VIP_RETURN 
VipkPtmDestroy(VIPK_PTM_HANDLE	PtmHandle);

/**
 * Create a Protection Tag.
 *
 * @param PtmHandle	The Protection Tag Manager in which to create
 *			the Protection Tag.
 * @param Ptag		The newly created Protection Tag.
 * @param NicInstance	The Nic instance associated with the Protection Tag.
 */
extern VIP_RETURN 
VipkPtmCreatePtag(VIPK_PTM_HANDLE	PtmHandle,
		  VIP_PROTECTION_HANDLE	*Ptag,
		  VIPK_NIC_INSTANCE	NicInstance);

/** 
 * Increment the Protection Tag usage count.
 *
 * @param PtmHandle	The Protection Tag Manager conaining 
 *			the Protection Tag.
 * @param PtagHandle	The Protection Tag to have its use count incremented.
 * @param NicInstance	The Nic instance requesting the use count increment.
 *
 * @return 	\c VIP_SUCCESS - The usage count was 
 *		successfully incremented.<br>
 *		\c VIP_INVALID_PTAG - The Protection Tag Handle was invalid.
 */
extern VIP_RETURN
VipkPtmUsePtag(VIPK_PTM_HANDLE		PtmHandle,
	       VIP_PROTECTION_HANDLE	PtagHandle,
	       VIPK_NIC_INSTANCE	NicInstance);

/**
 * Decrement the Protection Tag usage count.
 *
 * @param PtmHandle	The Protection Tag Manager containing
 *			the Protection Tag.
 * @param PtagHandle	The Protection Tag to have its use count decremented.
 * @param NicInstance	The Nic instance requesting the use count decremented.
 * 
 * @return 	\c VIP_SUCCESS - The usage count was 
 *		successfully decremented.<br> 
 * 		\c VIP_INVALID_PTAG - The Protection Tag Handle was invalid.
 */
extern VIP_RETURN
VipkPtmReleasePtag(VIPK_PTM_HANDLE		PtmHandle,
		   VIP_PROTECTION_HANDLE	PtagHandle,
		   VIPK_NIC_INSTANCE		NicInstance);

/**
 * Destroy a Protection Tag.
 *
 * @param PtmHandle	The Protection Tag Manager containing
 *			the Protection Tag.
 * @param PtagHandle	The Protection Tag to be destroyed.
 * @param NicInstance	The Nic instance requesting 
 *			the Protection Tag destruction.
 * 
 * @return 	\c VIP_SUCCESS - The usage count was 
 *		successfully decremented.<br> 
 * 		\c VIP_INVALID_PTAG - The Protection Tag Handle 
 *		was invalid.<br>
 *		\c VIP_ERROR_RESOURCE - The Protection Tag Handle was invalid.
 */
extern VIP_RETURN 
VipkPtmDestroyPtag(VIPK_PTM_HANDLE		PtmHandle,
		   VIP_PROTECTION_HANDLE	PtagHandle,
		   VIPK_NIC_INSTANCE		NicInstance);

/** 
 * Destroy all the Protection Tags associated with a Nic instance.
 *
 * @param PtmHandle	The Protection Tag Manager from which to destroy
 *			the Protection Tags.
 * @param NicInstance	The Nic instance requsting that all 
 *			of its Protection Tags be destroyed.
 * @return \c VIP_SUCCESS - This function never fails.
 */
extern VIP_RETURN 
VipkPtmDestroyPtagNic(VIPK_PTM_HANDLE 	PtmHandle,
		      VIPK_NIC_INSTANCE	NicInstance);

/** 
 * Determine if a Ptag is valid.
 *
 * @param PtmHandle	Protection Tag Manager containing 
 *			the Protection Tag.
 * @param PtagHandle	The Protection Tag to validate.
 * @param NicInstance	The Nic instance requesting the validation.
 * @return 	\c VIP_TRUE - The Protection Tag is valid.<br>
 *		\c VIP_FALSE - The Protection Tag is invalid.
 */
extern inline
VIP_BOOLEAN 
VipkPtmPtagValid(VIPK_PTM_HANDLE 	PtmHandle, 
		 VIP_PROTECTION_HANDLE	PtagHandle, 
		 VIPK_NIC_INSTANCE	NicInstance)
{
    VIPK_UINTPTR	Index = (VIPK_UINTPTR)PtagHandle;

    return (Index <= PtmHandle->NumPtags && 
	    PtmHandle->Ptag[Index].NicInstance == NicInstance);
}


/* The declarations from here forward are private */

/** \def VipkPtagIsFree(Ptag)
 * Checks if a Protection Tag is free for allocation.
 */
#define VipkPtagIsFree(Ptag)		((Ptag)->UseCnt == 0)

/** \def VipkPtagInUse(Ptag)
 * Checks if a Protection Tag has resources associated with it.
 */
#define VipkPtagInUse(Ptag)		((Ptag)->UseCnt > 1)

/** \def VipkPtagIncUsage
 * Increments the usage count of a Protection Tag.
 */
#define VipkPtagIncUsage(Ptag)		((Ptag)->UseCnt++)

/** \def VipkPtagDecUsage
 * Decrements the usage count of a Protection Tag.
 */
#define VipkPtagDecUsage(Ptag)		((Ptag)->UseCnt--)
	
#endif /* _VIPK_PTM_H */
