/* \file vipk_rmm.h
 *
 * Interface for VI Kernel Agent Registered Memory Management
 *
 * \bug The deregistration translate functions need to
 * use spinlocks on smps.  Translation on an SMP should work as follows:
 * lock/xlat/use/release.
 * 
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#ifndef _VIPK_RMM_H
#define _VIPK_RMM_H

#include <linux/kernel.h>
#include <linux/sched.h>
#include <asm/io.h>

#include "condvar.h"
#include <vipl.h>

typedef struct _VIPK_RM_MANAGER *VIPK_RMM_HANDLE;

#include "vipk_types.h"

/** \def VIPK_MAX_MAPPABLE_PAGES
 * The maximum number of pages a Registered Memmory Manager will
 * be allowed to support.
 * 
 * This value is now set in Makefile.config
 */
#if !defined(VIPK_MAX_MAPPABLE_PAGES) || ((VIPK_MAX_MAPPABLE_PAGES-1) < 0)
#error "You must set VIPK_MAX_MAPPABLE_PAGES in Makefile.config"
#endif

/** 
 * Create a Registered Memory Manager.
 *
 * @param NumRegions	Number of pages the Registered Memory Manager 
 *			will allow to be mapped.
 * @param RmmHandle	The newly created Registered Memory Manager.
 *
 * @return 	\c VIP_SUCCESS - The Registered Memory Manager was created
 *		successfully.<br>
 *		\c VIP_ERROR_RESOURCE - Insufficient resources.
 */
extern VIP_RETURN 
VipkRmmCreate(VIP_UINT32		NumRegions,
	      VIPK_RMM_HANDLE		*RmmHandle);

/** 
 * Destroy a Registered Memory Manager.
 *
 * @param RmmHandle	The Registered Memory Manager to destroy.
 *
 * @return 	\c VIP_SUCCESS - The Registered Memory Manager was 
 *		successfully destroyed.<br>
 *		\c VIP_ERROR_RESOURCE - The Registered Memory Manager
 *		had pages mapped and could not be destroyed.
 */
extern VIP_RETURN
VipkRmmDestroy(VIPK_RMM_HANDLE		RmmHandle);

/** 
 * Regisered a region of memory.
 *
 * @param RmmHandle	Registered Memory Manger in which to register 
 *			the memory region.
 * @param VirtualAddr	Virtual address in user's address space to register.
 * @param Length	Length of the region to register.
 * @param MemAttribs	Memory attributes of the region being registered.
 * @param MemHandle	Memory handle of the newly registered region.
 * @param NicInstance	The NicInstance to be associated with the 
 * 			memory region.
 * @return	\c VIP_SUCCESS - The memory region was
 *		successfully registered.<br>
 *		\c VIP_ERROR_RESOURCE - Insufficient resources.
 */
extern VIP_RETURN 
VipkRmmRegister(VIPK_RMM_HANDLE 	RmmHandle,
		VIP_PVOID		VirtualAddr,
		VIP_ULONG		Length,
		VIP_MEM_ATTRIBUTES	*MemAttribs,
		VIP_MEM_HANDLE		*MemHandle,
		VIPK_NIC_INSTANCE	NicInstance);

/**
 * Deregister a region of memory.
 *
 * @param RmmHandle	Registered Memory Manger from which to deregister 
 *			the memory region.
 * @param VirtualAddr	Virtual address in user's address space to deregister.
 * @param MemHandle	Memory handle of the region to deregister.
 * @param NicInstance	The NicInstance requesting the deregistration.
 *
 * @return	\c VIP_SUCCESS - The memory region was
 *		successfully registered.<br>
 *		\c VIP_INVALID_PARAMETER - The memory handle was invalid.
 *
 * \warning The VirtualAddress must match the VirtualAddress provided
 * when this MemHandle was registered to the byte.  The spec is misleading 
 * on this matter, as it implies that memory registration granularity is 
 * page oriented.  The Intel VIA Conformance Tests perform deregister
 * memory within the page, expecting the request to fail.
 */
extern VIP_RETURN 
VipkRmmDeregister(VIPK_RMM_HANDLE	RmmHandle,
		  VIP_PVOID		VirtualAddr,
		  VIP_MEM_HANDLE	MemHandle,
		  VIPK_NIC_INSTANCE	NicInstance);

/** 
 * Query the memory attributes of a registered memory region.
 *
 * @param RmmHandle	Registered Memory Manger to query.
 * @param VirtualAddr	Virtual address in user's address space to query.
 * @param MemHandle	Memory handle of the region to query.
 * @param MemAttribs    The returned memory attributes.
 * @param NicInstance	The NicInstance performing the query.
 *
 * @return	\c VIP_SUCCESS - The memory region was
 *		successfully queried.<br>
 *		\c VIP_INVALID_PARAMETER - The memory handle was invalid.
 *
 */
extern VIP_RETURN
VipkRmmQueryMem(VIPK_RMM_HANDLE		RmmHandle,
		VIP_PVOID		VirtualAddr,
		VIP_MEM_HANDLE		MemHandle,
		VIP_MEM_ATTRIBUTES	*MemAttribs,
		VIPK_NIC_INSTANCE	NicInstance);

/** 
 * Set the memory attributes of a registered memory region.
 *
 * @param RmmHandle	Registered Memory Manger to set.
 * @param VirtualAddr	Virtual address in user's address space to set.
 * @param MemHandle	Memory handle of the region to set.
 * @param MemAttribs    The supplied memory attributes.
 * @param NicInstance	The NicInstance performing the set.
 *
 * @return	\c VIP_SUCCESS - The memory region was
 *		successfully modified.<br>
 *		\c VIP_INVALID_PARAMETER - The memory handle was invalid.
 *
 */
extern VIP_RETURN
VipkRmmSetMemAttributes(VIPK_RMM_HANDLE		RmmHandle,
			VIP_PVOID		VirtualAddr,
			VIP_MEM_HANDLE		MemHandle,
			VIP_MEM_ATTRIBUTES	*MemAttribs,
			VIPK_NIC_INSTANCE	NicInstance);

/** 
 * Deregister all memory regions associated with a Nic instance.
 *
 * @param RmmHandle	Registered Memory Manger from which to deregister
 *			memory regions.
 * @param NicInstance	The Nic instance requesting the deletion of its 
 *			registered memory regions.
 * @return 	\c VIP_SUCCESS - This function does not fail.
 */
extern VIP_RETURN 
VipkRmmDeregisterNic(VIPK_RMM_HANDLE 	RmmHandle,
		     VIPK_NIC_INSTANCE	NicInstance);


/* Declarations from here forward are private */

/* XXX: this may be better as a segment table with an array of paddrs
 * as the FreeBSD 0.9 implementation, but this is closer to the via 
 * recomendation for the data structure.  Need to time and make sure
 * performance is ok.
 */

#define VIPK_RMM_MEM_FLAGS_READ		0x0000
#define	VIPK_RMM_MEM_FLAGS_WRITE	0x0001
#define VIPK_RMM_MEM_FLAGS_RDMA_WRITE	0x0002
#define VIPK_RMM_MEM_FLAGS_RDMA_READ	0x0004

/** Address translation and protection. */
typedef struct {
    /** Nic instance that owns the page. */
    VIPK_NIC_INSTANCE		NicInstance;

    /** Page portion of the user virtual address. */
    unsigned long		VirtualPage;

    /** Protection tag for page. */
    VIP_PROTECTION_HANDLE	Ptag;

    /** Protection flags of the page. */
    VIP_UINT32		       	Flags;

    /** Kernel address of page. */
    caddr_t			kaddr;

    /** Physical address of page. */
    caddr_t			paddr;

    /** User virtual address that was used to register this page.
     * Note, if multiple pages were registered in a single call, 
     * this address will be the same for all pages registered to the
     * region.
     */
    VIP_PVOID			VirtualAddr;

    /** Number of pages remaining in this memory region. */
    VIP_UINT32 			NumPages;
} VIPK_RMM_PAGE;

/** Registered Memory Manager. */
typedef struct _VIPK_RM_MANAGER {
    /** Protection for multiple access. */
    spinlock_t		Lock;

    /** Maximum number of pages which may be registered. */
    VIP_UINT32		NumPages;

    /** Number of pages currently registered. */
    VIP_UINT32		NumMapped;

    /** Array of page translation entries. */
    VIPK_RMM_PAGE       Rm[1];		
} VIPK_RM_MANAGER;

/** 
 * Convert a VirtualAddress/Protecion Index pair to a a Memory Handle.
 *
 * @param ProtIndex	Protection Index to convert.
 * @param VirtualAddr	Virtual address to convert.
 * @return 		Memory Handle corresponding to the 
 *			Virtual Address/Protection Index pair.
 */
extern inline 
VIP_MEM_HANDLE
VipkPItoHand(VIP_UINT32	ProtIndex,
	    VIP_PVOID	VirtualAddr)
{
    return (VIP_MEM_HANDLE) (((unsigned long) VirtualAddr 
			      >> PAGE_SHIFT) - ProtIndex);
}

/**
 * Convert a virtual address/Memory Handle pair to a Protection Index.
 *
 * @param MemHandle	Memory Handle to convert.
 * @param VirtualAddr	Virtual address to convert.
 * @return 		The Protection Index coresponding to the 
 *			virtual address/Memory Handle pair.
 */
extern inline
VIP_UINT32
VipkVAtoPI(VIP_MEM_HANDLE	MemHandle,
	   VIP_PVOID		VirtualAddr)
{
    return (VIP_UINT32) (((unsigned long) VirtualAddr >> PAGE_SHIFT) - 
			 (unsigned long ) MemHandle);
}

/**
 * Translate a registered virtual address to a kernel address.
 *
 * @param RmmHandle	Registered Memory Manager to perform the translation.
 * @param VirtualAddr	Virtual address to translate.
 * @param MemHandle	Memory Handle of the virtual address.
 * @param Ptag		Matched against the Protection Tag of the registered
 *			memory region
 * @param NicInstance	The NicInstance associated with the memory region.
 * @param 		Type of access to be used on the translated address.
 * @return		If non-NULL, the translated address, otherwise,
 *			the address was invalid, the Protection Tags did not
 *			match, or the access flags were invalid (e.g. write
 *			access was requested, but not supported by the page.)
 */			
extern inline 
VIP_PVOID 
VipkRmmKaddr(VIPK_RMM_HANDLE		RmmHandle,
	     VIP_PVOID			VirtualAddr,
	     VIP_MEM_HANDLE		MemHandle,
	     VIP_PROTECTION_HANDLE	Ptag,
	     VIP_UINT32			Flags,
	     VIPK_NIC_INSTANCE		NicInstance)
{
    VIP_UINT32		ProtIndex = VipkVAtoPI(MemHandle, VirtualAddr);
    VIPK_RM_MANAGER	*RmmPtr = RmmHandle;

    return ( ProtIndex < RmmPtr->NumPages &&
	     RmmPtr->Rm[ProtIndex].NicInstance == NicInstance &&
	     RmmPtr->Rm[ProtIndex].VirtualPage == 
				((unsigned long)VirtualAddr & PAGE_MASK) &&
	     RmmPtr->Rm[ProtIndex].Ptag == Ptag && 
	     (RmmPtr->Rm[ProtIndex].Flags & Flags) == Flags ? 
	     (RmmPtr->Rm[ProtIndex].kaddr + 
			((unsigned long)VirtualAddr & ~PAGE_MASK)) : 0);
}



#endif /* _VIPK_RMM_H */
