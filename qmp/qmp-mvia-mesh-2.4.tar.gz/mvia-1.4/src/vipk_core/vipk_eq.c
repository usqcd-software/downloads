/* \file vipk_eq.c
 * 
 * Functions for managing error queues
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#include <linux/vmalloc.h>

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
/**
 * The following two attributes are defined twice
 */
#ifdef __attribute_pure__
#undef __attribute_pure__
#endif

#ifdef __attribute_used__
#undef __attribute_used__
#endif

#include <linux/string.h>
#include <linux/sched.h>


#endif

#include "vipk_eq.h"
#include "vipk_trace.h"


VIP_RETURN
VipkEQCreate(VIP_UINT32 Size, VIPK_EQ_HANDLE *EQHandle) 
{
    VIPK_EQ 	*EQPtr;
    VIP_UINT32	AllocSize;
    VIP_RETURN	Status;

    AllocSize = sizeof(VIPK_EQ) + (Size-1)  * sizeof(VIP_ERROR_DESCRIPTOR);

    TRACE(VIPK_TRACE_EQ, "[%d] Initializing Size: %d AllocSize: %d", 
	  current->pid, Size, AllocSize); 

    EQPtr = vmalloc(AllocSize);
    if(EQPtr == NULL) {
	TRACE(VIPK_TRACE_EQ, 
	      "[%d] Failed to allocate error queue", current->pid);
	Status = VIP_ERROR_RESOURCE;
    } else {
	memset(EQPtr, 0, AllocSize);
	EQPtr->Size = Size;
	spin_lock_init(&EQPtr->Lock);
	cond_init(&EQPtr->NonEmpty);
	Status = VIP_SUCCESS;
    }

    *EQHandle = EQPtr;
    return Status;
}

VIP_RETURN
VipkEQDestroy(VIPK_EQ_HANDLE EQHandle)
{
    VIPK_EQ *EQPtr = EQHandle;
    unsigned long Flags;

    spin_lock_irqsave(&EQPtr->Lock, Flags);
    
    TRACE(VIPK_TRACE_EQ, "[%d] EQ: 0x%p", current->pid, (void *)EQPtr);

    if(EQPtr->Closing) {
	TRACE(VIPK_TRACE_EQ, "[%d] EQ: 0x%p Informing waiter", 
	      current->pid, (void *)EQPtr);
	*EQPtr->Closing = VIP_TRUE;
	cond_signal(&EQPtr->NonEmpty);
	spin_unlock_irqrestore(&EQPtr->Lock, Flags);
    } else {
	spin_unlock_irqrestore(&EQPtr->Lock, Flags);
	vfree(EQPtr);
    }

    return VIP_SUCCESS;
}

VIP_RETURN
VipkEQEnqueue(VIPK_EQ_HANDLE	EQHandle,
	      VIP_NIC_HANDLE	NicUserHandle,
	      VIP_VI_HANDLE	ViUserHandle,
	      VIP_CQ_HANDLE	CQUserHandle,
	      VIP_DESCRIPTOR	*DescPtr,
	      VIP_ULONG 	OpCode,
	      VIP_RESOURCE_CODE ResourceCode,
	      VIP_ERROR_CODE	ErrorCode)
{
    VIPK_EQ *EQPtr = EQHandle;
    VIP_ERROR_DESCRIPTOR *ErrDescPtr;
    VIP_UINT32 Next;
    unsigned long Flags;
    
    spin_lock_irqsave(&EQPtr->Lock, Flags);

    TRACE(VIPK_TRACE_EQ, "[%d] EQ: 0x%p Head: %d Tail: %d "
	  "NicHandle: 0x%p ViHandle: 0x%p ResourceCode: %d ErrorCode: %d "
	  "CQHandle: 0x%p OpCode: %ld DescPtr: 0x%p",
	  current->pid, (void *)EQPtr, EQPtr->Head, EQPtr->Tail,
	  (void *)NicUserHandle, (void *)ViUserHandle, ResourceCode,
	  ErrorCode, (void *)CQUserHandle, OpCode, (void *)DescPtr);

    Next = EQPtr->Head + 1;
    if(Next == EQPtr->Size) {
	Next = 0;
    }
    
    if(Next == EQPtr->Tail) {
	TRACE(VIPK_TRACE_EQ, "EQ overflow, droping error");
	spin_unlock_irqrestore(&EQPtr->Lock, Flags);
	return VIP_ERROR_RESOURCE;
    }	

    ErrDescPtr = &EQPtr->ErrDesc[Next];
    EQPtr->Head = Next;

    ErrDescPtr->NicHandle 	= NicUserHandle;
    ErrDescPtr->ViHandle	= ViUserHandle;
    ErrDescPtr->CQHandle	= CQUserHandle;
    ErrDescPtr->DescriptorPtr	= DescPtr;
    ErrDescPtr->OpCode		= OpCode;
    ErrDescPtr->ResourceCode	= ResourceCode;
    ErrDescPtr->ErrorCode	= ErrorCode;

    cond_signal(&EQPtr->NonEmpty);
    spin_unlock_irqrestore(&EQPtr->Lock, Flags);

    return VIP_SUCCESS;
}

/* VipEqDequeue
 * 
 * Closing/deallocating the error queue must be performed if 
 * a higher level function calls VipkEQDestroy while we are waiting.
 * Set the EQPtr->Closing pointer to point to our local Closing
 * flag.  If our Closing flag becomes VIP_TRUE we must leave
 * and deallocate the error queue.
 *
 */
VIP_BOOLEAN
VipkEQDequeue(VIPK_EQ_HANDLE 		EQHandle, 
	      VIP_ERROR_DESCRIPTOR	*ErrDescPtr)
{
    VIPK_EQ *EQPtr = EQHandle;
    VIP_BOOLEAN Closing = VIP_FALSE;
    unsigned long Flags;
    unsigned long KernTimeout = MAX_SCHEDULE_TIMEOUT;

    spin_lock_irqsave(&EQPtr->Lock, Flags);

    TRACE(VIPK_TRACE_EQ, "[%d] EQ: 0x%p Head: %d Tail: %d", 
	  current->pid, (void *)EQPtr, EQPtr->Head, EQPtr->Tail);

    if(EQPtr->Closing != NULL) {
	TRACE(VIPK_TRACE_EQ, "[%d] EQ: 0x%p EQPtr->Closing != NULL",
	      current->pid, (void *)EQPtr);
	spin_unlock_irqrestore(&EQPtr->Lock, Flags);
	return VIP_FALSE;
    }

    EQPtr->Closing = &Closing;
    
    while(EQPtr->Head == EQPtr->Tail && !Closing && !signal_pending(current)) {
	cond_wait_interruptible(&EQPtr->NonEmpty, &EQPtr->Lock, &KernTimeout);
    }

    
    if(EQPtr->Head == EQPtr->Tail) {
	if(Closing) {
	    spin_unlock_irqrestore(&EQPtr->Lock, Flags);
	    vfree(EQPtr);
	} else {
	    EQPtr->Closing = NULL;
	    spin_unlock_irqrestore(&EQPtr->Lock, Flags);
	}
	return VIP_FALSE;
    }

    if(++EQPtr->Tail == EQPtr->Size) {
	EQPtr->Tail = 0;
    }

    TRACE(VIPK_TRACE_EQ, "[%d] EQ: 0x%p Found ErrDesc Head: %d Tail: %d", 
	  current->pid, (void *)EQPtr, EQPtr->Head, EQPtr->Tail);
    
    *ErrDescPtr = EQPtr->ErrDesc[EQPtr->Tail];
    
    TRACE(VIPK_TRACE_EQ, "[%d] EQ: 0x%p "
	  "NicHandle: 0x%p ViHandle: 0x%p ResourceCode: %d ErrorCode: %d "
	  "CQHandle: 0x%p OpCode: %ld DescPtr: 0x%p",
	  current->pid, (void *)EQPtr,
	  (void *)ErrDescPtr->NicHandle, (void *)ErrDescPtr->ViHandle,
	  ErrDescPtr->ResourceCode, ErrDescPtr->ErrorCode,
	  (void *)ErrDescPtr->CQHandle, ErrDescPtr->OpCode,
	  (void *)ErrDescPtr->DescriptorPtr);
    

    EQPtr->Closing = NULL;
    
    spin_unlock_irqrestore(&EQPtr->Lock, Flags);
    return VIP_TRUE;
}





