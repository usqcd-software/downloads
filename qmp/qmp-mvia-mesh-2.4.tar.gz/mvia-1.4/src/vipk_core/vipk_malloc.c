/** \file vipk_malloc.h
 * 
 * Debugging malloc for the VI Kernel Agent.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

/*
 * Note:
 * When the ethernet device drivers kfree memory which came from other
 * parts of the kernel we get a false corruption warning!
 */

#ifdef VIPK_DEBUG_MALLOC

/*
 * If VIPK_DEBUG_CHECK_FREE is defined, rather than actually freeing memory
 * on a call to kfree() we checksum it and at each subsequent kmalloc() or
 * kfree() call we verify that none of the freed memory blocks have been
 * modified.  This can get slow.
 */
#undef VIPK_DEBUG_CHECK_FREE

#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/vmalloc.h>

#include "vipk_trace.h"

static unsigned char prepad[] = 
/*            1         2         3         4         5         6      */
/*   1234567890123456789012345678901234567890123456789012345678901234  */
    "The quick brown fox jumps over the lazy dog.";

static unsigned char postpad[] = 
/*            1         2         3         4         5         6      */
/*   1234567890123456789012345678901234567890123456789012345678901234  */
    "Four score and seven years ago our forefathers...";

static unsigned char freepad[] = 
/*            1         2         3         4         5         6      */
/*   1234567890123456789012345678901234567890123456789012345678901234  */
    "This block has been freed at least once.";

#define VIPK_PAD_LEN	32
#define VIPK_FPAD_LEN	16

#ifdef VIPK_DEBUG_CHECK_FREE

struct free_block {
    unsigned char	pad[VIPK_FPAD_LEN];
    struct free_block	*next;
    unsigned long	size;
    unsigned short	csum;
};

static struct free_block *freed = NULL;

static void check_free(void)
{
    struct free_block *p;

    p = freed;
    while(p != NULL) {
	unsigned char *addr = (unsigned char *)p + VIPK_PAD_LEN;

	if(strncmp(p->pad, freepad, VIPK_FPAD_LEN) ||
	   (p->csum != ip_compute_csum(addr, p->size))) {
	    TRACE(VIPK_TRACE_ALL, "FREED MEM AT 0x%p REUSED", p);
	}
	p = p->next;
    }
}
#endif /* defined(VIPK_DEBUG_CHECK_FREE) */

void *vipk_kmalloc(const char *file, int line, const char *func,
		   size_t size, int prio)
{
    void *addr = kmalloc(size+2*VIPK_PAD_LEN, prio);

    strncpy(addr, prepad, VIPK_PAD_LEN - sizeof(size_t));
    strncpy(addr+VIPK_PAD_LEN+size, postpad, VIPK_PAD_LEN);

    addr += VIPK_PAD_LEN;
    ((size_t *)addr)[-1] = size;

    printk("%s:%d: %s: kmalloc(%lu, %d) = 0x%p\n",
	   file, line, func, (unsigned long)size, prio, addr);

#ifdef VIPK_DEBUG_CHECK_FREE
    check_free();
#endif

    return addr;
}

void vipk_kfree(const char *file, int line, const char *func, const void *addr)
{
#ifdef VIPK_DEBUG_CHECK_FREE
    struct free_block *p;
#endif
    size_t size;

    printk("%s:%d: %s: kfree(0x%p)\n", file, line, func, addr);

    size = ((size_t *)addr)[-1];
    addr -= VIPK_PAD_LEN;

    if(strncmp(addr, prepad, VIPK_PAD_LEN - sizeof(size_t))) {
	if(!strncmp(addr, freepad, VIPK_FPAD_LEN)) {
	    TRACE(VIPK_TRACE_ALL, "MULTIPLE FREE DETECTED (NOT REFREEING)");
	} else {
	    TRACE(VIPK_TRACE_ALL, "CORRUPTION IN PRE-PAD (NOT FREEING)");
	}
	return;
    } else if(strncmp(addr+VIPK_PAD_LEN+size, postpad, VIPK_PAD_LEN)) {
	TRACE(VIPK_TRACE_ALL, "CORRUPTION IN POST-PAD (NOT FREEING)");
	return;
    }

#ifdef VIPK_DEBUG_CHECK_FREE
    p = (struct free_block *)addr;
    strncpy(p->pad, freepad, VIPK_FPAD_LEN);
    p->size = size;
    p->csum = ip_compute_csum(addr+VIPK_PAD_LEN, size);
    p->next = freed;
    freed = p;

    check_free();
#else
    strncpy((void *)addr, freepad, VIPK_FPAD_LEN);
    kfree(addr);
#endif
}

void *vipk_vmalloc(const char *file, int line, const char *func,
		   unsigned long size)
{
    void *addr = vmalloc(size);
    printk("%s:%d: %s: vmalloc(%lu) = 0x%p\n", file, line, func, size, addr);
    return addr;
}

void vipk_vfree(const char *file, int line, const char *func, void *addr)
{
    printk("%s:%d: %s: vfree(0x%p)\n", file, line, func, addr);
    vfree(addr);
}

#endif /* defined(VIPK_DEBUG_MALLOC) */

