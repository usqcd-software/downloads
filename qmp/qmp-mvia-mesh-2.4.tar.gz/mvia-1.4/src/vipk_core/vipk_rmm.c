/* \file vipk_rmm.c
 * 
 * Implementation of a registered memory manager for the generalized
 * VI Kernel Agent.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#include <linux/kernel.h>
#include <linux/types.h>

#include <linux/errno.h>
#include <linux/slab.h>
#include <linux/vmalloc.h>
#include <asm/uaccess.h>

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
/**
 * The following two attributes are defined twice
 */
#ifdef __attribute_pure__
#undef __attribute_pure__
#endif
                                                                                
#ifdef __attribute_used__
#undef __attribute_used__
#endif
 
#include <linux/mm.h>
#include <linux/pagemap.h>
#endif

#include "vipk_rmm.h"
#include "vipk_trace.h"

#define ROUND_PAGE(addr) ((unsigned long) (addr) & PAGE_MASK)

#define VIPK_RMM_FREE ((VIPK_NIC_INSTANCE)0)
#define VIPK_RMM_BUSY ((VIPK_NIC_INSTANCE)~0)

#define VipkRmmIsFree(RmmPtr, Index)  \
	((RmmPtr)->Rm[(Index)].NicInstance == VIPK_RMM_FREE)

static int VipkRmmFindFree(VIPK_RM_MANAGER	*RmmPtr, 
			   VIP_UINT32		NumPages);

static void VipkRmmMakeFree(VIPK_RM_MANAGER	*RmmPtr, 
			    VIP_UINT32		ProtIndex,
			    VIP_UINT32		NumPages);

static inline VIP_RETURN
VipkRmmVerifyArea(struct mm_struct	*mm,
	          unsigned long		first_page,
	          unsigned long		last_page,
	          int			*read_only);

static inline caddr_t
VipkRmmGetPage(struct mm_struct	*mm,
	       unsigned long	addr,
	       int		read_only);


VIP_RETURN 
VipkRmmCreate(VIP_UINT32	NumRegions,
	      VIPK_RMM_HANDLE	*RmmHandle)
{
    VIPK_RM_MANAGER 	*RmmPtr;
    VIP_UINT32 		AllocSize;
    VIP_RETURN		Status;

    AllocSize = sizeof(VIPK_RM_MANAGER) + 
	(NumRegions-1) * sizeof(VIPK_RMM_PAGE);

    TRACE(VIPK_TRACE_RMM, "Initializing NumPages: %d AllocSize: %d", 
	  NumRegions, AllocSize);

    RmmPtr = vmalloc(AllocSize);
    
    if(RmmPtr == NULL) {
	TRACE(VIPK_TRACE_RMM, "Failed to allocate Rm Manager");
	return VIP_ERROR_RESOURCE;
    }

    memset(RmmPtr, 0, AllocSize);
    spin_lock_init(&RmmPtr->Lock);
    RmmPtr->NumPages = NumRegions;

    Status = VIP_SUCCESS;

    *RmmHandle = RmmPtr;

    return Status;
}


VIP_RETURN 
VipkRmmDestroy(VIPK_RMM_HANDLE	RmmHandle)
{
    TRACE(VIPK_TRACE_RMM, "Destroying");
    if(RmmHandle->NumMapped > 0) {
	TRACE(VIPK_TRACE_RMM, "NumMapped > 0");
	return VIP_ERROR_RESOURCE;
    }

    vfree(RmmHandle);
    return VIP_SUCCESS;
}

/* 
 * Notes:
 *	This could be split up a bit.  Faulting in pages and performing COW
 *	could be a separate function.
 *
 * 	Needs to call NIC specific notification routine.
 *
 *	
 */
VIP_RETURN 
VipkRmmRegister(VIPK_RMM_HANDLE 	RmmHandle,
		VIP_PVOID		VirtualAddr,
		VIP_ULONG		Length,
		VIP_MEM_ATTRIBUTES	*MemAttribs,
		VIP_MEM_HANDLE		*MemHandle,
		VIPK_NIC_INSTANCE	NicInstance)
{
    VIP_UINT32	NumPages;
    int		ProtIndexStart;
    int		ProtIndex;
    int		Error;
    int		ReadOnly;

    unsigned long FirstPage;
    unsigned long LastPage;
    unsigned long PageAddr;
    caddr_t     kaddr;

    /* compute the virtual address of the first and last page in the range */
    FirstPage = (unsigned long)VirtualAddr & PAGE_MASK;
    LastPage = ((unsigned long)VirtualAddr + Length - 1) & PAGE_MASK;
    NumPages = 1 + ((LastPage - FirstPage) >> PAGE_SHIFT);

    TRACE(VIPK_TRACE_RMM, "[%d] VirtualAddr: 0x%p Length: %ld NumPages: %d", 
	  current->pid, VirtualAddr, Length, NumPages);

    if(Length > (RmmHandle->NumPages-1) * PAGE_SIZE || Length == 0) {
	TRACE(VIPK_TRACE_RMM, "[%d] Bad Length", current->pid);
	return VIP_INVALID_PARAMETER;
    }

    Error = VipkRmmVerifyArea(current->mm, FirstPage, LastPage, &ReadOnly);
    if(Error != VIP_SUCCESS) {
	TRACE(VIPK_TRACE_RMM, "[%d] Unable to verify area", current->pid);
	return Error;
    }

    /* XXX: mismatch between vipconf and spec.. vipconf implies that
     * you are not allowed to register readonly memory, so reject it
     */
    if(ReadOnly) {
	TRACE(VIPK_TRACE_RMM, "[%d] Attempt to register read only memory",
	      current->pid);
	return VIP_INVALID_PARAMETER;
    }

    if(ReadOnly && MemAttribs->EnableRdmaWrite) {
	TRACE(VIPK_TRACE_RMM, "[%d] RDMA Write request on read only memory",
	      current->pid);    
	return VIP_ERROR_RESOURCE;
    }

    ProtIndexStart = VipkRmmFindFree(RmmHandle, NumPages);
    ProtIndex = ProtIndexStart;

    TRACE(VIPK_TRACE_RMM, "[%d] selected ProtIndex: %d",
	  current->pid, ProtIndex);

    if(ProtIndexStart < 0) {
	TRACE(VIPK_TRACE_RMM, "[%d] Unable to allocate ProtIndex",
	      current->pid);
	return VIP_ERROR_RESOURCE;
    }

    PageAddr = ROUND_PAGE(VirtualAddr);

    do {
	RmmHandle->Rm[ProtIndex].NicInstance = NicInstance;
	RmmHandle->Rm[ProtIndex].VirtualPage = PageAddr;
	RmmHandle->Rm[ProtIndex].Ptag = MemAttribs->Ptag;
	RmmHandle->Rm[ProtIndex].Flags = 
	    ((MemAttribs->EnableRdmaWrite ? VIPK_RMM_MEM_FLAGS_RDMA_WRITE : 0)|
	     (MemAttribs->EnableRdmaRead ? VIPK_RMM_MEM_FLAGS_RDMA_READ : 0) |
	     (ReadOnly ? VIPK_RMM_MEM_FLAGS_READ : VIPK_RMM_MEM_FLAGS_WRITE));
	RmmHandle->Rm[ProtIndex].VirtualAddr = VirtualAddr;
	RmmHandle->Rm[ProtIndex].NumPages = NumPages;

	kaddr = VipkRmmGetPage(current->mm, PageAddr, ReadOnly);
	RmmHandle->Rm[ProtIndex].kaddr = kaddr;
	RmmHandle->Rm[ProtIndex].paddr = (caddr_t)virt_to_phys(kaddr);

	TRACE(VIPK_TRACE_RMM, 
	      "[%d] Registering PageAddr: 0x%p KernAddr: 0x%p "
	      "ProtIndex: %d Ptag: 0x%lx NumPages: %d",
	      current->pid, (void *)PageAddr, (void *)kaddr,
	      ProtIndex, (VIPK_UINTPTR)MemAttribs->Ptag, NumPages);

 	PageAddr += PAGE_SIZE;
	ProtIndex++;
    } while(--NumPages);

    *MemHandle = VipkPItoHand(ProtIndexStart, VirtualAddr);

    TRACE(VIPK_TRACE_RMM, "[%d] Registered MemHandle: 0x%08x",
	  current->pid, *MemHandle);

    return VIP_SUCCESS;
}

VIP_RETURN 
VipkRmmDeregister(VIPK_RMM_HANDLE	RmmHandle,
		  VIP_PVOID		VirtualAddr,
		  VIP_MEM_HANDLE	MemHandle,
		  VIPK_NIC_INSTANCE	NicInstance)
{
    VIP_UINT32 		ProtFirst;
    VIP_UINT32 		ProtLast;
    VIPK_RMM_PAGE	*RmTbl;
    int			i;
    struct page *page;

    ProtFirst = VipkVAtoPI(MemHandle, VirtualAddr);

    TRACE(VIPK_TRACE_RMM, "[%d] MemHandle: 0x%08x", current->pid, MemHandle);

    if(ProtFirst > RmmHandle->NumPages) {
	TRACE(VIPK_TRACE_RMM, "[%d] ProtFirst: %d invalid",
	      current->pid, ProtFirst);
	return VIP_INVALID_PARAMETER;
    }

    RmTbl = RmmHandle->Rm;

    if(RmTbl[ProtFirst].NicInstance != NicInstance ||
       RmTbl[ProtFirst].VirtualAddr != VirtualAddr) {
	TRACE(VIPK_TRACE_RMM,
	      "[%d] Bad Addr/MemHandle NicInstance %d(%d)" ,
	      current->pid, 
	      NicInstance, RmTbl[ProtFirst].NicInstance);
	return VIP_INVALID_PARAMETER;
    }

    ProtLast = ProtFirst + RmTbl[ProtFirst].NumPages;

    /*
     * Unpin all the pages.
     */
    for(i=ProtFirst; i<ProtLast; ++i) {
#if 0
	if (RmTbl[i].NicInstance != NicInstance) {
	    TRACE(VIPK_TRACE_RMM, "[%d] Wrong owner at ProtIndex: %d",
		  current->pid, i);
	    ProtLast = i;
	    RmTbl[ProtFirst].NumPages = ProtLast - ProtFirst;
	    break;
	}
#endif

	TRACE(VIPK_TRACE_RMM, "[%d] Deregistering ProtIndex: %d",
	      current->pid, i);

	/* Jie Chen: 3/23/2004: In order to truly release the page
	 * We have to remove lock flag on this page first and then
	 * free this page
	 */
	page = virt_to_page(RmTbl[i].kaddr);
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
	TRACE(VIPK_TRACE_RMM, "[%d] Free Physical Page %p and page count = %d. ",
	      current->pid, page, page_count(page));

	TestClearPageLocked(page);
	if (!PageReserved(page))
	  SetPageDirty(page);
	page_cache_release (page);
	/* __free_page (page); */
#else
	clear_bit (PG_locked, &page->flags);
	free_page((unsigned long) RmTbl[i].kaddr);
#endif

	TRACE(VIPK_TRACE_RMM, "[%d] Done Free Physical Page %p. ",
	      current->pid, page);
    }

    /*
     * Free all the protection entries.
     */
    VipkRmmMakeFree(RmmHandle, ProtFirst, RmTbl[ProtFirst].NumPages);

    TRACE(VIPK_TRACE_RMM, "[%d] MemHandle: 0x%08x successfully destroyed",
	  current->pid, MemHandle);

    return VIP_SUCCESS;
}

VIP_RETURN
VipkRmmQueryMem(VIPK_RMM_HANDLE		RmmHandle,
		VIP_PVOID		VirtualAddr,
		VIP_MEM_HANDLE		MemHandle,
		VIP_MEM_ATTRIBUTES	*MemAttribs,
		VIPK_NIC_INSTANCE	NicInstance)
{
    VIP_UINT32	ProtIndex;

    ProtIndex = VipkVAtoPI(MemHandle, VirtualAddr);

    TRACE(VIPK_TRACE_RMM, "[%d] MemHandle: 0x%08x", current->pid, MemHandle);

    if(ProtIndex > RmmHandle->NumPages) {
    	TRACE(VIPK_TRACE_RMM, "[%d] ProtIndex: %d invalid",
	      current->pid, ProtIndex);
	return VIP_INVALID_PARAMETER;
    }

    if(RmmHandle->Rm[ProtIndex].NicInstance != NicInstance ||
       RmmHandle->Rm[ProtIndex].VirtualAddr != VirtualAddr) {
	TRACE(VIPK_TRACE_RMM,
	      "[%d] Bad Addr/MemHandle NicInstance %d(%d)" ,
	      current->pid, NicInstance, RmmHandle->Rm[ProtIndex].NicInstance);
	return VIP_INVALID_PARAMETER;
    }

    MemAttribs->Ptag = RmmHandle->Rm[ProtIndex].Ptag;
    MemAttribs->EnableRdmaWrite =
	(RmmHandle->Rm[ProtIndex].Flags & VIPK_RMM_MEM_FLAGS_RDMA_WRITE) != 0;
    MemAttribs->EnableRdmaRead =	
	(RmmHandle->Rm[ProtIndex].Flags & VIPK_RMM_MEM_FLAGS_RDMA_READ) != 0;

    return VIP_SUCCESS;
}

VIP_RETURN
VipkRmmSetMemAttributes(VIPK_RMM_HANDLE		RmmHandle,
			VIP_PVOID		VirtualAddr,
			VIP_MEM_HANDLE		MemHandle,
			VIP_MEM_ATTRIBUTES	*MemAttribs,
			VIPK_NIC_INSTANCE	NicInstance)
{
    VIP_UINT32	ProtIndex;

    ProtIndex = VipkVAtoPI(MemHandle, VirtualAddr);

    TRACE(VIPK_TRACE_RMM, "[%d] MemHandle: 0x%08x", current->pid, MemHandle);

    if(ProtIndex > RmmHandle->NumPages) {
    	TRACE(VIPK_TRACE_RMM, "[%d] ProtIndex: %d invalid",
	      current->pid, ProtIndex);
	return VIP_INVALID_PARAMETER;
    }

    if(RmmHandle->Rm[ProtIndex].NicInstance != NicInstance ||
       RmmHandle->Rm[ProtIndex].VirtualAddr != VirtualAddr) {
	TRACE(VIPK_TRACE_RMM,
	      "[%d] Bad Addr/MemHandle NicInstance %d(%d)" ,
	      current->pid, NicInstance, RmmHandle->Rm[ProtIndex].NicInstance);
	return VIP_INVALID_PARAMETER;
    }

    RmmHandle->Rm[ProtIndex].Ptag = MemAttribs->Ptag;
    RmmHandle->Rm[ProtIndex].Flags &= 
	    ~(VIPK_RMM_MEM_FLAGS_RDMA_WRITE | VIPK_RMM_MEM_FLAGS_RDMA_READ);
    RmmHandle->Rm[ProtIndex].Flags |= 
	((MemAttribs->EnableRdmaWrite ? VIPK_RMM_MEM_FLAGS_RDMA_WRITE : 0)|
	 (MemAttribs->EnableRdmaRead  ? VIPK_RMM_MEM_FLAGS_RDMA_READ  : 0));

    return VIP_SUCCESS;
}

VIP_RETURN 
VipkRmmDeregisterNic(VIPK_RMM_HANDLE 	RmmHandle,
		     VIPK_NIC_INSTANCE	NicInstance)
{
    VIP_UINT32 		ProtIndex;
    VIP_UINT32 		NumPages;
    struct page *page;
    
    ProtIndex = 0;
    do {
	NumPages = 1;	/* default for free entry */

	if(!VipkRmmIsFree(RmmHandle, ProtIndex)) {
	    NumPages = RmmHandle->Rm[ProtIndex].NumPages;

	    if(RmmHandle->Rm[ProtIndex].NicInstance == NicInstance) {
		VIP_UINT32 	ProtTmp;
		int i;

		/*
		 * Unpin the pages.
		 */
		for(i=NumPages, ProtTmp=ProtIndex; i != 0; i--, ProtTmp++) {
		    TRACE(VIPK_TRACE_RMM, "[%d] Deregistering ProtIndex: %d", 
			  current->pid, ProtTmp);

		    /* Jie Chen: 3/23/2004: In order to truly release the page
		     * We have to remove lock flag on this page first and then
		     * free this page
		     */
		    page = virt_to_page(RmmHandle->Rm[ProtTmp].kaddr);
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
		    TRACE(VIPK_TRACE_RMM, "[%d] Free set of page %p page count = %d", current->pid, page, page_count(page));

		    TestClearPageLocked(page);
		    if (!PageReserved(page))
		      SetPageDirty(page);
		    page_cache_release (page);
		    /* __free_page (page); */
#else
		    clear_bit (PG_locked, &page->flags);
		    free_page((unsigned long) RmmHandle->Rm[ProtTmp].kaddr);
#endif

		    TRACE(VIPK_TRACE_RMM, "[%d] Done Free set of page %p", 
			  current->pid, page);
		}

		/*
		 * Free the protection entries.
		 */
		VipkRmmMakeFree(RmmHandle, ProtIndex, NumPages);
	    }
	}

	ProtIndex += NumPages;
    } while(ProtIndex < RmmHandle->NumPages);

    TRACE(VIPK_TRACE_RMM, 
	  "[%d] all rm regions successfully deregistered", current->pid);

    return VIP_SUCCESS;
}

/*
 * Attempts to find NumPages consecutive free entries.
 * Marks the selected range to prevent reallocation.
 */
static int
VipkRmmFindFree(VIPK_RM_MANAGER *RmmHandle, 
		VIP_UINT32	NumPages)
{
    int i, j;

    i = 0;

    spin_lock(&RmmHandle->Lock);
try_again:
    for(; i < RmmHandle->NumPages; i++) {
	if(VipkRmmIsFree(RmmHandle, i)) {
	    break;
	}
    }

    if(i == RmmHandle->NumPages) {
	i = -1;
	goto out;
    }

    for(j=i; j < RmmHandle->NumPages && (j < (i + NumPages)); j++) {
	if(!VipkRmmIsFree(RmmHandle, j)) {
	    i = j;
	    goto try_again;
	}
    }
    
    if(j != (i + NumPages)) {
	i = -1;
    }

out:
    spin_unlock(&RmmHandle->Lock);
    return i;
}

/*
 * Free a non-empty range of protection entries.
 * We don't NEED the lock here, but holding it could help an allocation
 * which comes right behind us see the FULL range free rather than just
 * a few enries at the start of the range.
 * DO NOT CALL WITH (NumPages == 0)
 */
static void
VipkRmmMakeFree(VIPK_RM_MANAGER *RmmHandle, 
		VIP_UINT32	ProtIndex,
		VIP_UINT32	NumPages)
{
    spin_lock(&RmmHandle->Lock);

    do {
	TRACE(VIPK_TRACE_RMM, "[%d] Freeing ProtIndex: %d",
	      current->pid, ProtIndex);
	RmmHandle->Rm[ProtIndex].NicInstance = VIPK_RMM_FREE;
	ProtIndex++;
    } while (--NumPages);

    spin_unlock(&RmmHandle->Lock);
}

static inline VIP_RETURN
VipkRmmVerifyArea(struct mm_struct	*mm,
		  unsigned long		first_page,
		  unsigned long		last_page,
		  int			*read_only)
{
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0))
# define down_read(X)	down(X)
# define up_read(X)	up(X)
#endif

    unsigned long addr = first_page;
    struct vm_area_struct *vma;
    int tmp;

    tmp = 0;
    down_read(&current->mm->mmap_sem);
    vma = find_vma(current->mm, addr);
    do {
	if (!(vma && vma->vm_start <= addr)) {
	    up_read(&current->mm->mmap_sem);
	    return VIP_INVALID_PARAMETER;
	}
	tmp |= !(vma->vm_flags & VM_WRITE);
	addr = vma->vm_end;
	vma = vma->vm_next;
    } while (addr < last_page);
    up_read(&current->mm->mmap_sem);

    *read_only = tmp;
    return VIP_SUCCESS;
}

static inline caddr_t
VipkRmmGetPage(struct mm_struct	*mm,
	       unsigned long	addr,
	       int		read_only)
{
    struct page	*page_map;
    caddr_t     kaddr;
    char	c;
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
    pmd_t *pmd;
    pte_t *ptep, pte;
#endif

    /* Make sure the page has been faulted in and cow performed.
     *
     * XXX: is the correct?  If the page is read only, this process
     * can not generate a copy on write, but what if the page is shared
     * with another process and that _other_ process has write privliges
     * and performs a write to the page.  Who keeps this page?  Should
     * we just do the write here anyway?
     *
     * XXX: make_pages_present() is the right way to do this.
     * Unfortunately, it is not exported to modules by the kernel.
     */
    __get_user(c, (char *)addr);
    if(!read_only) {
	__put_user(c, (char *)addr);
    }

    /* Find the kernel virtual address for the given user virtual
     * address and then pin the page. */
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
    spin_lock(&mm->page_table_lock);
    pmd = pmd_offset (pgd_offset(mm, addr), addr);
    ptep = pte_offset_map(pmd, addr);
    pte = *ptep;
    page_map = pte_page (pte);
    kaddr = page_address(page_map);
    get_page(page_map);

    /* 2.6 we have to unmap pte pointer */
    pte_unmap (ptep);


    /* Jie: 3/23/2004: get_page above increase page->count and not locked
     * In order to lock a physical page we have to set either PG_locked
     * or PG_reserved to prevent try_swap_out () function to swap the page out
     */
    TestSetPageLocked (page_map);

    spin_unlock(&mm->page_table_lock);
#else

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0))
    spin_lock(&mm->page_table_lock);
    page_map = 
	pte_page(*pte_offset(pmd_offset(pgd_offset(mm, addr), addr), addr));
    kaddr = page_address(page_map);
    get_page(page_map);

    /* Jie: 3/23/2004: get_page above increase page->count and not locked
     * In order to lock a physical page we have to set either PG_locked
     * or PG_reserved to prevent try_swap_out () function to swap the page out
     */
    test_and_set_bit (PG_locked, &page_map->flags);

    spin_unlock(&mm->page_table_lock);
#else
    kaddr = (caddr_t)
	pte_page(*pte_offset(pmd_offset(pgd_offset(mm, addr), addr), addr));
    page_map = mem_map + MAP_NR(kaddr);
    atomic_inc(&page_map->count);
#endif

#endif

    return kaddr;
}
