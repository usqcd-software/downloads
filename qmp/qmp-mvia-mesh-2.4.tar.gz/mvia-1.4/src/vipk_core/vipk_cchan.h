/** \file vipk_cchan.h
 *
 * Interface for M-VIA Control Channel
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#ifndef _VIPK_CCHAN_H
#define _VIPK_CCHAN_H

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
#include <linux/workqueue.h>
#else
#include <linux/tqueue.h>
#endif

#include "vipk_types.h"

/** Control Channel Operation. */
enum {
    VIPK_CCHAN_OP_ACK	= 1,
    VIPK_CCHAN_OP_CONNREQ,
    VIPK_CCHAN_OP_CONNACC,
    VIPK_CCHAN_OP_CONNREJ,
    VIPK_CCHAN_OP_CONNNOM,
    VIPK_CCHAN_OP_CONNCCMP,
    VIPK_CCHAN_OP_CONNSCMP,
    VIPK_CCHAN_OP_CONNTO,
    VIPK_CCHAN_OP_PEERREQ,
    VIPK_CCHAN_OP_PEERACC,
    VIPK_CCHAN_OP_PEER1CMP,
    VIPK_CCHAN_OP_PEER2CMP,
    VIPK_CCHAN_OP_PEERTO,
    VIPK_CCHAN_OP_CONNLOST,
    VIPK_CCHAN_OP_DISCO,
};

/** 
    Control Channel Packet.

    Defines the control channel packet structure.  Unused fields are
    passed with undefined values.

    XXX:
    Currently the entire packet goes out over the wire regardless of
    which fields are really needed.  This should be fixed w/ a union
    and a length/type argument to VipkCChanSendControl and to
    the device-specific SendControl.
 */
typedef struct {
    /** [000-001] Packet Id */
    VIP_UINT16		PSN;
    
    /** [002-003] Used to verify ACK for a PSN */
    VIP_UINT16		Token;

    /** [004-005] Operation to perform */
    VIP_UINT16		Op;

    /** [006-007] Padding for alignment */
    VIP_UINT16		_pad0;

    /** [008-075] Source address */
    VIP_NET_MAX_ADDRESS	SrcAddr;

    /** [076-143] Destination address */
    VIP_NET_MAX_ADDRESS	DstAddr;

    /** [144-147] Connecton session.  Used to distinguish stale responses. */
    VIP_UINT32		Session;

    /** [148-151] Connection handle of the sender of the packet. */
    VIPK_CONN_HANDLE	SrcConnHandle;

    /** [152-155] Connection handle of the receiver of the packet. */
    VIPK_CONN_HANDLE	DstConnHandle;

    /** [156-159] Source kernel VI handle */
    VIPK_VI_HANDLE	ViHandle;

    /** [160-163] Source VI initial sequence number */
    VIP_UINT32		Sequence;
    
    /** Source VI attributes with fixed widths: */
    VIP_UINT16		EnableRdmaWrite;	/* [164-165] */
    VIP_UINT16		EnableRdmaRead;		/* [166-167] */
    VIP_UINT32		ReliabilityLevel;	/* [168-171] */
    VIP_UINT32		MaxTransferSize;	/* [172-175] */
    VIP_UINT64		QoS;			/* [176-183] */
    VIP_UINT64		Ptag;			/* [184-191] */

    /** The following union is not sent out on the wire: */
    union {
	/** Space for the device-specific header of TXed packtes*/
	VIP_UINT8		DevHdr[1];

	/** In-memory linked list of  RXed packets */
	VIP_PVOID		Next;
    } u;
} VIPK_CCHAN_PACKET;

extern inline void
VipkEncodeAttribs(VIPK_CCHAN_PACKET		*Dest,
		  const VIP_VI_ATTRIBUTES	*Src)
{
    Dest->ReliabilityLevel = VIPK_SWAB32(Src->ReliabilityLevel);
    Dest->MaxTransferSize  = VIPK_SWAB32(Src->MaxTransferSize);
    Dest->QoS		   = VIPK_SWAB64((unsigned long)Src->QoS);
    Dest->Ptag		   = VIPK_SWAB64((unsigned long)Src->Ptag);
    Dest->EnableRdmaWrite  = VIPK_SWAB16(Src->EnableRdmaWrite);
    Dest->EnableRdmaRead   = VIPK_SWAB16(Src->EnableRdmaRead);
}

extern inline void
VipkDecodeAttribs(VIP_VI_ATTRIBUTES		*Dest,
		  const VIPK_CCHAN_PACKET	*Src)
{
    Dest->ReliabilityLevel = (VIP_RELIABILITY_LEVEL)
					VIPK_SWAB32(Src->ReliabilityLevel);
    Dest->MaxTransferSize  = (VIP_ULONG)
					VIPK_SWAB32(Src->MaxTransferSize);
    Dest->QoS		   = (VIP_QOS)(unsigned long)
					VIPK_SWAB64(Src->QoS);
    Dest->Ptag		   = (VIP_PROTECTION_HANDLE)(unsigned long)
					VIPK_SWAB64(Src->Ptag);
    Dest->EnableRdmaWrite  = (VIP_BOOLEAN)
					VIPK_SWAB16(Src->EnableRdmaWrite);
    Dest->EnableRdmaRead   = (VIP_BOOLEAN)
					VIPK_SWAB16(Src->EnableRdmaRead);
}

#include "vipk_cm.h"

struct _VIPK_CCHAN {
    void *Private;

    VIP_RETURN (*Init)(VIPK_CCHAN	*VipkCChan,
		       VIPK_DEVICE	*DevicePtr,
		       VIPK_CM		*Cm,
		       VIP_RETURN 	(*SendControl) (VIPK_DEVICE *DevicePtr,
							VIPK_CCHAN_PACKET *));

    VIP_RETURN (*Destroy) 	(VIPK_CCHAN		*CChan);

    VIP_RETURN (*GetPacket) 	(VIPK_CCHAN		*CChan,
				 VIPK_CCHAN_PACKET	**Pkt);

    VIP_RETURN (*SendControl) 	(VIPK_CCHAN		*CChan,
				 VIP_BOOLEAN		Block,
				 VIPK_CCHAN_PACKET	*Pkt);
    
    VIP_RETURN (*RecvControl) 	(VIPK_CCHAN		*CChan,
				 VIPK_CCHAN_PACKET	*Pkt);

    void (*CompleteControl)	(VIPK_CCHAN		*CChan,
				 VIPK_CCHAN_PACKET	*Pkt);
};
			
extern const VIPK_CCHAN VipkCChanDefault;

#endif


