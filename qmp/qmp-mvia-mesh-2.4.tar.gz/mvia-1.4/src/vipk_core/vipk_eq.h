/* \file vipk_eq.h 
 * 
 * Interface for VIA error queue data structure.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#ifndef _VIPK_EQ_H
#define _VIPK_EQ_H

#include <linux/config.h>
#include <linux/kernel.h>
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0))
#include <linux/spinlock.h>
#else
#include <asm/spinlock.h>
#endif

#include "condvar.h"
#include <vipl.h>

typedef struct _VIPK_EQ *VIPK_EQ_HANDLE;

/** \def VIPK_EQ_PER_PAGE
 *  Size of error queue that will fit in one page. 
 */
#define VIPK_EQ_PER_PAGE (((PAGE_SIZE - sizeof(VIPK_EQ)) 	\
			   / sizeof(VIP_ERROR_DESCRIPTOR)) - 1)

/** 
 * Create an asynchronous error queue.
 * @param Size 		Number of elements to allocate for the ciruclar 
 * 			error queue.
 * @param EQHandle 	The newly created error queue.
 * @return 	\c VIP_SUCCESS - The error queue was successfully created.<br>
 *		\c VIP_ERROR_RESOURCE - Insufficient resources to create the
 *		error queue.
 */
extern VIP_RETURN 	
VipkEQCreate(VIP_UINT32 	Size, 
	     VIPK_EQ_HANDLE	*EQHandle);

/**
 * Destroy an asynchronous error queue.
 *
 * @param EQHandle	The error queue to destroy.
 * @return 		\c VIP_SUCCESS - The error queue was 
 *			successfully destroyed.
 *
 * If there is someone currently waiting on the queue it can not be
 * freed out from under them.  A waiter will set VIPK_EQ::Closing to 
 * a pointer they can access to determine if they need to free the
 * queue when they wake up.  In other words, VIPK_EQ::Closing serves as both a 
 * flag that there is currently a waiter and also tells this function
 * where to make the notification of close.
 */
extern VIP_RETURN	
VipkEQDestroy(VIPK_EQ_HANDLE 	EQHandle);

/** 
 * Enqueue an error to an asynchronous error queue.
 *
 * @param EQHandle	The error queue in which to enqueue the error.
 * @param NicUserHandle	The VIPL VIP_NIC_HANDLE associated with the error.
 * @param ViUserHandle	The VIPL VIP_VI_HANDLE associated with the error.
 * @param CQUserHandle	The VIPL VIP_CQ_HANDLE associated with the error.
 * @param DescPtr	The user space pointer to the descriptor associated
 *			with the error.
 * @param OpCode	The operation code associated with the error.
 * @param ResourceCode	The VIP_RESOURCE_CODE associated with the error.
 * @param ErrorCode	The VIP_ERROR_CODE associated with the error.
 * @return 	\c VIP_SUCCESS - The error was successfully enqueue.<br>
 * 		\c VIP_ERROR_RESOURCE - An error queue overflow occured.
 */
extern VIP_RETURN 	
VipkEQEnqueue(VIPK_EQ_HANDLE 	EQHandle,
	      VIP_NIC_HANDLE	NicUserHandle,
	      VIP_VI_HANDLE	ViUserHandle,
	      VIP_CQ_HANDLE	CQUserHandle,
	      VIP_DESCRIPTOR	*DescPtr,
	      VIP_ULONG 	OpCode,
	      VIP_RESOURCE_CODE ResourceCode,
	      VIP_ERROR_CODE	ErrorCode);

/**
 * Dequeue an asynchronous error from the error queue.
 *
 * Called by the error thread for the Nic.  It is invalid for
 * this function to be called twice on the same Nic instance.
 *
 * @param EQHandle	The error queue from which to dequeue the error.
 * @param ErrDescPtr	A pointer to the VIP_ERROR_DESCRIPTOR in which 
 *			to store the error information.
 * @return 	\c VIP_SUCCESS - The error was successfully dequeued.<br>
 * 		\c VIP_ERROR_RESOURCE - The Nic associated with this error
 *		queue is being closed.
 */
extern VIP_BOOLEAN 	
VipkEQDequeue(VIPK_EQ_HANDLE		EQHandle, 
	      VIP_ERROR_DESCRIPTOR	*ErrDescPtr);

/* Remainder of this file is private to the implementation */

/** Ansynchronous error queue. */
typedef struct _VIPK_EQ {
    /** Number of elements in the circular error queue. */
    VIP_UINT32			Size;
    /** Head of the error queue. */
    VIP_UINT32 			Head;
    /** Tail of the error queue. */
    VIP_UINT32 			Tail;
    /** Closing flag.
     * @see VipkEQDestroy().
     */
    VIP_BOOLEAN			*Closing;
    /** Mutex lock */
    spinlock_t			Lock;
    /** Condition variable to signal a non-empty condition. */
    condvar_t			NonEmpty;
    /** The circular error queue entries. */
    VIP_ERROR_DESCRIPTOR 	ErrDesc[1];
} VIPK_EQ;


#endif


