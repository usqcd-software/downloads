/** \file vipk_types.h
 *
 * Type definitions ofor the M-VIA kernel agent.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#ifndef _VIPK_TYPES_H
#define _VIPK_TYPES_H

#include <vipl_private.h>
#include <asm/byteorder.h>

typedef VIP_UINT32 		VIPK_NIC_INSTANCE;
typedef struct _VIPK_DEVICE 	VIPK_DEVICE;
typedef struct _VIPK_VI		VIPK_VI;
typedef struct _VIPK_CCHAN 	VIPK_CCHAN;

/** \def VIPK_NO_OWNER
 * Used to signify no pid owns a given resource.
 */    
#define VIPK_NO_OWNER -1
typedef VIP_UINT32 VIPK_OWNER;


/* Select a byteorder for M-VIA's wire-format.
 * Individual devices might ignore this for device-level headers
 */
#define	VIPK_LITTLE_ENDIAN
#undef	VIPK_BIG_ENDIAN

#ifdef	VIPK_LITTLE_ENDIAN
		/* return possibly swapped integer argument */
# define	VIPK_SWAB16(X)	cpu_to_le16(X)
# define	VIPK_SWAB32(X)	cpu_to_le32(X)
# define	VIPK_SWAB64(X)	cpu_to_le64(X)
		/* return possibly swapped pointer argument */
# define	VIPK_SWAB16P(X)	cpu_to_le16p(X)
# define	VIPK_SWAB32P(X)	cpu_to_le32p(X)
# define	VIPK_SWAB64P(X)	cpu_to_le64p(X)
		/* possibly swap pointer argument in place */
# define	VIPK_SWAB16S(X)	cpu_to_le16s(X)
# define	VIPK_SWAB32S(X)	cpu_to_le32s(X)
# define	VIPK_SWAB64S(X)	cpu_to_le64s(X)
#endif

#ifdef	VIPK_BIG_ENDIAN
		/* return possibly swapped integer argument */
# define	VIPK_SWAB16(X)	cpu_to_be16(X)
# define	VIPK_SWAB32(X)	cpu_to_be32(X)
# define	VIPK_SWAB64(X)	cpu_to_be64(X)
		/* return possibly swapped pointer argument */
# define	VIPK_SWAB16P(X)	cpu_to_be16p(X)
# define	VIPK_SWAB32P(X)	cpu_to_be32p(X)
# define	VIPK_SWAB64P(X)	cpu_to_be64p(X)
		/* possibly swap pointer argument in place */
# define	VIPK_SWAB16S(X)	cpu_to_be16s(X)
# define	VIPK_SWAB32S(X)	cpu_to_be32s(X)
# define	VIPK_SWAB64S(X)	cpu_to_be64s(X)
#endif

#ifndef VIPK_SWAB16
# error No byteorder was selected.
#endif

#endif
