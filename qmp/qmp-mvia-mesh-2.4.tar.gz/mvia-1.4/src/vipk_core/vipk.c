/* vipk/vipk.c
 *
 * Implementation of the generalized VI Kernel Agent
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#ifdef MODULE
#define EXPORT_SYMTAB
#include <linux/module.h> 
#else
#define MOD_INC_USE_COUNT
#define MOD_DEC_USE_COUNT
#endif

#include <linux/config.h>
#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/types.h>

#include <linux/kmod.h>

#include <linux/errno.h>
#include <linux/slab.h>
#include <linux/vmalloc.h>
#include <asm/uaccess.h>

/* VIPK_MAIN causes copyright to be included in object file */
#define VIPK_MAIN
#include "copyright.h"


#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
/**
 * The following two attributes are defined twice
 */
#ifdef __attribute_pure__
#undef __attribute_pure__
#endif

#ifdef __attribute_used__
#undef __attribute_used__
#endif

#endif

#include "vipk.h"
#include "vipk_limits.h"
#include "vipk_trace.h"

#if MVIA_HAS_FAST_TRAP
# include <fast_trap.h>
#endif

/* TODO: Sort these in an inteligent manner */
EXPORT_SYMBOL(VipkRegisterDevice);
EXPORT_SYMBOL(VipkPostRecv);
EXPORT_SYMBOL(VipkPostError);
EXPORT_SYMBOL(VipkPostDeviceError);
EXPORT_SYMBOL(VipkViFlushDescs);
EXPORT_SYMBOL(VipkRecv);
EXPORT_SYMBOL(VipkRecvRdmaWrite);
EXPORT_SYMBOL(VipkPostDescError);
EXPORT_SYMBOL(VipkQueryMem);
EXPORT_SYMBOL(VipkConnectPeerRequest);
EXPORT_SYMBOL(VipkConnectionLost);
EXPORT_SYMBOL(VipkRecvWait);
EXPORT_SYMBOL(VipkSetMemAttributes);
EXPORT_SYMBOL(VipkConnectWait);
EXPORT_SYMBOL(VipkDestroyVi);
EXPORT_SYMBOL(VipkPostSend);
EXPORT_SYMBOL(VipkCreateVi);
EXPORT_SYMBOL(VipkSetViAttributes);
EXPORT_SYMBOL(VipkFetchError);
EXPORT_SYMBOL(VipkDeregisterMem);
EXPORT_SYMBOL(VipkViConnectionLost);
EXPORT_SYMBOL(VipkViSendCompleteErr);
EXPORT_SYMBOL(VipkViRecvCompleteErr);
EXPORT_SYMBOL(VipkDestroyCq);
EXPORT_SYMBOL(VipkOpenNic);
EXPORT_SYMBOL(VipkCmDefault);
EXPORT_SYMBOL(VipkConnectRequest);
EXPORT_SYMBOL(VipkCqPreWait);
EXPORT_SYMBOL(VipkQueryVi);
EXPORT_SYMBOL(VipkCreateCq);
EXPORT_SYMBOL(VipkQueryNic);
EXPORT_SYMBOL(VipkCreatePtag);
EXPORT_SYMBOL(VipkDeregisterDevice);
EXPORT_SYMBOL(VipkDisconnect);
EXPORT_SYMBOL(VipkSendWait);
EXPORT_SYMBOL(VipkRegisterMem);
EXPORT_SYMBOL(VipkDestroyPtag);
EXPORT_SYMBOL(VipkCChanDefault);
EXPORT_SYMBOL(VipkConnectPeerDone);
EXPORT_SYMBOL(VipkCqWait);
EXPORT_SYMBOL(VipkPreWait);
EXPORT_SYMBOL(VipkResizeCq);
EXPORT_SYMBOL(VipkConnectAccept);
EXPORT_SYMBOL(VipkConnectReject);
EXPORT_SYMBOL(VipkCqEnqueue);
EXPORT_SYMBOL(cond_init);
EXPORT_SYMBOL(cond_wait);
EXPORT_SYMBOL(cond_wait_interruptible);
EXPORT_SYMBOL(cond_signal);
#ifdef VIPK_TRACE_NONE
EXPORT_SYMBOL(vipk_trace);
EXPORT_SYMBOL(VipkTrace);
#endif

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0))
#include "vipk_2_2_compat.h"
#endif

/** Major device number.
 * See /usr/src/linux/Documentation/devices.txt for a list of allowed
 * LOCAL/EXPERIMENTAL device numbers.  Once this driver is in the main-stream
 * we need to follow the instructions in devices.txt to request an official
 * device id for the VIA control device
 */
#ifdef VIPK_CHAR_MAJOR
#define VIPK_MAJOR MVIA_CHAR_MAJOR
#else
#define VIPK_MAJOR 60
#endif

/** Maximum number of devices supported by the framework */
static VIP_UINT32	VipkMaxDevices = VIPK_MAX_DEVICES;

/** Array of device pointers */
static VIPK_DEVICE	**VipkDevicePtr;

/** Mutex for VipDevicePtr access */
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0))
static DECLARE_MUTEX(VipkDeviceSem);
#else
struct semaphore VipkDeviceSem = MUTEX;
#endif

/** Flag to determine if the Vipk framework should enforce drivers
 * to confrom to the minimum resource requirements. 
 * If EnforceConformance is set, then devices must support Min/Max values
 * as specified in the IDG.  If false, allow non-conforming drivers
 * to register themselves.
 */
static VIP_BOOLEAN	VipkEnforceConformance = VIP_TRUE;

/** The fast-trap operations table. */
VIPK_FAST_OPS_DESCRIPTOR VipkFastOpsTable[VIPK_MAX_DEVICES];

/** Initializer for fast-trap operations table. */
static const VIPK_FAST_OPS_DESCRIPTOR VipkFastOpsNull = {
    NULL,
    (unsigned long) VipkBadOp,
    (unsigned long) VipkBadOp,
    (unsigned long) VipkBadOp,
};


/**
 * Register a device with the M-VIA Kernel Agent.
 *
 * M-VIA Device Drivers call this function to register themsevles with
 * the M-VIA Kernel Agent.  
 *
 * Verifies as best as possible that the device being passed to the
 * routine has valid attributes.
 *
 * SPEC: 
 * 	Is there still a minimum MaxTransferSize?  It is not listed
 *	in the VIA-IG 0.66 section on NIC Attributes.  If there is
 *	still a minimum, verify it here.
 *
 * @param DevicePtr Pointer to the VIPK_DEVICE which is 
 *	requesting the registration.
 * @return 	\c VIP_SUCCESS - Device was successfully registered.<br>
 *		\c VIP_INVALID_PARAMETER - The device structure contained
 *		invalid attributes.
 *		\c VIP_ERROR_RESOURCE - No more free device entries.
 */
VIP_RETURN
VipkRegisterDevice(VIPK_DEVICE 		*DevicePtr)
{
    VIP_NIC_ATTRIBUTES *NicAttribs;
    int FreeIndex;
    int i;

    if(DevicePtr->DeviceName == NULL) {
	TRACE(VIPK_TRACE_REGDEV, "DevicePtr->DeviceName == NULL");
	return VIP_INVALID_PARAMETER;
    }

    TRACE(VIPK_TRACE_REGDEV, "%s", DevicePtr->DeviceName);

    if(DevicePtr->MinorNum == 0) {
	TRACE(VIPK_TRACE_REGDEV, "Illegal attempt to register MinorNum 0");
	return VIP_INVALID_PARAMETER;
    }
    
    NicAttribs = DevicePtr->NicAttribs;
    if(NicAttribs == NULL) {
	TRACE(VIPK_TRACE_REGDEV, "NicAttribs must not be NULL");
	return VIP_INVALID_PARAMETER;
    }  		  

    if(DevicePtr->DeviceOps == NULL) {
	TRACE(VIPK_TRACE_REGDEV, "DeviceOps must not be NULL");
	return VIP_INVALID_PARAMETER;
    }

    if((DevicePtr->DeviceOps->open || DevicePtr->DeviceOps->close) && 
       (!DevicePtr->DeviceOps->open || !DevicePtr->DeviceOps->close)) {
	TRACE(VIPK_TRACE_REGDEV, "Invalid combination of DeviceOps");
    }
	
    if(VipkEnforceConformance) {
	if(NicAttribs->MaxDiscriminatorLen < VIPK_MIN_DISCRIMINATOR_LEN) {
	    TRACE(VIPK_TRACE_REGDEV, "Invalid MaxDiscriminatorLen");
	    return VIP_INVALID_PARAMETER;
	}	

	if(NicAttribs->MaxPtags < NicAttribs->MaxVI) {
	    TRACE(VIPK_TRACE_REGDEV, "MaxPtags < MaxVI");
	    return VIP_INVALID_PARAMETER;
	}	
    }

    /* Scan for an open index in the device array, but don't stop there.
     * We must continue scanning through the entire array to make sure 
     * that no one else farther down the array is using our minor number.
     * At the end of the for loop, FreeIndex will contain the first free 
     * index found.
     */
    FreeIndex = -1;
    down(&VipkDeviceSem);
    for(i=0; i < VipkMaxDevices; i++) {
	if(VipkDevicePtr[i] != NULL) {
	    if(VipkDevicePtr[i]->MinorNum == DevicePtr->MinorNum) {
		TRACE(VIPK_TRACE_REGDEV,
		      "MinorNum in use by: %s",
		      VipkDevicePtr[i]->DeviceName);
		up(&VipkDeviceSem);
		return VIP_INVALID_PARAMETER;
	    }
	} else {
	    FreeIndex = FreeIndex < 0 ? i : FreeIndex;
	}
    }

    if(FreeIndex < 0) {
	TRACE(VIPK_TRACE_REGDEV, "No more free devices");
	up(&VipkDeviceSem);
	return VIP_ERROR_RESOURCE;
    }

    VipkDevicePtr[FreeIndex] = DevicePtr;
    DevicePtr->DeviceIndex = FreeIndex;

    /* Setup the NextInstance counter */
    DevicePtr->NextInstance = 1;
    spin_lock_init(&DevicePtr->Lock);

    /* XXX: doc and handle the following with dev specific setups */

    if(VipkPtmCreate(DevicePtr->NicAttribs->MaxPtags,
		     &DevicePtr->PtmHandle) != VIP_SUCCESS) {
	TRACE(VIPK_TRACE_REGDEV, "Failed to create protection tag map");
	goto bad_ptm;
    }

    if(VipkRmmCreate(DevicePtr->NicAttribs->MaxRegisterRegions,
		     &DevicePtr->RmmHandle) != VIP_SUCCESS) {
	TRACE(VIPK_TRACE_REGDEV, "Failed to create registered memory map");
	goto bad_rmm;
    }

    if(VipkCqmCreate(DevicePtr->NicAttribs->MaxCQ,
		     DevicePtr->NicAttribs->MaxCQEntries,
		     &DevicePtr->CqmHandle) != VIP_SUCCESS) {
	TRACE(VIPK_TRACE_REGDEV, "Failed to create completion queue manager");
	goto bad_cqm;
    }

    DevicePtr->Vi = vmalloc(sizeof(VIPK_VI) * DevicePtr->NicAttribs->MaxVI);
    if(DevicePtr->Vi == NULL) {
	TRACE(VIPK_TRACE_REGDEV, "Failed to init VIs");
	goto bad_vi;
    }

    memset(DevicePtr->Vi, 0, sizeof(VIPK_VI) * DevicePtr->NicAttribs->MaxVI);
    for(i = 0; i < DevicePtr->NicAttribs->MaxVI; i++) {
	DevicePtr->Vi[i].Owner = VIPK_NO_OWNER;
    }

    if(DevicePtr->UsesFastOps) {
	if(VipkFastOpsTable[FreeIndex].DevicePtr == NULL) {
	    TRACE(VIPK_TRACE_REGDEV, "Set FastOps[%d]", FreeIndex);
	    VipkFastOpsTable[FreeIndex].DevicePtr = DevicePtr;
	    VipkFastOpsTable[FreeIndex].VipkPostSend = 
		(unsigned long) DevicePtr->DeviceOps->VipkPostSend;
	    VipkFastOpsTable[FreeIndex].VipkPostRecv = 
		(unsigned long) DevicePtr->DeviceOps->VipkPostRecv;
	} else {
	    TRACE(VIPK_TRACE_REGDEV, "FastOps out of sync with dev table");
	}
    } else {
	TRACE(VIPK_TRACE_REGDEV, "Not using FastOps");
    }

    TRACE(VIPK_TRACE_REGDEV, "Registered: %s MinorNum: %d Index: %d",
	  DevicePtr->DeviceName, DevicePtr->MinorNum, 
	  DevicePtr->DeviceIndex);

    up(&VipkDeviceSem);
    return VIP_SUCCESS;
    
bad_vi:
    VipkCqmDestroy(DevicePtr->CqmHandle);
bad_cqm:
    VipkRmmDestroy(DevicePtr->RmmHandle);
bad_rmm:
    VipkPtmDestroy(DevicePtr->PtmHandle);
bad_ptm:
    VipkDevicePtr[i] = NULL;

    up(&VipkDeviceSem);
    return VIP_ERROR_RESOURCE;
}


/**
 * Deregister a device from the M-VIA Kernel Agent.
 *
 * @param DevicePtr - Pointer to device to deregister
 * @return: VIP_SUCCESS	- Device was successfully deregistered
 *
 * Notes:
 */
VIP_RETURN
VipkDeregisterDevice(VIPK_DEVICE *DevicePtr)
{

    TRACE(VIPK_TRACE_REGDEV, "%s", DevicePtr->DeviceName);

    down(&VipkDeviceSem);

    if(DevicePtr->UsesFastOps) {
	if(VipkFastOpsTable[DevicePtr->DeviceIndex].DevicePtr != DevicePtr) {
	    TRACE(VIPK_TRACE_REGDEV, "%s Bad VipkFastOpsTable entry", 
		  DevicePtr->DeviceName);
	} else {
	    TRACE(VIPK_TRACE_REGDEV, "%s setting VipkFastOpsTable[] to Null",
		  DevicePtr->DeviceName);
	    VipkFastOpsTable[DevicePtr->DeviceIndex] = VipkFastOpsNull;
	}
    }

    VipkCqmDestroy(DevicePtr->CqmHandle);
    VipkRmmDestroy(DevicePtr->RmmHandle);
    VipkPtmDestroy(DevicePtr->PtmHandle);
    VipkDevicePtr[DevicePtr->DeviceIndex] = NULL;

    up(&VipkDeviceSem);

    vfree(DevicePtr->Vi);

    TRACE(VIPK_TRACE_REGDEV, "Device deregistered");
    return VIP_SUCCESS;
}

/**
 * System level open routine for a device.
 *
 * Called when the device file is opened.  Locate the device
 * in the linked list of devices by minor number.  Allocate
 * a VIPK_FILE data structure and bind it to the file pointer
 * opened by the user application.  We can then use the 
 * file pointer to retrieve any information we need about the
 * device without having to scan for the correct device again.
 *
 * If the device supplies its own open routine, call it and
 * don't do anything.  The lower level device driver is on 
 * its own to manage everything about the interface, including
 * all other functionality.  We do take over the file->private_data
 * pointer though, otherwise ioctl would be terribly inefficient for
 * devices which do not provide their own file operations.  If
 * a driver needs a private area, it should use VipkFile->PrivateData.
 *
 * @param	inode Pointer to inode for device.
 * @param       file Pointer to file structure associated with the open.
 * @return: 	0 - success<br>
 *	      	code from \c errno.h on error.
 */
int
vipk_open(struct inode	*inode,
	  struct file	*file)
{
    VIPK_DEVICE *DevicePtr;
    VIPK_FILE *VipkFile;
    int i;
    short MinorNum = MINOR(inode->i_rdev);

    TRACE(VIPK_TRACE_FILE, "[%d]", current->pid);

    if(MinorNum == VIPK_CTRL_MINOR) {
	TRACE(VIPK_TRACE_FILE, "[%d] opening VIA control", current->pid);
	return 0;
    }

    down(&VipkDeviceSem);

    for(i=0; i < VipkMaxDevices; i++) {
	if(VipkDevicePtr[i] && VipkDevicePtr[i]->MinorNum == MinorNum)
	    break;
    }

    if(i >= VipkMaxDevices) {
	char module_name[25];

	sprintf(module_name, "char-major-%d-%d", VIPK_MAJOR, MinorNum);

	TRACE(VIPK_TRACE_FILE, 
	      "[%d] looking for module '%s'", current->pid, module_name);

	up(&VipkDeviceSem);
	request_module(module_name);
	down(&VipkDeviceSem);
	
	for(i=0; i < VipkMaxDevices; i++) {
	    if(VipkDevicePtr[i] && VipkDevicePtr[i]->MinorNum == MinorNum)
		break;
	}
    }

    if(i >= VipkMaxDevices) {
	TRACE(VIPK_TRACE_FILE, 
	      "[%d] MinorNum: %d not found", current->pid, MinorNum);
	up(&VipkDeviceSem);
	return -ENODEV;
    }
	
    DevicePtr = VipkDevicePtr[i];

    VipkFile = (VIPK_FILE *) vmalloc(sizeof(VIPK_FILE));
    if(VipkFile == NULL) {
	TRACE(VIPK_TRACE_FILE, 
	      "[%d] Could not allocate Nic structure", current->pid);
	up(&VipkDeviceSem);
	return -ENOMEM;
    }

    memset(VipkFile, 0, sizeof(VIPK_FILE));
    VipkFile->DevicePtr = DevicePtr;

    /* We just need a unique id for this instance of the opening of the nic. */
    VipkFile->NicInstance = DevicePtr->NextInstance++;

    file->private_data = VipkFile;

    if(DevicePtr->DeviceOps->open) {
	TRACE(VIPK_TRACE_FILE,
	      "[%d] %s MinorNum: %d has own open routine", 
	      current->pid, DevicePtr->DeviceName, DevicePtr->MinorNum);
	up(&VipkDeviceSem);
	return DevicePtr->DeviceOps->open(inode, file);
    }

    if(VipkEQCreate(VIPK_EQ_PER_PAGE, &VipkFile->EQHandle) != VIP_SUCCESS) {
	vfree(VipkFile);
	up(&VipkDeviceSem);
	return -ENOMEM;
    }

    DevicePtr->DeviceOps->mod_inc();
    up(&VipkDeviceSem);
    
    TRACE(VIPK_TRACE_FILE, "[%d] Opened: %s MinorNum: %d", 
	  current->pid, DevicePtr->DeviceName, DevicePtr->MinorNum);

    return 0;
}

/**
 * System level close routine for a device.
 *
 *
 * Called when the device is file is closed.  This is the only chance
 * to clean up after the user.  
 *
 * If the lower level device supplies its own close routine,
 * call it.  See the note in vipk_open() about the repsonsibilies
 * assumed by the device if it overrides vipk_open() and vipk_close().
 *
 * @param	inode Pointer to inode for device.
 * @param       file Pointer to file structure associated with the close.
 * @return: 	0 - success<br>
 *	      	code from \c errno.h on error.
 */
int
vipk_close(struct inode 	*inode,
	   struct file	 	*file)
{
    VIPK_DEVICE	*DevicePtr;
    VIPK_FILE 	*VipkFilePtr;

    int 	Status;
    short 	MinorNum = MINOR(inode->i_rdev);

    TRACE(VIPK_TRACE_FILE, "[%d]", current->pid);

    if(MinorNum == VIPK_CTRL_MINOR) {
	TRACE(VIPK_TRACE_FILE, "[%d] close VIA control", current->pid);
	return 0;
    }

    VipkFilePtr = (VIPK_FILE *) file->private_data;
    DevicePtr = VipkFilePtr->DevicePtr;

    Status = 0;
    if(DevicePtr->DeviceOps->close) {
	TRACE(VIPK_TRACE_FILE,
	      "[%d] %s MinorNum: %d has own close routine",
	      current->pid, DevicePtr->DeviceName, DevicePtr->MinorNum);
	Status = DevicePtr->DeviceOps->close(inode, file);
    } else {
	/* Clean up after user */

	DevicePtr->Cm.DestroyNic(&DevicePtr->Cm,
				 VipkFilePtr->NicInstance);

	VipkDestroyViNic(DevicePtr, VipkFilePtr->NicInstance);
	VipkCqmDestroyCqNic(DevicePtr->CqmHandle, VipkFilePtr->NicInstance);
	VipkRmmDeregisterNic(DevicePtr->RmmHandle, VipkFilePtr->NicInstance);
	VipkPtmDestroyPtagNic(DevicePtr->PtmHandle, VipkFilePtr->NicInstance);
	VipkEQDestroy(VipkFilePtr->EQHandle);
    }

    vfree(VipkFilePtr);

    /* MLW - clear private_data field of file structure */
    file->private_data = NULL;

    DevicePtr->DeviceOps->mod_dec();
    
    TRACE(VIPK_TRACE_FILE, "[%d] Closed: %s MinorNum: %d", 
	  current->pid, DevicePtr->DeviceName, DevicePtr->MinorNum);

    return Status;
}

/**
 * System level ioctl routine.
 *
 * Dispatches ioctl calls to appropriate function.
 * 
 * @param	inode Pointer to inode for device.
 * @param       file Pointer to file structure associated with the close.
 * @param	iocmd Encoded ioctl command from vipl_private.h.
 * @param	Untyped argument for command.
 * @return: 	0 - success<br>
 *	      	code from \c errno.h on error.
 */
static int
vipk_ioctl(struct inode		*inode,
	   struct file		*file,
	   unsigned int		iocmd,
	   unsigned long	ioarg)
{
    /* XXX: Some of the get_user'ing in this function could use a little bit 
     * of cleanup.  Also, explain why parameters are passed the way they
     * are, i.e. the relationship to the fast-trap.
     */

    VIPK_DEVICE	*DevicePtr;
    VIPK_FILE 	*VipkFilePtr;
    VIPK_DEVICE_OPERATIONS *DeviceOps;

    VipkFilePtr = file->private_data;
    DevicePtr = VipkFilePtr->DevicePtr;
    DeviceOps = DevicePtr->DeviceOps;

    TRACE(VIPK_TRACE_IOCTL, "[%d] %s:", current->pid, DevicePtr->DeviceName);
    
    if(DeviceOps->ioctl) {
	return DeviceOps->ioctl(inode, file, iocmd, ioarg);
    }

    switch (iocmd) {
    case VIP_OPEN_NIC: {
	VIP_NIC_HANDLE NicUserHandle;
	VIPK_NIC_HANDLE *NicKernHandle;

	get_user_ret(NicUserHandle,
		     &((VIP_OPEN_NIC_ARGS *)ioarg)->NicUserHandle,
		     VIP_INVALID_PARAMETER);

	get_user_ret(NicKernHandle,
		     &((VIP_OPEN_NIC_ARGS *)ioarg)->NicKernHandle,
		     VIP_INVALID_PARAMETER);

	return DeviceOps->VipkOpenNic(DevicePtr, VipkFilePtr, 
				      NicUserHandle, NicKernHandle);
    }

    case VIP_CREATE_PTAG: 
	return DeviceOps->VipkCreatePtag(DevicePtr, VipkFilePtr,
					 &((VIP_CREATE_PTAG_ARGS *)
					   ioarg)->Ptag);

    case VIP_DESTROY_PTAG: {
	VIP_PROTECTION_HANDLE Ptag;

	get_user_ret(Ptag, &((VIP_DESTROY_PTAG_ARGS *)ioarg)->Ptag, 
		     VIP_INVALID_PARAMETER);
	return DeviceOps->VipkDestroyPtag(DevicePtr, VipkFilePtr, Ptag);
    }

    case VIP_REGISTER_MEM: {
	VIP_PVOID VirtualAddress;
	VIP_ULONG Length;

	get_user_ret(VirtualAddress, 
		     &((VIP_REGISTER_MEM_ARGS *)ioarg)->VirtualAddress,
		     VIP_INVALID_PARAMETER);

	get_user_ret(Length, 
		     &((VIP_REGISTER_MEM_ARGS *)ioarg)->Length,
		     VIP_INVALID_PARAMETER);

	return DeviceOps->VipkRegisterMem(DevicePtr, VipkFilePtr,
					  VirtualAddress, Length,
					  &((VIP_REGISTER_MEM_ARGS *)
					    ioarg)->MemAttribs,
					  &((VIP_REGISTER_MEM_ARGS *)
					    ioarg)->MemHandle);
    }

    case VIP_DEREGISTER_MEM: {
	VIP_PVOID 	VirtualAddress;
	VIP_MEM_HANDLE	MemHandle;

	get_user_ret(VirtualAddress, 
		     &((VIP_DEREGISTER_MEM_ARGS *)ioarg)->VirtualAddress,
		     VIP_INVALID_PARAMETER);

	get_user_ret(MemHandle, 
		     &((VIP_DEREGISTER_MEM_ARGS *)ioarg)->MemHandle,
		     VIP_INVALID_PARAMETER);


	return DeviceOps->VipkDeregisterMem(DevicePtr, VipkFilePtr,
					    VirtualAddress, MemHandle);
    }

    case VIP_CREATE_CQ: {
	/* This is big enough to just use copy_user */
	VIP_CREATE_CQ_ARGS Args;

	copy_from_user_ret(&Args, (VIP_CREATE_CQ_ARGS *)ioarg, 
			   sizeof(VIP_CREATE_CQ_ARGS), VIP_INVALID_PARAMETER);
	
	/* Since the pointer write will be validated, might as well
	 * pass the one in the original structure so we don't have to 
	 * copy it back.. not really such a big deal though.. this can be slow
	 */
	return DeviceOps->VipkCreateCq(DevicePtr,
				       VipkFilePtr,
				       Args.Entry,
				       Args.EntryCount,
				       Args.MemHandle,
				       Args.Ptag,
				       &((VIP_CREATE_CQ_ARGS *)
					 ioarg)->CQHandle);
    }

    case VIP_DESTROY_CQ: {
	VIPK_CQ_HANDLE CQHandle;

	get_user_ret(CQHandle, &((VIP_DESTROY_CQ_ARGS *)ioarg)->CQHandle, 
		     VIP_INVALID_PARAMETER);

	return DeviceOps->VipkDestroyCq(DevicePtr, VipkFilePtr, CQHandle);
    }

    case VIP_RESIZE_CQ: {
	/* This is big enough to just use copy_user */
	VIP_RESIZE_CQ_ARGS Args;

	copy_from_user_ret(&Args, (VIP_RESIZE_CQ_ARGS *)ioarg, 
			   sizeof(VIP_RESIZE_CQ_ARGS), VIP_INVALID_PARAMETER);
	
	return DeviceOps->VipkResizeCq(DevicePtr, VipkFilePtr,
				       Args.CQHandle,
				       Args.Entry,
				       Args.EntryCount,
				       Args.MemHandle,
				       Args.Ptag);
    }

    case VIP_CQ_PRE_WAIT: {
	VIPK_CQ_HANDLE	CQHandle;

	get_user_ret(CQHandle, &((VIP_CQ_PRE_WAIT_ARGS *)ioarg)->CQHandle,
		     VIP_INVALID_PARAMETER);

	return DeviceOps->VipkCqPreWait(DevicePtr, VipkFilePtr, CQHandle);
    }
    
    case VIP_CQ_WAIT: {
	VIPK_CQ_HANDLE	CQHandle;
	VIP_ULONG	Timeout;
	VIP_RETURN	Status;

	get_user_ret(CQHandle, &((VIP_CQ_WAIT_ARGS *)ioarg)->CQHandle,
		     VIP_INVALID_PARAMETER);

	get_user_ret(Timeout, &((VIP_CQ_WAIT_ARGS *)ioarg)->Timeout,
		     VIP_INVALID_PARAMETER);

	Status = DeviceOps->VipkCqWait(DevicePtr, VipkFilePtr,
				       CQHandle, &Timeout);

	put_user_ret(Timeout, &((VIP_CQ_WAIT_ARGS *)ioarg)->Timeout,
		     VIP_INVALID_PARAMETER);

	return Status;
    }

    case VIP_CREATE_VI: {
	return DeviceOps->VipkCreateVi(DevicePtr,
				       VipkFilePtr,
				       (VIP_CREATE_VI_ARGS *)ioarg);

    }

    case VIP_DESTROY_VI: {
	VIPK_VI_HANDLE	ViHandle;

	get_user_ret(ViHandle, &((VIP_DESTROY_VI_ARGS *)ioarg)->ViHandle,
		     VIP_INVALID_PARAMETER);

	return DeviceOps->VipkDestroyVi(DevicePtr, ViHandle);
    }


    case VIP_CONNECT_WAIT: 
	return DeviceOps->VipkConnectWait(DevicePtr,
					  VipkFilePtr,
					  (VIP_CONNECT_WAIT_ARGS *)ioarg);

    case VIP_CONNECT_ACCEPT: {
	VIPK_CONN_HANDLE	ConnHandle;
	VIPK_VI_HANDLE		ViHandle;

	get_user_ret(ConnHandle, &((VIP_CONNECT_ACCEPT_ARGS *)
				   ioarg)->ConnHandle,
		     VIP_INVALID_PARAMETER);

	get_user_ret(ViHandle, &((VIP_CONNECT_ACCEPT_ARGS *)ioarg)->ViHandle,
		     VIP_INVALID_PARAMETER);

	return DeviceOps->VipkConnectAccept(DevicePtr, VipkFilePtr,
					    ConnHandle, ViHandle);
    }

    case VIP_CONNECT_REJECT: {
	VIPK_CONN_HANDLE	ConnHandle;

	get_user_ret(ConnHandle, &((VIP_CONNECT_REJECT_ARGS *)
				   ioarg)->ConnHandle,
		     VIP_INVALID_PARAMETER);

	return DeviceOps->VipkConnectReject(DevicePtr, VipkFilePtr,
					    ConnHandle);
    }

    case VIP_CONNECT_REQUEST:
	return DeviceOps->VipkConnectRequest(DevicePtr, VipkFilePtr,
					     (VIP_CONNECT_REQUEST_ARGS *)
					     ioarg);

    case VIP_DISCONNECT: {
	VIPK_VI_HANDLE	ViHandle;

	get_user_ret(ViHandle, &((VIP_DISCONNECT_ARGS *)ioarg)->ViHandle,
		     VIP_INVALID_PARAMETER);

	return DeviceOps->VipkDisconnect(DevicePtr, ViHandle);
    }

    case VIP_PEER_REQUEST: {
	return DeviceOps->VipkConnectPeerRequest(DevicePtr, VipkFilePtr,
						 (VIP_PEER_REQUEST_ARGS *)
						 ioarg);
    }
	
    case VIP_PEER_DONE: {
	VIPK_VI_HANDLE		ViHandle;
	VIP_VI_ATTRIBUTES	*RemoteViAttribs;
	VIP_BOOLEAN		Block;

	get_user_ret(ViHandle, &((VIP_PEER_DONE_ARGS *)ioarg)->ViHandle,
		     VIP_INVALID_PARAMETER);

	get_user_ret(RemoteViAttribs,
		     &((VIP_PEER_DONE_ARGS *)ioarg)->RemoteViAttribs,
		     VIP_INVALID_PARAMETER);

	get_user_ret(Block,
		     &((VIP_PEER_DONE_ARGS *)ioarg)->Block,
		     VIP_INVALID_PARAMETER);

	return DeviceOps->VipkConnectPeerDone(DevicePtr, VipkFilePtr,
					      ViHandle, RemoteViAttribs,
					      Block);
    }
	
    case VIP_POST_RECV: {
	VIPK_VI_HANDLE	ViHandle;
	VIP_DESCRIPTOR	*Desc;
	VIP_MEM_HANDLE	MemHandle;

	get_user_ret(ViHandle, &((VIP_POST_ARGS *)ioarg)->ViHandle,
		     VIP_INVALID_PARAMETER);
	get_user_ret(Desc, &((VIP_POST_ARGS *)ioarg)->Desc, 
		     VIP_INVALID_PARAMETER);
	get_user_ret(MemHandle, &((VIP_POST_ARGS *)ioarg)->MemHandle,
		     VIP_INVALID_PARAMETER);

	return DeviceOps->VipkPostRecv(DevicePtr, ViHandle, Desc, MemHandle);
    }

    case VIP_POST_SEND: {
	VIPK_VI_HANDLE	ViHandle;
	VIP_DESCRIPTOR	*Desc;
	VIP_MEM_HANDLE	MemHandle;

	get_user_ret(ViHandle, &((VIP_POST_ARGS *)ioarg)->ViHandle,
		     VIP_INVALID_PARAMETER);
	get_user_ret(Desc, &((VIP_POST_ARGS *)ioarg)->Desc, 
		     VIP_INVALID_PARAMETER);
	get_user_ret(MemHandle, &((VIP_POST_ARGS *)ioarg)->MemHandle,
		     VIP_INVALID_PARAMETER);

	return DeviceOps->VipkPostSend(DevicePtr, ViHandle, Desc, MemHandle);
    }


    case VIP_PRE_WAIT: {
	VIPK_VI_HANDLE    	ViHandle;
	VIP_BOOLEAN		Recv;

	get_user_ret(ViHandle, &((VIP_PRE_WAIT_ARGS *)ioarg)->ViHandle,
		     VIP_INVALID_PARAMETER);
	get_user_ret(Recv, &((VIP_PRE_WAIT_ARGS *)ioarg)->Recv,
		     VIP_INVALID_PARAMETER);

	return DeviceOps->VipkPreWait(DevicePtr, ViHandle, Recv);
    }

    case VIP_RECV_WAIT: {
	VIPK_VI_HANDLE	ViHandle;
	VIP_ULONG	Timeout;
	VIP_RETURN	Status;

	get_user_ret(ViHandle, &((VIP_RECV_WAIT_ARGS *)ioarg)->ViHandle,
		     VIP_INVALID_PARAMETER);

	get_user_ret(Timeout, &((VIP_RECV_WAIT_ARGS *)ioarg)->Timeout,
		     VIP_INVALID_PARAMETER);

	Status = DeviceOps->VipkRecvWait(DevicePtr, ViHandle, &Timeout);

	put_user_ret(Timeout, &((VIP_RECV_WAIT_ARGS *)ioarg)->Timeout,
		     VIP_INVALID_PARAMETER);

	return Status;
    }


    case VIP_SEND_WAIT: {
	VIPK_VI_HANDLE	ViHandle;
	VIP_ULONG	Timeout;
	VIP_RETURN	Status;

	get_user_ret(ViHandle, &((VIP_SEND_WAIT_ARGS *)ioarg)->ViHandle,
		     VIP_INVALID_PARAMETER);

	get_user_ret(Timeout, &((VIP_SEND_WAIT_ARGS *)ioarg)->Timeout,
		     VIP_INVALID_PARAMETER);

	Status = DeviceOps->VipkSendWait(DevicePtr, ViHandle, &Timeout);

	put_user_ret(Timeout, &((VIP_SEND_WAIT_ARGS *)ioarg)->Timeout,
		     VIP_INVALID_PARAMETER);

	return Status;
    }

    case VIP_QUERY_NIC: {
	VIP_NIC_ATTRIBUTES	*NicAttribs;
	VIP_UINT8		*NicAddr;

	get_user_ret(NicAttribs, &((VIP_QUERY_NIC_ARGS *)ioarg)->NicAttribs,
		     VIP_INVALID_PARAMETER);

	get_user_ret(NicAddr, &((VIP_QUERY_NIC_ARGS *)ioarg)->NicAddr,
		     VIP_INVALID_PARAMETER);

	return DeviceOps->VipkQueryNic(DevicePtr, NicAttribs, NicAddr);
    }

    case VIP_QUERY_VI: {
	VIPK_VI_HANDLE		ViHandle;
	VIP_VI_STATE		*State;
	VIP_VI_ATTRIBUTES	*Attribs;

	get_user_ret(ViHandle, &((VIP_QUERY_VI_ARGS *)ioarg)->ViHandle,
		     VIP_INVALID_PARAMETER);
	
	get_user_ret(State, &((VIP_QUERY_VI_ARGS *)ioarg)->State,
		     VIP_INVALID_PARAMETER);

	get_user_ret(Attribs, &((VIP_QUERY_VI_ARGS *)ioarg)->Attribs,
		     VIP_INVALID_PARAMETER);

	return DeviceOps->VipkQueryVi(DevicePtr, ViHandle, State, Attribs);
    }

    case VIP_SET_VI_ATTRIBS: {
	VIPK_VI_HANDLE		ViHandle;

	get_user_ret(ViHandle, &((VIP_SET_VI_ATTRIBS_ARGS *)ioarg)->ViHandle,
				 VIP_INVALID_PARAMETER);

	return DeviceOps->VipkSetViAttributes(DevicePtr, VipkFilePtr, ViHandle,
					      &((VIP_SET_VI_ATTRIBS_ARGS *)
						ioarg)->Attribs);
    }

    case VIP_QUERY_MEM: {
	VIP_PVOID 		VirtualAddress;
	VIP_MEM_HANDLE		MemHandle;
	VIP_MEM_ATTRIBUTES	*MemAttribs;

	get_user_ret(VirtualAddress, 
		     &((VIP_QUERY_MEM_ARGS *)ioarg)->Address,
		     VIP_INVALID_PARAMETER);

	get_user_ret(MemHandle, 
		     &((VIP_QUERY_MEM_ARGS *)ioarg)->MemHandle,
		     VIP_INVALID_PARAMETER);

	get_user_ret(MemAttribs, 
		     &((VIP_QUERY_MEM_ARGS *)ioarg)->MemAttribs,
		     VIP_INVALID_PARAMETER);


	return DeviceOps->VipkQueryMem(DevicePtr, VipkFilePtr,
				       VirtualAddress, MemHandle, MemAttribs);
    }

    case VIP_SET_MEM_ATTRIBS: {
	VIP_PVOID 		VirtualAddress;
	VIP_MEM_HANDLE		MemHandle;
	VIP_MEM_ATTRIBUTES	*MemAttribs;

	get_user_ret(VirtualAddress, 
		     &((VIP_SET_MEM_ATTRIBS_ARGS *)ioarg)->Address,
		     VIP_INVALID_PARAMETER);

	get_user_ret(MemHandle, 
		     &((VIP_SET_MEM_ATTRIBS_ARGS *)ioarg)->MemHandle,
		     VIP_INVALID_PARAMETER);

	get_user_ret(MemAttribs, 
		     &((VIP_SET_MEM_ATTRIBS_ARGS *)ioarg)->MemAttribs,
		     VIP_INVALID_PARAMETER);


	return DeviceOps->VipkSetMemAttributes(DevicePtr, VipkFilePtr,
					       VirtualAddress, MemHandle,
					       MemAttribs);
    }

    case VIP_VALIDATE_NIC: {
	TRACE(VIPK_TRACE_IOCTL, "[%d] %s: Validating NIC",
	      current->pid, DevicePtr->DeviceName);	
	return VIP_SUCCESS;
    }
    
    case VIP_FETCH_ERROR: 
	return DeviceOps->VipkFetchError(DevicePtr, VipkFilePtr,
					 &((VIP_FETCH_ERROR_ARGS *)
					   ioarg)->Found,
					 &((VIP_FETCH_ERROR_ARGS *)
					   ioarg)->ErrorDesc);

					 
    default: 
	TRACE(VIPK_TRACE_IOCTL, "[%d] %s: Bad ioctl",
	      current->pid, DevicePtr->DeviceName);
	return -EINVAL;
    }
}

/** File operations structure for registering character
 * device driver operations.
 *
 * \bug the flush routine, ifdefed out for now, is new to this
 * structure somewhere around 2.1.120.  Figure out how to properly
 * conditionally compile this attribute.
 */
/* MLW - use GCC Labeled Elements */
static struct file_operations vipk_fops = {
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0))
    owner:         THIS_MODULE,
#endif
    ioctl:         vipk_ioctl,
    open:          vipk_open,
    release:       vipk_close,
};

#ifndef MODULE
#error "XXX: non-module version not supported yet"
#else /* MODULE */

MODULE_AUTHOR("The Berkeley Lab M-VIA Team <via@nersc.gov>");
MODULE_DESCRIPTION("M-VIA Kernel Agent");
#ifdef VIPK_TRACE_ALL
MODULE_PARM(vipk_trace, "i");
#endif

/**
 * Called when the module is loaded.
 *
 * @return: 	0 - success<br>
 *	      	code from \c errno.h on error.
 */
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
static int vipk_init_m (void)
#else
int
init_module(void)
#endif
{
    int i;

    printk(KERN_INFO "M-VIA Kernel Agent\n%s\n", copyright);

#if MVIA_HAS_FAST_TRAP
    i = VipkInstallFastTrap();
    if(i) {
	return i;
    }
#endif
    
    for(i=0; i < VIPK_MAX_DEVICES; i++) {
	VipkFastOpsTable[i] = VipkFastOpsNull;
    }

    VipkDevicePtr = vmalloc(VipkMaxDevices * sizeof(VIPK_DEVICE *));
    if(VipkDevicePtr == NULL) {
	printk(KERN_INFO "vipk: could not allocate device array size: %d", 
	       VipkMaxDevices);
	return -ENOMEM;
    }
    memset(VipkDevicePtr, 0, VipkMaxDevices * sizeof(VIPK_DEVICE *));

    if(register_chrdev(VIPK_MAJOR, "vipk", &vipk_fops)) {
	printk(KERN_INFO "vipk: register_chrdev failed\n");
	return -EIO;
    }

    return 0;
}

/**
 * 
 * Called when the module is unloaded.  There is no need to check if 
 * the module is in use.  The module framework verifies use counts
 * before calling cleanup_module.
 */
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
static void vipk_cleanup_m (void)
#else
void
cleanup_module(void)
#endif
{
    unregister_chrdev(VIPK_MAJOR, "vipk");

#if MVIA_HAS_FAST_TRAP
    VipkRemoveFastTrap();
#endif

    vfree(VipkDevicePtr);
    printk(KERN_INFO "VIA Kernel Agent unloaded\n");
}



#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
module_init(vipk_init_m);
module_exit(vipk_cleanup_m);

MODULE_LICENSE("JLAB HPC BSD/GPL");
#endif


#endif



