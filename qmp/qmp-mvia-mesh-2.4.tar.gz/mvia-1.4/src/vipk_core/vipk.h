/** \file vipk.h
 * 
 * Interface for the generalized VI Kernel Agent.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#ifndef _VIPK_H
#define _VIPK_H

#include <linux/kernel.h>
#include <linux/types.h>

#include <linux/fs.h>
#include <asm/page.h>		/* for PAGE_SIZE */
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0))
#include <linux/spinlock.h>
#else
#include <asm/spinlock.h>
#endif
#include <asm/unaligned.h>

#include <vipl_private.h>

#include "vipk_types.h"

#include "vipk_eq.h"
#include "vipk_ptm.h"
#include "vipk_rmm.h"
#include "vipk_cqm.h"
#include "vipk_cm.h"

#ifndef min
#define min(a,b) ((a)<(b)?(a):(b))
#endif

#ifdef VIPK_DEBUG_MALLOC

extern void *vipk_kmalloc(const char *file, int line, const char *func,
			  size_t size, int prio);
extern void vipk_kfree(const char *file, int line, const char *func,
		       const void *addr);
extern void *vipk_vmalloc(const char *file, int line, const char *func,
			  unsigned long size);
extern void vipk_vfree(const char *file, int line, const char *func,
		       void *addr);

#undef kmalloc
#define kmalloc(S,P) vipk_kmalloc(__FILE__, __LINE__, __FUNCTION__, S, P)

#undef kfree
#define kfree(A) vipk_kfree(__FILE__, __LINE__, __FUNCTION__, A)

#undef vmalloc
#define vmalloc(S) vipk_vmalloc(__FILE__, __LINE__, __FUNCTION__, S)

#undef vfree
#define vfree(A) vipk_vfree(__FILE__, __LINE__, __FUNCTION__, A)

#endif /* defined(VIPK_DEBUG_MALLOC) */

/* The Linux kernel defines CS and DS macros which clash with 
 * the coresponding field names in the VIP_DESCRIPTOR structure.
 * They need to be undefined in order to be used here.  This may lead
 * to complications with creating in-kernel VIPL binding for the Linux
 * kernel further down the road.
 */
#undef CS
#undef DS

/* Forward declaration of circular structures */
typedef struct _VIPK_DEVICE_OPERATIONS VIPK_DEVICE_OPERATIONS;

/** \def VIPK_MIN_DISCRIMINATOR_LEN
 * Minimum discriminator length which a NIC may support.
 */
#define VIPK_MIN_DISCRIMINATOR_LEN 16

/** \def VIPK_CTRL_MINOR
 * Minor number of the VIPK control device.
 * The VIPK control device is currently unimplemented; however, it 
 * will evenutally be used for an ifconfig like interface for managing
 * VI NICs.
 */
#define VIPK_CTRL_MINOR 0

/** 
 * Device structure for a VI device.
 * Each NIC has a single device entry which maintains the state of 
 * the device.
 *
 * \warning UsesFastOps must be set inorder to register fast-trap 
 * doorbell support, even if the DoorbellType is set to fast-trap.
 * This is for historical reasons and should be changed.
 */
struct _VIPK_DEVICE {
    /** Name of low device, e.g. 'de', 'lo', etc. */
    VIP_CHAR			*DeviceName;
    /** Index number of this device in the device array */
    VIP_UINT32			DeviceIndex;

    /** Private data to be used by lower level driver */
    void			*PrivateData;
    
    /** Attributes of the VI NIC */
    VIP_NIC_ATTRIBUTES		*NicAttribs;

    /** Type of doorbell for this device, i.e. register, fasttrap, ioctl */
    VIP_DOORBELL		DoorbellType;

    /** If VIP_TRUE, indicates that this devices uses fasttraps for 
     * functions which are fasttrapable.  Note, it is possible to 
     * use fasttraps from some functions even though they are not
     * being used for the doorbell mechanism.  
     */
    VIP_BOOLEAN			UsesFastOps;

    /** Function pointers for the device. */
    VIPK_DEVICE_OPERATIONS	*DeviceOps;

    /** Protection Tag Manager Handle. */
    VIPK_PTM_HANDLE		PtmHandle;

    /** Registerd Memory Manager Handle. */
    VIPK_RMM_HANDLE		RmmHandle;

    /** Completion Queue Manager Handle. */
    VIPK_CQM_HANDLE		CqmHandle;

    /* Control Channel. */
    VIPK_CCHAN			CChan;

    /* Connection Manager. */
    VIPK_CM			Cm;

    /** Array of VIs for this device. */
    VIPK_VI			*Vi;

    /** NicInstance value to be used by the next instance */
    VIPK_NIC_INSTANCE		NextInstance;

    /** Lock to serialize access to the Vi array */
    spinlock_t			Lock;

    /** Device minor number for this device. */
    short			MinorNum;
};

/** 
 * Private state associated with an open file pointer.
 * 
 * Note, the name of this structure reflects the fact that
 * it is stored in the private data field of the open file structure
 * associated with the open of the /dev entry for the NIC.  
 * It should be renamed to indicate its purpose.
 */
typedef struct _VIPK_FILE {
    /** Pointer to the device structure for this instance. */
    VIPK_DEVICE		*DevicePtr;

    /** User handle associated with the opening of this NIC. */
    VIP_NIC_HANDLE	NicUserHandle;

    /** Unique Kernel Agent id for the instance of this NIC. 
     * The NicInstance is used to differentiate between resources
     * allocated to the same physical NIC in the event a process
     * opens the NIC multiple times.  When one of the instances is
     * closed, resources should only be autmatically released for 
     * that particular instance.
     *
     * Note: This attribute should NOT be removed in favor of run-time
     * address of this structure itself, because this address can be
     * reused.
     */
    VIPK_NIC_INSTANCE	NicInstance;

    /** Error Queue associated with this NIC instance. */
    VIPK_EQ_HANDLE	EQHandle;

    /** Private data for use by the lower level device driver. */
    void 		*PrivateData;
} VIPK_FILE;

/* typedefed to VIPK_VI above */

/**
 * Kernel Agent state associated with a VI.
 *
 * Note, devices with native VIA hardware support may not utilize
 * all of these fields.
 */
struct _VIPK_VI {
    /** Pointer to the Device this VI is associated with */
    VIPK_DEVICE			*DevicePtr;

    /** uid that owns this VI. */
    VIPK_OWNER			Owner;

    /** Current state of the VI. */
    VIP_VI_STATE		State;

    VIP_UINT32			Session;

    /** Mutex lock for the VI. */
    spinlock_t			Lock;

    /** If VIP_TRUE, indicates that this VI is operating in loopback mode. */
    VIP_BOOLEAN			Loopback;

    /** Private data for use by lower level driver. */
    VIP_PVOID			*PrivateData;

    /** Head of send descriptor queue. */
    VIP_DESCRIPTOR		*SendDesc;

    /** Memory handle of the next descriptor in the send queue. */
    VIP_MEM_HANDLE		SendMemHandle;

    /** Number of send descriptors processed. */
    VIP_UINT32			SendCnt;

    /** Number of send descriptors processed at the time a PreWait was 
     * requested by VIPL.
     * @see VipSendWait()
     */
    VIP_UINT32			SendCntOld;

    /** Head of receive descriptor queue. */
    VIP_DESCRIPTOR		*RecvDesc;

    /** Memory handle of the next descriptor in the receive queue. */
    VIP_MEM_HANDLE		RecvMemHandle;

    /** Number of receive descriptors processed. */
    VIP_UINT32			RecvCnt;

    /** Number of receive descriptors processed at the time a PreWait was
     * requested by VIPL.
     */
    VIP_UINT32			RecvCntOld;

    /** Pointer into user buffer to continue receiving data into during 
     * fragmented receives.
     */
    VIP_PVOID			RecvPtr;

    /** Segment index to continue receiving data from during a 
     * fragmented receive.
     */
    VIP_UINT16			RecvSegIndex;

    /** Length remaining in segment to continue receiving data into during
     * a fragmented receive.
     */
    VIP_UINT32			RecvSegLen;

    /** Total data received so far during a fragmented receive.*/
    VIP_UINT32			RecvXferLen;

    /** VIPL VI Handle associated with this VI.
     * Passed to the user in a VIP_ERROR_DESCRIPTOR in the event of an 
     * asynchronous error.
     */
    VIP_VI_HANDLE		UserViHandle;

    /** If non-NULL, completion queue associated with the send queue. */
    VIPK_CQ			*SendCQ;

    /** Condition variable indicating that data has been sent. */
    condvar_t			Sent;

    /** If non-NULL, completion queue associated with the receive queue. */
    VIPK_CQ			*RecvCQ;

    /** Condition variable inicating that data has been received. */
    condvar_t			Received;

    /** Handle of the remote VI. */
    VIPK_VI_HANDLE		RemoteViHandle;

    /** Address of the remote VI. */
    VIP_NET_MAX_ADDRESS		RemoteAddr;

    /** Attributes of the remote VI. */
    VIP_VI_ATTRIBUTES		RemoteViAttribs;

    /** Pointer to the per-open NIC instance data. */
    VIPK_FILE			*FilePtr;

    /** Attributes of this VI. */
    VIP_VI_ATTRIBUTES		ViAttribs;

    /** Sequence number optionally recorded in packets sent. */
    VIP_UINT32			SendSeq;

    /** Sequence number optionally checked in packets received. */
    VIP_UINT32			RecvSeq;

    /** Indication that a CONNLOST message is being deferred.
     * This is needed to ensure causality.
     * In particular a connection should not be broken before
     * the send causing a remote error is completed.
     */
    VIP_BOOLEAN			ConnectionLost;

    /** If ConnectionLost is set, the sequence number of the CONNLOST. */
    VIP_UINT32			ConnLostSeq;

    /** Private data for use by Connection Manager. */
    void			*CmPrivate;
};

/* The following are typedef'ed because they are used as both the
 * prototype for the coresponding VipkFunctions as well as the 
 * handler prototypes in VIPK_DEVICE_OPERATIONS
 */
typedef VIP_RETURN (VIPK_OPEN_NIC_F) (VIPK_DEVICE	*DevicePtr,
				      VIPK_FILE		*VipkFilePtr,
				      VIP_NIC_HANDLE	NicUserHandle,
				      VIPK_NIC_HANDLE	*NicKernHandle);

typedef VIP_RETURN (VIPK_REGISTER_MEM_F) (VIPK_DEVICE		*DevicePtr,
					  VIPK_FILE		*FilePtr,
					  VIP_PVOID		VirtualAddress,
					  VIP_ULONG		Length,
					  VIP_MEM_ATTRIBUTES	*MemAttrs,
					  VIP_MEM_HANDLE	*MemHandle);

typedef VIP_RETURN (VIPK_DEREGISTER_MEM_F) (VIPK_DEVICE		*DevicePtr,
					    VIPK_FILE		*FilePtr,
					    VIP_PVOID		VirtualAddress,
					    VIP_MEM_HANDLE	MemHandle);

typedef VIP_RETURN (VIPK_CREATE_PTAG_F) (VIPK_DEVICE 		*DevicePtr,
					 VIPK_FILE		*FilePtr,
					 VIP_PROTECTION_HANDLE 	*Ptag);

typedef VIP_RETURN (VIPK_DESTROY_PTAG_F) (VIPK_DEVICE		*DevicePtr,
					  VIPK_FILE		*FilePtr,
					  VIP_PROTECTION_HANDLE	Ptag);

typedef VIP_RETURN (VIPK_CREATE_CQ_F) (VIPK_DEVICE		*DevicePtr,
				       VIPK_FILE		*FilePtr,
				       VIP_CQ_ENTRY		*UserEntry,
				       VIP_ULONG		NumEntries,
				       VIP_MEM_HANDLE		UserMemHandle,
				       VIP_PROTECTION_HANDLE	Ptag,
				       VIPK_CQ_HANDLE		*UserCqHandle);

typedef VIP_RETURN (VIPK_DESTROY_CQ_F) (VIPK_DEVICE		*DevicePtr,
					VIPK_FILE		*FilePtr,
					VIPK_CQ_HANDLE		CqHandle);

typedef VIP_RETURN (VIPK_RESIZE_CQ_F) (VIPK_DEVICE		*DevicePtr,
				       VIPK_FILE		*FilePtr,
				       VIPK_CQ_HANDLE		CqHandle,
				       VIP_CQ_ENTRY		*NewUserEntry,
				       VIP_ULONG		NewEntryCount,
				       VIP_MEM_HANDLE		NewMemHandle,
				       VIP_PROTECTION_HANDLE	NewPtag);

typedef VIP_RETURN (VIPK_CQ_PRE_WAIT_F) (VIPK_DEVICE		*DevicePtr,
					 VIPK_FILE		*FilePtr,
					 VIPK_CQ_HANDLE		CqHandle);

typedef VIP_RETURN (VIPK_CQ_WAIT_F) (VIPK_DEVICE		*DevicePtr,
				     VIPK_FILE			*FilePtr,
				     VIPK_CQ_HANDLE		CqHandle,
				     VIP_ULONG			*Timeout);


typedef VIP_RETURN (VIPK_CREATE_VI_F) (VIPK_DEVICE		*DevicePtr,
				       VIPK_FILE		*FilePtr,
				       VIP_CREATE_VI_ARGS	*Args);

typedef VIP_RETURN (VIPK_DESTROY_VI_F) (VIPK_DEVICE		*DevicePtr,
					VIPK_VI_HANDLE		ViHandle);

typedef VIP_RETURN (VIPK_CONNECT_WAIT_F) (VIPK_DEVICE		*DevicePtr,
					  VIPK_FILE		*FilePtr,
					  VIP_CONNECT_WAIT_ARGS	*UserArgs);

typedef VIP_RETURN (VIPK_CONNECT_REQUEST_F) (VIPK_DEVICE	*DevicePtr,
					     VIPK_FILE		*VipkFilePtr,
					     VIP_CONNECT_REQUEST_ARGS *UArgs);

typedef VIP_RETURN (VIPK_CONNECT_ACCEPT_F) (VIPK_DEVICE		*DevicePtr,
					    VIPK_FILE		*FilePtr,
					    VIPK_CONN_HANDLE	ConnHandle,
					    VIPK_VI_HANDLE	ViHandle);

typedef VIP_RETURN (VIPK_CONNECT_REJECT_F) (VIPK_DEVICE		*DevicePtr,
					    VIPK_FILE		*FilePtr,
					    VIPK_CONN_HANDLE	ConnHandle);

typedef VIP_RETURN (VIPK_DISCONNECT_F) (VIPK_DEVICE		*DevicePtr,
					VIPK_VI_HANDLE		ViHandle);

typedef VIP_RETURN (VIPK_PEER_REQUEST_F) (VIPK_DEVICE		*DevicePtr,
					  VIPK_FILE		*VipkFilePtr,
					  VIP_PEER_REQUEST_ARGS *UArgs);

typedef VIP_RETURN (VIPK_PEER_DONE_F) (VIPK_DEVICE		*DevicePtr,
				       VIPK_FILE		*FilePtr,
				       VIPK_VI_HANDLE		ViHandle,
				       VIP_VI_ATTRIBUTES	*RemoteViAttrs,
				       VIP_BOOLEAN		Block);

typedef VIP_RETURN (VIPK_POST_RECV_F) (VIPK_DEVICE		*DevicePtr,
				       VIPK_VI_HANDLE		ViHandle,
				       VIP_DESCRIPTOR		*Desc,
				       VIP_MEM_HANDLE		MemHandle);

typedef VIP_RETURN (VIPK_POST_SEND_F) (VIPK_DEVICE		*DevicePtr,
				       VIPK_VI_HANDLE		ViHandle,
				       VIP_DESCRIPTOR		*Desc,
				       VIP_MEM_HANDLE		MemHandle);

typedef VIP_RETURN (VIPK_PRE_WAIT_F) (VIPK_DEVICE		*DevicePtr,
				      VIPK_VI_HANDLE		ViHandle,
				      VIP_BOOLEAN		Recv);

typedef VIP_RETURN (VIPK_RECV_WAIT_F) (VIPK_DEVICE		*DevicePtr,
				       VIPK_VI_HANDLE		ViHandle,
				       VIP_ULONG		*Timeout);

typedef VIP_RETURN (VIPK_SEND_WAIT_F) (VIPK_DEVICE		*DevicePtr,
				       VIPK_VI_HANDLE		ViHandle,
				       VIP_ULONG		*Timeout);

typedef VIP_RETURN (VIPK_QUERY_NIC_F) (VIPK_DEVICE		*DevicePtr,
				       VIP_NIC_ATTRIBUTES	*UserNicAttrs,
				       VIP_UINT8		*UserNicAddr);

typedef VIP_RETURN (VIPK_QUERY_VI_F) (VIPK_DEVICE		*DevicePtr,
				      VIPK_VI_HANDLE		ViHandle,
				      VIP_VI_STATE		*UserState,
				      VIP_VI_ATTRIBUTES		*UserAttrs);

typedef VIP_RETURN (VIPK_SET_VI_ATTRIBS_F) (VIPK_DEVICE		*DevicePtr,
					    VIPK_FILE		*FilePtr,
					    VIPK_VI_HANDLE	ViHandle,
					    VIP_VI_ATTRIBUTES	*UserAttrs);

typedef VIP_RETURN (VIPK_QUERY_MEM_F) (VIPK_DEVICE		*DevicePtr,
				       VIPK_FILE		*FilePtr,
				       VIP_PVOID		VirtualAddress,
				       VIP_MEM_HANDLE		MemHandle,
				       VIP_MEM_ATTRIBUTES	*UserAttribs);

typedef VIP_RETURN (VIPK_SET_MEM_ATTRIBS_F) (VIPK_DEVICE	*DevicePtr,
					     VIPK_FILE		*FilePtr,
					     VIP_PVOID		VirtualAddress,
					     VIP_MEM_HANDLE	MemHandle,
					     VIP_MEM_ATTRIBUTES	*UserAttribs);

typedef VIP_RETURN (VIPK_FETCH_ERROR_F) (VIPK_DEVICE		*DevicePtr,
					 VIPK_FILE		*VipkFilePtr,
					 VIP_BOOLEAN		*Found,
					 VIP_ERROR_DESCRIPTOR 	*ErrorDesc);

typedef VIP_RETURN (VIPK_BAD_OP_F) (void);

extern VIPK_OPEN_NIC_F 		VipkOpenNic;
extern VIPK_REGISTER_MEM_F	VipkRegisterMem;
extern VIPK_DEREGISTER_MEM_F	VipkDeregisterMem;
extern VIPK_CREATE_PTAG_F	VipkCreatePtag;
extern VIPK_DESTROY_PTAG_F	VipkDestroyPtag;
extern VIPK_DEREGISTER_MEM_F	VipkDeregisterMem;
extern VIPK_CREATE_CQ_F		VipkCreateCq;
extern VIPK_DESTROY_CQ_F	VipkDestroyCq;
extern VIPK_RESIZE_CQ_F		VipkResizeCq;
extern VIPK_CREATE_VI_F		VipkCreateVi;
extern VIPK_DESTROY_VI_F	VipkDestroyVi;
extern VIPK_CQ_PRE_WAIT_F	VipkCqPreWait;
extern VIPK_CQ_WAIT_F		VipkCqWait;
extern VIPK_CONNECT_WAIT_F	VipkConnectWait;
extern VIPK_CONNECT_REQUEST_F	VipkConnectRequest;
extern VIPK_CONNECT_ACCEPT_F	VipkConnectAccept;
extern VIPK_CONNECT_REJECT_F	VipkConnectReject;
extern VIPK_DISCONNECT_F	VipkDisconnect;
extern VIPK_PEER_REQUEST_F	VipkConnectPeerRequest;
extern VIPK_PEER_DONE_F		VipkConnectPeerDone;
extern VIPK_POST_RECV_F		VipkPostRecv;
extern VIPK_POST_SEND_F		VipkPostSend;
extern VIPK_PRE_WAIT_F		VipkPreWait;
extern VIPK_RECV_WAIT_F		VipkRecvWait;
extern VIPK_SEND_WAIT_F		VipkSendWait;
extern VIPK_QUERY_NIC_F		VipkQueryNic;
extern VIPK_QUERY_VI_F		VipkQueryVi;
extern VIPK_SET_VI_ATTRIBS_F	VipkSetViAttributes;
extern VIPK_QUERY_MEM_F		VipkQueryMem;
extern VIPK_SET_MEM_ATTRIBS_F	VipkSetMemAttributes;
extern VIPK_FETCH_ERROR_F	VipkFetchError;
extern VIPK_BAD_OP_F		VipkBadOp;

/** 
 * Operations on a VIA Device 
 *
 * The VIPK_DEVICE_OPS_DEFAULT macro will automatically fill in 
 * this structure with default entries.  
 */
struct _VIPK_DEVICE_OPERATIONS {
    /** Function to call on system open of /dev entry */
    int (*open) 	(struct inode *inode, struct file *file);
    /** Function to call on system close of /dev entry */
    int (*close)	(struct inode *inode, struct file *file);
    /** Function to call on system ioctl on /dev entry file pointer */
    int (*ioctl)	(struct inode *inode, struct file *file,
			 unsigned int iocmd, unsigned long ioarg);
    /** Increment the use count of the low-level driver */
    void (*mod_inc)	(void);
    /** Decrement the use count of the low-level driver */
    void (*mod_dec)	(void);

    VIP_RETURN (*SendConnLost)	(VIPK_DEVICE		*DevicePtr,
				 VIPK_VI		*Vi,
				 VIP_BOOLEAN		IsError);

    VIP_RETURN (*ConnectionLost)(VIPK_DEVICE		*DevicePtr,
				 VIPK_VI_HANDLE		ViHandle,
				 VIP_UINT32		Session,
				 VIP_UINT32		Sequence,
				 VIP_BOOLEAN		IsError);

    void (*Connected)		(VIPK_DEVICE		*DevicePtr,
				 VIPK_VI		*Vi);
	
    /** Perform Kernel Agent portion of VipOpenNic(). */
    VIPK_OPEN_NIC_F		(*VipkOpenNic);

    /** Perform Kernel Agent portion of VipCreatePtag(). */
    VIPK_CREATE_PTAG_F		(*VipkCreatePtag);
    /** Perform Kernel Agent portion of VipDestroyPtag(). */
    VIPK_DESTROY_PTAG_F		(*VipkDestroyPtag);

    /** Perform Kernel Agent portion of VipRegisterMem(). */
    VIPK_REGISTER_MEM_F 	(*VipkRegisterMem);
    /** Perform Kernel Agent portion of VipDeregisterMem(). */
    VIPK_DEREGISTER_MEM_F 	(*VipkDeregisterMem);

    /** Perform Kernel Agent portion of VipCreateCQ(). */
    VIPK_CREATE_CQ_F 		(*VipkCreateCq);
    /** Perform Kernel Agent portion of VipDestroyCQ(). */
    VIPK_DESTROY_CQ_F		(*VipkDestroyCq);
    /** Perform Kernel Agent portion of VipResizeCQ(). */
    VIPK_RESIZE_CQ_F		(*VipkResizeCq);
    /** Perform CQPreWait request for VIPL.
	@see VipCQWait()
    */
    VIPK_CQ_PRE_WAIT_F		(*VipkCqPreWait);
    /** Perform Kernel Agent portion of VipCQWait(). */
    VIPK_CQ_WAIT_F		(*VipkCqWait);

    /** Perform Kernel Agent portion of VipCreateVi().*/
    VIPK_CREATE_VI_F		(*VipkCreateVi);
    /** Perform Kernel Agent portion of VipDestroyVi(). */
    VIPK_DESTROY_VI_F		(*VipkDestroyVi);

    /** Perform Kernel Agent portion of VipConnectWait(). */
    VIPK_CONNECT_WAIT_F		(*VipkConnectWait);
    /** Perform Kernel Agent portion of VipConnectAccept(). */
    VIPK_CONNECT_ACCEPT_F	(*VipkConnectAccept);
    /** Perform Kernel Agent portion of VipConnectReject(). */
    VIPK_CONNECT_REJECT_F	(*VipkConnectReject);
    /** Perform Kernel Agent portion of VipConnectRequest(). */
    VIPK_CONNECT_REQUEST_F	(*VipkConnectRequest);
    /** Perform Kernel Agent portion of VipDisconnect(). */
    VIPK_DISCONNECT_F		(*VipkDisconnect);

    /** Perform Kernel Agent portion of VipConnectPeerRequest(). */
    VIPK_PEER_REQUEST_F		(*VipkConnectPeerRequest);
    /** Perform Kernel Agent portion of VipConnectPeer{Done,Wait}(). */
    VIPK_PEER_DONE_F		(*VipkConnectPeerDone);

    /** Perform Kernel Agent portion of VipPostRecv().
     * Note, this is only used in the case of emulated VIs.
     */
    VIPK_POST_RECV_F		(*VipkPostRecv);
    /** Perform Kernel Agent portion of VipPostSend().
     * Note, this is only used in the case of emulated VIs.
     */
    VIPK_POST_SEND_F		(*VipkPostSend);

    /** Perform PreWAit for VIPL.
	@see VipRecvWait(), VipSendWait()
     */
    VIPK_PRE_WAIT_F		(*VipkPreWait);
    /** Perform Kernel Agent portion of VipRecvWait(). */
    VIPK_RECV_WAIT_F		(*VipkRecvWait);
    /** Perform Kernel Agent portion of VipSendWait(). */
    VIPK_SEND_WAIT_F		(*VipkSendWait);

    /** Perform Kernel Agent portion of VipQueryNic(). */
    VIPK_QUERY_NIC_F		(*VipkQueryNic);
    /** Perform Kernel Agent portion of VipQueryVi(). */
    VIPK_QUERY_VI_F		(*VipkQueryVi);
    /** Perform Kernel Agent portion of VipSetViAttributes(). */
    VIPK_SET_VI_ATTRIBS_F	(*VipkSetViAttributes);
    /** Perform Kernel Agent portion of VipQueryMem(). */
    VIPK_QUERY_MEM_F		(*VipkQueryMem);
    /** Perform Kernel Agent portion of VipSetMemAttributes(). */
    VIPK_SET_MEM_ATTRIBS_F	(*VipkSetMemAttributes);

    /** Fetch an asynchronous error for the error handler thread. */
    VIPK_FETCH_ERROR_F		(*VipkFetchError);
};

/** Table of fast operation pointers into Kernel Agent */
typedef struct {
    /** Device pointer to perform the operation on. */
    VIPK_DEVICE		*DevicePtr;
    /** PostSend routine to enter via fast-trap. */
    unsigned long	VipkPostSend;
    /** PostRecv routine to enter via fast-trap. */
    unsigned long	VipkPostRecv;
    /** Padding for alignment */
    unsigned long	_pad0;
} VIPK_FAST_OPS_DESCRIPTOR;

/* Documented in vipk.c */
extern VIP_RETURN 	
VipkRegisterDevice(VIPK_DEVICE		*DevicePtr);

/* Documented in vipk.c */
extern VIP_RETURN	
VipkDeregisterDevice(VIPK_DEVICE *DevicePtr);

/* Documented in vipk_ops.c */
extern VIP_BOOLEAN
VipkRecv(VIPK_DEVICE	*DevicePtr,
	 VIPK_VI_HANDLE	ViHandle,
	 VIP_PVOID	Buf,
	 VIP_UINT32	Length,
	 VIP_UINT32	*IDataPtr,
	 VIP_BOOLEAN	FirstFrag,
	 VIP_BOOLEAN	LastFrag);

/* Documented in vipk_ops.c */
extern VIP_RETURN
VipkRecvRdmaWrite(VIPK_DEVICE		*DevicePtr, 
		  VIPK_VI_HANDLE	ViHandle,
		  VIP_PVOID		Buf,
		  VIP_UINT32		SegXferLen,
		  VIP_PVOID		RecvBuf,
		  VIP_MEM_HANDLE	MemHandle,
		  VIP_UINT32		*IDataPtr,
		  VIP_BOOLEAN		FirstFrag,
		  VIP_BOOLEAN		LastFrag);

/* Documented in vipk_ops.c */
extern VIP_RETURN
VipkDestroyViNic(VIPK_DEVICE		*DevicePtr,
		 VIPK_NIC_INSTANCE	NicInstance);

extern VIP_RETURN
VipkViConnectionLost(VIPK_DEVICE	*DevicePtr,
		     VIPK_VI		*Vi,
		     VIP_UINT32		Session,
		     VIP_UINT32		Sequence);

extern VIP_RETURN
VipkConnectionLost(VIPK_DEVICE		*DevicePtr,
		   VIPK_VI_HANDLE	ViHandle,
		   VIP_UINT32		Session,
		   VIP_UINT32		Sequence,
		   VIP_BOOLEAN		IsError);

extern void 
VipkViFlushDescs(VIPK_DEVICE		*DevicePtr,
		 VIPK_VI		*Vi,
		 VIP_BOOLEAN		Recv);

/* Documented in vipk_ops.c */
extern void
VipkPostError(VIPK_VI			*Vi,
	      VIP_RESOURCE_CODE		ResourceCode,
	      VIP_ERROR_CODE		ErrorCode);

/* Documented in vipk_ops.c */
extern void
VipkPostDeviceError(VIPK_DEVICE		*DevicePtr);

/* Documented in vipk_ops.c */
extern void
VipkPostDescError(VIPK_VI		*Vi,
		  VIP_DESCRIPTOR	*Desc,
		  VIP_RESOURCE_CODE	ResourceCode,
		  VIP_ERROR_CODE	ErrorCode);

/* Documented in vipk_ops.c */
extern void
VipkViRecvCompleteErr(VIPK_VI		*Vi,
		      VIP_DESCRIPTOR	*KernDesc,
		      VIP_UINT32	*IDataPtr);

/* Documented in vipk_ops.c */
extern void
VipkViSendCompleteErr(VIPK_VI		*Vi,
		      VIP_DESCRIPTOR	*KernDesc);

/** \def VIPK_DEVICE_PROTOTYPES(name)
 * Automatically generates prototypes and functions required
 * by low-level driver.
 */
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
#define VIPK_DEVICE_PROTOTYPES(name)		\
static void name ## _mod_inc(void) {		\
    try_module_get(THIS_MODULE);                \
}						\
						\
static void name ## _mod_dec(void) {		\
    module_put(THIS_MODULE);         		\
}
#else
#define VIPK_DEVICE_PROTOTYPES(name)		\
static void name ## _mod_inc(void) {		\
    MOD_INC_USE_COUNT;				\
}						\
						\
static void name ## _mod_dec(void) {		\
    MOD_DEC_USE_COUNT;				\
}
#endif

/** \def VIPK_DEVICE_OPS_DEFAULT(name)
 * Automatically fill in the VIPK_DEVICE_OPERATIONS structure
 * with default values.  This will help insulate low-level drivers
 * from changes to the default operations.
 */
#define VIPK_DEVICE_OPS_DEFAULT(name)		\
{						\
    NULL,					\
    NULL,					\
    NULL,					\
    name ## _mod_inc,				\
    name ## _mod_dec,				\
    NULL,					\
    VipkConnectionLost,				\
    NULL,					\
    VipkOpenNic,				\
    VipkCreatePtag,				\
    VipkDestroyPtag,				\
    VipkRegisterMem,				\
    VipkDeregisterMem,				\
    VipkCreateCq,				\
    VipkDestroyCq,				\
    VipkResizeCq,				\
    VipkCqPreWait,				\
    VipkCqWait,					\
    VipkCreateVi,				\
    VipkDestroyVi,				\
    VipkConnectWait,				\
    VipkConnectAccept,				\
    VipkConnectReject,				\
    VipkConnectRequest,				\
    VipkDisconnect,				\
    VipkConnectPeerRequest,			\
    VipkConnectPeerDone,			\
    VipkPostRecv,				\
    VipkPostSend,				\
    VipkPreWait,				\
    VipkRecvWait,				\
    VipkSendWait,				\
    VipkQueryNic,				\
    VipkQueryVi,				\
    VipkSetViAttributes,			\
    VipkQueryMem,				\
    VipkSetMemAttributes,			\
    VipkFetchError				\
};

/** \def ROUND_UP(x,y) 
 * Round x to y 
 */
#define ROUND_UP(x,y) (((x)+(y)-1)/(y))

/** 
 * Convert a VIA timeout value to jiffies.
 *
 * @param Timeout VIA timeout value, in msec, or VIP_INFINITE.
 * @return The linux kernel timeout value coresponding to the VIA timeout.
 */
extern inline unsigned long
VipkLinuxTimeout(VIP_ULONG Timeout) {
    switch(Timeout) {
    case VIP_INFINITE:
	Timeout = MAX_SCHEDULE_TIMEOUT;
	break;
    case 0:
	/* No timeout requested. */
	break;
    default:
	Timeout = ROUND_UP(Timeout * 1000, (1000000/HZ));
	break;
    }

    return Timeout;
}

/**
 * Convert a timeout in jiffies to a VIA timeout value.
 *
 * @param Timeout linux kernel timeout in jiffies or MAX_SCHEDULE_TIMEOUT
 * @return The VIA timeout value corresponding to the linux kernel timeout.
 */
extern inline VIP_ULONG
VipkViaTimeout(unsigned long Timeout) {
    switch(Timeout) {
    case MAX_SCHEDULE_TIMEOUT:
        Timeout = VIP_INFINITE;
        break;
    case 0:
        /* No timeout requested. */
        break;
    default:
        Timeout = ROUND_UP(Timeout * (1000000 / HZ), 1000);
        break;
    }

    return Timeout;
}

/** 
 * Complete a receive operation on a VI.
 *
 * Marks the descriptor complete and performs all operations 
 * necessary to complete a receive descriptor, i.e. wakes up a block process, 
 * increments the receive count, pushes a completion queue entry if necessary,
 * etc.
 *
 * @param DevicePtr Pointer to the device the completion event is occuring on.
 * @param Vi Pointer to the VI the completion event is occuring on.
 * @param KernDesc Pointer to the descriptor 
 * 	relative to the kernel's address space.
 * @param If non-NULL, pointer to the immediate data 
 *	to place in the descriptor.
 * @param Status Bits to set in the VIP_DESCRIPTOR CS.Status field.
 */
extern inline void
VipkViRecvComplete(VIPK_DEVICE 		*DevicePtr,
		   VIPK_VI		*Vi,
		   VIP_DESCRIPTOR	*KernDesc,
		   VIP_UINT32		*IDataPtr,
		   VIP_UINT32		Status)
{
    unsigned long	Flags;

    /* XXX: SPEC: the spec is unclear on what to do in this case.
     * should we check this up front and divert data to the next
     * descriptor?
     */
    /* Must check that the FORMAT_ERROR bit was not set previously */
    if(((KernDesc->CS.Control & VIP_CONTROL_OP_MASK)
        != VIP_CONTROL_OP_SENDRECV ||
        (KernDesc->CS.Control & VIP_CONTROL_RESERVED) ||
        KernDesc->CS.Reserved != 0) &&
       !(KernDesc->CS.Status & VIP_STATUS_FORMAT_ERROR)) {
	KernDesc->CS.Status |=
		((Status & ~VIP_STATUS_DONE) | VIP_STATUS_FORMAT_ERROR);
	VipkViRecvCompleteErr(Vi, KernDesc, IDataPtr);
	return;
    }

    spin_lock_irqsave(&Vi->Lock, Flags);

    Vi->RecvMemHandle = KernDesc->CS.NextHandle;
    Vi->RecvDesc = KernDesc->CS.Next.Address;

    if(IDataPtr) {
	KernDesc->CS.ImmediateData = get_unaligned(IDataPtr);
	KernDesc->CS.Status |= VIP_STATUS_IMMEDIATE;
    }

    KernDesc->CS.Length = Vi->RecvXferLen;
    KernDesc->CS.Status |= Status;

    Vi->RecvCnt++;    
    cond_signal(&Vi->Received);

    if(Vi->RecvCQ) {
	VipkCqEnqueue(Vi->RecvCQ, DevicePtr->RmmHandle, 
		      Vi->UserViHandle, VIP_TRUE);
    }

    Vi->RecvSeq++;
    Vi->RecvXferLen = 0;

    spin_unlock_irqrestore(&Vi->Lock, Flags);	
}

/** 
 * Complete a send operation on a VI.
 *
 * Marks the descriptor complete and performs all operations 
 * necessary to complete a send descriptor, i.e. wakes up a block process, 
 * increments the send count, pushes a completion queue entry if necessary,
 * etc.
 *
 * @param DevicePtr Pointer to the device the completion event is occuring on.
 * @param Vi Pointer to the VI the completion event is occuring on.
 * @param KernDesc Pointer to the descriptor in the kernel's address space.
 * @param Status Bits to set in the descriptor's CS.Status field.
 */
extern inline void
VipkViSendComplete(VIPK_DEVICE		*DevicePtr,
		   VIPK_VI 		*Vi,
		   VIP_DESCRIPTOR	*KernDesc,
		   VIP_UINT32		Status)
{
    unsigned long Flags;

    spin_lock_irqsave(&Vi->Lock, Flags);

    KernDesc->CS.Status |= Status;

    Vi->SendMemHandle = KernDesc->CS.NextHandle;
    Vi->SendDesc = KernDesc->CS.Next.Address;

    Vi->SendCnt++;
    cond_signal(&Vi->Sent);
    
    if(Vi->SendCQ) {
	VipkCqEnqueue(Vi->SendCQ, DevicePtr->RmmHandle, 
		      Vi->UserViHandle, VIP_FALSE);
    }

    spin_unlock_irqrestore(&Vi->Lock, Flags);	
}

/** 
 * Check for a descriptor format error.
 *
 * Checking for the reserved bits is a bit paranoid but 
 * vipconf requires it.  Consider conditionally compiling this.
 */
extern inline VIP_BOOLEAN
VipkDescFormatError(VIP_DESCRIPTOR	*KernDesc)
{
    VIP_UINT32 Control = KernDesc->CS.Control;
    VIP_UINT32 Reserved = KernDesc->CS.Reserved;
    VIP_UINT32 RemoteReserved = KernDesc->DS[0].Remote.Reserved;

    VIP_BOOLEAN FormatError = 
	(((Control & VIP_CONTROL_OP_MASK) == VIP_CONTROL_OP_RESERVED) ||
	 ((Control & VIP_CONTROL_RESERVED) != 0) ||
	 (Reserved != 0) ||
	 ((Control & VIP_CONTROL_OP_MASK) != VIP_CONTROL_OP_SENDRECV &&
	  RemoteReserved != 0));
    
    return FormatError;
}

/* XXX: need to document */
extern inline VIPK_VI *
VipkViLookup(VIPK_DEVICE 	*DevicePtr,
	     VIPK_VI_HANDLE	ViHandle) 
{
    VIPK_VI *Vi = NULL;

    if(ViHandle < DevicePtr->NicAttribs->MaxVI) {
	Vi = &(DevicePtr->Vi[ViHandle]);
    }

    return Vi;
}

/* XXX: need to document */
extern inline VIPK_OWNER
VipkGetCurrentOwner(void) 
{
    return current->uid;
}

extern inline VIP_BOOLEAN
VipkViVerifyOwner(VIPK_VI *Vi)
{
    return (Vi->Owner == VipkGetCurrentOwner());
}


/** 
 * Verify that the given VIP_NET_ADDRESS sizes are 
 * valid for a given VIPK_DEVICE.
 *
 * @param DevicePtr Pointer to the Device to verify the address against.
 * @param Addr Address to verify.
 * @return 	\c VIP_TRUE - Address size is valid<br>
 *		\c VIP_FALSE - Address size is invalid.
 * 
 * \warning Does not verify that the address pointer is valid.
 */
extern inline VIP_RETURN
VipkAddrVerifySize(VIPK_DEVICE 		*DevicePtr,
		   VIP_NET_ADDRESS 	*Addr) 
{
    if(DevicePtr->NicAttribs->NicAddressLen != Addr->HostAddressLen)
	return VIP_INVALID_PARAMETER;

    if(Addr->DiscriminatorLen > DevicePtr->NicAttribs->MaxDiscriminatorLen)
	return VIP_INVALID_PARAMETER;

    return VIP_SUCCESS;
}

/** 
 * Compares a given address to the hardware address of a given device.
 *
 * @param DevicePtr Pointer to the Device to verify the address against.
 * @param Addr Address to verify.
 *
 * @return 	\c VIP_TRUE - Address matches NIC address<br>
 *		\c VIP_FALSE - Address matches NIC address.
 */
extern inline VIP_BOOLEAN
VipkAddrNicHostEq(VIPK_DEVICE *DevicePtr,
		  VIP_NET_ADDRESS *Addr)
{
    if(DevicePtr->NicAttribs->NicAddressLen != Addr->HostAddressLen)
	return VIP_FALSE;

    if(!memcmp(DevicePtr->NicAttribs->LocalNicAddress,
	       Addr->HostAddress,
	       DevicePtr->NicAttribs->NicAddressLen)) {
	return VIP_TRUE;
    } else {
	return VIP_FALSE;
    }
}
	       
/** 
 * Compares two host addresses for matching descriminators.
 * Both addresses given using network byte order.
 *
 * @param Addr1	Pointer to first address
 * @param Addr2 Pointer to second address
 * @return 	\c VIP_TRUE - discriminators match.<br>
 *		\c VIP_FALSE - discriminators do not match.
 */
extern inline 
VIP_BOOLEAN              
__VipkAddrDiscrimEq(VIP_NET_ADDRESS	*Addr1, 
		    VIP_NET_ADDRESS	*Addr2)
{
    if(Addr1->DiscriminatorLen != Addr2->DiscriminatorLen) {
	return VIP_FALSE;
    }

    if(!memcmp(Addr1->HostAddress + VIPK_SWAB16(Addr1->HostAddressLen), 
	       Addr2->HostAddress + VIPK_SWAB16(Addr2->HostAddressLen),
	       VIPK_SWAB16(Addr1->DiscriminatorLen))) {
	return VIP_TRUE;
    } else {
	return VIP_FALSE;
    }
}

/** 
 * Compares two host addresses.
 * Both addresses given using network byte order.
 *
 * @param Addr1 Pointer to first address.
 * @param Addr2 Pointer to second address.
 * @return	\c VIP_TRUE - addresses match.<br>
 *		\c VIP_FALSE - addresses do not match.
 */
extern inline 
VIP_BOOLEAN              
__VipkAddrHostEq(VIP_NET_ADDRESS	*Addr1, 
		 VIP_NET_ADDRESS	*Addr2)
{
    if(Addr1->HostAddressLen != Addr2->HostAddressLen) {
	return VIP_FALSE;
    }

    if(!memcmp(Addr1->HostAddress,
	       Addr2->HostAddress,
	       VIPK_SWAB16(Addr1->HostAddressLen))) {
	return VIP_TRUE;
    } else {
	return VIP_FALSE;
    }
}

/** 
 * Copies Src address to Dest address.
 * Both addresses given using network byte order.
 *
 * @param Dest Destination address.
 * @param Src Source address.
 *
 * \warning The destination address must be large enough to hold
 * the source address.
 */
extern inline 
void 
__VipkAddrCopy(VIP_NET_ADDRESS *Dest, 
	       VIP_NET_ADDRESS *Src)
{
    Dest->HostAddressLen = Src->HostAddressLen;
    Dest->DiscriminatorLen = Src->DiscriminatorLen;
    memcpy(Dest->HostAddress, Src->HostAddress, 
	   VIPK_SWAB16(Src->HostAddressLen) +
	   VIPK_SWAB16(Src->DiscriminatorLen));
}

extern inline
void 
__VipkNicAddrCopy(VIP_NET_ADDRESS 	*Dest,
		  VIP_NIC_ATTRIBUTES	*NicAttrs)
{
    Dest->HostAddressLen = VIPK_SWAB16(NicAttrs->NicAddressLen);
    Dest->DiscriminatorLen = 0;
    memcpy(Dest->HostAddress, 
	   NicAttrs->LocalNicAddress, NicAttrs->NicAddressLen);
}

/** 
 * Compares a given address to the hardware address of a given device.
 * The given address is in network byte order.
 *
 * @param DevicePtr Pointer to the Device to verify the address against.
 * @param Addr Address to verify.
 *
 * @return 	\c VIP_TRUE - Address matches NIC address<br>
 *		\c VIP_FALSE - Address matches NIC address.
 */
extern inline VIP_BOOLEAN
__VipkAddrNicHostEq(VIPK_DEVICE		*DevicePtr,
		    VIP_NET_ADDRESS	*Addr)
{
    if(DevicePtr->NicAttribs->NicAddressLen !=
					VIPK_SWAB16(Addr->HostAddressLen))
	return VIP_FALSE;

    if(!memcmp(DevicePtr->NicAttribs->LocalNicAddress,
	       Addr->HostAddress,
	       DevicePtr->NicAttribs->NicAddressLen)) {
	return VIP_TRUE;
    } else {
	return VIP_FALSE;
    }
}

void VipkAddrPrint(char *str, VIP_NET_ADDRESS *Addr);

#endif /* _VIPK_H */

