/** \file vipk_trace.c
 *
 * Debugging output for VI Kernel Agent.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#include <linux/config.h>
#include <linux/kernel.h>
#include <linux/vmalloc.h>

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
/**
 * The following two attributes are defined twice
 */
#ifdef __attribute_pure__
#undef __attribute_pure__
#endif
 
#ifdef __attribute_used__
#undef __attribute_used__
#endif

#endif

#include "vipk.h"
#include "vipk_trace.h"

#ifdef VIPK_TRACE_ALL

unsigned int vipk_trace = VIPK_TRACE_NONE;

static char vipk_trace_buf[4096];

void
VipkTrace(const char *file, int line, const char *func, const char * fmt, ...)
{
    va_list	args;

    va_start(args, fmt);
    vsprintf(vipk_trace_buf, fmt, args);
    va_end(args);

    printk("%s:%d %s: %s\n", file, line, func, vipk_trace_buf);
}

#endif /* defined(VIPK_TRACE_ALL) */
