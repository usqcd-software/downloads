/** \file vipk_cchan.c
 *
 * Implementation of Control Channel for Software Emulated VIA
 * Provides best effort, at least once, unordered delivery of control packets.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#include <linux/errno.h>
#include <linux/slab.h>
#include <linux/vmalloc.h>
#include <linux/list.h>
#include <linux/interrupt.h>


#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
/**
 * The following two attributes are defined twice
 */
#ifdef __attribute_pure__
#undef __attribute_pure__
#endif

#ifdef __attribute_used__
#undef __attribute_used__
#endif

#endif

#include "vipk_cchan.h"
#include "condvar.h"

#include "vipk.h"
#include "vipk_trace.h"

#define VIPK_CCHAN_RETRANSMIT_LIMIT 100
#define VIPK_CCHAN_TIMEOUT (HZ/10)

#define VIPK_DRIVER_PARANOIA	1  /* see VipkCChanCompleteControl */

/** Control Channel State. */
typedef enum {
    CCHAN_STATE_FREE,
    CCHAN_STATE_PENDING,
    CCHAN_STATE_SENT,
    CCHAN_STATE_ACKED,
    CCHAN_STATE_EXPIRED
} CCHAN_STATE;

/** Retransmittion information for a Control Channel packet */
typedef struct _CCHAN_PACKET_INFO {
    /** Linked list pointers */
    struct list_head	List;

    /** Time to resend */
    unsigned long	TimeOut;

    /** Is a process waiting for completion? */
    VIP_BOOLEAN		NeedSignal;

    /** Number of re-xmits */
    VIP_UINT16		Xmits;

    /** Reference counting bits */
    VIP_UINT16		RefBits;

    /** State of packet */
    CCHAN_STATE		State;

    /** Signaled when the packet has been acknowlegdged or expired */
    condvar_t		Done;

    /** The packet to send */
    VIPK_CCHAN_PACKET	*Pkt;
} CCHAN_PACKET_INFO;

/** Values for RefBits bitmask
*/
#define CCHAN_PKT_REF_ACK	0x0001	/* awaiting ACK or expire of packet */
#define CCHAN_PKT_REF_DEV	0x0002	/* awaiting TX-done from device */
#define CCHAN_PKT_REF_ALL	0x0003	/* bitwise-OR of the above */

/** Control Channel Transmit and Receive Queues
 */
typedef struct {
    /* START OF READ-ONLY FIELDS */
    /** Connection Manager to dispatch control packets to */
    VIPK_CM	*Cm;

    /** Device pointer and device-specific SendControl function pointer */
    VIPK_DEVICE *DevicePtr;
    VIP_RETURN (*SendControl) (VIPK_DEVICE *, VIPK_CCHAN_PACKET *);

    /** Amount of space allocated for device-specific header construction */
    VIP_UINT16	DevHdrLen;
    /* END OF READ-ONLY FIELDS */

    /** Data associated with the queue of outstanding transmitted packets */
    struct CCHAN_SEND_QUEUE {
	/** Lock for queue manipulation */
	spinlock_t	Lock;

	/** Timer for the resend task */
	struct timer_list	Timer;

	/** Token to assign to the next packet allocated */
	VIP_UINT16		NextToken;

	/** Size of PktInfo array */
	VIP_UINT32		PSNLimit;

	/** The complete array of PktInfo structures */
	CCHAN_PACKET_INFO	*PktInfo;

	/** LIFO (stack) of unused PktInfo entries (singly-linked) */
	struct list_head	*FreeList;

	/** FIFO (queue) of sent PktInfo entries (doubly-linked, circular) */
	struct list_head	SentList;
    } SendQueue;

    /** Data associated with the queue of outstanding received packets */
    struct CCHAN_RECV_QUEUE {
	/** Lock for queue manipulation */
	spinlock_t		Lock;

	/** Task queue structure for the receive task (bottom-half) */
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
        struct work_struct      Task;
#else
	struct tq_struct	Task;
#endif

	/** The queue: */
	VIP_UINT32		Room;
	VIPK_CCHAN_PACKET	*Head;
	VIPK_CCHAN_PACKET	*Tail;
    } RecvQueue;
} CCHAN;


static VIP_RETURN
VipkCChanInit(VIPK_CCHAN	*VipkCChan,
	      VIPK_DEVICE	*DevicePtr,
	      VIPK_CM		*Cm,
	      VIP_RETURN	(*SendControl) (VIPK_DEVICE *DevicePtr,
						VIPK_CCHAN_PACKET *));

#ifdef VIPK_DRIVER_PARANOIA	/* see VipkCChanCompleteControl */
static VIP_UINT32
CSumAckPacket(VIPK_CCHAN_PACKET	*Pkt);
#endif

static VIP_RETURN
VipkCChanDestroy(VIPK_CCHAN		*CChan);

static VIP_RETURN
VipkCChanGetPacket(VIPK_CCHAN		*CChan,
		   VIPK_CCHAN_PACKET	**Pkt);

static VIP_RETURN
VipkCChanSendControl(VIPK_CCHAN		*CChan,
		     VIP_BOOLEAN	Block,
		     VIPK_CCHAN_PACKET	*Pkt);

static VIP_RETURN
VipkCChanRecvControl(VIPK_CCHAN	*CChan,
		     VIPK_CCHAN_PACKET	*Pkt);



static void VipkCChanRecvTask(VIPK_CCHAN *);
static void VipkCChanSendTimer(unsigned long arg);

static inline void
CopyAddrOnly(VIP_NET_ADDRESS *Dest,
	     VIP_NET_ADDRESS *Src);

static inline VIP_RETURN
DestroyPacket(VIPK_CCHAN_PACKET	*Pkt);

static CCHAN_PACKET_INFO*
GetPktInfo(CCHAN		*CChan,
	   VIPK_CCHAN_PACKET	*Pkt,
	   VIP_BOOLEAN		Block);

static VIP_RETURN
ReleasePktInfo(CCHAN			*CChan,
	       CCHAN_PACKET_INFO	*PktInfo,
	       VIP_UINT16		Bit);

static inline VIP_RETURN
SendPktInfo(CCHAN		*CChan,
	    CCHAN_PACKET_INFO	*PktInfo,
	    unsigned long	*Flags);

static void
ByteSwapPacket(VIPK_CCHAN_PACKET	*Pkt);

static void
ProcessPacket(CCHAN		*CChan,
	      VIPK_CCHAN_PACKET	*Pkt);

static void
VipkCChanCompleteControl(VIPK_CCHAN		*CChan,
			 VIPK_CCHAN_PACKET	*Pkt);

const VIPK_CCHAN VipkCChanDefault = {
    NULL,
    VipkCChanInit,
    VipkCChanDestroy,
    VipkCChanGetPacket,
    VipkCChanSendControl,
    VipkCChanRecvControl,
    VipkCChanCompleteControl
};


static VIP_RETURN
VipkCChanInit(VIPK_CCHAN	*VipkCChan,
	      VIPK_DEVICE	*DevicePtr,
	      VIPK_CM		*Cm,
	      VIP_RETURN	(*SendControl) (VIPK_DEVICE *DevicePtr,
						VIPK_CCHAN_PACKET *))
{
    VIP_UINT32		MaxXmitPkts;
    VIP_UINT32		MaxRecvPkts;
    VIP_UINT32		DevHdrLen;
    CCHAN		*CChan;
    CCHAN_PACKET_INFO	*PktInfo;
    int			i;

    /* XXX: pass as var */
    MaxXmitPkts = 1024;

    /* XXX: pass as var */
    MaxRecvPkts = 1024;

    /* XXX: pass as var, right now this acts as a max */
    DevHdrLen = 64;

    CChan = vmalloc(sizeof(CCHAN));
    if(CChan == NULL) {
	return VIP_ERROR_RESOURCE;
    }
    memset(CChan, 0, sizeof(CCHAN));

    CChan->SendQueue.PktInfo = vmalloc(MaxXmitPkts * sizeof(CCHAN_PACKET_INFO));
    if(CChan->SendQueue.PktInfo == NULL) {
	vfree(CChan);
	return VIP_ERROR_RESOURCE;
    }

    CChan->Cm		= Cm;
    CChan->DevicePtr	= DevicePtr;
    CChan->SendControl	= SendControl;
    CChan->DevHdrLen	= DevHdrLen;

    spin_lock_init(&CChan->SendQueue.Lock);
    init_timer(&CChan->SendQueue.Timer);
    CChan->SendQueue.Timer.function	= VipkCChanSendTimer;
    CChan->SendQueue.Timer.data		= (unsigned long) VipkCChan;
    CChan->SendQueue.NextToken		= (VIP_UINT16)jiffies; /* "random" */
    CChan->SendQueue.PSNLimit		= MaxXmitPkts;
    memset(CChan->SendQueue.PktInfo, 0,
	   MaxXmitPkts * sizeof(CCHAN_PACKET_INFO));
    for(i = 0; i < MaxXmitPkts; i++) {
	PktInfo = &CChan->SendQueue.PktInfo[i];

	PktInfo->List.next	= &((PktInfo + 1)->List);
	PktInfo->State		= CCHAN_STATE_FREE;
	cond_init(&PktInfo->Done);
	PktInfo->Pkt		= NULL;
    }
    PktInfo->List.next		= NULL;
    CChan->SendQueue.FreeList	= &CChan->SendQueue.PktInfo[0].List;
    INIT_LIST_HEAD(&CChan->SendQueue.SentList);

    spin_lock_init(&CChan->RecvQueue.Lock);

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
    /* Declaring 2.6 work struct */
    INIT_WORK(&(CChan->RecvQueue.Task),(void (*)(void *)) VipkCChanRecvTask, VipkCChan);
#else
    /* 2.4 Kernel use Task queue */
    CChan->RecvQueue.Task.sync		= 0;
    CChan->RecvQueue.Task.routine	= (void (*)(void *)) VipkCChanRecvTask;
    CChan->RecvQueue.Task.data		= VipkCChan;
#endif

    CChan->RecvQueue.Room		= MaxRecvPkts;

    VipkCChan->Private = CChan;

    return VIP_SUCCESS;
}

static VIP_RETURN
VipkCChanDestroy(VIPK_CCHAN	*VipkCChan)
{
    CCHAN	*CChan;

    CChan = VipkCChan->Private;

    /* XXX: Do we need to free remaining packets here too? */
    vfree(CChan->SendQueue.PktInfo);
    vfree(CChan);

    return VIP_SUCCESS;
}

static VIP_RETURN
VipkCChanGetPacket(VIPK_CCHAN		*VipkCChan,
		   VIPK_CCHAN_PACKET	**Pkt)
{
    VIPK_CCHAN_PACKET	*LocalPkt;
    CCHAN		*CChan;
    int			AllocSize;

    TRACE(VIPK_TRACE_CCHAN, "CChanGetPacket");

    CChan = VipkCChan->Private;
    AllocSize = offsetof(VIPK_CCHAN_PACKET,u.DevHdr) + CChan->DevHdrLen;
    LocalPkt = kmalloc(AllocSize, in_interrupt() ? (GFP_ATOMIC | GFP_DMA)
						 : (GFP_KERNEL | GFP_DMA));

    if(LocalPkt == NULL) {
	TRACE(VIPK_TRACE_CCHAN, "Could not allocate packet");
	return VIP_ERROR_RESOURCE;
    }
    memset(LocalPkt, 0, AllocSize);

    LocalPkt->Token = CChan->SendQueue.NextToken++;

    *Pkt = LocalPkt;
    TRACE(VIPK_TRACE_CCHAN, "Returning packet token: %d", LocalPkt->Token);
    return VIP_SUCCESS;
}

/* Copy address w/o Discriminator, using network byteorder */
static inline void
CopyAddrOnly(VIP_NET_ADDRESS *Dest,
	     VIP_NET_ADDRESS *Src)
{
    Dest->HostAddressLen = Src->HostAddressLen;
    Dest->DiscriminatorLen = 0;
    memcpy(Dest->HostAddress, Src->HostAddress,
	   VIPK_SWAB16(Src->HostAddressLen));
}

#ifdef VIPK_DRIVER_PARANOIA	/* see VipkCChanCompleteControl */
static VIP_UINT32
CSumAckPacket(VIPK_CCHAN_PACKET	*Pkt)
{
    VIP_UINT32  Result;
    VIP_UINT32  *Ptr;
    int		i;

    Ptr = (VIP_UINT32 *)Pkt;

    Result = 0;
    for(i=0; i<offsetof(VIPK_CCHAN_PACKET, Session)/sizeof(VIP_UINT32); ++i) {
	Result ^= *(Ptr++);
    }

    return Result;
}
#endif

static inline VIP_RETURN
DestroyPacket(VIPK_CCHAN_PACKET	*Pkt)
{
#ifdef VIPK_DRIVER_PARANOIA	/* see VipkCChanCompleteControl */
    Pkt->PSN = ~Pkt->PSN;
#endif

    kfree(Pkt);
    return VIP_SUCCESS;
}

static CCHAN_PACKET_INFO*
GetPktInfo(CCHAN		*CChan,
	   VIPK_CCHAN_PACKET	*Pkt,
	   VIP_BOOLEAN		Block)
{
    CCHAN_PACKET_INFO	*Result;

    Result = list_entry(CChan->SendQueue.FreeList, CCHAN_PACKET_INFO, List);
    if(Result != NULL) {
	CChan->SendQueue.FreeList = Result->List.next;
	Pkt->PSN = (Result - CChan->SendQueue.PktInfo);

	Result->NeedSignal = Block;
	Result->Xmits	   = 0;
	Result->RefBits    = CCHAN_PKT_REF_ACK;
	Result->State	   = CCHAN_STATE_PENDING;
	Result->Pkt	   = Pkt;
    }

    return Result;
}

static VIP_RETURN
ReleasePktInfo(CCHAN			*CChan,
	       CCHAN_PACKET_INFO	*PktInfo,
	       VIP_UINT16		Bit)
{
    if(PktInfo->RefBits & Bit) {
	PktInfo->RefBits &= ~Bit;

	if(!PktInfo->RefBits) {
	    TRACE(VIPK_TRACE_CCHAN, "packet destroyed");
	    DestroyPacket(PktInfo->Pkt);
	    PktInfo->State = CCHAN_STATE_FREE;
	    PktInfo->List.next = CChan->SendQueue.FreeList;
	    CChan->SendQueue.FreeList = &(PktInfo->List);
	} else {
	    TRACE(VIPK_TRACE_CCHAN,
		  "packet destroy deferred, RefBits=%d", PktInfo->RefBits);
	}

	return VIP_SUCCESS;
    } else {
	VIP_UINT16 Tmp;

	Tmp = PktInfo->RefBits & CCHAN_PKT_REF_ALL;

	TRACE(VIPK_TRACE_CCHAN, "attempting to clear the %s bit on %s packet",
	      ((Bit == CCHAN_PKT_REF_ACK) ? "ACK" :
	       (Bit == CCHAN_PKT_REF_DEV) ? "DEV" :
					    "???"),
	      ((Tmp == CCHAN_PKT_REF_DEV) ? "an ACKed" :
	       (Tmp == CCHAN_PKT_REF_ACK) ? "a TXed" :
					    "a free"));

	return VIP_NOT_DONE;
    }
}

static inline VIP_RETURN
SendPktInfo(CCHAN		*CChan,
	    CCHAN_PACKET_INFO	*PktInfo,
	    unsigned long	*Flags)
{
    VIP_RETURN	Status;

    if(!(PktInfo->RefBits & CCHAN_PKT_REF_DEV)) {
	PktInfo->TimeOut = jiffies + VIPK_CCHAN_TIMEOUT;
	PktInfo->RefBits |= CCHAN_PKT_REF_DEV;
	PktInfo->Xmits++;
	PktInfo->State = CCHAN_STATE_SENT;

	list_add(&PktInfo->List, &CChan->SendQueue.SentList);

	spin_unlock_irqrestore(&CChan->SendQueue.Lock, *Flags);
	Status = CChan->SendControl(CChan->DevicePtr, PktInfo->Pkt);
	spin_lock_irqsave(&CChan->SendQueue.Lock, *Flags);

	if (Status != VIP_SUCCESS) {
	    TRACE(VIPK_TRACE_CCHAN, "SendControl failed");
	    ReleasePktInfo(CChan, PktInfo, CCHAN_PKT_REF_DEV);
	}
    } else {
	PktInfo->TimeOut = jiffies + VIPK_CCHAN_TIMEOUT;
	list_add(&PktInfo->List, &CChan->SendQueue.SentList);
	TRACE(VIPK_TRACE_CCHAN, "packet is still on dev TX queue!");
	Status = VIP_NOT_DONE;
    }

    return Status;
}


VIP_RETURN
VipkCChanSendControl(VIPK_CCHAN			*VipkCChan,
		     VIP_BOOLEAN		Block,
		     VIPK_CCHAN_PACKET		*Pkt)
{
    CCHAN_PACKET_INFO *PktInfo;
    VIP_RETURN Status;

    CCHAN *CChan;

    unsigned long KernTimeout;
    unsigned long Flags;

    TRACE(VIPK_TRACE_CCHAN, "CChanSendControl");

    CChan = VipkCChan->Private;

    /* Fast path for local connections */
    if(VipkAddrNicHostEq(CChan->DevicePtr,
			 (VIP_NET_ADDRESS *) &Pkt->DstAddr)) {
	ProcessPacket(CChan, Pkt);
	return VIP_SUCCESS;
    }

    ByteSwapPacket(Pkt);

    spin_lock_irqsave(&CChan->SendQueue.Lock, Flags);

    PktInfo = GetPktInfo(CChan, Pkt, Block);
    if(PktInfo == NULL) {
	goto out_qfull;
    }

    if(!timer_pending(&CChan->SendQueue.Timer)) {
	TRACE(VIPK_TRACE_CCHAN, "Start timer");
	CChan->SendQueue.Timer.expires = jiffies + VIPK_CCHAN_TIMEOUT;
	add_timer(&CChan->SendQueue.Timer);
    }

    TRACE(VIPK_TRACE_CCHAN,
	  "Sending to device PSN: %d Token: %d", Pkt->PSN, Pkt->Token);
    SendPktInfo(CChan, PktInfo, &Flags);

    if(Block) {
	while(PktInfo->State == CCHAN_STATE_SENT) {
	    TRACE(VIPK_TRACE_CCHAN,
		  "Waiting for ACK PSN: %d Token: %d", Pkt->PSN, Pkt->Token);
	    KernTimeout = MAX_SCHEDULE_TIMEOUT;
	    cond_wait_interruptible(&PktInfo->Done, &CChan->SendQueue.Lock,
				    &KernTimeout);
	}

	if(PktInfo->State == CCHAN_STATE_ACKED) {
	    TRACE(VIPK_TRACE_CCHAN,
		  "Awoken/ACKed: PSN: %d Token: %d", Pkt->PSN, Pkt->Token);
	    Status = VIP_SUCCESS;
	} else {
	    TRACE(VIPK_TRACE_CCHAN,
		  "Awoken/NOT ACKed: PSN: %d Token: %d", Pkt->PSN, Pkt->Token);
	    /* XXX: is this right? */
	    Status = VIP_NOT_REACHABLE;
	}

	ReleasePktInfo(CChan, PktInfo, CCHAN_PKT_REF_ACK);
    } else {
	TRACE(VIPK_TRACE_CCHAN, "Returing on non-blocking send");
	Status = VIP_SUCCESS;
    }

    spin_unlock_irqrestore(&CChan->SendQueue.Lock, Flags);
    return Status;

out_qfull:
    /* XXX: TODO in case of full retransmit queue
     * + Non-blocking sends go into a deferred queue.
     * + Blocking sends block on a waitqueue or condition variable.
     */
    spin_unlock_irqrestore(&CChan->SendQueue.Lock, Flags);
    TRACE(VIPK_TRACE_CCHAN, "Could not allocate packet info slot");
    DestroyPacket(Pkt);
    return VIP_ERROR_RESOURCE;
}


void
VipkCChanSendTimer(unsigned long arg)
{
    VIPK_CCHAN		*VipkCChan;
    CCHAN		*CChan;
    CCHAN_PACKET_INFO	*PktInfo;
    struct list_head	*Head;
    unsigned long Flags;

    TRACE(VIPK_TRACE_CCHAN, "In retransmit timer");

    VipkCChan = (VIPK_CCHAN *) arg;
    CChan = VipkCChan->Private;
    Head = &CChan->SendQueue.SentList;

    spin_lock_irqsave(&CChan->SendQueue.Lock, Flags);

    /* XXX: It is conceiveable that if things move slowly enough we could
       go all the way around the list and back to the start! */
    while(Head->prev != Head) {
	PktInfo = list_entry(Head->prev, CCHAN_PACKET_INFO, List);

	if(time_after_eq(jiffies, PktInfo->TimeOut)) {
	    list_del(Head->prev);

	    if(PktInfo->Xmits < VIPK_CCHAN_RETRANSMIT_LIMIT) {
		TRACE(VIPK_TRACE_CCHAN, "Resending PSN: %d Token: %d Rep: %d",
		      PktInfo->Pkt->PSN, PktInfo->Pkt->Token, PktInfo->Xmits);
		SendPktInfo(CChan, PktInfo, &Flags);
	    } else {
		TRACE(VIPK_TRACE_CCHAN,
		      "Packet over retransmit limit PSN: %d Token: %d",
		      PktInfo->Pkt->PSN, PktInfo->Pkt->Token);
		if(PktInfo->NeedSignal) {
		    TRACE(VIPK_TRACE_CCHAN, "Expiring packet");
		    PktInfo->State = CCHAN_STATE_EXPIRED;
		    cond_signal(&PktInfo->Done);
		} else {
		    TRACE(VIPK_TRACE_CCHAN, "Freeing packet");
		    ReleasePktInfo(CChan, PktInfo, CCHAN_PKT_REF_ACK);
		}
	    }
	} else {
	    TRACE(VIPK_TRACE_CCHAN, "Reinstalling timer");
	    CChan->SendQueue.Timer.expires = PktInfo->TimeOut;
	    add_timer(&CChan->SendQueue.Timer);
	    break;
	}
    }

    spin_unlock_irqrestore(&CChan->SendQueue.Lock, Flags);
}


/* VipkCChanCompleteControl
 *
 * This function is called from the handler for the TX-done interrupt,
 * or from a similar place, to indicate that a control packet is no
 * longer on the device's send queue (hopefully because it was
 * actually sent).  The job of this function is to mark non-ACK
 * packets as transmitted, allowing them to be freed when they have
 * also been ACKed.  ACK packet are simply freed, since no ACK is
 * expected.  This job is complicated be the fact that at least one
 * buggy device driver (hamachi.c v0.11) has been observed to invoke
 * this function multiple times for the same packet!  While this
 * driver bug may corrupt the VIA traffic, it should not be permitted
 * to cause a kernel panic by invoking kfree() multiple times on the
 * same buffer.  Therefore, when VIPK_DEVICE_PARANOIA is defined,
 * efforts are taken to detect packet which are already freed.
 * Non-ACK packets are validated by checking for a valid value of the
 * PSN field.  ACK packets are validated by use of a simple checksum
 * of the significant fields, which is then stored in the unused
 * Session field.  When freed (in DestroyPacket), the PSN value is
 * made invalid, causing both ACK and non-ACK packets to fail the
 * validation done here.  While not fool-proof, this seems to work
 * pretty well.
 */
static void
VipkCChanCompleteControl(VIPK_CCHAN		*VipkCChan,
			 VIPK_CCHAN_PACKET	*Pkt)
{
    unsigned long Flags;
    CCHAN *CChan;

    TRACE(VIPK_TRACE_CCHAN, "Pkt: %d Token: %d", Pkt->PSN, Pkt->Token);

    if(Pkt->Op == VIPK_SWAB16(VIPK_CCHAN_OP_ACK)) {
#ifdef VIPK_DRIVER_PARANOIA	/* see comments above */
	if(Pkt->Session != CSumAckPacket(Pkt)) {
	    TRACE(VIPK_TRACE_CCHAN,
		  "invalid/corrupted ACK.  Buggy device driver?");
	    return;
	}
#endif
	/* No PktInfo, so simply destroy the packet */
	DestroyPacket(Pkt);
    } else {
	CChan = (CCHAN *)VipkCChan->Private;

#ifdef VIPK_DRIVER_PARANOIA	/* see comments above */
	if(Pkt->PSN >= CChan->SendQueue.PSNLimit) {
	    TRACE(VIPK_TRACE_CCHAN,
		  "invalid/corrupted packet.  Buggy device driver?");
	    return;
	}
#endif
	spin_lock_irqsave(&CChan->SendQueue.Lock, Flags);
	ReleasePktInfo(CChan,
		       &CChan->SendQueue.PktInfo[Pkt->PSN],
		       CCHAN_PKT_REF_DEV);
	spin_unlock_irqrestore(&CChan->SendQueue.Lock, Flags);
    }
}


VIP_RETURN
VipkCChanRecvControl(VIPK_CCHAN		*VipkCChan,
		     VIPK_CCHAN_PACKET	*Pkt)
{
    VIPK_CCHAN_PACKET	*LocalPkt;
    CCHAN_PACKET_INFO	*PktInfo;
    CCHAN		*CChan;

    unsigned long Flags;

    TRACE(VIPK_TRACE_CCHAN,
	  "CChan: 0x%p PSN: %d Op: %d",
	  VipkCChan->Private, Pkt->PSN, Pkt->Op);

    CChan = VipkCChan->Private;

    if(Pkt->Op == VIPK_SWAB16(VIPK_CCHAN_OP_ACK)) {
	TRACE(VIPK_TRACE_CCHAN, "ACK");
	if(Pkt->PSN < CChan->SendQueue.PSNLimit) {
	    spin_lock_irqsave(&CChan->SendQueue.Lock, Flags);
	    PktInfo = &CChan->SendQueue.PktInfo[Pkt->PSN];

	    if(PktInfo->State == CCHAN_STATE_SENT) {
		if(PktInfo->Pkt->Token == Pkt->Token) {
		    list_del(&PktInfo->List);
		    if(list_empty(&CChan->SendQueue.SentList)) {
			TRACE(VIPK_TRACE_CCHAN, "Clearing timer");
			del_timer(&CChan->SendQueue.Timer);
		    }

		    if(PktInfo->NeedSignal) {
			TRACE(VIPK_TRACE_CCHAN, "Marking Acked");
			PktInfo->State = CCHAN_STATE_ACKED;
			TRACE(VIPK_TRACE_CCHAN, "Sending signal");
			cond_signal(&PktInfo->Done);
		    } else {
			TRACE(VIPK_TRACE_CCHAN, "Destroying packet");
			ReleasePktInfo(CChan, PktInfo, CCHAN_PKT_REF_ACK);
		    }
		} else {
		    TRACE(VIPK_TRACE_CCHAN, "Bad ACK (token mismatch)");
		}
	    } else {
		TRACE(VIPK_TRACE_CCHAN, "Bad ACK (bad state)");
	    }

	    spin_unlock_irqrestore(&CChan->SendQueue.Lock, Flags);
	} else {
	    TRACE(VIPK_TRACE_CCHAN, "Bad ACK (invalid PSN)");
	}
	TRACE(VIPK_TRACE_CCHAN, "Returning");
    } else {
	/* XXX It would be good to keep a pool of buffers to
	   fall-back on if this kmalloc should fail. */
	LocalPkt = kmalloc(sizeof(VIPK_CCHAN_PACKET), GFP_ATOMIC);
	if(LocalPkt == NULL) {
	    TRACE(VIPK_TRACE_CCHAN, "Could not allocate packet");
	    goto out_nomem;
	}
	memcpy(LocalPkt, Pkt, offsetof(VIPK_CCHAN_PACKET, u));
	LocalPkt->u.Next = NULL;

	spin_lock_irqsave(&CChan->RecvQueue.Lock, Flags);

	/* The use of a limit is left over from when received packets
	 * where processed on the tq_scheduler queue.  They are now
	 * processed on the tq_immediate queue.  Thus the RX_RING_SIZE
	 * is the maximum number that can be queued here.  The Room
	 * field is kept incase there is ever a need to impose a tighter
	 * limit on the number of control packets to process at a time.
	 */
	if(!CChan->RecvQueue.Room) {
	    TRACE(VIPK_TRACE_CCHAN, "Receiver overrun");
	    goto out_overrun;
	} else {
	    CChan->RecvQueue.Room--;
	}

	if(CChan->RecvQueue.Head) {
	    CChan->RecvQueue.Tail->u.Next = LocalPkt;
	} else {
	    CChan->RecvQueue.Head = LocalPkt;
	}
	CChan->RecvQueue.Tail = LocalPkt;

	spin_unlock_irqrestore(&CChan->RecvQueue.Lock, Flags);

	TRACE(VIPK_TRACE_CCHAN, "Queing packet handling task");
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
	/* using default work queue */
	schedule_work (&CChan->RecvQueue.Task);
#else
	queue_task(&CChan->RecvQueue.Task, &tq_immediate);
	mark_bh(IMMEDIATE_BH);
#endif
    }

    return VIP_SUCCESS;

out_overrun:
    spin_unlock_irqrestore(&CChan->RecvQueue.Lock, Flags);
    kfree(LocalPkt);

out_nomem:
    return VIP_ERROR_RESOURCE;
}

void
VipkCChanRecvTask(VIPK_CCHAN *VipkCChan)
{
    CCHAN		*CChan;
    VIPK_CCHAN_PACKET	*Pkt;
    VIPK_CCHAN_PACKET	*AckPkt;
    VIP_RETURN		Status;
    unsigned long	Flags;

    TRACE(VIPK_TRACE_CCHAN, "CChanTask");

    CChan = VipkCChan->Private;

    do {
	TRACE(VIPK_TRACE_CCHAN, "Dequeing packet");
	spin_lock_irqsave(&CChan->RecvQueue.Lock, Flags);
	if(!CChan->RecvQueue.Head) {
	    break;
	}
	Pkt = CChan->RecvQueue.Head;
	CChan->RecvQueue.Head = Pkt->u.Next;
	CChan->RecvQueue.Room++;
	spin_unlock_irqrestore(&CChan->RecvQueue.Lock, Flags);

	TRACE(VIPK_TRACE_CCHAN, "Preparing ACK");
	VipkCChan->GetPacket(VipkCChan, &AckPkt);

	/* Only care about the following three fields and src/dst addrs: */
	AckPkt->Op    = VIPK_SWAB16(VIPK_CCHAN_OP_ACK);
	AckPkt->PSN   = Pkt->PSN;
	AckPkt->Token = Pkt->Token;

	/* XXX: really bad.. coping of unchecked addrs is going on. */
	/* We don't copy the unneeded Discriminator portions of addrs. */
	CopyAddrOnly((VIP_NET_ADDRESS *) &AckPkt->SrcAddr,
		     (VIP_NET_ADDRESS *) &Pkt->DstAddr);
	CopyAddrOnly((VIP_NET_ADDRESS *) &AckPkt->DstAddr,
		     (VIP_NET_ADDRESS *) &Pkt->SrcAddr);

#ifdef VIPK_DRIVER_PARANOIA	/* see VipkCChanCompleteControl */
	AckPkt->Session = CSumAckPacket(AckPkt);
#endif

	TRACE(VIPK_TRACE_CCHAN, "Sending ACK");
	Status = CChan->SendControl(CChan->DevicePtr, AckPkt);
	if (Status != VIP_SUCCESS) {
	    TRACE(VIPK_TRACE_CCHAN, "SendControl failed (ACK)");
	    DestroyPacket(Pkt);
	} else {
	    ByteSwapPacket(Pkt);
	    ProcessPacket(CChan, Pkt);
	}
    } while (1);

    spin_unlock_irqrestore(&CChan->RecvQueue.Lock, Flags);
    TRACE(VIPK_TRACE_CCHAN, "Queue empty");
    return;
}

void ByteSwapPacket(VIPK_CCHAN_PACKET	*Pkt)
{
    /* Pkt->PSN is opaque */
    /* Pkt->Token is opaque */
    VIPK_SWAB16S(&Pkt->Op);
    VIPK_SWAB16S(&Pkt->SrcAddr.HostAddressLen);
    VIPK_SWAB16S(&Pkt->SrcAddr.DiscriminatorLen);
    VIPK_SWAB16S(&Pkt->DstAddr.HostAddressLen);
    VIPK_SWAB16S(&Pkt->DstAddr.DiscriminatorLen);
    VIPK_SWAB32S(&Pkt->Session);
    VIPK_SWAB32S(&Pkt->SrcConnHandle);
    VIPK_SWAB32S(&Pkt->DstConnHandle);
    VIPK_SWAB32S(&Pkt->ViHandle);
    /* Pkt->ViAttribs is encoded in canonical order */
    VIPK_SWAB32S(&Pkt->Sequence);
}

void ProcessPacket(CCHAN		*CChan,
		   VIPK_CCHAN_PACKET	*Pkt)
{
    TRACE(VIPK_TRACE_CCHAN, "PSN: %d Op: %d", Pkt->PSN, Pkt->Op);
    switch(Pkt->Op) {
    case VIPK_CCHAN_OP_CONNREQ:
    case VIPK_CCHAN_OP_CONNACC:
    case VIPK_CCHAN_OP_CONNREJ:
    case VIPK_CCHAN_OP_CONNSCMP:
    case VIPK_CCHAN_OP_CONNCCMP:
    case VIPK_CCHAN_OP_CONNTO:
    case VIPK_CCHAN_OP_CONNNOM:
    case VIPK_CCHAN_OP_PEERREQ:
    case VIPK_CCHAN_OP_PEERACC:
    case VIPK_CCHAN_OP_PEER1CMP:
    case VIPK_CCHAN_OP_PEER2CMP:
    case VIPK_CCHAN_OP_PEERTO:
	TRACE(VIPK_TRACE_CCHAN,
	      "CM dispatch PSN: %d Op: %d", Pkt->PSN, Pkt->Op);
	CChan->Cm->RecvControl(CChan->Cm, Pkt);
	break;

    case VIPK_CCHAN_OP_CONNLOST:
	CChan->DevicePtr->DeviceOps->ConnectionLost(CChan->DevicePtr,
						    Pkt->ViHandle,
						    Pkt->Session,
						    Pkt->Sequence,
						    VIP_TRUE);
	break;

    case VIPK_CCHAN_OP_DISCO:
	CChan->DevicePtr->DeviceOps->ConnectionLost(CChan->DevicePtr,
						    Pkt->ViHandle,
						    Pkt->Session,
						    Pkt->Sequence,
						    VIP_FALSE);
	break;

    default:
	/* XXX: error */
      break;
    }

    DestroyPacket(Pkt);
}
