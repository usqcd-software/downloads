/* vipk/condvar.c
 * 
 * Implementation of condition variables for the Linux kernel.
 * See notes in condvar.h for details.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#include "condvar.h"

#include <linux/sched.h>

/**
 * Linux 2.6 uses simple spin_lock_t instead of wq_lock_t
 * in the 2.4 kernel
 */
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
# define wq_read_lock spin_lock
# define wq_read_lock_irqsave spin_lock_irqsave
# define wq_read_unlock spin_unlock
# define wq_read_unlock_irqrestore spin_unlock_irqrestore
# define wq_write_lock_irq spin_lock_irq
# define wq_write_lock_irqsave spin_lock_irqsave
# define wq_write_unlock_irqrestore spin_unlock_irqrestore
# define wq_write_unlock spin_unlock
#endif

void cond_init(condvar_t *cv) 
{
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0))
    init_waitqueue_head(&cv->q);
#else
    init_waitqueue(&cv->q);
#endif
}

void __cond_wait(condvar_t *cv,
		 spinlock_t *l,
		 int state,
		 unsigned long *timeout)
{
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0))
    unsigned long flags;
    unsigned long _timeout = *timeout;

    DECLARE_WAITQUEUE(wait,current);

    set_current_state(state);
    /* I presume we need the wait queue lock before we can unlock l */
    wq_write_lock_irqsave(&cv->q.lock, flags);
    __add_wait_queue(&cv->q, &wait);
    spin_unlock(l);
    wq_write_unlock(&cv->q.lock);
    if(state == TASK_UNINTERRUPTIBLE) {
	schedule();
    } else {
	_timeout = schedule_timeout(_timeout);
    }
    wq_write_lock_irq(&cv->q.lock);
    __remove_wait_queue(&cv->q, &wait);
    wq_write_unlock_irqrestore(&cv->q.lock, flags);
    *timeout = _timeout;
    spin_lock(l);

    
#else
    unsigned long flags;
    unsigned long _timeout = *timeout;
    struct wait_queue wait;

    current->state = state;
    wait.task = current;
    write_lock_irqsave(&waitqueue_lock, flags);
    __add_wait_queue(&cv->q, &wait);
    spin_unlock(l);
    write_unlock(&waitqueue_lock);
    if(state == TASK_UNINTERRUPTIBLE) {
	schedule();
    } else {
	_timeout = schedule_timeout(_timeout);
    }
    write_lock_irq(&waitqueue_lock);
    __remove_wait_queue(&cv->q, &wait);
    write_unlock_irqrestore(&waitqueue_lock, flags);
    *timeout = _timeout;
    spin_lock(l);
#endif
}

void cond_wait(condvar_t *cv, spinlock_t *l)
{
    unsigned long timeout = MAX_SCHEDULE_TIMEOUT;
    return __cond_wait(cv, l, TASK_UNINTERRUPTIBLE, &timeout);
}

void cond_wait_interruptible(condvar_t *cv,
			     spinlock_t *l,
			     unsigned long *timeout)
{
    return __cond_wait(cv, l, TASK_INTERRUPTIBLE, timeout);
}    

/* sigh, not enough is exported from the kernel to do this properly,
 * what I really want to do is below, but neither wake_up_process
 * nor any of the other functions for manipulating the run queue
 * are exported.  Live with it for now, but write up proper condition
 * variable support and submit it as a patch to sched.c when
 * the linux 2.1.x -> 2.2.x feature freeze ends
 *
 * A plain wake_up is basically a broadcast to the cond, which is
 * inefficient.  But, as this is for the VIA code and not a patch
 * to the general kernel yet, this is ok.  We never have more than
 * one via thread waiting on a cond var.
 *
 */
void cond_signal(condvar_t *cv) 
{
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0))
    if(waitqueue_active(&cv->q)) {
	/* The queue is not empty, just wake up the first process
	   on the list */
	wait_queue_t *w =  list_entry(cv->q.task_list.next,
				      wait_queue_t, task_list);
	struct task_struct *p = w->task;

	if((p->state == TASK_UNINTERRUPTIBLE) ||
	   (p->state == TASK_INTERRUPTIBLE)) {
	    wake_up_process(p);
	} else {
	    /* oops, this should never happen */
	    wake_up(&cv->q);
	}
    }
#else
    wake_up(&cv->q);
#endif
}
