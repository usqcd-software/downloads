/******************************************************************************
 *
 * Name:	version.h
 * Project:	GEnesis, PCI Gigabit Ethernet Adapter
 * Version:	$Revision: 1.1.1.1 $
 * Date:	$Date: 2005/01/18 19:37:20 $
 * Purpose:	SK specific Error log support
 *
 ******************************************************************************/

/******************************************************************************
 *
 *	(C)Copyright 1998,1999 SysKonnect,
 *	a business unit of Schneider & Koch & Co. Datensysteme GmbH.
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *	(at your option) any later version.
 *
 *	The information in this file is provided "AS IS" without warranty.
 *
 ******************************************************************************/

/******************************************************************************
 *
 * History:
 *	$Log: skversion.h,v $
 *	Revision 1.1.1.1  2005/01/18 19:37:20  chen
 *	Initial import of mvia-1.4
 *	
 *	Revision 1.1.1.1  2003/04/10 14:34:18  chen
 *	Import MVIA and Intel Pro 1000 MVIA Driver
 *	
 *	Revision 1.1  2002/03/11 23:41:26  welcome
 *	Upgraded driver, based on the Redhat 7.2 kernel version 2.4.9-13.
 *	
 *	Revision 1.1  2001/03/06 09:25:00  mlindner
 *	first version
 *	
 *	
 *
 ******************************************************************************/
 
 
static const char SysKonnectFileId[] = "@(#)" __FILE__ " (C) SysKonnect GmbH.";
static const char SysKonnectBuildNumber[] =
	"@(#)SK-BUILD: 4.06 PL: 01"; 

#define BOOT_STRING	"sk98lin: Network Device Driver v4.06\n" \
			"Copyright (C) 2000-2001 SysKonnect GmbH."

#define VER_STRING	"4.06"


