/** \file vnettest.c
 *
 * Example VI application to measure latency and bandwidth.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <sys/time.h>

#include <assert.h>

#include <vipl.h>

#define REPS 5000

/*
#define MAX_SIZE 32000
#define MIN_SIZE 4
*/
#define MAX_SIZE 32000
#define MIN_SIZE 4

#define MAX_SEND_BUFFS 2
#define MAX_RECV_BUFFS 8


#define round(a, b) ((a) -((a)%(b)))

char * amalloc(int size, int align);
int next_size(int size);

double get_seconds(void) {
  struct timeval t;
  gettimeofday(&t,NULL);
  return (double)t.tv_sec+((double)t.tv_usec/(double)1e6);
}

char usage[] = "usage: vnettest /dev/via_device r|s machine latfile bwfile\n";

int
main(int argc, char *argv[])
{
    double t1, t2;
    int reps = REPS;
    int size;
    int sending;
    int i, k;

    VIP_CONN_HANDLE	connHand;

    VIP_NET_ADDRESS	*localAddr;
    VIP_NET_ADDRESS	*remoteAddr;

    VIP_NIC_HANDLE	nicHand;
    VIP_NIC_ATTRIBUTES	nicAttrs;

    VIP_VI_HANDLE	viHand;
    VIP_VI_ATTRIBUTES 	viAttrs;
    VIP_VI_ATTRIBUTES	remoteViAttrs;

    VIP_MEM_ATTRIBUTES	memAttrs;
    VIP_PROTECTION_HANDLE ptag;

    VIP_DESCRIPTOR 	*descp;
    VIP_DESCRIPTOR 	*send_desc;
    VIP_DESCRIPTOR 	*recv_desc;
    char 		*send_buff;
    char                *recv_buff;
    int                 *val;                
    char                latfile[80], bwfile[80];

    FILE		*fp_bw = NULL;
    FILE		*fp_lat = NULL;


    VIP_MEM_HANDLE 	send_descHand, send_buffHand;
    VIP_MEM_HANDLE 	recv_descHand, recv_buffHand;

    if(argc != 6) {
	fprintf(stderr, usage);
	exit(-1);
    }

    switch(argv[2][0]) {
    case 's':
	sending = 1;
	break;
    case 'r':
	sending = 0;
	break;
    default:
	fprintf(stderr, usage);
	exit(-1);
    }
    strcpy (latfile, argv[4]);
    strcpy (bwfile, argv[5]);

    if(VipOpenNic(argv[1], &nicHand) != VIP_SUCCESS) {
	printf("Failed VipOpenNic\n");
	exit(-1);
    }

    if(VipNSInit(nicHand, NULL) != VIP_SUCCESS) {
	printf("Failed VipNSInit\n");
	exit(-1);
    }

    if(VipQueryNic(nicHand, &nicAttrs) != VIP_SUCCESS) {
	printf("Failed VipQueryNic\n");
	exit(-1);
    }

    localAddr = malloc(sizeof(VIP_NET_ADDRESS)+nicAttrs.NicAddressLen);
    localAddr->HostAddressLen = nicAttrs.NicAddressLen;
    
    localAddr->DiscriminatorLen = 0;
    memcpy(localAddr->HostAddress, 
	   nicAttrs.LocalNicAddress, nicAttrs.NicAddressLen);


    remoteAddr = malloc(sizeof(VIP_NET_ADDRESS)+nicAttrs.NicAddressLen);
    memset(remoteAddr, 0, sizeof(VIP_NET_ADDRESS));
    remoteAddr->HostAddressLen = nicAttrs.NicAddressLen;
    remoteAddr->DiscriminatorLen = 0;

    if(VipNSGetHostByName(nicHand, argv[3], remoteAddr, 0) != VIP_SUCCESS) {
	printf("Failed VipNSGetHostByName\n");
	exit(-1);
    }
    
    send_desc = (VIP_DESCRIPTOR *) amalloc(sizeof(VIP_DESCRIPTOR), 
					   VIP_DESCRIPTOR_ALIGNMENT);

    send_buff = amalloc(MAX_SIZE, 4096);

    if(VipCreatePtag(nicHand, &ptag) != VIP_SUCCESS) {
	printf("Failed to create ptag\n");
	exit(-1);
    }

    memAttrs.Ptag = ptag;
    memAttrs.EnableRdmaWrite = VIP_FALSE;
    memAttrs.EnableRdmaRead = VIP_FALSE;

    if(VipRegisterMem(nicHand, send_desc, sizeof(VIP_DESCRIPTOR), 
		      &memAttrs, &send_descHand) != VIP_SUCCESS) {
	printf("Failed to register descriptors\n");
	exit(-1);
    }
    
    if(VipRegisterMem(nicHand, send_buff, MAX_SIZE, 
		      &memAttrs, &send_buffHand) != VIP_SUCCESS) {
	printf("Failed to register buffers\n");
	exit(-1);
    }

    /* Create bunch of receiving buffers */
    recv_desc = (VIP_DESCRIPTOR *) amalloc(MAX_RECV_BUFFS*sizeof(VIP_DESCRIPTOR), 
					   VIP_DESCRIPTOR_ALIGNMENT);

    recv_buff = amalloc(MAX_RECV_BUFFS*MAX_SIZE, 4096);


    if(VipRegisterMem(nicHand, recv_desc, MAX_RECV_BUFFS*sizeof(VIP_DESCRIPTOR), 
		      &memAttrs, &recv_descHand) != VIP_SUCCESS) {
	printf("Failed to register descriptors\n");
	exit(-1);
    }
    
    if(VipRegisterMem(nicHand, recv_buff, MAX_RECV_BUFFS*MAX_SIZE, 
		      &memAttrs, &recv_buffHand) != VIP_SUCCESS) {
	printf("Failed to register buffers\n");
	exit(-1);
    }

    viAttrs.ReliabilityLevel = VIP_SERVICE_UNRELIABLE; 
    /* viAttrs.ReliabilityLevel = VIP_SERVICE_RELIABLE_DELIVERY; */

    viAttrs.Ptag = ptag;
    viAttrs.EnableRdmaWrite = VIP_FALSE;
    viAttrs.EnableRdmaRead = VIP_FALSE;
    viAttrs.QoS = 0;
    viAttrs.MaxTransferSize = MAX_SIZE;

    if(VipCreateVi(nicHand, &viAttrs, NULL, NULL, &viHand) != VIP_SUCCESS) {
	printf("Failed to create VI\n");
	exit(-1);
    }
    

    if(sending) {
	if((fp_bw = fopen(bwfile, "w")) == 0) {
	    printf("Failed open bw file %s\n", bwfile);
	    exit(-1);
	}
	
	if((fp_lat = fopen(latfile, "w")) == 0) {
	    printf("Failed open latency file %s\n", latfile);
	    exit(-1);
	}
    }
	
    for(size = MIN_SIZE; size <= MAX_SIZE; size=next_size(size)) {

      send_desc->CS.Length = size;
      send_desc->CS.Status = 0;
      send_desc->CS.Control = VIP_CONTROL_OP_SENDRECV;
      send_desc->CS.SegCount = 1;
      send_desc->CS.Reserved = 0;
      send_desc->DS[0].Local.Data.Address = send_buff;
      send_desc->DS[0].Local.Handle = send_buffHand;
      send_desc->DS[0].Local.Length = size;

      /* Recv descriptor */
      for(i=0; i < MAX_RECV_BUFFS; i++) {
	recv_desc[i].CS.Length = size;
	recv_desc[i].CS.Status = 0;
	recv_desc[i].CS.Control = VIP_CONTROL_OP_SENDRECV;
	recv_desc[i].CS.SegCount = 1;
	recv_desc[i].CS.Reserved = 0;
	recv_desc[i].DS[0].Local.Data.Address = &recv_buff[i*size];
	recv_desc[i].DS[0].Local.Handle = recv_buffHand;
	recv_desc[i].DS[0].Local.Length = size;
      }
	
      if(sending) {
	VIP_RETURN Status;

	Status = VIP_NO_MATCH;
	/* Post tons of recv buffers */
	for (k = 0; k < MAX_RECV_BUFFS; k++)
	  VipPostRecv (viHand, &recv_desc[k], recv_descHand);


	while(Status == VIP_NO_MATCH) {
	  Status = VipConnectRequest(viHand, localAddr,
				     remoteAddr, VIP_INFINITE,
				     &remoteViAttrs);
	}
	if(Status != VIP_SUCCESS) {
	  printf("Failed VipConnectRequest\n");
	  exit(-1);
	}
	    
	fprintf(stderr, "size: %d\n", size);
	fflush(stderr);

	/* Send this thing out */
	VipPostSend(viHand, send_desc, send_descHand);
	VipSendWait(viHand, VIP_INFINITE, &descp);

	t1 = get_seconds();
	for(i=0; i < reps; i++) {
	  /* Reciving a packet and put this memory back into queue again */
	  VipRecvWait(viHand, VIP_INFINITE, &descp);
	  VipPostRecv(viHand, descp, recv_descHand);

	  /* Send this thing out */
	  if (i < reps - 1) {
	    VipPostSend(viHand, send_desc, send_descHand);
	    VipSendWait(viHand, VIP_INFINITE, &descp);
	  }
	}
	t2 = get_seconds();

	fprintf(fp_lat, "%d %f\n", size, (.5*((t2-t1)*1e6)/reps));
	/* fprintf(fp_bw, "%d %f\n", size, (reps*size)/(.5*(1e6*(t2-t1)))); */
	fprintf(fp_bw, "%d %f\n", size, (reps*size)/(1e6*(t2-t1)));
	VipDisconnect(viHand);	    
      } else {
	if(VipConnectWait(nicHand, localAddr, VIP_INFINITE, 
			  remoteAddr, &remoteViAttrs, 
			  &connHand) != VIP_SUCCESS) {
	  printf("Failed VipConnectWait\n");
	  exit(-1);
	}

	/* Post tons of recv buffers */
	for (k = 0; k < MAX_RECV_BUFFS; k++)
	  VipPostRecv (viHand, &recv_desc[k], recv_descHand);
	
	if(VipConnectAccept(connHand, viHand) != VIP_SUCCESS) {
	  printf("Failed VipConnectAccept\n");
	  exit(-1);
	}

	/* Send this thing out */
	VipPostSend(viHand, send_desc, send_descHand);
	VipSendWait(viHand, VIP_INFINITE, &descp);

	for(i=0; i<reps; i++) {
	  /* receive a descritpion and put back into queu again */
	  VipRecvWait(viHand, VIP_INFINITE, &descp);
	  VipPostRecv(viHand, descp, recv_descHand);

	  if (i < reps - 1) {
	    /* Send something out first */
	    VipPostSend(viHand, send_desc, send_descHand);
	    VipSendWait(viHand, VIP_INFINITE, &descp);
	  }

	}	

	VipDisconnect(viHand);
	/* while(VipRecvDone(viHand, &descp) == VIP_SUCCESS) ; */
	}
    }

    VipDeregisterMem(nicHand, send_buff, send_buffHand);
    VipDeregisterMem(nicHand, send_desc, send_descHand);

    VipDeregisterMem(nicHand, recv_buff, recv_buffHand);
    VipDeregisterMem(nicHand, recv_desc, recv_descHand);

    VipDisconnect(viHand);
    VipDestroyVi(viHand);

    exit(0);
}
  
char *
amalloc(int size, int align)
{
    char *ptr;
    uintptr_t mask = align - 1;

    ptr = malloc(size + align - 1);
    if(ptr != NULL && ((uintptr_t)ptr & mask) != 0) {
	ptr = (char *) (((uintptr_t)ptr + mask) & ~mask);
    }

    return ptr;
}


/* pick the next message size based on the current size 
 * code modified from WCS Perf1.1a2 MPI tests */
int next_size(int size) 
{
  int delta = 0;
  double dsize = size;

  /* for small sizes, return fixed increments */
  /* choose not quite power ot two increments so that we don't
   * always end up on some nice boundary
   * choose multiple of four because it will be rare to send smaller
   * amounts (bytes or chars or shorts).
   */
  if (size < 8)         delta = 1;
  else if (size < 16)   delta = 4;
  else if (size < 128)  delta = 12;
  else if (size < 512)  delta = 28;
  else if (size < 8192) delta = 120;
  else {
    dsize *= 1.02;
    delta = dsize - size;
  }

  delta = round(delta, 1);

  return(size+delta);
}  
