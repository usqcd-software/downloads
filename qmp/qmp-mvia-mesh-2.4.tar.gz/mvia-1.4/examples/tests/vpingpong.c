/** \file vpingpong.c
 *
 * Example application to test connection between VI NICs.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <sys/time.h>

#include <assert.h>

#include <vipl.h>

char * amalloc(int size, int align);
void   fatal(char *);

double get_seconds(void) {
  struct timeval t;
  gettimeofday(&t,NULL);
  return (double)t.tv_sec+((double)t.tv_usec/(double)1e6);
}

char usage[] = "usage: vpingpong device r|s remote packets size\n\n"
               "       device         Device, such as /dev/via_lo or /dev/via_eth0\n"
               "       r|s            Sender starts pingpong; receiver relays. (Start receiver first)\n"
               "       remote         Name of remote machine, as in /etc/vip_hosts\n"
               "       packets        Number of packets to send (roundtrip)\n"
               "       size           Size (in bytes) of each packet\n";

int
main(int argc, char *argv[])
{
    double t1, t2;
    char *deviceName, *remoteName;
    int packets;
    int size;
    int sending = 0;
    int i;

    VIP_CONN_HANDLE	connHand;

    VIP_NET_ADDRESS	*localAddr;
    VIP_NET_ADDRESS	*remoteAddr;

    VIP_NIC_HANDLE	nicHand;
    VIP_NIC_ATTRIBUTES	nicAttrs;

    VIP_VI_HANDLE	viHand;
    VIP_VI_ATTRIBUTES 	viAttrs;
    VIP_VI_ATTRIBUTES	remoteViAttrs;

    VIP_MEM_ATTRIBUTES	memAttrs;
    VIP_PROTECTION_HANDLE ptag;

    VIP_DESCRIPTOR 	*descp;
    VIP_DESCRIPTOR 	*desc;
    char 		*buff;


    VIP_MEM_HANDLE 	descHand, buffHand;

    if(argc != 6) {
	fatal(usage);
    }

    switch(argv[2][0]) {
    case 's':
	sending = 1;
	break;
    case 'r':
	sending = 0;
	break;
    default:
	fatal(usage);
    }

    deviceName = argv[1];
    remoteName = argv[3];
    packets = atoi(argv[4]);
    size = atoi(argv[5]);

    if(VipOpenNic(deviceName, &nicHand) != VIP_SUCCESS) {
	fatal("VipOpenNic failed\n");
    }

    if(VipNSInit(nicHand, NULL) != VIP_SUCCESS) {
	fatal("VipNSInit failed\n");
    }

    if(VipQueryNic(nicHand, &nicAttrs) != VIP_SUCCESS) {
	fatal("VipQueryNic failed\n");
    }

    localAddr = malloc(sizeof(VIP_NET_ADDRESS)+nicAttrs.NicAddressLen);
    localAddr->HostAddressLen = nicAttrs.NicAddressLen;
    
    localAddr->DiscriminatorLen = 0;
    memcpy(localAddr->HostAddress, 
	   nicAttrs.LocalNicAddress, nicAttrs.NicAddressLen);

    remoteAddr = malloc(sizeof(VIP_NET_ADDRESS)+nicAttrs.NicAddressLen);
    memset(remoteAddr, 0, sizeof(VIP_NET_ADDRESS));
    remoteAddr->HostAddressLen = nicAttrs.NicAddressLen;
    remoteAddr->DiscriminatorLen = 0;

    if(VipNSGetHostByName(nicHand, remoteName, remoteAddr, 0) != VIP_SUCCESS) {
	fatal("VipNSGetHostByName failed\n");
    }
    
    desc = (VIP_DESCRIPTOR *) amalloc(2*sizeof(VIP_DESCRIPTOR), 
				      VIP_DESCRIPTOR_ALIGNMENT);

    buff = amalloc(2*size, 32);

    if(VipCreatePtag(nicHand, &ptag) != VIP_SUCCESS) {
	fatal("Failed to create ptag\n");
    }

    memAttrs.Ptag = ptag;
    memAttrs.EnableRdmaWrite = VIP_FALSE;
    memAttrs.EnableRdmaRead = VIP_FALSE;

    if(VipRegisterMem(nicHand, desc, 2*sizeof(VIP_DESCRIPTOR), 
		      &memAttrs, &descHand) != VIP_SUCCESS) {
	fatal("Failed to register descriptors\n");
    }
    
    if(VipRegisterMem(nicHand, buff, (2*size)+1, 
		      &memAttrs, &buffHand) != VIP_SUCCESS) {
	fatal("Failed to register buffers\n");
    }

    viAttrs.ReliabilityLevel = VIP_SERVICE_UNRELIABLE;

    viAttrs.Ptag = ptag;
    viAttrs.EnableRdmaWrite = VIP_FALSE;
    viAttrs.EnableRdmaRead = VIP_FALSE;
    viAttrs.QoS = 0;
    viAttrs.MaxTransferSize = size;
    
    if(VipCreateVi(nicHand, &viAttrs, NULL, NULL, &viHand) != VIP_SUCCESS) {
	fatal("Failed to create VI\n");
    }

    for(i=0; i<2; i++) {
	desc[i].CS.Length = size;
	desc[i].CS.Status = 0;
	desc[i].CS.Control = VIP_CONTROL_OP_SENDRECV;
	desc[i].CS.SegCount = 1;
	desc[i].CS.Reserved = 0;
	desc[i].DS[0].Local.Data.Address = &buff[i*size];
	desc[i].DS[0].Local.Handle = buffHand;
	desc[i].DS[0].Local.Length = size;
    }

    if(sending) {
	if(VipConnectRequest(viHand, localAddr,
			     remoteAddr, 5000,
			     &remoteViAttrs) != VIP_SUCCESS) {
	    fatal("VipConnectRequest failed\n");
	}
	
	for(i=0; i < 5; i++) {
	    VipPostRecv(viHand, &desc[0], descHand);
	    VipPostSend(viHand, &desc[1], descHand);
	    VipSendWait(viHand, VIP_INFINITE, &descp);
	    VipRecvWait(viHand, VIP_INFINITE, &descp);
	}

	t1 = get_seconds();
	for(i=0; i < packets; i++) {
	    VipPostRecv(viHand, &desc[0], descHand);
	    VipPostSend(viHand, &desc[1], descHand);
	    VipSendWait(viHand, VIP_INFINITE, &descp);
	    VipRecvWait(viHand, VIP_INFINITE, &descp);
	}
	t2 = get_seconds();

	printf("RT: %f (us)\tLat: %f (us) BW: %f (MB/s)\n",
	       ((t2-t1)*1e6)/packets,
	       (((t2-t1)*1e6)/packets)/2,
	       ((packets*size)/(((t2-t1)*1e6)/2)));
    } else {
	VipPostRecv(viHand, &desc[0], descHand);
	descp = &desc[1];

	if(VipConnectWait(nicHand, localAddr, VIP_INFINITE, 
			  remoteAddr, &remoteViAttrs, 
			  &connHand) != VIP_SUCCESS) {
	    fatal("VipConnectWait failed\n");
	}

	if(VipConnectAccept(connHand, viHand) != VIP_SUCCESS) {
	    fatal("VipConnectAccept failed\n");
	}
	
	for(i=0; i < 5; i++) {
	    VipPostRecv(viHand, descp, descHand);
	    VipRecvWait(viHand, VIP_INFINITE, &descp);
	    VipPostSend(viHand, descp, descHand);
	    VipSendWait(viHand, VIP_INFINITE, &descp);
	}
	
	for(i=0; i<packets; i++) {
	    VipPostRecv(viHand, descp, descHand);
 	    VipRecvWait(viHand, VIP_INFINITE, &descp);
	    VipPostSend(viHand, descp, descHand);
	    VipSendWait(viHand, VIP_INFINITE, &descp);
	}
    }

    VipDeregisterMem(nicHand, buff, buffHand);
    VipDeregisterMem(nicHand, desc, descHand);

    VipDisconnect(viHand);
    VipDestroyVi(viHand);

    exit(0);
}
  
char *
amalloc(int size, int align)
{
    char *ptr;
    uintptr_t mask = align - 1;

    ptr = malloc(size + align - 1);
    if(ptr != NULL && ((uintptr_t)ptr & mask) != 0) {
	ptr = (char *) (((uintptr_t)ptr + mask) & ~mask);
    }

    return ptr;
}

  
void fatal(char *msg)
{
  fprintf(stderr, "%s\n", msg);
  exit(-1);
}
