/** \file vnettest.c
 *
 * Example VI application to measure latency and bandwidth.
 *
 *
 * Copyright (C) 1998-2001 The Regents of the University of California
 * (through E.O. Lawrence Berkeley National Laboratory), subject to
 * approval by the U.S. Department of Energy.
 *
 * Your use of this software is under license -- the license agreement is
 * attached and included in the top-level M-VIA directory as LICENSE.TXT
 * or you may contact Berkeley Lab's Technology Transfer Department at
 * TTD@lbl.gov.
 *
 * NOTICE OF U.S. GOVERNMENT RIGHTS.  The Software was developed under
 * funding from the U.S. Government which consequently retains certain
 * rights as follows: the U.S. Government has been granted for itself and
 * others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, prepare derivative
 * works, and perform publicly and display publicly.  Beginning five (5)
 * years after the date permission to assert copyright is obtained from
 * the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others
 * acting on its behalf a paid-up, nonexclusive, irrevocable, worldwide
 * license in the Software to reproduce, prepare derivative works,
 * distribute copies to the public, perform publicly and display
 * publicly, and to permit others to do so.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <sys/time.h>

#include <pthread.h>

#include <assert.h>

#include <vipl.h>

#define REPS 5000

/*
#define MAX_SIZE 32000
#define MIN_SIZE 4
*/
#define MAX_SIZE 32000
#define MIN_SIZE 32000

#define MAX_RECV_BUFFS 8

#define MAX_DEVS 3

static char* device_names[] = {
  "/dev/via_eth2",
  "/dev/via_eth4",
  "/dev/via_eth6",
};

static int num_devices = 3;

static char* recv_host_names[] = {
  "via1-2",
  "via1-4",
  "via1-6",
};

static char* send_host_names[] = {
  "via2-2",
  "via2-4",
  "via2-6",
};


/*
static char* device_names[] = {
  "/dev/via_eth2",
  "/dev/via_eth4",
};

static int num_devices = 2;

static char* recv_host_names[] = {
  "via1-2",
  "via1-4",
};

static char* send_host_names[] = {
  "via2-2",
  "via2-4",
};
*/

/*
static char* device_names[] = {
  "/dev/via_eth6",
  "/dev/via_eth7",
};

static int num_devices = 2;

static char* recv_host_names[] = {
  "via1-6",
  "via1-7",
};

static char* send_host_names[] = {
  "via2-6",
  "via2-7",
};
*/

typedef struct via_conn_
{
  int reps;
  VIP_VI_HANDLE viHand;
  VIP_DESCRIPTOR* send_desc;
  VIP_MEM_HANDLE send_descHand;
  VIP_MEM_HANDLE recv_descHand;
}via_conn_t;
  

#define round(a, b) ((a) -((a)%(b)))

char * amalloc(int size, int align);
int next_size(int size);

double get_seconds(void) {
  struct timeval t;
  gettimeofday(&t,NULL);
  return (double)t.tv_sec+((double)t.tv_usec/(double)1e6);
}

char usage[] = "usage: vnet-mdev r|s latfile bwfile\n";

static void *sender_thread (void *arg)
{
  int m;
  VIP_DESCRIPTOR* descp;
  via_conn_t* conn = (via_conn_t *)arg;

  for(m = 0; m < conn->reps; m++) {
    /* Send this thing out */
    VipPostSend(conn->viHand, conn->send_desc, conn->send_descHand);
    VipSendWait(conn->viHand, VIP_INFINITE, &descp);

    /* Reciving a packet and put this memory back into queue again */
    VipRecvWait(conn->viHand, VIP_INFINITE, &descp);
    VipPostRecv(conn->viHand, descp, conn->recv_descHand);
  }
  return (void *)0;
}

static void *recver_thread (void* arg) 
{
  int m;
  VIP_DESCRIPTOR* descp;
  via_conn_t* conn = (via_conn_t *)arg;

  for (m = 0; m < conn->reps; m++) {

    /* Send something out first */
    VipPostSend(conn->viHand, conn->send_desc, conn->send_descHand);
    VipSendWait(conn->viHand, VIP_INFINITE, &descp);

    /* receive a descritpion and put back into queu again */
    VipRecvWait(conn->viHand, VIP_INFINITE, &descp);
    VipPostRecv(conn->viHand, descp, conn->recv_descHand);
  } 
  return 0;
}

int
main(int argc, char *argv[])
{
    double t1, t2;
    int reps = REPS;
    int size;
    int sending;
    int i, k, m;

    VIP_CONN_HANDLE	connHand[MAX_DEVS];

    VIP_NET_ADDRESS	*localAddr[MAX_DEVS];
    VIP_NET_ADDRESS	*remoteAddr[MAX_DEVS];

    VIP_NIC_HANDLE	nicHand[MAX_DEVS];
    VIP_NIC_ATTRIBUTES	nicAttrs[MAX_DEVS];

    VIP_VI_HANDLE	viHand[MAX_DEVS];
    VIP_VI_ATTRIBUTES 	viAttrs[MAX_DEVS];
    VIP_VI_ATTRIBUTES	remoteViAttrs[MAX_DEVS];

    VIP_MEM_ATTRIBUTES	memAttrs[MAX_DEVS];
    VIP_PROTECTION_HANDLE ptag[MAX_DEVS];

    VIP_DESCRIPTOR 	*send_desc[MAX_DEVS];
    VIP_DESCRIPTOR 	*recv_desc[MAX_DEVS];
    char 		*send_buff[MAX_DEVS];
    char                *recv_buff[MAX_DEVS];
    char                latfile[80], bwfile[80];

    FILE		*fp_bw = NULL;
    FILE		*fp_lat = NULL;


    VIP_MEM_HANDLE 	send_descHand[MAX_DEVS], send_buffHand[MAX_DEVS];
    VIP_MEM_HANDLE 	recv_descHand[MAX_DEVS], recv_buffHand[MAX_DEVS];

    if(argc != 4) {
	fprintf(stderr, usage);
	exit(-1);
    }

    switch(argv[1][0]) {
    case 's':
	sending = 1;
	break;
    case 'r':
	sending = 0;
	break;
    default:
	fprintf(stderr, usage);
	exit(-1);
    }
    strcpy (latfile, argv[2]);
    strcpy (bwfile, argv[3]);

    for (i = 0; i < num_devices; i++) {
      if(VipOpenNic(device_names[i], &nicHand[i]) != VIP_SUCCESS) {
	printf("Failed VipOpenNic for device %s\n", device_names[i]);
	exit(-1);
      }

      if(VipNSInit(nicHand[i], NULL) != VIP_SUCCESS) {
	printf("Failed VipNSInit for device %s\n", device_names[i]);
	exit(-1);
      }

      if(VipQueryNic(nicHand[i], &nicAttrs[i]) != VIP_SUCCESS) {
	printf("Failed VipQueryNic for device %s\n", device_names[i]);
	exit(-1);
      }

      localAddr[i] = malloc(sizeof(VIP_NET_ADDRESS)+nicAttrs[i].NicAddressLen);
      localAddr[i]->HostAddressLen = nicAttrs[i].NicAddressLen;
    
      localAddr[i]->DiscriminatorLen = 0;
      memcpy(localAddr[i]->HostAddress, 
	     nicAttrs[i].LocalNicAddress, nicAttrs[i].NicAddressLen);


      remoteAddr[i] = malloc(sizeof(VIP_NET_ADDRESS)+nicAttrs[i].NicAddressLen);
      memset(remoteAddr[i], 0, sizeof(VIP_NET_ADDRESS));
      remoteAddr[i]->HostAddressLen = nicAttrs[i].NicAddressLen;
      remoteAddr[i]->DiscriminatorLen = 0;
      
      if (sending) {
	if(VipNSGetHostByName(nicHand[i], send_host_names[i], remoteAddr[i], 0) != VIP_SUCCESS) {
	  printf("Failed VipNSGetHostByName for device %s host %s\n",
		 device_names[i], send_host_names[i]);
	  exit(-1);
	}
      }
      else {
	if(VipNSGetHostByName(nicHand[i], recv_host_names[i], remoteAddr[i], 0) != VIP_SUCCESS) {
	  printf("Failed VipNSGetHostByName for device %s host %s\n",
		 device_names[i], recv_host_names[i]);
	  exit(-1);
	}
      }
    
      send_desc[i] = (VIP_DESCRIPTOR *) amalloc(sizeof(VIP_DESCRIPTOR), 
						VIP_DESCRIPTOR_ALIGNMENT);

      send_buff[i] = amalloc(MAX_SIZE, 4096);

      if(VipCreatePtag(nicHand[i], &ptag[i]) != VIP_SUCCESS) {
	printf("Failed to create ptag\n");
	exit(-1);
      }
      
      memAttrs[i].Ptag = ptag[i];
      memAttrs[i].EnableRdmaWrite = VIP_FALSE;
      memAttrs[i].EnableRdmaRead = VIP_FALSE;

      if(VipRegisterMem(nicHand[i], send_desc[i], sizeof(VIP_DESCRIPTOR), 
			&memAttrs[i], &send_descHand[i]) != VIP_SUCCESS) {
	printf("Failed to register send descriptors for device %s\n", device_names[i]);
	exit(-1);
      }
    
      if(VipRegisterMem(nicHand[i], send_buff[i], MAX_SIZE, 
			&memAttrs[i], &send_buffHand[i]) != VIP_SUCCESS) {
	printf("Failed to register send buffers for device %s\n",
	       device_names[i]);
	exit(-1);
      }

      /* Create bunch of receiving buffers */
      recv_desc[i] = (VIP_DESCRIPTOR *) amalloc(MAX_RECV_BUFFS*sizeof(VIP_DESCRIPTOR), 
						VIP_DESCRIPTOR_ALIGNMENT);

      recv_buff[i] = amalloc(MAX_RECV_BUFFS*MAX_SIZE, 4096);


      if(VipRegisterMem(nicHand[i], recv_desc[i], MAX_RECV_BUFFS*sizeof(VIP_DESCRIPTOR), 
			&memAttrs[i], &recv_descHand[i]) != VIP_SUCCESS) {
	printf("Failed to register recv descriptors for device %s\n", device_names[i]);
	exit(-1);
      }
    
      if(VipRegisterMem(nicHand[i], recv_buff[i], MAX_RECV_BUFFS*MAX_SIZE, 
		      &memAttrs[i], &recv_buffHand[i]) != VIP_SUCCESS) {
	printf("Failed to register recv buffers for device %s\n", device_names[i]);
	exit(-1);
      }

      viAttrs[i].ReliabilityLevel = VIP_SERVICE_UNRELIABLE; 
      /* viAttrs.ReliabilityLevel = VIP_SERVICE_RELIABLE_DELIVERY; */

      viAttrs[i].Ptag = ptag[i];
      viAttrs[i].EnableRdmaWrite = VIP_FALSE;
      viAttrs[i].EnableRdmaRead = VIP_FALSE;
      viAttrs[i].QoS = 0;
      viAttrs[i].MaxTransferSize = MAX_SIZE;

      if(VipCreateVi(nicHand[i], &viAttrs[i], NULL, NULL, &viHand[i]) 
	 != VIP_SUCCESS) {
	printf("Failed to create VI for device %s\n", device_names[i]);
	exit(-1);
      }
    }

    if(sending) {
      if((fp_bw = fopen(bwfile, "w")) == 0) {
	printf("Failed open bw file %s\n", bwfile);
	exit(-1);
      }
	
      if((fp_lat = fopen(latfile, "w")) == 0) {
	printf("Failed open latency file %s\n", latfile);
	exit(-1);
      }
    }
	
    for(size = MIN_SIZE; size <= MAX_SIZE; size=next_size(size)) {
      
      for (i = 0; i < num_devices; i++) {
	send_desc[i]->CS.Length = size;
	send_desc[i]->CS.Status = 0;
	send_desc[i]->CS.Control = VIP_CONTROL_OP_SENDRECV;
	send_desc[i]->CS.SegCount = 1;
	send_desc[i]->CS.Reserved = 0;
	send_desc[i]->DS[0].Local.Data.Address = send_buff[i];
	send_desc[i]->DS[0].Local.Handle = send_buffHand[i];
	send_desc[i]->DS[0].Local.Length = size;

	/* Recv descriptor */
	for(m=0; m < MAX_RECV_BUFFS; m++) {
	  recv_desc[i][m].CS.Length = size;
	  recv_desc[i][m].CS.Status = 0;
	  recv_desc[i][m].CS.Control = VIP_CONTROL_OP_SENDRECV;
	  recv_desc[i][m].CS.SegCount = 1;
	  recv_desc[i][m].CS.Reserved = 0;
	  recv_desc[i][m].DS[0].Local.Data.Address = &recv_buff[i][m*size];
	  recv_desc[i][m].DS[0].Local.Handle = recv_buffHand[i];
	  recv_desc[i][m].DS[0].Local.Length = size;
	}

	
	if(sending) {
	  VIP_RETURN Status;

	  Status = VIP_NO_MATCH;
	  /* Post tons of recv buffers */
	  for (k = 0; k < MAX_RECV_BUFFS; k++)
	    VipPostRecv (viHand[i], &recv_desc[i][k], recv_descHand[i]);


	  while(Status == VIP_NO_MATCH) {
	    Status = VipConnectRequest(viHand[i], localAddr[i],
				       remoteAddr[i], VIP_INFINITE,
				       &remoteViAttrs[i]);
	  }
	  if(Status != VIP_SUCCESS) {
	    printf("Failed VipConnectRequest to host %s\n", 
		   send_host_names[i]);
	    exit(-1);
	  }
	}
	else {
	  if(VipConnectWait(nicHand[i], localAddr[i], VIP_INFINITE, 
			  remoteAddr[i], &remoteViAttrs[i], 
			  &connHand[i]) != VIP_SUCCESS) {
	    printf("Failed VipConnectWait for device %s and remote host %s\n",
		   device_names[i], recv_host_names[i]);
	    exit(-1);
	  }

	  /* Post tons of recv buffers */
	  for (k = 0; k < MAX_RECV_BUFFS; k++)
	    VipPostRecv (viHand[i], &recv_desc[i][k], recv_descHand[i]);
	
	  if(VipConnectAccept(connHand[i], viHand[i]) != VIP_SUCCESS) {
	    printf("Failed VipConnectAccept for device %s and remote host %s\n",
		   device_names[i], recv_host_names[i]);
	    exit(-1);
	  }
	}      
      }
	
      if (sending) {
	pthread_attr_t attr[MAX_DEVS];
	pthread_t      thread[MAX_DEVS];
	via_conn_t     conn[MAX_DEVS];
	void*          estat;
	
	fprintf(stderr, "size: %d\n", size);
	fflush(stderr);

	for (i = 0; i < num_devices; i++) {
	  conn[i].reps = reps;
	  conn[i].viHand = viHand[i];
	  conn[i].send_desc = send_desc[i];
	  conn[i].send_descHand = send_descHand[i];
	  conn[i].recv_descHand = recv_descHand[i];
	  pthread_attr_init (&attr[i]);
	}

	t1 = get_seconds();

	/* start all threads */
	for (i = 0; i < num_devices; i++)
	  pthread_create (&thread[i], &attr[i], &sender_thread, (void *)&conn);
	

	/* wait for all thread */
	for (i = 0; i < num_devices; i++)
	  pthread_join (thread[i], &estat);

	t2 = get_seconds();
	
	fprintf(fp_lat, "%d %f\n", size, (.5*((t2-t1)*1e6)/reps));
	/* fprintf(fp_bw, "%d %f\n", size, (reps*size)/(.5*(1e6*(t2-t1)))); */
	fprintf(fp_bw, "%d %f\n", size, (reps*size*num_devices)/(1e6*(t2-t1)));

	for (i = 0; i < num_devices; i++)
	  pthread_attr_destroy (&attr[i]);

	for (i = 0; i < num_devices; i++)
	  VipDisconnect(viHand[i]);
      } else {
	pthread_attr_t attr[MAX_DEVS];
	pthread_t      thread[MAX_DEVS];
	via_conn_t     conn[MAX_DEVS];
	void*          estat;
	
	for (i = 0; i < num_devices; i++) {
	  conn[i].reps = reps;
	  conn[i].viHand = viHand[i];
	  conn[i].send_desc = send_desc[i];
	  conn[i].send_descHand = send_descHand[i];
	  conn[i].recv_descHand = recv_descHand[i];
	  pthread_attr_init (&attr[i]);
	}


	for (i = 0; i < num_devices; i++)
	  pthread_create (&thread[i], &attr[i], &recver_thread, (void *)&conn);

	/* wait for all threads */
	for (i = 0; i < num_devices; i++)
	  pthread_join (thread[i], &estat);

	for (i = 0; i < num_devices; i++)
	  pthread_attr_destroy (&attr[i]);

	for (i = 0; i < num_devices; i++)
	  VipDisconnect(viHand[i]);
      }
    }

    for (i = 0; i < num_devices; i++) {
      VipDeregisterMem(nicHand[i], send_buff[i], send_buffHand[i]);
      VipDeregisterMem(nicHand[i], send_desc[i], send_descHand[i]);

      VipDeregisterMem(nicHand[i], recv_buff[i], recv_buffHand[i]);
      VipDeregisterMem(nicHand[i], recv_desc[i], recv_descHand[i]);

      VipDestroyVi(viHand[i]);
    }

    exit(0);
}
  
char *
amalloc(int size, int align)
{
    char *ptr;
    uintptr_t mask = align - 1;

    ptr = malloc(size + align - 1);
    if(ptr != NULL && ((uintptr_t)ptr & mask) != 0) {
	ptr = (char *) (((uintptr_t)ptr + mask) & ~mask);
    }

    return ptr;
}


/* pick the next message size based on the current size 
 * code modified from WCS Perf1.1a2 MPI tests */
int next_size(int size) 
{
  int delta = 0;
  double dsize = size;

  /* for small sizes, return fixed increments */
  /* choose not quite power ot two increments so that we don't
   * always end up on some nice boundary
   * choose multiple of four because it will be rare to send smaller
   * amounts (bytes or chars or shorts).
   */
  if (size < 8)         delta = 1;
  else if (size < 16)   delta = 4;
  else if (size < 128)  delta = 12;
  else if (size < 512)  delta = 28;
  else if (size < 8192) delta = 120;
  else {
    dsize *= 1.02;
    delta = dsize - size;
  }

  delta = round(delta, 1);

  return(size+delta);
}  
