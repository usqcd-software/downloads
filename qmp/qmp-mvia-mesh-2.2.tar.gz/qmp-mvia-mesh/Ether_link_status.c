/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Quick Ethernet Link Test for a mesh based cluster.
 *
 *      This test is based on ethernet driver dumping information
 *      in the /proc/net/PRO_LAN_Adapters directory. Future release 
 *      may be based on /sbin/ethtool.
 *
 * Author:  
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: Ether_link_status.c,v $
 *   Revision 1.2  2004/02/17 17:19:58  chen
 *   Ether_link_status.c
 *
 *   Revision 1.1  2004/02/13 20:09:39  chen
 *   Add a test and utility program
 *
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#define MAX_NUM_HOSTS 1024
#define MAX_HOST_LEN  128

/**
 * The following hosts are the 3g cluster at jefferson lab hpc group
 */
static char* default_all_hosts[]={
  "qcd3g000",
  "qcd3g100",
  "qcd3g200",
  "qcd3g300",
  "qcd3g010",
  "qcd3g110",
  "qcd3g210",
  "qcd3g310",
  "qcd3g020",
  "qcd3g120",
  "qcd3g220",
  "qcd3g320",
  "qcd3g030",
  "qcd3g130",
  "qcd3g230",
  "qcd3g330",
  "qcd3g040",
  "qcd3g140",
  "qcd3g240",
  "qcd3g340",
  "qcd3g050",
  "qcd3g150",
  "qcd3g250",
  "qcd3g350",
  "qcd3g060",
  "qcd3g160",
  "qcd3g260",
  "qcd3g360",
  "qcd3g070",
  "qcd3g170",
  "qcd3g270",
  "qcd3g370",
  "qcd3g001",
  "qcd3g101",
  "qcd3g201",
  "qcd3g301",
  "qcd3g011",
  "qcd3g111",
  "qcd3g211",
  "qcd3g311",
  "qcd3g021",
  "qcd3g121",
  "qcd3g221",
  "qcd3g321",
  "qcd3g031",
  "qcd3g131",
  "qcd3g231",
  "qcd3g331",
  "qcd3g041",
  "qcd3g141",
  "qcd3g241",
  "qcd3g341",
  "qcd3g051",
  "qcd3g151",
  "qcd3g251",
  "qcd3g351",
  "qcd3g061",
  "qcd3g161",
  "qcd3g261",
  "qcd3g361",
  "qcd3g071",
  "qcd3g171",
  "qcd3g271",
  "qcd3g371",
  "qcd3g002",
  "qcd3g102",
  "qcd3g202",
  "qcd3g302",
  "qcd3g012",
  "qcd3g112",
  "qcd3g212",
  "qcd3g312",
  "qcd3g022",
  "qcd3g122",
  "qcd3g222",
  "qcd3g322",
  "qcd3g032",
  "qcd3g132",
  "qcd3g232",
  "qcd3g332",
  "qcd3g042",
  "qcd3g142",
  "qcd3g242",
  "qcd3g342",
  "qcd3g052",
  "qcd3g152",
  "qcd3g252",
  "qcd3g352",
  "qcd3g062",
  "qcd3g162",
  "qcd3g262",
  "qcd3g362",
  "qcd3g072",
  "qcd3g172",
  "qcd3g272",
  "qcd3g372",
  "qcd3g003",
  "qcd3g103",
  "qcd3g203",
  "qcd3g303",
  "qcd3g013",
  "qcd3g113",
  "qcd3g213",
  "qcd3g313",
  "qcd3g023",
  "qcd3g123",
  "qcd3g223",
  "qcd3g323",
  "qcd3g033",
  "qcd3g133",
  "qcd3g233",
  "qcd3g333",
  "qcd3g043",
  "qcd3g143",
  "qcd3g243",
  "qcd3g343",
  "qcd3g053",
  "qcd3g153",
  "qcd3g253",
  "qcd3g353",
  "qcd3g063",
  "qcd3g163",
  "qcd3g263",
  "qcd3g363",
  "qcd3g073",
  "qcd3g173",
  "qcd3g273",
  "qcd3g373",
  "qcd3g004",
  "qcd3g104",
  "qcd3g204",
  "qcd3g304",
  "qcd3g014",
  "qcd3g114",
  "qcd3g214",
  "qcd3g314",
  "qcd3g024",
  "qcd3g124",
  "qcd3g224",
  "qcd3g324",
  "qcd3g034",
  "qcd3g134",
  "qcd3g234",
  "qcd3g334",
  "qcd3g044",
  "qcd3g144",
  "qcd3g244",
  "qcd3g344",
  "qcd3g054",
  "qcd3g154",
  "qcd3g254",
  "qcd3g354",
  "qcd3g064",
  "qcd3g164",
  "qcd3g264",
  "qcd3g364",
  "qcd3g074",
  "qcd3g174",
  "qcd3g274",
  "qcd3g374",
  "qcd3g005",
  "qcd3g105",
  "qcd3g205",
  "qcd3g305",
  "qcd3g015",
  "qcd3g115",
  "qcd3g215",
  "qcd3g315",
  "qcd3g025",
  "qcd3g125",
  "qcd3g225",
  "qcd3g325",
  "qcd3g035",
  "qcd3g135",
  "qcd3g235",
  "qcd3g335",
  "qcd3g045",
  "qcd3g145",
  "qcd3g245",
  "qcd3g345",
  "qcd3g055",
  "qcd3g155",
  "qcd3g255",
  "qcd3g355",
  "qcd3g065",
  "qcd3g165",
  "qcd3g265",
  "qcd3g365",
  "qcd3g075",
  "qcd3g175",
  "qcd3g275",
  "qcd3g375",
  "qcd3g006",
  "qcd3g106",
  "qcd3g206",
  "qcd3g306",
  "qcd3g016",
  "qcd3g116",
  "qcd3g216",
  "qcd3g316",
  "qcd3g026",
  "qcd3g126",
  "qcd3g226",
  "qcd3g326",
  "qcd3g036",
  "qcd3g136",
  "qcd3g236",
  "qcd3g336",
  "qcd3g046",
  "qcd3g146",
  "qcd3g246",
  "qcd3g346",
  "qcd3g056",
  "qcd3g156",
  "qcd3g256",
  "qcd3g356",
  "qcd3g066",
  "qcd3g166",
  "qcd3g266",
  "qcd3g366",
  "qcd3g076",
  "qcd3g176",
  "qcd3g276",
  "qcd3g376",
  "qcd3g007",
  "qcd3g107",
  "qcd3g207",
  "qcd3g307",
  "qcd3g017",
  "qcd3g117",
  "qcd3g217",
  "qcd3g317",
  "qcd3g027",
  "qcd3g127",
  "qcd3g227",
  "qcd3g327",
  "qcd3g037",
  "qcd3g137",
  "qcd3g237",
  "qcd3g337",
  "qcd3g047",
  "qcd3g147",
  "qcd3g247",
  "qcd3g347",
  "qcd3g057",
  "qcd3g157",
  "qcd3g257",
  "qcd3g357",
  "qcd3g067",
  "qcd3g167",
  "qcd3g267",
  "qcd3g367",
  "qcd3g077",
  "qcd3g177",
  "qcd3g277",
  "qcd3g377",
};
static int default_num_hosts = 256;


/**
 * The following hosts actually use eth5 device to construct extra 
 * configuration.
 */
static char* default_all_e5hosts[]={
  "qcd3g000",
  "qcd3g001",
  "qcd3g002",
  "qcd3g003",
  "qcd3g004",
  "qcd3g005",
  "qcd3g006",
  "qcd3g007",
  "qcd3g030",
  "qcd3g031",
  "qcd3g032",
  "qcd3g033",
  "qcd3g034",
  "qcd3g035",
  "qcd3g036",
  "qcd3g037",
  "qcd3g040",
  "qcd3g041",
  "qcd3g042",
  "qcd3g043",
  "qcd3g044",
  "qcd3g045",
  "qcd3g046",
  "qcd3g047",
  "qcd3g070",
  "qcd3g071",
  "qcd3g072",
  "qcd3g073",
  "qcd3g074",
  "qcd3g075",
  "qcd3g076",
  "qcd3g077",
  "qcd3g010",
  "qcd3g017",
  "qcd3g020",
  "qcd3g027",
  "qcd3g050",
  "qcd3g057",
  "qcd3g060",
  "qcd3g067",
  "qcd3g100",
  "qcd3g101",
  "qcd3g102",
  "qcd3g103",
  "qcd3g104",
  "qcd3g105",
  "qcd3g106",
  "qcd3g107",
  "qcd3g130",
  "qcd3g131",
  "qcd3g132",
  "qcd3g133",
  "qcd3g134",
  "qcd3g135",
  "qcd3g136",
  "qcd3g137",
  "qcd3g140",
  "qcd3g141",
  "qcd3g142",
  "qcd3g143",
  "qcd3g144",
  "qcd3g145",
  "qcd3g146",
  "qcd3g147",
  "qcd3g170",
  "qcd3g171",
  "qcd3g172",
  "qcd3g173",
  "qcd3g174",
  "qcd3g175",
  "qcd3g176",
  "qcd3g177",
  "qcd3g110",
  "qcd3g117",
  "qcd3g120",
  "qcd3g127",
  "qcd3g150",
  "qcd3g157",
  "qcd3g160",
  "qcd3g167",
  "qcd3g200",
  "qcd3g201",
  "qcd3g202",
  "qcd3g203",
  "qcd3g204",
  "qcd3g205",
  "qcd3g206",
  "qcd3g207",
  "qcd3g230",
  "qcd3g231",
  "qcd3g232",
  "qcd3g233",
  "qcd3g234",
  "qcd3g235",
  "qcd3g236",
  "qcd3g237",
  "qcd3g240",
  "qcd3g241",
  "qcd3g242",
  "qcd3g243",
  "qcd3g244",
  "qcd3g245",
  "qcd3g246",
  "qcd3g247",
  "qcd3g270",
  "qcd3g271",
  "qcd3g272",
  "qcd3g273",
  "qcd3g274",
  "qcd3g275",
  "qcd3g276",
  "qcd3g277",
  "qcd3g210",
  "qcd3g217",
  "qcd3g220",
  "qcd3g227",
  "qcd3g250",
  "qcd3g257",
  "qcd3g260",
  "qcd3g267",
  "qcd3g300",
  "qcd3g301",
  "qcd3g302",
  "qcd3g303",
  "qcd3g304",
  "qcd3g305",
  "qcd3g306",
  "qcd3g307",
  "qcd3g330",
  "qcd3g331",
  "qcd3g332",
  "qcd3g333",
  "qcd3g334",
  "qcd3g335",
  "qcd3g336",
  "qcd3g337",
  "qcd3g340",
  "qcd3g341",
  "qcd3g342",
  "qcd3g343",
  "qcd3g344",
  "qcd3g345",
  "qcd3g346",
  "qcd3g347",
  "qcd3g370",
  "qcd3g371",
  "qcd3g372",
  "qcd3g373",
  "qcd3g374",
  "qcd3g375",
  "qcd3g376",
  "qcd3g377",
  "qcd3g310",
  "qcd3g317",
  "qcd3g320",
  "qcd3g327",
  "qcd3g350",
  "qcd3g357",
  "qcd3g360",
  "qcd3g367",
};
static int default_num_e5hosts = 160;


/**
 * Host property: whether this host uses eth5 or not
 */
typedef struct host_prop_
{
  /* Host name                                                         */
  char* hostname;

  /* whether it has eth5 active or not                                 */
  int   e5_active;

}host_prop_t;

/**
 * Options used in the program
 */
typedef struct link_prog_args_
{
  /* Number of hosts to contact to get all information                */
  int num;
  host_prop_t* hosts;

  /* Verbose mode or not                                               */
  int verbose;

}link_prog_args_t;
  

/**
 * Print out useful information about this program
 */
static void 
usage (char* prog)
{
  fprintf (stderr, "Usage: %s [-f hostfile] [-f5 h5file] [-h] [-v].\n", prog);
  fprintf (stderr, "-h: print out this help information.\n");
  fprintf (stderr, "-v: put out all information.\n");
  fprintf (stderr, "-f hostfile: hostfile contains host names to check eth0 eth1 eth2 eth3 eth4 eth6 eth7.\n");
  fprintf (stderr, "-f5 h5file:  h5file contains hosts that have eth5 active.\n");
}

/**
 * parse user supplied options. If options are invalid, this program
 * will exit
 */
static void 
parse_options (int argc, char** argv, link_prog_args_t* pargs)
{
  int i, k, num_hosts, num_e5hosts;
  char* hostfname;
  char* e5fname;
  FILE *hfd, *e5fd;
  char all_hosts[MAX_NUM_HOSTS][MAX_HOST_LEN], all_e5hosts[MAX_NUM_HOSTS][MAX_HOST_LEN];
  char thost[MAX_HOST_LEN];

  pargs->verbose = 0;
  hostfname = e5fname = 0;
  i = 1;
  while (i < argc) {
    if (strcasecmp (argv[i], "-h") == 0) {
      usage (argv[0]);
      exit (0);
    }
    if (strcasecmp (argv[i], "-v") == 0) {
      pargs->verbose = 1;
    }
    else if (strcasecmp (argv[i], "-f") == 0) {
      i++;
      if (i >= argc) {
	usage (argv[0]);
	fprintf (stderr, "-f option requires a file name.\n");
	exit (0);
      }
      hostfname = argv[i];
    }
    else if (strcasecmp (argv[i], "-f5") == 0) {
      i++;
      if (i >= argc) {
	usage (argv[0]);
	fprintf (stderr, "-f5 option requires a file name.\n");
	exit (0);
      }
      e5fname = argv[i];
    }
    i++;
  }

  if (hostfname) {
    hfd = fopen (hostfname, "r");
    if (!hfd) {
      fprintf (stderr, "Cannot open host file %s.\n", hostfname);
      exit (1);
    }
    num_hosts = 0;
    while (!feof (hfd)) {
      if (fscanf (hfd, "%s", thost) >= 1) {
	if (num_hosts >= MAX_NUM_HOSTS) {
	  fprintf (stderr, "Error: number of hosts %d is exceeding allowed %d limites.\n", num_hosts, MAX_NUM_HOSTS);
	  exit (1);
	}
	strncpy (all_hosts[num_hosts++], thost, MAX_HOST_LEN - 1);
      }
    }
    fclose (hfd);
  }
  else {
    num_hosts = default_num_hosts;

    for (i = 0; i < num_hosts; i++) 
      strncpy (all_hosts[i], default_all_hosts[i],  MAX_HOST_LEN - 1);
  }

  if (e5fname) {
    e5fd = fopen (e5fname, "r");
    if (!e5fd) {
      fprintf (stderr, "Cannot open file %s.\n", e5fname);
      exit (1);
    }
    num_e5hosts = 0;
    while (!feof (e5fd)) {
      if (fscanf (e5fd, "%s", thost) >= 1) {
	if (num_e5hosts >= MAX_NUM_HOSTS) {
	  fprintf (stderr, "Error: number of hosts %d is exceeding allowed %d limites.\n", num_e5hosts, MAX_NUM_HOSTS);
	  exit (1);
	}
	strncpy (all_e5hosts[num_e5hosts++], thost, MAX_HOST_LEN - 1);
      }
    }
    fclose (e5fd);	  
  }
  else {
    num_e5hosts = default_num_e5hosts;
    for (i = 0; i < num_e5hosts; i++) 
      strncpy (all_e5hosts[i], default_all_e5hosts[i], MAX_HOST_LEN - 1);
  }

  /* Now set host properties */
  pargs->num = num_hosts;
  pargs->hosts = (host_prop_t *)malloc(num_hosts * sizeof (host_prop_t));
  if (!pargs->hosts) {
    fprintf (stderr, "Cannot create memory for all host properties.\n");
    exit (1);
  }

  /* Initialize the values of data */
  for (i = 0; i < num_hosts; i++) {
    pargs->hosts[i].e5_active = 0;
    pargs->hosts[i].hostname = (char *)malloc((strlen (all_hosts[i]) + 1) * sizeof (char));
    if (!pargs->hosts[i].hostname) {
      fprintf (stderr, "Cannot allocate memory for hostname.\n");
      exit (1);
    }
    strcpy (pargs->hosts[i].hostname, all_hosts[i]);

    /* Find out whether this name also appears in the e5hosts list */
    for (k = 0; k < num_e5hosts; k++) {
      if (strcmp (all_hosts[i], all_e5hosts[k]) == 0) {
	pargs->hosts[i].e5_active = 1;
	break;
      }
    }
  }

  if (pargs->verbose) {
    fprintf (stderr, "Number of hosts = %d.\n", pargs->num);
    for (i = 0; i < pargs->num; i++) {
      fprintf (stderr, "hosts[%d] = %s e5 active = %d.\n", i, pargs->hosts[i].hostname, pargs->hosts[i].e5_active);
    }
  }
}

/**
 * Location of ethernet information 
 */
#define PROC_DIR "/proc/net/PRO_LAN_Adapters"

static char* eth_devices[]={
  "eth0", 
  "eth1", 
  "eth2", 
  "eth3", 
  "eth6", 
  "eth7"
};
static int   num_eth_devices = 6;

static char* eth5_devices[] = {
  "eth0", 
  "eth1", 
  "eth2", 
  "eth3", 
  "eth5", 
  "eth6", 
  "eth7"
};
static int   num_eth5_devices = 7;

int
main (int argc, char** argv)
{
  int i, k, l;
  char fullcomd[1024], scomd[128];
  char state[7][32], speed[7][32];
  int  fds[2];
  FILE* rfd;
  link_prog_args_t args;

  parse_options (argc, argv, &args);

  /* Create a pipe */
  pipe (fds);

  /* attach regular stream to fds[0] */
  rfd = fdopen (fds[0], "r");
  if (!rfd) {
    fprintf (stderr, "Cannot attach stream reader.\n");
    exit (1);
  }

  /* Close output */
  close (1);

  /* attach fds[1] to output */
  dup (fds[1]);
  for (i = 0; i < args.num; i++) {
    if (args.hosts[i].e5_active) {
      k = 0;
      sprintf (fullcomd, "rsh %s cat %s/%s/State %s/%s/Speed ", 
	       args.hosts[i].hostname, PROC_DIR, eth5_devices[k],
	       PROC_DIR, eth5_devices[k]);
      for (k = 1; k < num_eth5_devices; k++) {
	sprintf (scomd, " %s/%s/State %s/%s/Speed ", 
		 PROC_DIR, eth5_devices[k],
		 PROC_DIR, eth5_devices[k]);
	strcat (fullcomd, scomd);
      }

      if (system (fullcomd) != 0)
	break;

      fscanf (rfd, "%s %s %s %s %s %s %s %s %s %s %s %s %s %s", 
	      state[0], speed[0],
	      state[1], speed[1],
	      state[2], speed[2],
	      state[3], speed[3],
	      state[4], speed[4],
	      state[5], speed[5],
	      state[6], speed[6]
	      );

      for (k = 0; k < num_eth5_devices; k++) {
	if (strcmp (state[k], "up") != 0 || 
	    strcmp (speed[k], "1000") != 0 ||
	    args.verbose)
	  fprintf (stderr, "\n%s %s: state = %s speed = %s\n", 
		   args.hosts[i].hostname,eth5_devices[k],
		   state[k], speed[k]);
      }
    }
    else {
      k = 0;
      sprintf (fullcomd, "rsh %s cat %s/%s/State %s/%s/Speed ", 
	       args.hosts[i].hostname, PROC_DIR, eth_devices[k],
	       PROC_DIR, eth_devices[k]);
      for (k = 1; k < num_eth_devices; k++) {
	sprintf (scomd, " %s/%s/State %s/%s/Speed ", 
		 PROC_DIR, eth_devices[k],
		 PROC_DIR, eth_devices[k]);
	strcat (fullcomd, scomd);
      }

      if (system (fullcomd) != 0)
	break;
	
      fscanf (rfd, "%s %s %s %s %s %s %s %s %s %s %s %s", 
	      state[0], speed[0],
	      state[1], speed[1],
	      state[2], speed[2],
	      state[3], speed[3],
	      state[4], speed[4],
	      state[5], speed[5]
	      );

      for (k = 0; k < num_eth_devices; k++) {
	if (strcmp (state[k], "up") != 0 || 
	    strcmp (speed[k], "1000") != 0 ||
	    args.verbose)
	  fprintf (stderr, "\n%s %s: state = %s speed = %s\n", 
		   args.hosts[i].hostname,eth5_devices[k],
		   state[k], speed[k]);
      }
    }
    if (!args.verbose)
      fprintf (stderr, ".");

  }
  if (!args.verbose)
    fprintf (stderr, "\n");

  fclose (rfd);

  /* Free memory */
  for (i = 0; i < args.num; i++) 
    free (args.hosts[i].hostname);

  free (args.hosts);

  return 0;
}


