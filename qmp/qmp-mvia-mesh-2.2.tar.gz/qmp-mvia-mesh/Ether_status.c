/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Quick Ethernet Link Test for a mesh based cluster.
 *
 *      This test is based on ethtool utility
 *
 * Author:  
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: Ether_status.c,v $
 *   Revision 1.1  2004/11/22 18:48:19  chen
 *   Add 4g cluster Ethernet status test code
 *
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>

#define MAX_NUM_HOSTS 1024
#define MAX_HOST_LEN  128

#define END_COMD "uname"
#define END_COMD_OUTPUT "Linux"


/**
 * The following hosts are the 4g cluster at jefferson lab hpc group
 */
#define DIMS 3

static int dimsizes[]={6,8,8};

/**
 * Host property: whether this host uses eth5 or not
 */
typedef struct host_prop_
{
  /* Host name                                                         */
  char* hostname;

}host_prop_t;



/**
 * Options used in the program
 */
typedef struct link_prog_args_
{
  /* Number of hosts to contact to get all information                */
  int num;
  host_prop_t* hosts;

  /* Verbose mode or not                                               */
  int verbose;

}link_prog_args_t;
  

/**
 * Print out useful information about this program
 */
static void 
usage (char* prog)
{
  fprintf (stderr, "Usage: %s [-f hostfile] [-h] [-v].\n", prog);
  fprintf (stderr, "-h: print out this help information.\n");
  fprintf (stderr, "-v: put out all information.\n");
  fprintf (stderr, "-f hostfile: hostfile contains host names to check eth1 eth2 eth3 eth4 eth5 eth6 eth7.\n");
}

/**
 * parse user supplied options. If options are invalid, this program
 * will exit
 */
static void 
parse_options (int argc, char** argv, link_prog_args_t* pargs)
{
  int i, j, k, m, num_hosts;
  char* hostfname;
  FILE *hfd;
  char all_hosts[MAX_NUM_HOSTS][MAX_HOST_LEN];
  char thost[MAX_HOST_LEN];

  hostfname = 0;
  pargs->verbose = 0;
  i = 1;
  while (i < argc) {
    if (strcasecmp (argv[i], "-h") == 0) {
      usage (argv[0]);
      exit (0);
    }
    if (strcasecmp (argv[i], "-v") == 0) {
      pargs->verbose = 1;
    }
    else if (strcasecmp (argv[i], "-f") == 0) {
      i++;
      if (i >= argc) {
	usage (argv[0]);
	fprintf (stderr, "-f option requires a file name.\n");
	exit (0);
      }
      hostfname = argv[i];
    }
    i++;
  }

  if (hostfname) {
    /* Hostname is provided */
    hfd = fopen (hostfname, "r");
    if (!hfd) {
      fprintf (stderr, "Cannot open host file %s.\n", hostfname);
      exit (1);
    }
    num_hosts = 0;
    while (!feof (hfd)) {
      if (fscanf (hfd, "%s", thost) >= 1) {
	if (num_hosts >= MAX_NUM_HOSTS) {
	  fprintf (stderr, "Error: number of hosts %d is exceeding allowed %d limites.\n", num_hosts, MAX_NUM_HOSTS);
	  exit (1);
	}
	strncpy (all_hosts[num_hosts++], thost, MAX_HOST_LEN - 1);
      }
    }
    fclose (hfd);
  }
  else {
    /* No hostname file provided, use default */
    num_hosts = 1;
    for (i = 0; i < DIMS; i++)
      num_hosts = num_hosts * dimsizes[i];

    m = 0;
    for (i = 0; i < dimsizes[0]; i++) {
      for (j = 0; j < dimsizes[1]; j++) {
	for (k = 0; k < dimsizes[2]; k++) {
	  sprintf (thost, "qcd4g%d%d%d", i, j, k);

	  strncpy (all_hosts[m++], thost,  MAX_HOST_LEN - 1);
	}
      }
    }
  }

  /* Now set host properties */
  pargs->num = num_hosts;
  pargs->hosts = (host_prop_t *)malloc(num_hosts * sizeof (host_prop_t));
  if (!pargs->hosts) {
    fprintf (stderr, "Cannot create memory for all host properties.\n");
    exit (1);
  }

  /* Initialize the values of data */
  for (i = 0; i < num_hosts; i++) {
    pargs->hosts[i].hostname = (char *)malloc((strlen (all_hosts[i]) + 1) * sizeof (char));
    if (!pargs->hosts[i].hostname) {
      fprintf (stderr, "Cannot allocate memory for hostname.\n");
      exit (1);
    }
    strcpy (pargs->hosts[i].hostname, all_hosts[i]);
  }

  if (pargs->verbose) {
    fprintf (stderr, "Number of hosts = %d.\n", pargs->num);
    for (i = 0; i < pargs->num; i++) 
      fprintf (stderr, "hosts[%d] = %s \n", i, pargs->hosts[i].hostname);
  }
}

static char* eth_devices[]={
  "eth1", 
  "eth2", 
  "eth3", 
  "eth4",
  "eth5",
  "eth6", 
  "eth7",
};
static int   num_eth_devices = 7;

int
main (int argc, char** argv)
{
  int i, k, l, n, ok;
  char fullcomd[1024], scomd[128], line[80];
  char speed[7][32], *speeds;
  int  fds[2];
  FILE* rfd;
  link_prog_args_t args;
  uid_t uid;

  parse_options (argc, argv, &args);

  /* get user id */
  uid =getuid ();

  /* set to root */
  if (setuid (0) != 0) {
    fprintf (stderr, "Permission denied. \n");
    exit (1);
  }

  /* Create a pipe */
  pipe (fds);

  /* attach regular stream to fds[0] */
  rfd = fdopen (fds[0], "r");
  if (!rfd) {
    fprintf (stderr, "Cannot attach stream reader.\n");
    exit (1);
  }

  /* Close output */
  close (1);

  /* attach fds[1] to output */
  dup (fds[1]);
  for (i = 0; i < args.num; i++) {
    k = 0;
    sprintf (fullcomd, "rsh %s \"/sbin/ethtool %s | grep Speed ;", 
	     args.hosts[i].hostname, eth_devices[k]);
    for (k = 1; k < num_eth_devices; k++) {
      sprintf (scomd, " /sbin/ethtool %s | grep Speed;" ,
	       eth_devices[k]);
      strcat (fullcomd, scomd);
    }
    strcpy (scomd, END_COMD);
    strcat (fullcomd, scomd);
    strcat (fullcomd, "\" ");

    if (args.verbose) 
      fprintf (stderr, "%s  \n", fullcomd);

    if (system (fullcomd) != 0)
      break;

#if 0
    k = 0;
    while (fgets (line, sizeof(line), rfd)) {
      fprintf (stderr, "line = %s \n");
      if ((speeds = strstr(line, "Speed:")) )
	sscanf (speeds, "Speed: %s", speed[k++]);
    }

    for (k = 0; k <  num_eth_devices; k++) 
      fprintf (stderr, "%s speed = %s\n", eth_devices[k], speed[k]);
#endif
    l = 0;
    k = 0;
    while ((n = fgetc (rfd)) != EOF) {
      line[l++] = n;
      if (n == '\n') {
	line[l-1] = '\0';
	l = 0;
	if ((speeds = strstr(line, "Speed:")))
	  sscanf (speeds, "Speed: %s", speed[k++]);
	else if (strstr(line, END_COMD_OUTPUT))
	  break;
      }
    }

    ok = 1;
    for (k = 0; k <  num_eth_devices; k++) {
      if (strcmp (speed[k], "1000Mb/s") != 0) {
	fprintf (stderr, "Host %s %s speed = %s\n", 
		 args.hosts[i].hostname, eth_devices[k], speed[k]);
	ok = 0;
      }
    }

    if (ok)
      fprintf (stderr, ".");
  }
  if (!args.verbose)
    fprintf (stderr, "\n");

  fclose (rfd);

  /* Free memory */
  for (i = 0; i < args.num; i++) 
    free (args.hosts[i].hostname);

  free (args.hosts);

  /* set uid back */
  setuid (uid);

  return 0;
}


