/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Gigebit ethernet port handling code
 *      
 *
 * Author:  
 *      Jie Chen, Chip Watson and Robert Edwards
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_comm_mvia_mesh.c,v $
 *   Revision 1.17  2004/10/14 13:42:10  chen
 *   Fix QMP_xor problem
 *
 *   Revision 1.16  2004/10/08 19:59:29  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.15  2004/10/04 13:36:41  chen
 *   fix a bug on switched send/receive
 *
 *   Revision 1.14  2004/09/23 14:11:27  chen
 *   Fix a switch port send bug and add support for MPI port
 *
 *   Revision 1.13  2004/09/01 19:25:41  chen
 *   Add some MPI required routines
 *
 *   Revision 1.12  2004/04/22 19:37:22  chen
 *   Change scatter and gather implementation
 *
 *   Revision 1.11  2004/04/08 15:30:57  chen
 *   First implementation of double shift global sum
 *
 *   Revision 1.10  2004/03/20 02:55:06  edwards
 *   Added status tests within qmp_process_vi_{send,recv}_i .
 *
 *   Revision 1.9  2004/03/03 15:23:02  chen
 *   Remove any block waiting call in QMP_poll
 *
 *   Revision 1.8  2004/02/25 16:48:45  chen
 *   Change debug information
 *
 *   Revision 1.7  2004/02/19 19:21:49  chen
 *   Add more debug info for RDMA
 *
 *   Revision 1.6  2004/02/19 15:22:02  chen
 *   Use static buffer inside QMP_route
 *
 *   Revision 1.5  2003/12/15 18:53:10  chen
 *   Add QMP_free and correct regmem refcount
 *
 *   Revision 1.4  2003/12/12 20:12:58  chen
 *   Add global routing, scatter, gather
 *
 *   Revision 1.3  2003/12/05 18:45:55  chen
 *   Add more CQ entries to switched VIA connection
 *
 *   Revision 1.2  2003/12/01 16:53:08  chen
 *   Fixed a minor bug for local loopback devices
 *
 *   Revision 1.1.1.1  2003/11/18 18:55:36  chen
 *   First CVS QMP_mvia_gigeD_mesh
 *
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "qmp.h"
#include "QMP_P_MVIA_MESH.h"

/**
 * The following is the spin loop for 1 micro second for a pentium 4
 * Xeon 2.66 GHZ machine.
 * This code number 1000 has to be modified for different processors.
 *  "movl $1000, %ecx\n\t"   \
 */
#define QMP_SPIN_LOOPS {             \
    __asm__("pushl %eax\n\t"         \
            "pushl %ecx\n\t"         \
            "movl $1000, %ecx\n\t"   \
            "movl $0, %eax\n"        \
            ".QMP_ASM_LOOP:\n\t"     \
            "cmpl %eax,%ecx\n\t"     \
            "je .QMP_ASM_LOOP_END\n\t"\
            "incl %eax\n\t"          \
            "jmp .QMP_ASM_LOOP\n"    \
            ".QMP_ASM_LOOP_END:\n\t" \
            "popl %ecx\n\t"          \
            "popl %eax\n\t");        \
}


#define QMP_PORT_SPIN_LOOPS {        \
    __asm__("pushl %eax\n\t"         \
            "pushl %ecx\n\t"         \
            "movl $1000, %ecx\n\t"   \
            "movl $0, %eax\n"        \
            ".QMP_PORT_ASM_LOOP:\n\t"\
            "cmpl %eax,%ecx\n\t"     \
            "je .QMP_PORT_ASM_LOOP_END\n\t"\
            "incl %eax\n\t"          \
            "jmp .QMP_PORT_ASM_LOOP\n"    \
            ".QMP_PORT_ASM_LOOP_END:\n\t" \
            "popl %ecx\n\t"          \
            "popl %eax\n\t");        \
}

#if 0
int 
main (int argc, char** argv)
{
  struct timeval it, ft, gt;
  register int i, nloops;
  double loops_per_sec;

  if (argc < 2) {
    fprintf (stderr, "usage: %s numloops\n", argv[0]);
    exit (1);
  }

  nloops = atoi (argv[1]);
  gettimeofday (&it, 0);
  for (i = 0; i < nloops; i++)
    QMP_SPIN_LOOPS;

  gettimeofday (&ft, 0);

  printf ("Running %d number of loops\n", nloops);
  loops_per_sec = (double)nloops/(double)(ft.tv_sec - it.tv_sec);
  
  printf ("loops_per_sec is %lf\n", loops_per_sec);
}
#endif

/**
 * Global table of data sizes for different QMP data types.
 */
QMP_u32_t QMP_data_size_table[] = {1, 1, 1, 2, 2, 4, 4, 8, 8, 4, 8};

/**
 * String name for gige connection type.
 */
static char* qmp_gige_conn_type_strings[] = {"Direct", "Switch"};

/**
 * Static protocol string names for debug purpose
 */
static char* qmp_protocol_names[]={"Immediate", "Query", "Query Reply",
				   "RDMA put", "RDMA put reply", 
				   "RDMA PUT Finish", "NOOP"};


/**
 * Error handler for underlying VIA device
 */
static void
qmp_via_error_handler_i (void* context,
			 VIP_ERROR_DESCRIPTOR* err_desc)
{
  QMP_gige_port_t* port;

  QMP_TRACE ("qmp_via_error_handler_i");

  port = (QMP_gige_port_t *)context;

  port->err_code = err_desc->ErrorCode + VIP_ERRCBK_CODE_OFFSET;

  if (err_desc->ErrorCode == VIP_ERROR_CONN_LOST ||
      err_desc->ErrorCode == VIP_ERROR_CATASTROPHIC) {
    QMP_error ("VIA device %s lost connection to peer %s on host %s\n",
	       port->eth_device, port->peer_via_host,
	       port->peer->host);
    port->active = QMP_FALSE;
    exit (1);
  }
}

/**
 * Initialize a gigbit ethernet port
 * @param gige a pointer to a gigbit ethernet port
 */
void
QMP_init_gige_port (QMP_gige_port_t* gige)
{
  QMP_TRACE("QMP_init_gige_port");

  gige->type = QMP_CONN_DIRECT;
  gige->eth_device[0] = '\0';
  gige->direction = QMP_DIR_UNKNOWN;
  gige->axis = QMP_X;
  gige->peer_via_host[0] = '\0';
  
  /* set peer to unkonwn */
  gige->peer = 0;

  gige->active = QMP_FALSE;
  gige->err_code = QMP_SUCCESS;
  gige->phys = 0;

  gige->viadev = 0;
  gige->viadev_owner = QMP_FALSE;
  gige->conn = 0;
}

/**
 * Print out information for a gigabit ethernet port.
 *
 * @param port a pointer to a gigabit ethernet port.
 */
void
QMP_print_port_info (QMP_gige_port_t* port)
{
  int i;

  QMP_TRACE ("QMP_print_port_info");

  QMP_fprintf (stderr, "%s port use device %s connect to via host %s\n",
	       qmp_gige_conn_type_strings[port->type],
	       port->eth_device, port->peer_via_host);

  QMP_fprintf (stderr, "Axis %d dir %d\n",
	       port->axis, port->direction);
  if (port->peer) {
    QMP_fprintf (stderr, "Peer looks like: rank %d host %s coordinate [ ",
		 port->peer->rank, port->peer->host);
  
    for (i = 0; i < port->phys->dimension; i++)
      fprintf (stderr, "%d ", port->peer->coordinates[i]);
    fprintf (stderr, "]\n");
  }
  else {
    QMP_fprintf (stderr, "No peer information yet.\n");
  }
}


/**
 * Set up gigbit ethernet port from a single line
 *
 * @param line a char string containing gigebit port information
 * @phys  physical geometry pointer
 * @return QMP_SUCCESS if everything is ok.
 */
QMP_status_t
QMP_setup_gige_port (char* line, QMP_phys_geometry_t* phys,
		     QMP_rtenv_t* rt)
{
  QMP_gige_port_t* port;
  int direction, axis, i;
  char name[QMP_HOSTNAME_LEN];
  char ethd[QMP_ETHDEV_NAME_LEN];

  QMP_TRACE ("QMP_setup_gige_port");
  
  if (sscanf (line,"%s %s %d %d", ethd, name ,&direction, &axis) >= 4 && 
      axis >= QMP_X && axis <= QMP_T) {
    if (direction == -1|| direction == 1) {
      port = &(phys->ports[axis][(direction + 1)/2]);
      strncpy (port->eth_device, ethd, QMP_ETHDEV_NAME_LEN - 1);
      strncpy (port->peer_via_host, name, QMP_HOSTNAME_LEN - 1);
      port->direction = (direction + 1)/2;
      port->axis = axis;
      port->phys = phys;
      port->type = QMP_CONN_DIRECT;
    }
    else {
      QMP_fprintf (stderr, "Direction specification error.\n");
      return QMP_RTENV_ERR;
    }
  }
  else if (sscanf (line, "%s", ethd) >= 1) {
    for (i = 0; i < QMP_PHYS_NUMNODES(phys); i++) {
      port = &phys->switch_ports[i];
      port->phys = phys;
      port->type = QMP_CONN_SWITCH;
      strncpy (port->eth_device, ethd, QMP_ETHDEV_NAME_LEN - 1);
    }
  }
  else {
    QMP_fprintf (stderr, "Configuration syntax error for ports \n");
    return QMP_RTENV_ERR;
  }
  return QMP_SUCCESS;
}


/**
 * Update neighboring information for a physical geometry
 *
 * @param phys physical geometry information of this node.
 * @param rtenv total runtime envrionment of this job
 * @param num   number of runtime enviornment entries.
 *
 * @return QMP_SUCCESS if everything is ok
 */
QMP_status_t
QMP_update_port_peer_info (QMP_machine_t* glm,
			   QMP_phys_geometry_t* phys,
			   QMP_rtenv_t* rtenv, QMP_u32_t num)
{
  int i, j, k, m, type, ok0, ok1;
  QMP_u32_t nbp[QMP_PHYS_NMD], nbm[QMP_PHYS_NMD];
  QMP_u32_t *dsize;
  QMP_gige_port_t *portp, *portm, *port;

  QMP_TRACE ("QMP_update_neighbor_info");

  /* get dimension size                             */
  dsize = QMP_PHYS_DIMSIZE(phys);

  for (i = 0; i < QMP_PHYS_DIMENSION(phys); i++) {
    /* minus direction first                        */
    portm = &(phys->ports[i][0]);

    /* check positive direction of this axis        */
    portp = &(phys->ports[i][1]);

    /* find neighboring coordinates for this axis in both directiion */
    for (k = 0; k < QMP_PHYS_DIMENSION(phys); k++) {
      nbp[k] = QMP_PHYS_COORDINATES(phys)[k];
      nbm[k] = QMP_PHYS_COORDINATES(phys)[k];
    }
    
    /* First for positive direction      */
    nbp[i] = (nbp[i] + 1) % dsize[i];
    nbm[i] = nbm[i] == 0 ? dsize[i] - 1 : nbm[i] - 1;


    type = 0;
    for (m = 0; m < num; m++) {
      /* postive direction */
      if (QMP_coordinates_equal(nbp, 
				QMP_NODE_COORDINATES(rtenv->all_nodes[m]),
				QMP_PHYS_DIMENSION(phys))) {
	portp->peer = &rtenv->all_nodes[m];
	type++;
      }
      /* minus direction   */
      if (QMP_coordinates_equal(nbm, 
				QMP_NODE_COORDINATES(rtenv->all_nodes[m]),
				QMP_PHYS_DIMENSION(phys))) {
	portm->peer = &rtenv->all_nodes[m];
	type++;
      }
    }
    if (type < 2) {
      QMP_error ("Could not get neighboring information.\n");
      return QMP_RTENV_ERR;
    }
  }

  for (i = 0; i < QMP_PHYS_NUMNODES(phys); i++) {
    port = &phys->switch_ports[i];
    port->phys = phys;
    /* 
     * Find out which node has the same rank as index i
     * the runtime environment
     */
    ok0 = ok1 = 0;
    for (j = 0; j < QMP_PHYS_NUMNODES(phys); j++) {
      if (rtenv->all_nodes[j].rank == i) {
	port->peer = &rtenv->all_nodes[j];
	for (k = 0; k < QMP_PHYS_NUMNODES(phys); k++) {
	  if (strcmp (rtenv->switched_table[k].host,
		      rtenv->all_nodes[j].host) == 0) {
	    strncpy (port->peer_via_host, rtenv->switched_table[k].via_host, 
		     QMP_HOSTNAME_LEN - 1);
	    ok1 = 1;
	    break;
	  }
	}
	ok0 = 1;
	break;
      }
    }
    if ((ok0 & ok1) == 0)
      return QMP_ERROR;
  }

  return QMP_SUCCESS;
}

/**
 * Prepost receiving descriptors or buffers
 */
static QMP_status_t
qmp_prepost_recv_buffers_i (QMP_gige_port_t* port,
			    QMP_qbuf_manager_t* manager)
{
  QMP_qbuf_t* qbuf;
  VIP_RETURN status;

  QMP_TRACE ("qmp_prepost_recv_buffers_i");

  while ((qbuf = QMP_get_qbuf (manager))) {
    QMP_set_qbuf_sendrecv_ready (qbuf, QMP_QBUF_SIZE);
    if ((status = VipPostRecv(port->conn->vi_handle, (VIP_DESCRIPTOR *)qbuf,
			      qbuf->manager->mem_handle)) != VIP_SUCCESS) {
      QMP_error ("%s: cannot prepost receiving buffers. \n", port->eth_device);
      return status;
    }
  }
  
  return QMP_SUCCESS;
}

/**
 * Create a new QMP_viadev_handle object
 */
static QMP_viadev_handle_t*
qmp_create_viadev_handle_i (char* eth_device)
{
  QMP_viadev_handle_t* h;

  QMP_TRACE("qmp_create_viadev_handle_i");

  h = (QMP_viadev_handle_t *)malloc(sizeof (QMP_viadev_handle_t));
  if (!h) {
    QMP_error ("cannot allocate space to QMP_viadev_handle_t. \n");
    return 0;
  }
  strncpy (h->eth_device, eth_device, QMP_ETHDEV_NAME_LEN - 1);
  h->nic_handle = 0;
  h->count = 0;

  return h;
}

static QMP_viadev_handle_t*
qmp_find_viadev_handle_i (QMP_machine_t* glm, char* eth_device)
{
  int i;
  QMP_gige_port_t *port;

  QMP_TRACE ("qmp_find_viadev_handle_i");

  for (i = 0; i < glm->phys->dimension; i++) {
    /* minus direction */
    port = &glm->phys->ports[i][0];

    if (port->viadev && 
	strcmp (port->viadev->eth_device, eth_device) == 0 &&
	port->viadev->nic_handle)
      return port->viadev;

    /* plus direction */
    port = &glm->phys->ports[i][1];
    if (port->viadev && 
	strcmp (port->viadev->eth_device, eth_device) == 0 &&
	port->viadev->nic_handle)
      return port->viadev;
  }
  return 0;
}


static QMP_status_t
qmp_open_viadev_handle_i (QMP_machine_t* glm,
			  QMP_gige_port_t* port, QMP_viadev_handle_t *h)
{
  QMP_status_t status;
  QMP_u32_t    numcq_entries;

  QMP_TRACE("qmp_open_viadev_handle_i");

  if (!h->nic_handle) {
    status = VipOpenNic (h->eth_device, &h->nic_handle);
    if (status == VIP_SUCCESS) {
      if (QMP_rt_verbose) 
	QMP_info ("open via nic device %s ...success 0x%x.\n", 
		  h->eth_device, h->nic_handle);
      /**
       * Doing a name service query
       */
      if ((status = VipNSInit (h->nic_handle, NULL)) != VIP_SUCCESS) {
	QMP_error ("%s: VipNSInit failed: %s.\n", port->eth_device,
		   QMP_error_string(status));
	h->nic_handle = 0;
	return status;
      }

      if ((status = VipQueryNic(h->nic_handle, &h->nic_attrs))!= VIP_SUCCESS){
	QMP_error ("%s: VipQueryNic failed.\n", port->eth_device);
	h->nic_handle = 0;
	return status;
      }

      if((status = VipCreatePtag(h->nic_handle, 
				 &h->ptag)) != VIP_SUCCESS) {
	QMP_error ("%s: VipCreatePtag failed.\n", port->eth_device);
	h->nic_handle = 0;
	return status;
      }

      /**
       * Create Completion queue for this NIC
       */
      if (port->type == QMP_CONN_DIRECT)
	numcq_entries = QMP_MIN_VAL(QMP_CQ_NUM_ENTRIES,
				    h->nic_attrs.MaxCQEntries);
      else
	numcq_entries = QMP_MIN_VAL(QMP_CQ_SWITCH_NUM_ENTRIES,
				    h->nic_attrs.MaxCQEntries);
	
      if ((status = VipCreateCQ (h->nic_handle,
				 numcq_entries,
				 &h->cq)) != VIP_SUCCESS) {
	QMP_error ("%s: VipCreateCQ failed. \n", port->eth_device);
	h->nic_handle = 0;
	return status;
      }
      else {
	/* add this queue to the table if this port is not a switched type */
	/* Switched type will be added when the switched port is used */
	if (port->type == QMP_CONN_DIRECT)
	  QMP_add_viacq (glm, h->cq);
	
	if (QMP_rt_verbose) 
	  QMP_info ("%s: Create a completion queue with %d entry slots.\n",
		    port->eth_device, 
		    numcq_entries);
      }
      h->count++;

      /**
       * Now register a error callback to this port
       */
      if (VipErrorCallback (h->nic_handle, (void *)port, qmp_via_error_handler_i) !=
	  VIP_SUCCESS)
	QMP_info ("cannot register via error callback handler for device %s.\n",
		  h->eth_device);
    }
    else
      h->nic_handle = 0;
  }
  else {
    status = QMP_SUCCESS;
    h->count++;
  }

  return status;
}

static QMP_status_t
qmp_close_viadev_handle_i (QMP_machine_t* glm,
			   QMP_viadev_handle_t *h)
{
  QMP_status_t status;

  QMP_TRACE("qmp_close_viadev_handle_i");

  status = QMP_SUCCESS;
  h->count--;
  if (h->count == 0) {
    if (QMP_rt_verbose) 
      QMP_info ("close via nic device %s \n", h->eth_device);

    /* Deregister memories */
    QMP_regmem_table_clean (h);

    /* Remove error handler by providing NULL context pointer */
    VipErrorCallback(h->nic_handle, NULL, qmp_via_error_handler_i);

    /* Destroy PTAG */
    VipDestroyPtag(h->nic_handle, h->ptag);

    /* Destroy the completion queue */
    VipDestroyCQ (h->cq);

    /* Remove from the list */
    QMP_remove_viacq (glm, h->cq);

    /* Close NIC */
    status = VipCloseNic (h->nic_handle);
    free (h);
  }
  
  return QMP_SUCCESS;
}
  


/**
 * Initialize VIA NIC handler for our machine
 */
QMP_status_t
QMP_open_viadev (QMP_machine_t* glm)
{
  int i;
  QMP_gige_port_t* port;
  VIP_RETURN       status;
  QMP_viadev_handle_t* viah;

  QMP_TRACE ("QMP_viadev_init");

  /* Open VIA Nic Handle for neighbors */
  for (i = 0; i < glm->phys->dimension; i++) {
    /* minus direction */
    port = &glm->phys->ports[i][0];

    /* Find out whether there is an existing VIA device */
    viah = qmp_find_viadev_handle_i (glm, port->eth_device);

    if (!viah) {
      viah = qmp_create_viadev_handle_i (port->eth_device);
      if (!viah) 
	return QMP_NOMEM_ERR;
      /* Create free list and initialize registered memory table */
      QMP_regmem_table_init (glm, viah, &(viah->regmem_table));
      /* Set this port as the owner of this device */
      port->viadev_owner = QMP_TRUE;
    }

    status = qmp_open_viadev_handle_i (glm, port, viah);
    if (status != QMP_SUCCESS) {
      QMP_error ("cannot open via device %s.\n", viah->eth_device);
      return status;
    }
    port->viadev = viah;

    
    /* positive direction */
    port = &glm->phys->ports[i][1];

    /* Find out whether there is an existing VIA device */
    viah = qmp_find_viadev_handle_i (glm, port->eth_device);

    if (!viah) {
      viah = qmp_create_viadev_handle_i (port->eth_device);
      if (!viah) 
	return QMP_NOMEM_ERR;

      /* Create free list and initialize registered memory table */
      QMP_regmem_table_init (glm, viah, &(viah->regmem_table));

      /* Set this port as the owner of this device */
      port->viadev_owner = QMP_TRUE;
    }

    status = qmp_open_viadev_handle_i (glm, port, viah);
    if (status != QMP_SUCCESS) {
      QMP_error ("cannot open via device %s.\n", viah->eth_device);
      return status;
    }
    port->viadev = viah;
  }

  /* Work on switched ports which share one VIP_NIC_HANDLE */
  if (glm->phys->switch_ports) {
    port = &glm->phys->switch_ports[0];

    /* Find out whether there is an existing VIA device */
    viah = qmp_find_viadev_handle_i (glm, port->eth_device);

    if (!viah) {
      viah = qmp_create_viadev_handle_i (port->eth_device);
      if (!viah) 
	return QMP_NOMEM_ERR;

      /* Create free list and initialize registered memory table */
      QMP_regmem_table_init (glm, viah, &(viah->regmem_table));

      /* Set this port as the owner of this device */
      port->viadev_owner = QMP_TRUE;
    }

    status = qmp_open_viadev_handle_i (glm, port, viah);
    if (status != QMP_SUCCESS) {
      QMP_error ("cannot open a switched via device %s .\n", viah->eth_device);
      return status;
    }
    port->viadev = viah;
  }

  for (i = 1; i < glm->phys->num_nodes; i++) {
    port = &glm->phys->switch_ports[i];

    viah = glm->phys->switch_ports[0].viadev;
    qmp_open_viadev_handle_i (glm, port, viah);
    port->viadev = viah;
  }
  
  return QMP_SUCCESS;
}  


/**
 * Shutdown VIA devices for a ports
 */
void
QMP_close_viadev (QMP_machine_t* glm)
{
  int i;
  QMP_gige_port_t* port;

  QMP_TRACE ("QMP_close_viadev");

  /* Close VIA Nic Handle for neighbors */
  for (i = 0; i < glm->phys->dimension; i++) {
    /* minus direction */
    port = &glm->phys->ports[i][0];
    qmp_close_viadev_handle_i (glm, port->viadev);
    port->viadev = 0;
    
    /* positive direction */
    port = &glm->phys->ports[i][1];
    qmp_close_viadev_handle_i (glm, port->viadev);
    port->viadev = 0;
  }

  for (i = 0; i < glm->phys->num_nodes; i++) {
    port = &glm->phys->switch_ports[i];
    qmp_close_viadev_handle_i (glm, port->viadev);
    port->viadev = 0;
  }
}

/**
 * print out discriminator
 */
static void
qmp_print_via_conn_disc_i (QMP_via_conn_disc_t* disc, QMP_bool_t local)
{
  QMP_TRACE ("qmp_print_via_conn_disc_i");

  if (local)
    QMP_info ("Local Discriminator looks like: %d %d %d %d\n",
	      disc->local_rank, disc->remote_rank,
	      disc->axis, disc->direction);
  else
    QMP_info ("Remote Discriminator looks like: %d %d %d %d\n",
	      disc->local_rank, disc->remote_rank,
	      disc->axis, disc->direction);
}

/**
 * Create a local connection discriminator which is not used
 */
static void
qmp_set_conn_local_discriminator_i (QMP_gige_port_t* port,
				    QMP_via_conn_disc_t* disc)
{
  QMP_TRACE ("qmp_set_conn_local_discriminator_i");


  disc->local_rank = QMP_PHYS_RANK(port->phys);
  disc->remote_rank = QMP_NODEP_RANK(port->peer);
  disc->axis = port->axis;
  disc->direction = port->direction;
}

/**
 * Create a connection discriminator
 * Always use positive direction as local to remote since
 * both ends must have the same remote discriminator
 */
static void
qmp_set_conn_remote_discriminator_i (QMP_gige_port_t* port,
				     QMP_via_conn_disc_t* disc)
{
  QMP_TRACE("qmp_set_conn_remote_discriminator_i");

  if (port->direction == QMP_DIR_UNKNOWN) {
    /**
     * This is a switched port, the end with smaller rank control the local to remote
     * direction
     */
    if (QMP_PHYS_RANK(port->phys) < QMP_NODEP_RANK(port->peer)) {
      disc->local_rank = QMP_PHYS_RANK(port->phys);
      disc->remote_rank = QMP_NODEP_RANK(port->peer);
      disc->axis = QMP_U;
      disc->direction = QMP_DIR_UNKNOWN;
    }
    else {
      disc->local_rank = QMP_NODEP_RANK(port->peer);
      disc->remote_rank = QMP_PHYS_RANK(port->phys);
      disc->axis = QMP_U;
      disc->direction = QMP_DIR_UNKNOWN;
    }
  }
  else if (port->direction == 1) {
    /** 
     * This is the positive direction
     */
    disc->local_rank = QMP_PHYS_RANK(port->phys);
    disc->remote_rank = QMP_NODEP_RANK(port->peer);
    disc->axis = port->axis;
    disc->direction = port->direction;
  }
  else {
    /** 
     * This is the minus direction
     */    
    disc->local_rank = QMP_NODEP_RANK(port->peer);
    disc->remote_rank = QMP_PHYS_RANK(port->phys);
    disc->axis = port->axis;
    disc->direction = port->direction + 1;
  }
}

/**
 * Start opening an individual connection for a port
 */
static QMP_status_t
qmp_start_open_connection_i (QMP_gige_port_t* port)
{
  VIP_NET_ADDRESS *local, *remote;
  VIP_NIC_ATTRIBUTES    nic_attrs;
  QMP_via_conn_disc_t   ldisc, rdisc;
  QMP_status_t          status;

  QMP_TRACE ("qmp_open_connection_i");

  /**
   * First allocate memory for connection handle
   */
  port->conn = (QMP_via_connection_t *)malloc(sizeof (QMP_via_connection_t));
  if (!port->conn) {
    QMP_error ("%s: cannot allocate memory for QMP_via_connection_t .\n",
	       port->eth_device);
    return QMP_NOMEM_ERR;
  }

  /**
   * Assign nic handle from device handle.
   * This nic handle is bundled together for convenience purpose.
   */
  port->conn->nic_handle = port->viadev->nic_handle;

  /**
   * Get a local value for NIC_ATTRS to make some memory debugger
   * happy (valgrind)
   */
  nic_attrs = port->viadev->nic_attrs;
  
  /** 
   * Set local address information
   */
  local = (VIP_NET_ADDRESS *)malloc(sizeof(VIP_NET_ADDRESS) + 
				    nic_attrs.NicAddressLen +
				    sizeof (QMP_via_conn_disc_t));
  if (!local) {
    QMP_error ("%s: cannot allocate space for local address. \n", 
	       port->eth_device);
    free (port->conn);
    port->conn = 0;
    return QMP_NOMEM_ERR;
  }
  memset (local, 0, sizeof(VIP_NET_ADDRESS) + nic_attrs.NicAddressLen +
	  sizeof (QMP_via_conn_disc_t));
  local->HostAddressLen = nic_attrs.NicAddressLen;
  local->DiscriminatorLen = sizeof (QMP_via_conn_disc_t);
  memcpy (local->HostAddress, nic_attrs.LocalNicAddress,
	  nic_attrs.NicAddressLen);

  /* Set local discriminator */
  qmp_set_conn_local_discriminator_i (port, &ldisc);
  memcpy (local->HostAddress + local->HostAddressLen, &ldisc,
	  local->DiscriminatorLen);
  
  if (QMP_rt_verbose)
    qmp_print_via_conn_disc_i ((QMP_via_conn_disc_t *)(local->HostAddress + local->HostAddressLen), 1);

  /**
   * Remote address information 
   */
  remote = (VIP_NET_ADDRESS *)malloc(sizeof(VIP_NET_ADDRESS) + 
				     nic_attrs.NicAddressLen +
				     sizeof (QMP_via_conn_disc_t));
  if (!remote) {
    QMP_error ("%s: cannot allocate space for remote address. \n",
	       port->eth_device);
    free (port->conn);
    port->conn = 0;
    free (local);
    return QMP_NOMEM_ERR;
  }
  memset (remote, 0, sizeof(VIP_NET_ADDRESS) + nic_attrs.NicAddressLen +
	  sizeof (QMP_via_conn_disc_t));

  remote->HostAddressLen = nic_attrs.NicAddressLen;
  if ((status = VipNSGetHostByName (port->conn->nic_handle,
				    port->peer_via_host,
				    remote, 0)) != VIP_SUCCESS) {
    QMP_error ("%s: cannot get host by name for peer via host %s.\n",
	       port->eth_device, port->peer_via_host);
    free (port->conn);
    port->conn = 0;
    free (local);
    return status;
  }
  remote->DiscriminatorLen = sizeof (QMP_via_conn_disc_t);

  /** 
   * Set remote discriminator which should be the same as the local
   * address discriminator on the other end
   */
  qmp_set_conn_remote_discriminator_i (port, &rdisc);
  memcpy (remote->HostAddress + remote->HostAddressLen, &rdisc,
	  remote->DiscriminatorLen);

  if (QMP_rt_verbose)
    qmp_print_via_conn_disc_i ((QMP_via_conn_disc_t *)(remote->HostAddress + remote->HostAddressLen), 0);

  /* Now set VI attribute field values */
  /* port->conn->vi_attrs.ReliabilityLevel = VIP_SERVICE_RELIABLE_DELIVERY;*/
  port->conn->vi_attrs.ReliabilityLevel = VIP_SERVICE_UNRELIABLE;
  port->conn->vi_attrs.Ptag = port->viadev->ptag;
  port->conn->vi_attrs.EnableRdmaWrite = VIP_TRUE;
  port->conn->vi_attrs.EnableRdmaRead = VIP_FALSE;
  port->conn->vi_attrs.QoS = 0;
  port->conn->vi_attrs.MaxTransferSize = QMP_MAX_MSGLEN;


  if ((status = VipCreateVi(port->conn->nic_handle, 
			    &port->conn->vi_attrs, 
			    port->viadev->cq, port->viadev->cq,
			    &port->conn->vi_handle)) != VIP_SUCCESS) {
    QMP_error ("%s: cannot create vi handle for peer %d %s error = %d.\n", 
	       port->eth_device, QMP_NODEP_RANK(port->peer),
	       port->peer_via_host, status);
    free (port->conn);
    port->conn = 0;
    free (local);
    free (remote);
    return status;
  }

  /* create buffer managers for sending and receiving */
  if ((status = QMP_init_qbuf_manager (port->viadev, 
				       &(port->conn->send_qbufs),
				       QMP_MH_SEND,
				       port->type)) != QMP_SUCCESS) {
    free (port->conn);
    port->conn = 0;
    free (local);
    free (remote);
    return status;
  }

  if ((status = QMP_init_qbuf_manager (port->viadev, 
				       &(port->conn->recv_qbufs),
				       QMP_MH_RECV,
				       port->type)) != QMP_SUCCESS) {
    QMP_finalize_qbuf_manager (port->viadev, &(port->conn->send_qbufs));
    free (port->conn);
    port->conn = 0;
    free (local);
    free (remote);
    return status;
  }

  /* 
   * Set up local and remote token number which is two smaller than
   * number of qbufs
   *
   * local tokens represents how many buffers posted since last update
   */
  port->conn->local_tokens = 0;
  port->conn->remote_tokens = port->conn->recv_qbufs.count;
  port->conn->notify_peer = QMP_FALSE;
  QMP_DEBUG(QMP_DBGLVL_TOKEN, "Currently port %p have %d local tokens and %d remote tokens \n",port, port->conn->local_tokens,port->conn->remote_tokens);
	    

  /**
   * Set up send and receive id
   */
  port->conn->send_id = 9093;
  port->conn->recv_id = 1213;

  /* Now post all receiving descriptor for this via handle before connection
   * is set
   */
  if ((status = qmp_prepost_recv_buffers_i (port, &(port->conn->recv_qbufs)))
      != QMP_SUCCESS) {
    QMP_finalize_qbuf_manager (port->viadev, &(port->conn->send_qbufs));
    QMP_finalize_qbuf_manager (port->viadev, &(port->conn->recv_qbufs));
    free (port->conn);
    port->conn = 0;
    free (local);
    free (remote);
    return status;
  }
  if (QMP_rt_verbose)
    QMP_info ("%s prepost %d buffers with buffer size of %d for receiving.\n",
	      port->eth_device, port->conn->recv_qbufs.count,
	      QMP_QBUF_SIZE);

  /* finally issue connect peer request with a timeout value 
   * but this routine will return right away, the later connection wait
   * will check connection
   */

  status = VipConnectPeerRequest(port->conn->vi_handle, local,
				 remote,QMP_NEIGHBOR_CONN_TIMEOUT*1000);
  if (status != VIP_SUCCESS) {
    QMP_error ("%s cannot start connection request to %s on host %s. \n",
	       port->eth_device, port->peer_via_host, port->peer->host);
    QMP_finalize_qbuf_manager (port->viadev, &(port->conn->send_qbufs));
    QMP_finalize_qbuf_manager (port->viadev, &(port->conn->recv_qbufs));
    free (port->conn);
    port->conn = 0;
    free (local);
    free (remote);
    return status;
  }

  /* set up local and remote memories */
  port->conn->local = local;
  port->conn->remote = remote;

  /* Initialize all send and receiving requests */
  port->conn->sent_list = 0;
  port->conn->pend_send_head = 0;
  port->conn->not_claimed_buf_list = 0;
  port->conn->posted_recv_list = 0;
  port->conn->rdmarecv_list = 0;

  /* Initialize send/recv message handle list */
  port->conn->send_handles = 0;
  port->conn->recv_handles = 0;

  /* Let VI remember this port so that when we receive and send something
   * on this vi we can quickly find out which port we are talking about.
   *
   * This is MVIA only; This is not in the VIA spec
   */
  QMP_mvia_set_vi_app_data (port->conn->vi_handle, (void *)port);
  
  return QMP_SUCCESS;
}

static QMP_status_t
qmp_wait_connection_i (QMP_gige_port_t* port)
{
  QMP_status_t status;

  QMP_TRACE ("qmp_wait_connections_i");

  QMP_DEBUG(QMP_DBGLVL_CONNECTION, "%s : Waiting for connection to via peer %s on host %s . \n",
	      port->eth_device, 
	      port->peer_via_host, port->peer->host);

  status = VipConnectPeerWait (port->conn->vi_handle,
			       &port->conn->remote_vi_attrs);
  
  if (status == VIP_SUCCESS) {
    /* Now connection is done */
    port->active = QMP_TRUE;
    QMP_DEBUG(QMP_DBGLVL_CONNECTION, "%s : connection to via peer %s on host %s is established. \n",
		port->eth_device, 
		port->peer_via_host, port->peer->host);
  }
  else 
    QMP_error ("%s : connection to via peer %s on host %s cannot be established. \n",
	       port->eth_device, 
	       port->peer_via_host, port->peer->host);
  
  return status;
}

/**
 * Open VIA connections to all neighbors
 */
QMP_status_t
QMP_open_connections_to_neighbors (QMP_machine_t* glm)
{
  int i;
  QMP_gige_port_t *port0, *port1;
  QMP_status_t     status;

  QMP_TRACE ("QMP_open_connections_to_neighbors");

  /* Open VIA Nic Handle for neighbors */
  for (i = 0; i < glm->phys->dimension; i++) {
    /**
     * If this is an even node on this axis, positive connection first
     */
    if (QMP_PHYS_POS_IN_DIM(glm->phys, i) % 2 == 0) {
      port0 = &glm->phys->ports[i][1];
      port1 = &glm->phys->ports[i][0];
    }
    else {
      port0 = &glm->phys->ports[i][0];
      port1 = &glm->phys->ports[i][1];
    }

    if ((status = qmp_start_open_connection_i (port0)) != QMP_SUCCESS)
      return status;

    if ((status = qmp_start_open_connection_i (port1)) != QMP_SUCCESS)
      return status;
  }

  for (i = 0; i < glm->phys->dimension; i++) {
    /**
     * If this is an even node on this axis, positive connection first
     */
    if (QMP_PHYS_POS_IN_DIM(glm->phys, i) % 2 == 0) {
      port0 = &glm->phys->ports[i][1];
      port1 = &glm->phys->ports[i][0];
    }
    else {
      port0 = &glm->phys->ports[i][0];
      port1 = &glm->phys->ports[i][1];
    }
    
    if ((status = qmp_wait_connection_i (port0)) != VIP_SUCCESS)
      return status;

    if ((status = qmp_wait_connection_i (port1)) != VIP_SUCCESS)
      return status;
  }

  return QMP_SUCCESS;
}


/**
 * Close a single port VIA connection
 */
static QMP_status_t
qmp_close_via_connection_i (QMP_gige_port_t* port)
{
  QMP_TRACE ("qmp_close_connection_i");
  
  VipDisconnect (port->conn->vi_handle);

  VipDestroyVi  (port->conn->vi_handle);

  /* deregister and release memory for qbufs */
  QMP_finalize_qbuf_manager (port->viadev, &(port->conn->send_qbufs));
  QMP_finalize_qbuf_manager (port->viadev, &(port->conn->recv_qbufs));

  if (QMP_rt_verbose)
    QMP_info ("%s: close connection to via host %s on host %s. \n",
	      port->eth_device, port->peer_via_host, port->peer->host);
  
  free (port->conn->local);
  free (port->conn->remote);
  free (port->conn);
  port->conn = 0;
  port->active = 0;

  return QMP_SUCCESS;
}

/**
 * Close all VIA connections 
 */
QMP_status_t
QMP_close_via_connections (QMP_machine_t* glm)
{
  int i;
  QMP_gige_port_t* port;

  QMP_TRACE ("QMP_close_via_connections");


  /* Open VIA Nic Handle for neighbors */
  for (i = 0; i < glm->phys->dimension; i++) {
    /* minus direction */
    port = &glm->phys->ports[i][0];

    if (port->active) 
      qmp_close_via_connection_i (port);

    /* plus direction */
    port = &glm->phys->ports[i][1];

    if (port->active)
      qmp_close_via_connection_i (port);
  }

  for (i = 0; i < glm->phys->num_nodes; i++) {
    port = &glm->phys->switch_ports[i];
    
    if (port->active) 
      qmp_close_via_connection_i (port);
  }
  return QMP_SUCCESS;
}

/**
 * Open a switched connection port
 * This routine is called after the active flag is checked
 */
QMP_status_t
QMP_open_via_switch_port (QMP_machine_t* glm,
			  QMP_gige_port_t* port)
{
  QMP_status_t status;

  QMP_TRACE ("QMP_open_via_switch_port");

  status = qmp_start_open_connection_i (port);

  if (status != QMP_SUCCESS) {
    QMP_error ("Cannot open a switched connection using %s to %s.\n",
	       port->eth_device, port->peer_via_host);
    return status;
  }
    
  status = qmp_wait_connection_i (port);
  if (status != QMP_SUCCESS) {
    QMP_error ("Waiting for open a switched connection using %s to %s failed.\n",
	       port->eth_device, port->peer_via_host);
    return status;
  }

  /* Now add this via completion queue to my global table */
  /* Duplicate cq will not be added since the following code will check */
  QMP_add_viacq (glm, port->viadev->cq);

  return QMP_SUCCESS;
}

/**
 * Finish a rdma put using information collected inside a qbuf
 */
static inline void
qmp_flush_rdma_qbuf_i (QMP_qbuf_t* qbuf,
		       QMP_gige_port_t* port,
		       QMP_machine_t* glm)
{
  QMP_u32_t     si, rdmalen, num_qbufs;
  void *mylocaladdr, *myremaddr;
  QMP_packet_t* packet;
  QMP_request_t* req;

  QMP_TRACE ("qmp_flush_rdma_qbuf_i");

  packet = (QMP_packet_t *)(qbuf->buffer);

  /* Get index of segments for the rdma message */
  si = QMP_RDMA_GET_SEGINDEX(((QMP_rdma_packet_t *)packet));

  /* Set token information */
  QMP_SET_PACKET_TOKENS (packet, port->conn->local_tokens,
			 port->conn->remote_tokens);

  /* retrieve request inside qbuf */
  req = (QMP_request_t *)qbuf->req;

  /* Get number of qbufs needed for the message */
  num_qbufs = QMP_RDMA_NUM_QBUFS_NEEDED(QMP_REQ_USERBUFLEN(req));

 /* Calculate this rdma local and remote address and length */
  mylocaladdr = QMP_RDMA_GET_ADDR(req->memory.address,si);
  myremaddr   = QMP_RDMA_GET_ADDR(req->remote_memory.address,si);
  rdmalen     = QMP_RDMA_GET_LEN (req->memory.len,num_qbufs,si);

  QMP_DEBUG(QMP_DBGLVL_RDMA, "Flushing out a rdma packet for segment %d with local address %p remote address %p memory length %d.\n", si, mylocaladdr, myremaddr, rdmalen);

  
  /* Set RDMA READY for this qbuf */
  QMP_set_qbuf_rdmaw_ready (qbuf, 
			    mylocaladdr,
			    QMP_REQ_MEMHANDLE(req),
			    myremaddr,
			    QMP_REQ_REM_MEMHANDLE(req),
			    rdmalen,
			    QMP_REQ_RID(req));
      
  /* This is a RDMA post but still use other end a token */
  if (QMP_qbuf_post_send(glm, port, qbuf, QMP_TRUE) == QMP_SUCCESS) {
    ;
  }
  else {
    /* Put back qbuf and send request */
    QMP_release_qbuf (&(port->conn->send_qbufs), qbuf);
    QMP_RELEASE_REQUEST(glm, req);

    QMP_error ("Fatal: could not send out RDMA packet.\n");
    exit (1);
  }
}


/**
 * Start a rdma put using information collected inside a request
 */
static inline void
qmp_start_rdma_put_i (QMP_request_t* request,
		      QMP_gige_port_t* port,
		      QMP_machine_t* glm)
{
  QMP_qbuf_t* qbuf;
  QMP_u32_t   num_qbufs, i, numbufsdone, rdmalen;
  void *mylocaladdr, *myremaddr;
  QMP_rdma_packet_t* packet;

  QMP_TRACE ("qmp_start_rdma_put_i");

  /* Calculate number of qbufs needed for this rdma message */
  num_qbufs = QMP_RDMA_NUM_QBUFS_NEEDED(QMP_REQ_USERBUFLEN(request));

  /* Set this send request number of qbufs needed */
  QMP_SET_REQ_NUM_QBUFS_NEEDED(request,num_qbufs);

  i = 0;

_qmp_start_rdma_put0:

  while (i < num_qbufs && QMP_PORT_HAS_SEND_QBUFS(port->conn)) {

    /* Get a qbuf from the sender buffer list */
    qbuf = QMP_get_qbuf (&(port->conn->send_qbufs));

    /* Calculate this rdma local and remote address and length */
    mylocaladdr = QMP_RDMA_GET_ADDR(request->memory.address,i);
    myremaddr   = QMP_RDMA_GET_ADDR(request->remote_memory.address,i);
    rdmalen     = QMP_RDMA_GET_LEN (request->memory.len,num_qbufs,i);

    QMP_DEBUG(QMP_DBGLVL_RDMA, "Ready to start a rdma put operation for segment %d.\n", i);
    QMP_DEBUG(QMP_DBGLVL_RDMA, "Local memory: addr=%p len = %d mem_handle=0x%x\n",
	      mylocaladdr, rdmalen, request->memory.mem_handle);
    QMP_DEBUG(QMP_DBGLVL_RDMA, "Remote memory: addr=%p len = %d mem_handle=0x%x Receiving ID %d\n",
	      myremaddr, rdmalen,
	      request->remote_memory.mem_handle,
	      request->memory.rid);
    
    packet = (QMP_rdma_packet_t *)(qbuf->buffer);
      
    /* Set packet header: this packet will not travel over network */
    /* this packet will be used in the process_via_send code       */
    QMP_SET_RDMA_PACKET_OP(packet, QMP_RDMA_PUT_FINISH);
      
    /* Set segment index of this packet for the rdma message       */
    QMP_SET_RDMA_SEGINDEX(packet, i);

    /* Get number of segments done so far */
    numbufsdone = QMP_REQ_NUM_QBUFS_DONE(request);
      
    if (QMP_PORT_CAN_SEND(port->conn)) {
      /* Set RDMA READY for this qbuf */
      QMP_set_qbuf_rdmaw_ready (qbuf, 
				mylocaladdr,
				QMP_REQ_MEMHANDLE(request),
				myremaddr,
				QMP_REQ_REM_MEMHANDLE(request),
				rdmalen,
				QMP_REQ_RID(request));
      
      /* This is a RDMA post but still use other end a token */
      if (QMP_qbuf_post_send(glm, port, qbuf, QMP_TRUE) == QMP_SUCCESS) {
	/* This qbuf should track this request                         */
	QMP_QBUF_TRACK_REQ(qbuf,request);
	
	/* Track this qbuf inside request */
	QMP_SET_REQ_QBUF(request,qbuf);

	/* I need to wait for this qbuf has been sent out if there 
	 * are more than 1 qbufs
	 *
	 * Reason: The limited number of send descriptors of giga
	 * bit ethernet devices
	 */
	if (num_qbufs > 0 && i < num_qbufs - 1 && i != 0 && i % 7 == 0) {
	  while (numbufsdone == QMP_REQ_NUM_QBUFS_DONE(request))
	    QMP_poll (glm, 0);
	}
      }
      else {
	/* Put back qbuf and send request */
	QMP_release_qbuf (&(port->conn->send_qbufs), qbuf);
	
	QMP_error ("Fatal: could not send out RDMA packet.\n");
	exit (1);
      }
    }
    else {
      /* Track this request inside qbuf */
      QMP_QBUF_TRACK_REQ(qbuf,request);
	
      /* Track this qbuf inside request */
      QMP_SET_REQ_QBUF(request,qbuf);
      
      /* Now I have to pend this send */
      /* Adding this send request to the pending send list */
      QMP_ENQUEUE_QBUF_TO_PEND_SENDLIST(qbuf, port->conn);
    }
    i++;
  }

  if (i < num_qbufs) {
    /* Wait for other to finish to get more qbufs */
    while (!QMP_PORT_HAS_SEND_QBUFS(port->conn))
      QMP_poll (glm, port);
    goto _qmp_start_rdma_put0;
  }
}

/**
 * Sending out a idata or not idata using information in the qbuf
 */
static inline void
qmp_flush_send_qbuf_i (QMP_qbuf_t* qbuf,
		       QMP_gige_port_t* port,
		       QMP_machine_t* glm)
{
  QMP_u32_t sendsize;
  QMP_packet_t* packet;

  QMP_TRACE ("qmp_flush_send_qbuf_i");
 
  packet = (QMP_packet_t *)qbuf->buffer;

  switch (packet->op) {
  case QMP_IMMEDIATE_DATA:
    sendsize = QMP_IDATA_PAYLOAD_LEN(((QMP_idata_packet_t *)packet)) + sizeof (QMP_idata_packet_t);
    QMP_DEBUG(QMP_DBGLVL_SEND, "Flushing out packet with total len %d offset %d payload len %d and tag %d\n", 
	      QMP_IDATA_LEN(((QMP_idata_packet_t *)packet)),
	      QMP_IDATA_OFFSET(((QMP_idata_packet_t *)packet)),
	      QMP_IDATA_PAYLOAD_LEN(((QMP_idata_packet_t *)packet)),
	      QMP_PACKET_TAG(((QMP_packet_t *)packet)));
    break;
  case QMP_RDMA_PUT:
    sendsize = sizeof (QMP_rdma_packet_t);
    break;
  case QMP_NO_OP:
  case QMP_QUERY:
  case QMP_QUERY_REPLY:
    sendsize = sizeof (QMP_packet_t);
    break;
  default:
    QMP_error ("Not yet implemented for other protocol in flush pending.\n");
    exit (1);
    break;
  }

  QMP_DEBUG(QMP_DBGLVL_SEND, "flush out a pending request.\n");

  /* Set current local and remote tokens */
  QMP_SET_PACKET_TOKENS(packet, port->conn->local_tokens, 
			port->conn->remote_tokens);

  /* Now it is time to send this packet */
  QMP_set_qbuf_sendrecv_ready(qbuf, sendsize);

  /* Remote token is reduced here and local tokens set to 0 */
  if (QMP_qbuf_post_send(glm, port, qbuf, QMP_FALSE) == QMP_SUCCESS) {
    QMP_DEBUG(QMP_DBGLVL_SEND, "A pending request is sent out.\n");
  }
  else {
    /* Put back qbuf and send request */
    QMP_release_qbuf (&(port->conn->send_qbufs), qbuf);
    QMP_RELEASE_REQUEST(glm, ((QMP_request_t *)qbuf->req));
	  
    QMP_error ("Fatal sending pending list error \n");
    exit (1);
  }
} 
  

/**
 * Send out backloged or pending send request when there are 
 * remote tokens available.
 *
 * This routine is called after we know there are pending send
 *
 */
static void
qmp_flush_pending_send_i (QMP_gige_port_t *port,
			  QMP_machine_t* glm)
{
  QMP_qbuf_t* qbuf;
  QMP_packet_t* packet;

  QMP_TRACE ("qmp_flush_pending_send_i");

  while (!(QMP_PEND_SENDLIST_EMPTY(port->conn)) && 
	 port->conn->remote_tokens > QMP_TOKEN_PRESERVE) {

    qbuf = 0;
    QMP_DEQUEUE_QBUF_FROM_PEND_SENDLIST(qbuf, port->conn);

    packet = (QMP_packet_t *)qbuf->buffer;

    switch (packet->op) {
    case QMP_IMMEDIATE_DATA:
    case QMP_RDMA_PUT:
    case QMP_NO_OP:
    case QMP_QUERY:
    case QMP_QUERY_REPLY:
      qmp_flush_send_qbuf_i (qbuf, port, glm);
      break;
    case QMP_RDMA_PUT_FINISH:
      qmp_flush_rdma_qbuf_i (qbuf, port, glm);
      break;
    default:
      QMP_error ("Not yet implemented for other protocol in flush pending.\n");
      exit (1);
      break;
    }
  }
}

/**
 * Fast send to the other end to update tokens or query tokens
 *
 * If sendid or recvid are not zero, use these two values
 * If recv id not zero, we actually sending out rdma packet
 */
QMP_status_t
QMP_isend_nodata (QMP_u16_t dest, QMP_u16_t protocol, 
		  QMP_u32_t sendid, QMP_u32_t recvid,
		  QMP_gige_port_t *port, 
		  QMP_machine_t* glm)
{
  QMP_qbuf_t *qbuf = 0;
  QMP_status_t status = QMP_SUCCESS;
  QMP_packet_t* packet;
  QMP_request_t* sendreq = 0;
  QMP_u32_t sendsize;

  QMP_TRACE ("QMP_isend_nodata");

_qmp_send_nodata_0:

  if (QMP_PORT_HAS_SEND_QBUFS(port->conn)) {
    /* Get a qbuf from the send buffer list      */
    qbuf = QMP_get_qbuf (&(port->conn->send_qbufs));

    packet = (QMP_packet_t *)(qbuf->buffer);

    /* Get a send request from send request free list */
    QMP_GET_REQUEST(glm, sendreq, QMP_MH_SEND);

    /* Set packet header information */
    QMP_SET_PACKET(packet, protocol,
		   port->conn->local_tokens,port->conn->remote_tokens,
		   QMP_PHYS_RANK(port->phys), dest, QMP_RESERVED);


    /* Set send request information */
    if (sendid == 0)
      QMP_SET_REQ_SID(sendreq,port->conn);
    else
      QMP_SET_REQ_SENDID(sendreq,sendid);

    if (recvid == 0) 
      /* Now we are just send reguler packet */
      sendsize = sizeof (QMP_packet_t);
    else {
      /* Set request receive id */
      QMP_SET_REQ_RECVID(sendreq,recvid);
      
      /* Set rdma packet send and receive id */
      QMP_SET_RDMA_MEMORY(((QMP_rdma_packet_t *)packet),0, 0, 0, sendid, recvid);

      /* Set send data size */
      sendsize = sizeof (QMP_rdma_packet_t);
    }

    QMP_SET_REQ_HDR(sendreq,(*packet));
    QMP_SET_REQ_PORT(sendreq,port);

    QMP_DEBUG(QMP_DBGLVL_REQUEST, "post a send a %s request .\n", 
	      qmp_protocol_names[protocol - QMP_PSTART]);
    QMP_DUMP_REQUEST(sendreq);
    QMP_DEBUG(QMP_DBGLVL_REQUEST, "\n");

    if (QMP_PORT_CAN_SEND(port->conn)) {
      /* Now it is time to send this packet */
      QMP_set_qbuf_sendrecv_ready(qbuf, sendsize);

      /* Remote token is reduced here and local tokens set to zero */
      if ((status = QMP_qbuf_post_send(glm, port, qbuf, QMP_FALSE)) 
	  == QMP_SUCCESS) {
	QMP_DEBUG (QMP_DBGLVL_SEND, "Sent out a %s packet.\n",
		   qmp_protocol_names[protocol - QMP_PSTART]);

	/* Track this request inside qbuf */
	QMP_QBUF_TRACK_REQ(qbuf,sendreq);

	/* Track this qbuf inside request */
	QMP_SET_REQ_QBUF(sendreq,qbuf);
      }
      else {
	/* Problem */
	QMP_DEBUG(QMP_DBGLVL_REQUEST, "cannot post a %s send .\n",
		  qmp_protocol_names[protocol - QMP_PSTART]);
   	
	/* Put back qbuf and send request */
	QMP_release_qbuf (&(port->conn->send_qbufs), qbuf);
	QMP_RELEASE_REQUEST(glm,sendreq);
      
	QMP_error ("Fatal: could not get remote token number.\n");
	exit (1);
      }
    }
    else {
      /* Track this request inside qbuf */
      QMP_QBUF_TRACK_REQ(qbuf,sendreq);

      /* Track this qbuf inside request */
      QMP_SET_REQ_QBUF(sendreq,qbuf);
      
      /* Now I have to pend this send */
      /* Adding this send request to the pending send list */
      QMP_ENQUEUE_QBUF_TO_PEND_SENDLIST(qbuf, port->conn);
    }
  }
  else {
    /* Wait for other to finish to get more qbufs */
    while (!QMP_PORT_HAS_SEND_QBUFS(port->conn))
      QMP_poll (glm, port);
    goto _qmp_send_nodata_0;
  }    
  
  return QMP_SUCCESS;
}

/**
 * Send a rdma write request to other end
 */
static inline QMP_status_t
qmp_isend_rdmaw_request_i (QMP_request_t* sendreq,
			   QMP_gige_port_t* port,
			   QMP_machine_t* glm)
{
  QMP_status_t status = QMP_SUCCESS;
  QMP_qbuf_t* qbuf = 0;

  QMP_TRACE("qmp_isend_rdmaw_request_i");

_qmp_isend_rdmaw_req_0:

  if (QMP_PORT_HAS_SEND_QBUFS(port->conn)) {
    /* Get a qbuf from send qbuf manager */
    qbuf = QMP_get_qbuf (&(port->conn->send_qbufs));

    /* Memcpy packet header from send request to the packet inside qbuf */
    memcpy (qbuf->buffer, &(sendreq->hdr), sizeof(QMP_packet_t));
    
    /* Set memory information from send request */
    QMP_SET_RDMA_MEMORY(((QMP_rdma_packet_t *)(qbuf->buffer)), 
			QMP_REQ_USERBUF(sendreq), QMP_REQ_USERBUFLEN(sendreq),
			0, QMP_REQ_SID(sendreq), QMP_REQ_RID(sendreq));
    
    if (QMP_PORT_CAN_SEND(port->conn)) {
      /* Now it is time to send this packet */
      QMP_set_qbuf_sendrecv_ready(qbuf, sizeof (QMP_rdma_packet_t));

      if ((status = QMP_qbuf_post_send (glm, port, qbuf, QMP_FALSE)) 
	  == QMP_SUCCESS) {
	/* Track this request inside qbuf */
	QMP_QBUF_TRACK_REQ(qbuf,sendreq);

	/* Track this qbuf inside request */
	QMP_SET_REQ_QBUF(sendreq,qbuf);

	/* Add this to sent list */
	QMP_ADD_REQ_TO_SENTLIST(sendreq,port->conn);
      }
      else {
	QMP_DEBUG(QMP_DBGLVL_RDMA, "cannot post a send for a rdma put.\n");
	
	/* Put back qbuf and send request */
	QMP_release_qbuf (&(port->conn->send_qbufs), qbuf);
	QMP_RELEASE_REQUEST(glm,sendreq);
      }
    }
    else {
      /* Track this request inside qbuf */
      QMP_QBUF_TRACK_REQ(qbuf,sendreq);

      /* Track this qbuf inside request */
      QMP_SET_REQ_QBUF(sendreq,qbuf);

      /* Adding this send request to the pending send list */
      QMP_ENQUEUE_QBUF_TO_PEND_SENDLIST(qbuf, port->conn);
    }
  }
  else {
    /* Now we cannot do anything, tell user service is busy */
    while (!QMP_PORT_HAS_SEND_QBUFS(port->conn))
      QMP_poll (glm, port);
    goto _qmp_isend_rdmaw_req_0;
  }

  return status;
}      


/**
 * Send out an immediate data using one or more qbufs
 */
static inline QMP_status_t
qmp_isend_idata_request_i (QMP_request_t* sendreq,
			   QMP_gige_port_t* port,
			   QMP_machine_t* glm)
{
  QMP_qbuf_t*   qbuf;
  QMP_u32_t     num_qbufs, i;
  QMP_idata_part_t idata_info;
  QMP_status_t  status = QMP_SUCCESS;

  QMP_TRACE ("qmp_isend_request_i");

  /* Calculate number of qbufs needed for this message */
  num_qbufs = QMP_IDATA_NUM_QBUFS_NEEDED(QMP_REQ_USERBUFLEN(sendreq));

  /* Set send request number qbufs needed */
  QMP_SET_REQ_NUM_QBUFS_NEEDED(sendreq,num_qbufs);

_qmp_isend_idata_req_0:
  
  if (num_qbufs <= QMP_PORT_NUM_SEND_QBUFS(port->conn)) {
    i = 0;

    while (i < num_qbufs) {
      /* Now get qbuf from the qbuf free list */
      qbuf = QMP_get_qbuf (&(port->conn->send_qbufs));

      /* Copy request hdr into the packet hdr */
      memcpy (qbuf->buffer, &(sendreq->hdr), sizeof (QMP_packet_t));

      /* But local and remote tokens has to be different for different packet */
      QMP_SET_PACKET_TOKENS (((QMP_packet_t *)qbuf->buffer), 
			     port->conn->local_tokens, port->conn->remote_tokens);

      /* Calculate information for this packet */
      idata_info.total_len = QMP_REQ_USERBUFLEN(sendreq);
      
      idata_info.payload_len = QMP_CALC_IDATA_PAYLOAD_LEN(QMP_REQ_USERBUFLEN(sendreq), num_qbufs, i);

      idata_info.offset = QMP_CALC_IDATA_OFFSET(num_qbufs,i);

      /* Copy idata information into the packet */
      memcpy (qbuf->buffer + sizeof(QMP_packet_t), &idata_info, sizeof(idata_info));

      /* Copy user buffer information into the packet */
      memcpy (qbuf->buffer + sizeof (QMP_idata_packet_t),
	      ((char *)QMP_REQ_USERBUF(sendreq)) + idata_info.offset,
	      idata_info.payload_len);
      

      if (QMP_PORT_CAN_SEND(port->conn)) {
	QMP_set_qbuf_sendrecv_ready (qbuf, sizeof(QMP_idata_packet_t) + idata_info.payload_len);

	/* remote tokens reduced inside this routine */
	if ((status = QMP_qbuf_post_send (glm, port, qbuf, 
					  QMP_FALSE)) == QMP_SUCCESS) {
	  /* Track this send req inside qbuf */
	  QMP_QBUF_TRACK_REQ(qbuf, sendreq);

	  /* Track this qbuf inside request */
	  QMP_SET_REQ_QBUF(sendreq, qbuf);
	}
	else {
	  QMP_DEBUG(QMP_DBGLVL_SEND, "Cannot send out a qbuf.\n");
	  
	  /* Put back qbuf and send request */
	  QMP_release_qbuf (&(port->conn->send_qbufs), qbuf);
	  QMP_RELEASE_REQUEST(glm, sendreq);

	  /* Now need to continue */
	  return status;
	}
      }
      else {
	/* Track this send req inside qbuf */
	QMP_QBUF_TRACK_REQ(qbuf, sendreq);

	/* Track this qbuf inside request */
	QMP_SET_REQ_QBUF(sendreq, qbuf);

	/* Enqueue this to a pending send list */
	QMP_ENQUEUE_QBUF_TO_PEND_SENDLIST(qbuf, port->conn);
      }
      i++;
    }
  }
  else {
    /* We wait for more qbufs available */
    while (num_qbufs > QMP_PORT_NUM_SEND_QBUFS(port->conn)) 
      QMP_poll (glm, port);

    goto _qmp_isend_idata_req_0;
  }

  return status;
}

/**
 * Fast send to a neighbor using a VIA connection
 */
QMP_status_t
QMP_isend_direct (void* buf, QMP_u32_t count, QMP_datatype_t datatype,
		  QMP_u16_t dest, QMP_u16_t tag, QMP_gige_port_t *port, 
		  QMP_machine_t* glm, QMP_request_t** request)
{
  QMP_u32_t len, protocol;
  QMP_status_t status = QMP_SUCCESS;
  QMP_request_t* sendreq = 0;
  QMP_regmem_entry_t* regmem = 0;

  QMP_TRACE ("QMP_isend_direct");

  /**
   * Check whether we can send or not
   * If there is no remote credit, or there are no qbuf
   */
  len = count * QMP_DATA_SIZE(datatype);

  /* Get a send request from send request free list */
  QMP_GET_REQUEST(glm, sendreq, QMP_MH_SEND);

  if (len <= QMP_MEMCPY_THRESHOLD) 
    /* Do memory copy to send small messages */
    protocol = QMP_IMMEDIATE_DATA;
  else {
    regmem = QMP_regmem_register (glm, 
				  QMP_PORT_REGMEM_TABLE(port),
				  buf, len);
    if (!regmem) {
      QMP_error ("Fatal: cannot register memory for buf %p and length %d\n",
		 buf, len);
      QMP_abort (1);      
    }
    protocol = QMP_RDMA_PUT;
  }

  /* Set packet header information inside the request */
  QMP_SET_PACKET ((&(sendreq->hdr)), protocol,
		  port->conn->local_tokens,port->conn->remote_tokens,
		  QMP_PHYS_RANK(port->phys), dest, tag);
  
  /* Set send request information */
  QMP_SET_REQ_SID(sendreq,port->conn);
  QMP_SET_REQ_USERBUF(sendreq,buf);
  QMP_SET_REQ_USERBUFLEN(sendreq,len);
  QMP_SET_REQ_COUNT(sendreq,count);
  QMP_SET_REQ_DATATYPE(sendreq,datatype);
  QMP_SET_REQ_PORT(sendreq,port);
  if (regmem) 
    QMP_SET_REQ_MEMHANDLE(sendreq,regmem->mem_handle);

  QMP_DEBUG(QMP_DBGLVL_REQUEST, "post a send %s request .\n", 
	    qmp_protocol_names[protocol-QMP_PSTART]);
  QMP_DUMP_REQUEST(sendreq);
  QMP_DEBUG(QMP_DBGLVL_REQUEST, "\n"); 

  if (protocol == QMP_IMMEDIATE_DATA) 
    status = qmp_isend_idata_request_i (sendreq, port, glm);
  else
    status = qmp_isend_rdmaw_request_i (sendreq, port, glm);

  if (status == QMP_SUCCESS)
    *request = sendreq;
  else
    *request = 0;

  return status;
}


/**
 * Send to a switched port using a VIA connection
 */
QMP_status_t
QMP_isend_switch (void* buf, QMP_u32_t count, QMP_datatype_t datatype,
		  QMP_u16_t dest, QMP_u16_t tag, QMP_gige_port_t *port, 
		  QMP_machine_t* glm, 
		  QMP_request_t** request)
{
  QMP_status_t status;

  QMP_TRACE ("QMP_Isend_switch");

  if (!port->active) {
    /**
     * If this port is not connected, we do connection now
     */
    if (QMP_open_via_switch_port (glm, port) != QMP_SUCCESS) {
      QMP_error ("cannot open via switch connection port from %s to %s\n",
		 port->eth_device, port->peer_via_host);
      exit (1);
    }
    QMP_info("Using switch network from %s to %s\n",
	     port->eth_device, port->peer_via_host);
  }

  status = QMP_isend_direct (buf, count, datatype, dest, tag, port, glm,
			     request);

  if (status != QMP_SUCCESS) {
    qmp_close_via_connection_i (port);
    QMP_remove_viacq (glm, port->viadev->cq);
  }

  return status;
}

/**
 * Start a general message sending
 *
 * Direction either -1 or +1 for positive and negative direction
 * along axis.
 *
 * For switched port, this argument is not used
 */
QMP_status_t
QMP_isend (void* buf, QMP_u32_t count, QMP_datatype_t datatype,
	   QMP_u16_t dest, QMP_u16_t tag, QMP_s16_t direction,
	   QMP_machine_t* glm,
	   QMP_request_t** request)
{
  QMP_u16_t pdest;
  QMP_gige_port_t* port;

  QMP_TRACE ("QMP_isend");

  /**
   * First convert destination rank to physical rank
   */
  if (!glm->tpl)
    pdest = dest;
  else 
    pdest = QMP_logical_to_allocated (dest);

  /**
   * Secondly check whether this destination can be reached
   * by mesh conenctions.
   */
  port = QMP_get_connection_port (glm, pdest, direction, QMP_MH_SEND);

  if (port->type == QMP_CONN_DIRECT) 
    /* This is a directly connected */
    return QMP_isend_direct (buf, count, datatype,
			     pdest, tag, port, glm,
			     request);
  else
    return QMP_isend_switch (buf, count, datatype,
			     pdest, tag, port, glm, request);
}

/**
 * Send back a RDMA PUT REPLY upon receiving a RDMA PUT Message
 */
static inline void
qmp_send_rdma_reply_i (QMP_request_t* req, QMP_u32_t sendid,
		       QMP_gige_port_t* port, QMP_machine_t* glm)
{
  QMP_rdma_packet_t* rpacket;
  QMP_qbuf_t* qbuf = 0;

  QMP_TRACE ("qmp_send_rdma_reply_i");

_qmp_send_rdma_reply_0:

  if (QMP_PORT_HAS_SEND_QBUFS(port->conn)) {
    /* Get qbuf from the send buffer list */
    qbuf = QMP_get_qbuf (&(port->conn->send_qbufs));

    rpacket = (QMP_rdma_packet_t *)(qbuf->buffer);

    QMP_SET_RDMA_HDR (rpacket, QMP_RDMA_PUT_REPLY,
		      port->conn->local_tokens,port->conn->remote_tokens,
		      QMP_PHYS_RANK(port->phys), port->peer->rank,
		      QMP_RESERVED);

    /* Set send request information */ 
    /* first update the send id of this request. 
       This send id is the sender's id */
    QMP_SET_REQ_SENDID(req,sendid);
    QMP_SET_REQ_RID(req,port->conn);

    /* Set RDMA packet memory part */
    QMP_SET_RDMA_MEMORY(rpacket, req->memory.address, 
			req->memory.len, req->memory.mem_handle,
			QMP_REQ_SID(req),QMP_REQ_RID(req));

    if (QMP_PORT_CAN_SEND(port->conn)) {
      /* Now it is time to send this packet */
      QMP_set_qbuf_sendrecv_ready(qbuf, sizeof(QMP_rdma_packet_t));

      /* Remote token is reduced here and local tokens set to zero */
      if (QMP_qbuf_post_send(glm, port, qbuf, QMP_FALSE) == QMP_SUCCESS) {
	QMP_DEBUG(QMP_DBGLVL_RDMA, "Send a RDMA PUT REPLY with sendid %d recv id %d to node %d\n",
		  sendid, QMP_REQ_RID(req), rpacket->hdr.source);
	QMP_DEBUG(QMP_DBGLVL_RDMA, "RDMA PUT REPLY has memory addr = %p len = %d mem_handle = 0x%x \n",
		  req->memory.address, req->memory.len, req->memory.mem_handle);


	/* Track this request inside qbuf */
	QMP_QBUF_TRACK_REQ(qbuf,req);

	/* Track this qbuf inside request */
	QMP_SET_REQ_QBUF(req,qbuf);

	/* Add this to RDMA LIST: Note this is the difference from unreliable
	 * and relible data transfer
	 */
	QMP_ADD_REQ_TO_RDMALIST(req,port->conn);
      }
      else {
	/* Problem */
	QMP_DEBUG(QMP_DBGLVL_RDMA, "Cannot send out RDMA PUT REPLY.\n");
   	
	/* Put back qbuf and send request */
	QMP_release_qbuf (&(port->conn->send_qbufs), qbuf);
	QMP_RELEASE_REQUEST(glm,req);
      
	QMP_error ("Fatal: could not get remote token number.\n");
	exit (1);
      }
    }
    else {
      /* Track this request inside qbuf */
      QMP_QBUF_TRACK_REQ(qbuf,req);

      /* Track this qbuf inside request */
      QMP_SET_REQ_QBUF(req,qbuf);
      
      /* Now I have to pend this send */
      /* Adding this send request to the pending send list */
      QMP_ENQUEUE_QBUF_TO_PEND_SENDLIST(qbuf, port->conn);
    }
  }
  else {
    /* Wait for other to finish to get more qbufs */
    while (!QMP_PORT_HAS_SEND_QBUFS(port->conn))
      QMP_poll (glm, port);
    goto _qmp_send_rdma_reply_0;
  }    
}

/**
 * Macro handling a request that is matching a idata buffer
 */
#define QMP_REQ_MATCH_IDATA_BUFFER(req,qbuf,st,offset, len, gp,mach) {\
  memcpy ((char *)req->memory.address + offset,                       \
          qbuf->buffer + sizeof (QMP_idata_packet_t),                 \
	  len);                                                       \
  QMP_set_qbuf_sendrecv_ready (qbuf, QMP_QBUF_SIZE);                  \
  if ((st = QMP_qbuf_post_recv (mach, gp, qbuf)) != QMP_SUCCESS) {    \
    QMP_error ("fatal : device %s cannot repost a buffer after receiving with error %s.\n", gp->eth_device, QMP_error_string (st));                     \
  exit (1);                                                           \
  }                                                                   \
}

/**
 * Check whether a packet match a preposted idata receiving request
 */
static inline QMP_bool_t
qmp_match_posted_idata_buf_i (QMP_packet_t* packet,
			      QMP_qbuf_t* qbuf,
			      QMP_gige_port_t* port,
			      QMP_machine_t* glm)
{
  QMP_request_t *req;
  int            found;
  QMP_status_t   status;
  QMP_idata_packet_t* datap;

  QMP_TRACE("qmp_match_posted_idata_buf_i");

  found = 0;
  req = port->conn->posted_recv_list;

  while (req) {

    if (QMP_CAN_RECV (packet, (&(req->hdr))) ) {
      datap = (QMP_idata_packet_t *)packet;
      /* Now check buffer len is ok */
      
      if (req->memory.len == QMP_IDATA_LEN(datap)) {
	found = 1;
	/* My request match a posted data buffer */
	QMP_REQ_MATCH_IDATA_BUFFER(req, qbuf, status, 
				   QMP_IDATA_OFFSET(datap), 
				   QMP_IDATA_PAYLOAD_LEN(datap),
				   port, glm);

	QMP_DEBUG(QMP_DBGLVL_RECV, "Match posted idata for total len %d offset %d payload %d with tag = %d with ivalue = %d.\n", QMP_IDATA_LEN(datap), QMP_IDATA_OFFSET(datap), QMP_IDATA_PAYLOAD_LEN(datap), QMP_PACKET_TAG(packet), (*(int *)(qbuf->buffer + sizeof (QMP_idata_packet_t))));

	/* Now let us set tag number in the request to the tag number in
	 * the packet if the tag number in the request is still QMP_ANY
	 */
	if (req->hdr.tag == QMP_ANY)
	  req->hdr.tag = packet->tag;

	/* Increase number of finished qbuf */
	QMP_INC_REQ_NUM_QBUFS_DONE(req);

	if (QMP_REQ_NUM_QBUFS_DONE(req) == QMP_REQ_NUM_QBUFS_NEEDED(req)) {
	  QMP_DEBUG(QMP_DBGLVL_RECV, "Match posted all packets for receiving memory %p and len %d with tag = %d. \n", QMP_REQ_USERBUF(req), QMP_REQ_USERBUFLEN(req), QMP_PACKET_TAG((&(req->hdr))));

	  /* Set state of this request to IDLE */
	  QMP_SET_REQ_STATE(req, QMP_MH_IDLE);

	  /* Remove this list from preposted list */
	  QMP_RM_REQ_FROM_POSTED_LIST(req,port->conn);
	}
	/* Now I am done with this receive request */
	break;
      }
    }
    req = req->next;
  }
  
  if (found) 
    return QMP_TRUE;

  return QMP_FALSE;
}


/**
 * Check whether a packet match a preposted rdma receiving request
 */
static inline QMP_bool_t
qmp_match_posted_rdma_buf_i (QMP_packet_t* packet,
			      QMP_qbuf_t* qbuf,
			      QMP_gige_port_t* port,
			      QMP_machine_t* glm)
{
  QMP_request_t* req;
  int            found;
  QMP_status_t   status;
  QMP_rdma_packet_t* rdmap;
  QMP_u32_t      sendid;

  QMP_TRACE("qmp_match_posted_rdma_buf_i");

  found = 0;
  sendid = 0;

  req = port->conn->posted_recv_list;

  while (req) {

_qmp_rdma_match_0:
    if (QMP_CAN_RECV (packet, (&(req->hdr))) ) {
      rdmap = (QMP_rdma_packet_t *)packet;

      /* Now check buffer len is ok */

      if (req->memory.len == rdmap->rdma.len) {
	found = 1;
	/* Remember the sender's id */
	sendid = rdmap->rdma.sid;

	QMP_DEBUG (QMP_DBGLVL_RDMA, 
		   "Qbuf find a match on the posted list: \n");
	QMP_DEBUG (QMP_DBGLVL_RDMA,
		   "Request has tag %d src %d dest %d and packet has tag %d send id %d recv id %d\n",
		   req->hdr.tag, req->hdr.source, req->hdr.dest, 
		   rdmap->hdr.tag, rdmap->rdma.sid, rdmap->rdma.rid);

	/* Now let us set tag number in the request to the tag number in
	 * the packet if the tag number in the request is still QMP_ANY
	 */
	if (req->hdr.tag == QMP_ANY)
	  req->hdr.tag = packet->tag;

	/* Repost this qbuf to receive */
	QMP_set_qbuf_sendrecv_ready (qbuf, QMP_QBUF_SIZE);
    
	/* Local credits is increased here */
	if ((status = QMP_qbuf_post_recv (glm, port, qbuf)) != QMP_SUCCESS) {
	  QMP_error ("fatal : device %s cannot repost a buffer after receiving with error %s.\n",
		     port->eth_device, QMP_error_string (status));
	  exit (1);
	}

	/* Remove this list from preposted list */
	QMP_RM_REQ_FROM_POSTED_LIST(req, port->conn);

	/* This request has no more interesting for the received qbuf */
	QMP_SET_REQ_QBUF(req, 0);

	qmp_send_rdma_reply_i (req, sendid, port, glm);
	break;
      }
    }
    else {
      /* Check whether there is a matching buffer posted by IMMEDIATE_DATA
       * since we are doing synchronized RDMA for small messages
       */
      if (QMP_MATCH (packet, (&(req->hdr))) && 
	  req->hdr.op == QMP_IMMEDIATE_DATA) {
	/* Now we need to change this request to RDMA */
	QMP_regmem_entry_t* regmem;
	void* buf;
	QMP_u32_t len;

	buf = QMP_REQ_USERBUF(req);
	len = QMP_REQ_USERBUFLEN(req);
	regmem = QMP_regmem_register (glm,
				     QMP_PORT_REGMEM_TABLE(port),
				     buf, len);
	if (!regmem) {
	  QMP_error ("Fatal: cannot register memory for receiving at address %p and length %d.\n", buf, len);
	  QMP_abort (1);
	}
	QMP_SET_REQ_MEMHANDLE(req,regmem->mem_handle);
	/* Set number of needed qbufs */
	QMP_SET_REQ_NUM_QBUFS_NEEDED(req,QMP_RDMA_NUM_QBUFS_NEEDED(len));

	req->hdr.op = QMP_RDMA_PUT;
	/* Let us do regular RDMA match */
	goto _qmp_rdma_match_0;
      }
    }
    req = req->next;
  }
  
  if (found) 
    return QMP_TRUE;

  return QMP_FALSE;
}

/**
 * Check whether a receive request match any received but not yet
 * claimed buffer.
 */
static inline QMP_bool_t
qmp_match_not_claimed_buf_i (QMP_request_t* recvreq,
			     QMP_gige_port_t* port,
			     QMP_machine_t* glm)
{
  QMP_request_t  *req, *nreq;
  QMP_packet_t*  packet;
  int            found;
  QMP_status_t   status;

  QMP_TRACE("qmp_match_not_claimed_buf_i");

  /* This is the request on the not claimed list */
  req = port->conn->not_claimed_buf_list;
  found = 0;

  while (req) {
    /* this is next request object in the list in case the current request
     * is removed from the list 
     */
    nreq = req->next;

    /* Those requests all have qbuf pointer */
    packet = (QMP_packet_t *)(req->qbuf->buffer);

_qmp_rdam_not_claimed_0:

    if (QMP_CAN_RECV(packet, (&(recvreq->hdr)))) {
      switch (packet->op) {
      case QMP_IMMEDIATE_DATA:
	{
	  QMP_idata_packet_t *datap = (QMP_idata_packet_t *)packet;

	  /* Now check buffer len if ok, copy it */
	  if (recvreq->memory.len == QMP_IDATA_LEN(datap)) {
	    /* My request matches a qbuf from a not claimed buffer */
	    QMP_REQ_MATCH_IDATA_BUFFER(recvreq, req->qbuf, status, 
				       QMP_IDATA_OFFSET(datap),
				       QMP_IDATA_PAYLOAD_LEN(datap),
				       port, glm);



	    QMP_DEBUG(QMP_DBGLVL_RECV, "Received idata (matching not claimed buffer) for total len %d offset %d payload %d with tag %d with ivalue = %d.\n", QMP_IDATA_LEN(datap), QMP_IDATA_OFFSET(datap), QMP_IDATA_PAYLOAD_LEN(datap), QMP_PACKET_TAG(packet), (*(int *)(req->qbuf->buffer + sizeof (QMP_idata_packet_t))));

	    /* Now let us set tag number in the request to the tag number in
	     * the packet if the tag number in the request is still QMP_ANY
	     */
	    if (req->hdr.tag == QMP_ANY)
	      recvreq->hdr.tag = packet->tag;
	    
	    /* Remove this request from not claimed list */
	    QMP_RM_REQ_FROM_RECVED_LIST(req, port->conn);
    
	    /* Now I do not need request in the received list anymore */
	    QMP_RELEASE_REQUEST(glm, req);


	    /* Increase number of finished qbuf */
	    QMP_INC_REQ_NUM_QBUFS_DONE(recvreq);

	    if (QMP_REQ_NUM_QBUFS_DONE(recvreq) == QMP_REQ_NUM_QBUFS_NEEDED(recvreq)) {
	      /* Set state to idle */
	      QMP_SET_REQ_STATE(recvreq, QMP_MH_IDLE);

	      QMP_DEBUG(QMP_DBGLVL_RECV, 
			"Received all packets for data buffer %p len %d tag = %d.\n",
			QMP_REQ_USERBUF(recvreq), QMP_REQ_USERBUFLEN(recvreq),
			QMP_PACKET_TAG((&(recvreq->hdr))));

	      found = 1;

	    }
	  }
	}
	break;
      case QMP_RDMA_PUT:
	{
	  QMP_u32_t sendid;
	  QMP_rdma_packet_t *rdmap = (QMP_rdma_packet_t *)packet;

	
	  /* Now check buffer len if ok, */
	  if (recvreq->memory.len >= rdmap->rdma.len) {
	    found = 1;

	    /* keep track sender's sendid */
	    sendid = rdmap->rdma.sid;

	    QMP_DEBUG (QMP_DBGLVL_RDMA, 
		       "This rdma put request matches a not claimed qbuf.\n");
	    QMP_DEBUG (QMP_DBGLVL_RDMA,
		       "Request has tag %d and packet has tag %d src = %d dest = %d send id %d recv id %d \n",
		       recvreq->hdr.tag, rdmap->hdr.tag, rdmap->hdr.source, rdmap->hdr.dest,
		       rdmap->rdma.sid, rdmap->rdma.rid);
	    /* Now let us set tag number in the request to the tag number in
	     * the packet if the tag number in the request is still QMP_ANY
	     */
	    if (req->hdr.tag == QMP_ANY)
	      recvreq->hdr.tag = packet->tag;

	    /* This request is not finished yet but its qbuf is reposted */
	    /* Repost this qbuf to receive */
	    QMP_set_qbuf_sendrecv_ready (req->qbuf, QMP_QBUF_SIZE);
    
	    if ((status = QMP_qbuf_post_recv (glm, port, req->qbuf)) 
		!= QMP_SUCCESS) {
	      QMP_error ("fatal : device %s cannot repost a buffer after receiving with error %s.\n",
			 port->eth_device, QMP_error_string (status));
	      exit (1);
	    }
	    
	    /* This request has no more interesting for the received qbuf */
	    QMP_SET_REQ_QBUF(req, 0);

	    /* Remove this request from not claimed list */
	    QMP_RM_REQ_FROM_RECVED_LIST(req, port->conn);

	    /* Now I do not need request in the received list anymore */
	    QMP_RELEASE_REQUEST(glm, req);
	    
	    qmp_send_rdma_reply_i (recvreq, sendid, port, glm);
	  }
	}
	break;
      default:
	QMP_error ("Unimpemented opereation %d\n", packet->op);
	exit (1);
      }
    }
    else {
      if (QMP_MATCH(packet, (&(recvreq->hdr))) && 
	  recvreq->hdr.op == QMP_IMMEDIATE_DATA && packet->op == QMP_RDMA_PUT){
	/**
	 * The other end is doing synchronzed send, so we switch
	 * this request into RDMA
	 */
	QMP_u32_t len;
	void* buf;
	QMP_regmem_entry_t* regmem = 0;

	buf = QMP_REQ_USERBUF (recvreq);
	len = QMP_REQ_USERBUFLEN (recvreq);
	regmem = QMP_regmem_register (glm,
				      QMP_PORT_REGMEM_TABLE(port),
				      buf, len);
	if (!regmem) {
	  QMP_error ("Fatal: synchronized recv cannot register memory for receiving at address %p and length %d.\n", buf, len);
	  QMP_abort (1);
	}
	QMP_SET_REQ_MEMHANDLE(recvreq,regmem->mem_handle);
	QMP_SET_REQ_NUM_QBUFS_NEEDED(recvreq,QMP_RDMA_NUM_QBUFS_NEEDED(len));

	/* Finally change protocol number */
	recvreq->hdr.op = QMP_RDMA_PUT;


	/* Go to regular RDMA match */
	goto _qmp_rdam_not_claimed_0;
      }
    }

    if (found)
      return QMP_TRUE;

    req = nreq;
  }

  return QMP_FALSE;
	  
}

/**
 * Fast recv from a neighbor using a VIA connection
 */
QMP_status_t
QMP_irecv_direct (void* buf, QMP_u32_t count, QMP_datatype_t datatype,
		  QMP_u16_t src, QMP_u16_t tag, QMP_gige_port_t *port, 
		  QMP_machine_t* glm, QMP_request_t** request)
{
  QMP_u32_t len;
  QMP_request_t* recvreq = 0;
  QMP_packet_t* packet = 0;
  QMP_regmem_entry_t* regmem = 0;
  QMP_u32_t protocol;

  QMP_TRACE ("QMP_irecv_direct");

  /* get total data len of the receiving buffer */
  len = count * QMP_DATA_SIZE(datatype);

  /* Check whether we are receiving immediate data or not */
  if (len <= QMP_MEMCPY_THRESHOLD) 
    protocol = QMP_IMMEDIATE_DATA;
  else {
    regmem = QMP_regmem_register (glm,
				  QMP_PORT_REGMEM_TABLE(port),
				  buf, len);
    if (!regmem) {
      QMP_error ("Fatal: cannot register memory for receiving at address %p and length %d.\n", buf, len);
      QMP_abort (1);
    }
    protocol = QMP_RDMA_PUT;
  }

  /* Get a recv request from the free list */
  QMP_GET_REQUEST(glm,recvreq, QMP_MH_RECV);

  /* Set request hdr information */
  packet = &recvreq->hdr;
  QMP_SET_PACKET(packet,protocol,
		 port->conn->local_tokens,port->conn->remote_tokens,
		 src, QMP_PHYS_RANK(port->phys), tag);

  /* Set various recv request information */
  QMP_SET_REQ_RID(recvreq,port->conn);
  QMP_SET_REQ_QBUF(recvreq, 0);
  QMP_SET_REQ_USERBUF(recvreq,buf);
  QMP_SET_REQ_USERBUFLEN(recvreq,len);
  if (regmem)
    QMP_SET_REQ_MEMHANDLE(recvreq,regmem->mem_handle);
  QMP_SET_REQ_COUNT(recvreq,count);
  QMP_SET_REQ_DATATYPE(recvreq,datatype);
  QMP_SET_REQ_PORT(recvreq,port);

  if (protocol == QMP_IMMEDIATE_DATA) 
    /* Set number of needed qbufs */
    QMP_SET_REQ_NUM_QBUFS_NEEDED(recvreq,QMP_IDATA_NUM_QBUFS_NEEDED(len));
  else
    /* Set number of needed qbufs */
    QMP_SET_REQ_NUM_QBUFS_NEEDED(recvreq,QMP_RDMA_NUM_QBUFS_NEEDED(len));


  QMP_DEBUG(QMP_DBGLVL_REQUEST, "Post a receiving request.\n");
  QMP_DUMP_REQUEST(recvreq);
  QMP_DEBUG(QMP_DBGLVL_REQUEST, "\n");

  /* first check whether there is a buffer inside the list of
   * not claimed.
   */
  if (qmp_match_not_claimed_buf_i (recvreq, port, glm)) 
    *request = recvreq;
  else {
    QMP_DEBUG(QMP_DBGLVL_RECV, "Irecv does not match not claimed list.\n");
    QMP_ADD_REQ_TO_POSTED_LIST(recvreq, port->conn);
    *request = recvreq;
  }

  return QMP_SUCCESS;
}


/**
 * Recv from a switched port using a VIA connection
 */
QMP_status_t
QMP_irecv_switch (void* buf, QMP_u32_t count, QMP_datatype_t datatype,
		  QMP_u16_t src, QMP_u16_t tag, QMP_gige_port_t *port, 
		  QMP_machine_t* glm, 
		  QMP_request_t** request)
{
  QMP_status_t status;

  QMP_TRACE ("QMP_irecv_switch");

  if (!port->active) {
    /**
     * If this port is not connected, we do connection now
     */
    if (QMP_open_via_switch_port (glm, port) != QMP_SUCCESS) {
      QMP_error ("cannot open via switch connection port from %s to %s\n",
		 port->eth_device, port->peer_via_host);
      exit (1);
    }
    QMP_info ("Using switch network to recv from %s to %s\n",
	      port->eth_device, port->peer_via_host);
  }


  status = QMP_irecv_direct (buf, count, datatype, src, tag, port, glm,
			     request);

  if (status != QMP_SUCCESS) {
    qmp_close_via_connection_i (port);
    QMP_remove_viacq (glm, port->viadev->cq);
  }

  return status;
}


/**
 * Start a general message receiving
 *
 * Direction of receiving. +1 and -1 for postive and negtive axis
 */
QMP_status_t
QMP_irecv (void* buf, QMP_u32_t count, QMP_datatype_t datatype,
	   QMP_u16_t src, QMP_u16_t tag, QMP_s16_t direction,
	   QMP_machine_t* glm, QMP_request_t** request)
{
  QMP_u16_t psrc;
  QMP_gige_port_t* port;

  QMP_TRACE ("QMP_irecv");

  /**
   * First convert destination rank to physical rank
   */
  if (!glm->tpl)
    psrc = src;
  else 
    psrc = QMP_logical_to_allocated (src);

  /**
   * Secondly check whether this destination can be reached
   * by mesh conenctions.
   */
  port = QMP_get_connection_port (glm, psrc, direction, QMP_MH_RECV);

  if (port->type == QMP_CONN_DIRECT) 
    /* This is a directly connected */
    return QMP_irecv_direct (buf, count, datatype,
			     psrc, tag, port, glm,
			     request);
  else
    return QMP_irecv_switch (buf, count, datatype,
			     psrc, tag, port, glm, request);
}

/**
 * Processing receiving messages
 *
 * Return a corresponding gigeport
 */
static QMP_gige_port_t *
qmp_process_via_recv_i (QMP_machine_t* glm,
			QMP_gige_port_t* p,
			VIP_VI_HANDLE vi)
{
  QMP_qbuf_t* qbuf = 0;
  QMP_packet_t* packet = 0;
  QMP_gige_port_t* port = 0;
  QMP_request_t* req = 0;
  VIP_DESCRIPTOR *descp = 0;
  VIP_RETURN    status;

  QMP_TRACE ("qmp_process_vi_recv_i");

  if ((status = VipRecvDone (vi, (VIP_DESCRIPTOR **) &qbuf)) != VIP_SUCCESS) {
    QMP_error ("fatal: corruption in qmp_process_vi_recv_i: status=%d\n",status);
    exit (1);
  }
  

  if (qbuf) {
    /* This is ok since the first element of qbuf is descp */
    descp = (VIP_DESCRIPTOR *)qbuf;
    if (descp->CS.Status & VIP_STATUS_ERROR_MASK) {
      QMP_error ("fatal error: via descriptor error in receiving status %x Error = %x.\n",
		 descp->CS.Status, descp->CS.Status & VIP_STATUS_ERROR_MASK);
      exit (1);
    }
  }


  /** 
   * Get application data from vi to figure out which port we are 
   * receiving from
   */
  QMP_mvia_get_vi_app_data (vi, (void **)&port);
  
  /* Descrease local token number by one */
  QMP_DEBUG (QMP_DBGLVL_TOKEN,
	     "Process Recv: Port %p now has %d local tokens.\n",
	     port, port->conn->local_tokens);

  if (descp->CS.Status != QMP_RDMA_STATUS) {
    /* This is reguler send using packets */

    /**
     * Get protocol header
     */
    packet = (QMP_packet_t *)qbuf->buffer;
    
    QMP_DEBUG(QMP_DBGLVL_PACKET, "Received a packet as the following.\n");
    QMP_DUMP_PACKET(packet);
    QMP_DEBUG(QMP_DBGLVL_PACKET, "\n");

    /* Update remote tokens number */
    port->conn->remote_tokens += packet->num_qbufs;

    QMP_DEBUG(QMP_DBGLVL_TOKEN, "Process recv: port %p now has remote tokens %d with addition %d\n",
	      port, port->conn->remote_tokens, packet->num_qbufs);
    

    
    if (packet->remote_qbufs <= QMP_TOKEN_NOTIFY_THRESHOLD) {
      /* Now my peer thinks I am running out tokens */
      port->conn->notify_peer = QMP_TRUE;
      QMP_DEBUG(QMP_DBGLVL_TOKEN, "Port %p Set notify peer flag to true since my peer only has %d remote tokens.\n", 
		port, packet->remote_qbufs);
    }

    switch (packet->op) {
    case QMP_IMMEDIATE_DATA:
      if (!qmp_match_posted_idata_buf_i (packet, qbuf, port, glm)) {
	/* Get a request to help establish a linked list */
	QMP_GET_REQUEST(glm,req, QMP_MH_RECV);
	QMP_SET_REQ_QBUF(req,qbuf);

	QMP_ADD_REQ_TO_RECVED_LIST(req,port->conn);
	QMP_DEBUG (QMP_DBGLVL_RECV, "Packet does not match posted request.\n");
      }
      break;
    case QMP_RDMA_PUT:
      QMP_DEBUG (QMP_DBGLVL_RDMA, "Received a RDMA PUT Packet.\n");

      if (!qmp_match_posted_rdma_buf_i (packet, qbuf, port, glm)) {
	/* not matching, we create a new request a put on the not claimed list */
	QMP_DEBUG (QMP_DBGLVL_RDMA, "QMP_process_via_recv: recv a RDMA packet not maching posted buffer.\n");
	
	QMP_GET_REQUEST(glm,req, QMP_MH_RECV);
	
	QMP_SET_REQ_QBUF(req,qbuf);
    
	QMP_ADD_REQ_TO_RECVED_LIST(req,port->conn);
      }
      break;
    case QMP_RDMA_PUT_REPLY:
      QMP_DEBUG (QMP_DBGLVL_RDMA, "Received a RDMA PUT REPLY packet.\n");
      
      {
	QMP_rdma_packet_t *rp = (QMP_rdma_packet_t *)packet;
	
	/* First find out which send request generated this RDMA PUT */
	QMP_DEBUG (QMP_DBGLVL_RDMA, "This packet has tag %d src %d dest %d sid %d recv id %d\n",
		   rp->hdr.tag, rp->hdr.source, rp->hdr.dest, rp->rdma.sid, rp->rdma.rid);

	QMP_GET_REQ_FROM_SENTLIST(req, port->conn, rp->rdma.sid);

	if (!req) {
	  QMP_error ("fatal: no body generated this QMP_RDMA request with send id %d \n", 
		     rp->rdma.sid);
	  exit (1);
	}

	/* Get receive id from rdma packet and update this request receive id */
	QMP_SET_REQ_RECVID(req,rp->rdma.rid);
	
	/**
	 * Now retrieve remote memory information from incoming rdma
	 * packet.
	 */
	QMP_SET_REQ_REM_MEMORY_FROM_RDMA_PACKET(req,rp);

	/* Now we should repost this qbuf */
	QMP_set_qbuf_sendrecv_ready (qbuf, QMP_QBUF_SIZE);
    
	/* Local credits is increased here */
	if ((status = QMP_qbuf_post_recv (glm, port, qbuf)) != QMP_SUCCESS) {
	  QMP_error ("fatal : device %s cannot repost a buffer after receiving with error %s.\n",
		     port->eth_device, QMP_error_string (status));
	  exit (1);
	}
	
	
	/**
	 * Now we can start a rdma put operation using
	 * all information collected inside this request
	 */
	qmp_start_rdma_put_i (req, port, glm);
      }
      break;
    case QMP_NO_OP:
      /* don't care but NO OP packet */
      QMP_DEBUG(QMP_DBGLVL_RECV, "Received a NOOP packet, do nothing\n");
      /* Repost this qbuf to receive */
      QMP_set_qbuf_sendrecv_ready (qbuf, QMP_QBUF_SIZE);
    
      /* Local credits is increased here */
      if ((status = QMP_qbuf_post_recv (glm, port, qbuf)) != QMP_SUCCESS) {
	QMP_error ("fatal : device %s cannot repost a buffer after receiving with error %s.\n",
		   port->eth_device, QMP_error_string (status));
	exit (1);
      }
      break;
    case QMP_QUERY:
      /* I need send back a packet to notify other side token numbers */
      QMP_DEBUG(QMP_DBGLVL_RECV, "Received a Query packet, send back token number %d \n", port->conn->local_tokens);
      
      QMP_isend_nodata (port->peer->rank, QMP_QUERY_REPLY, 0, 0, port, glm);
      
      /* Repost this qbuf to receive */
      QMP_set_qbuf_sendrecv_ready (qbuf, QMP_QBUF_SIZE);
    
      /* Local credits is increased here */
      if ((status = QMP_qbuf_post_recv (glm, port, qbuf)) != QMP_SUCCESS) {
	QMP_error ("fatal : device %s cannot repost a buffer after receiving with error %s.\n",
		   port->eth_device, QMP_error_string (status));
	exit (1);
      }
      break;
    case QMP_QUERY_REPLY:
      QMP_DEBUG(QMP_DBGLVL_RECV, "Received a Query Reply packet, do nothing\n"); 
      /* Repost this qbuf to receive */
      QMP_set_qbuf_sendrecv_ready (qbuf, QMP_QBUF_SIZE);
    
      /* Local credits is increased here */
      if ((status = QMP_qbuf_post_recv (glm, port, qbuf)) != QMP_SUCCESS) {
	QMP_error ("fatal : device %s cannot repost a buffer after receiving with error %s.\n",
		   port->eth_device, QMP_error_string (status));
	exit (1);
      }
      break;
    default:
      QMP_error ("fatal: have not done this protocol yet,\n");
      exit (1);
      break;
    }
  }
  else {
    /**
     * This is the finish of the RDMA write. We get immediate data from
     * this descriptor. The immediate is actually the receiving id set
     * by RDMA_PUT_REPLY packet. We use this receiving id to find
     * request that is in the RDMA_LIST
     */
    QMP_GET_REQ_FROM_RDMALIST(req, port->conn,
			      descp->CS.ImmediateData);
    
    if (!req) {
      QMP_error ("Fatal: nobody is having this receiving id %d\n",
		 descp->CS.ImmediateData);
      exit (1);
    }

    QMP_DEBUG(QMP_DBGLVL_RDMA, "Received a RDMA finish descriptor with receiving id %d. Number of QBUF done = %d\n", descp->CS.ImmediateData, req->num_qbufs_done);

    /* Increase number of finished qbuf */
    QMP_INC_REQ_NUM_QBUFS_DONE(req);

    /* If there are many rdma qbufs coming, my peer may need notification
     * of my local tokens */
    if (QMP_REQ_NUM_QBUFS_DONE(req) % 5 == 0)
      port->conn->notify_peer = QMP_TRUE;

    if (QMP_REQ_NUM_QBUFS_DONE(req) == QMP_REQ_NUM_QBUFS_NEEDED(req)) {
      QMP_DEBUG(QMP_DBGLVL_RDMA, "RDMA receiving id %d. Done.\n", descp->CS.ImmediateData, req->num_qbufs_done);
      QMP_SET_REQ_STATE(req, QMP_MH_IDLE);
      QMP_RM_REQ_FROM_RDMALIST(req,port->conn);
    }

    /* Repost this buffer */
    QMP_set_qbuf_sendrecv_ready (qbuf, QMP_QBUF_SIZE);
    if (QMP_qbuf_post_recv (glm, port, qbuf) != QMP_SUCCESS) {
      QMP_error ("fatal:device %s cannot repost a buffer after receiving.\n",
		 port->eth_device);
      exit (1);
    }


  }
  

  /* Check whether there are pending sends */
  /*
  if (!QMP_PEND_SENDLIST_EMPTY(port->conn))
    qmp_flush_pending_send_i (port, glm);
  */
  return port;
}

/**
 * Processing Sent Messages
 *
 * Return a corresponding gige port
 */
static QMP_gige_port_t*
qmp_process_via_send_i (QMP_machine_t* glm,
		       QMP_gige_port_t* p,
		       VIP_VI_HANDLE vi)
{
  QMP_qbuf_t* qbuf;
  QMP_packet_t* packet;
  VIP_DESCRIPTOR* descp;
  VIP_RETURN status;
  QMP_request_t*  sendreq;
  QMP_gige_port_t* port;
  
  QMP_TRACE ("qmp_process_vi_send_i");

  if ((status = VipSendDone (vi, (VIP_DESCRIPTOR **) &qbuf)) != VIP_SUCCESS) {
    QMP_error ("fatal: corruption in qmp_process_vi_send_i: status=%d\n",status);
    exit (1);
  }
  

  /* check descriptor for errors. */
  /* descriptor is the first element of the qbuf */
  descp = (VIP_DESCRIPTOR *)qbuf;

  if (descp->CS.Status & VIP_STATUS_ERROR_MASK) {
    QMP_error("qmp_process_send error: descriptor status %x error %x\n",
	      descp->CS.Status, descp->CS.Status & VIP_STATUS_ERROR_MASK);
    exit (1);
  }
  
  /* Get packet header */
  packet = (QMP_packet_t *)qbuf->buffer;

  /* Get send request from this qbuf */
  sendreq = (QMP_request_t *)qbuf->req;

  /* Get corresponding port */
  QMP_mvia_get_vi_app_data (vi, (void **)&port);

  switch (packet->op) {
  case QMP_IMMEDIATE_DATA:
    /* Increase number of QBUF done */
    QMP_INC_REQ_NUM_QBUFS_DONE(sendreq);

    QMP_DEBUG(QMP_DBGLVL_SEND, "Sent out a qbuf with total len %d offset %d and payload len %d with tag %d with value = %d \n",  
	      QMP_IDATA_LEN(((QMP_idata_packet_t *)packet)),
	      QMP_IDATA_OFFSET(((QMP_idata_packet_t *)packet)),
	      QMP_IDATA_PAYLOAD_LEN(((QMP_idata_packet_t *)packet)),
	      QMP_PACKET_TAG(packet),
	      (*(int *)(qbuf->buffer + sizeof (QMP_idata_packet_t))));

    if (QMP_REQ_NUM_QBUFS_DONE(sendreq) == QMP_REQ_NUM_QBUFS_NEEDED(sendreq)){
      QMP_SET_REQ_STATE(sendreq, QMP_MH_IDLE);


      QMP_DEBUG(QMP_DBGLVL_REQUEST, "Send request is done.\n");
      QMP_DUMP_REQUEST(sendreq);
      QMP_DEBUG(QMP_DBGLVL_REQUEST, "\n");

      QMP_DEBUG(QMP_DBGLVL_SEND, "A packet of user memory %p and len %d has been sent out with value = %d. \n", QMP_REQ_USERBUF(sendreq), QMP_REQ_USERBUFLEN(sendreq), 
		(*(int *)QMP_REQ_USERBUF(sendreq)));
    }
    /* release qbuf */
    QMP_release_qbuf (&(port->conn->send_qbufs), qbuf);

    /* Do not release the send request yet, user will release it */
    break;
  case QMP_RDMA_PUT:
    QMP_DEBUG(QMP_DBGLVL_RDMA, "Sent out a RDMA put request.\n");
    QMP_DEBUG(QMP_DBGLVL_RDMA, "This request has tag %d src %d dest %d and send id %d recv id %d local addr=%p len = %d mem_handle=0x%x\n",
	      sendreq->hdr.tag, sendreq->hdr.source, sendreq->hdr.dest,
	      sendreq->memory.sid, sendreq->memory.rid,
	      sendreq->memory.address, sendreq->memory.len, 
	      sendreq->memory.mem_handle);

    /* release qbuf */
    QMP_release_qbuf (&(port->conn->send_qbufs), qbuf);

    /* Reset qbuf pointer inside the request to NULL */
    QMP_SET_REQ_QBUF(sendreq, 0);

    /* Add this request to the sent list */
    /*
    QMP_ADD_REQ_TO_SENTLIST(sendreq,port->conn);
    */

    break;
  case QMP_RDMA_PUT_REPLY:
    /* release qbuf */
    QMP_release_qbuf (&(port->conn->send_qbufs), qbuf);

    QMP_DEBUG(QMP_DBGLVL_RDMA, "Sent out a RDMA PUT REPLAY .\n");
    QMP_DEBUG(QMP_DBGLVL_RDMA, "This request has tag %d src %d dest %d and send id %d recv id %d\n",
	      sendreq->hdr.tag, sendreq->hdr.source, sendreq->hdr.dest, 
	      sendreq->memory.sid, sendreq->memory.rid);

    /* Reset qbuf pointer inside the request to NULL */
    QMP_SET_REQ_QBUF(sendreq, 0);

    /* Add this request to the sent list */
    /*
    QMP_ADD_REQ_TO_RDMALIST (sendreq,port->conn);
    */
    break;
    
  case QMP_RDMA_PUT_FINISH:
    /* Increase number of QBUF done */
    QMP_INC_REQ_NUM_QBUFS_DONE(sendreq);

    if (QMP_REQ_NUM_QBUFS_DONE(sendreq) == QMP_REQ_NUM_QBUFS_NEEDED(sendreq)){
      /* Now I am done with this send, finally */
      /* This packety will not travel over the net */
      QMP_SET_REQ_STATE(sendreq, QMP_MH_IDLE);
      QMP_DEBUG(QMP_DBGLVL_RDMA, "RDMA Write is done .\n");
      QMP_DEBUG(QMP_DBGLVL_RDMA, "Local memory addr=%p len = %d mem_handle=0x%x\n",
		sendreq->memory.address, sendreq->memory.len, 
		sendreq->memory.mem_handle);
      QMP_DEBUG(QMP_DBGLVL_RDMA, "Remote memory addr=%p len = %d mem_handle=0x%x\n",
		sendreq->remote_memory.address, sendreq->remote_memory.len, 
		sendreq->remote_memory.mem_handle);

      /* Reset qbuf pointer inside the request to NULL */
      QMP_SET_REQ_QBUF(sendreq, 0);

      /* Remove this request from sent list */
      QMP_RM_REQ_FROM_SENTLIST(sendreq, port->conn);
    }
    /* release qbuf */
    QMP_release_qbuf (&(port->conn->send_qbufs), qbuf);

    break;
  case QMP_NO_OP:
  case QMP_QUERY_REPLY:
  case QMP_QUERY:

    /* release qbuf */
    QMP_release_qbuf (&(port->conn->send_qbufs), qbuf);

    QMP_DEBUG(QMP_DBGLVL_SEND, "NO OP Send request is done.\n");
    QMP_DUMP_REQUEST(sendreq);
    QMP_DEBUG(QMP_DBGLVL_SEND, "\n");    

    /* We do not care about this request any more */
    QMP_RELEASE_REQUEST(glm,sendreq);
    break;
  default:
    QMP_error("not yet implemented on other protcol.\n");
    exit (1);
    break;
  }
  /* Check whether there are pending sends */
  /*
  if (!QMP_PEND_SENDLIST_EMPTY(port->conn)) 
    qmp_flush_pending_send_i (port, glm);
  */

  return port;
}

/**
 * Main loop for QMP VIA 
 * 
 * Check myport before polling of all VIA devices
 */
inline QMP_status_t
QMP_poll (QMP_machine_t* glm, QMP_gige_port_t* myport)
{
  int i, onrecvq, getsome;
  VIP_VI_HANDLE vi;
  VIP_RETURN status;
  QMP_gige_port_t* retp = 0;

  QMP_TRACE("QMP_poll");
  
  getsome = 0;
  if (myport) {
    while ((status = VipCQDone(myport->viadev->cq, 
			       &vi, &onrecvq)) == VIP_SUCCESS){
      if(onrecvq) 
	retp = qmp_process_via_recv_i (glm, myport, vi);
      else
	retp = qmp_process_via_send_i (glm, myport, vi);
      getsome = 1;
    }
    if (status != VIP_NOT_DONE) {
      QMP_error ("fatal error %s for VipCQDone for device %s. \n",
		 QMP_error_string(status), myport->eth_device);
      return status;
    }

    /* Flush out pending send request */
    if (getsome) {
      /* Check whether there are pending sends */
      if (!QMP_PEND_SENDLIST_EMPTY(retp->conn)) 
	qmp_flush_pending_send_i (retp, glm);
    }
    else {
      /* We have not received anything here, so we should get off memory bus for
       * a while then come back to check again
       */
      QMP_PORT_SPIN_LOOPS;
    }

    /* Go through all VIA devices CQ */
    for (i = 0; i < glm->numcqs; i++) {
      getsome = 0;
      while ((status = VipCQDone(glm->allcqs[i], &vi, &onrecvq)) == VIP_SUCCESS){
	if (onrecvq) 
	  retp = qmp_process_via_recv_i (glm, 0, vi);
	else
	  retp = qmp_process_via_send_i (glm, 0, vi);
	getsome = 1;
      }
      if (status != VIP_NOT_DONE) {
	QMP_error ("fatal error %s for VipCQDone for device %d. \n",
		   QMP_error_string(status), i);
	return status;
      }
      
      if (getsome) {
	if (!QMP_PEND_SENDLIST_EMPTY(retp->conn)) 
	  qmp_flush_pending_send_i (retp, glm);
      }
    }
  }
  else {
    for (i = 0; i < glm->numcqs; i++) {
      getsome = 0;
      /* There may be more */
      while ((status = VipCQDone(glm->allcqs[i], &vi, &onrecvq)) 
	     == VIP_SUCCESS){
	if (onrecvq) 
	  retp = qmp_process_via_recv_i (glm, 0, vi);
	else
	  retp = qmp_process_via_send_i (glm, 0, vi);
	getsome = 1;
      }
      if (status != VIP_NOT_DONE) {
	QMP_error ("fatal error %s for VipCQDone for device %d. \n",
		   QMP_error_string(status), i);
	return status;
      }
      
      if (getsome) {
	/* Check whether there are pending sends */
	if (!QMP_PEND_SENDLIST_EMPTY(retp->conn)) 
	  qmp_flush_pending_send_i (retp, glm);
      }
      else
	QMP_SPIN_LOOPS;
    }
  }    
  return QMP_SUCCESS;
}



/**
 * Check whether a request is complete
 */
QMP_bool_t
QMP_request_complete (QMP_machine_t* glm, QMP_request_t *request)
{
  QMP_TRACE ("QMP_request_complete");
  
  if (QMP_REQ_STATE(request) != QMP_MH_IDLE)
    QMP_poll (glm, request->port);
  
  if (QMP_REQ_STATE(request) == QMP_MH_IDLE) {
    QMP_request_done (glm, request);
    return QMP_TRUE;
  }
  return QMP_FALSE;
}


/**
 * Wait for a request to finish
 */
void
QMP_request_wait (QMP_machine_t* glm, QMP_request_t *request)
{
  QMP_TRACE ("QMP_request_wait"); 

  while (QMP_REQ_STATE(request) != QMP_MH_IDLE) 
    QMP_poll (glm, request->port);
  
  /* Now remove memory information from the RDMA hash table */
  QMP_request_done (glm, request);
}

/**
 * Blocking Send 
 */
QMP_status_t
QMP_send  (void* buf, QMP_u32_t count, QMP_datatype_t datatype,
	   QMP_u16_t dest, QMP_u16_t tag, QMP_s16_t direction)

{
  QMP_request_t* sreq;
  QMP_status_t   status;

  QMP_TRACE ("QMP_send");
  
  if ((status = QMP_isend (buf, count, datatype, dest, tag, direction,
			   &QMP_global_m,
			   &sreq)) == QMP_SUCCESS) {
    QMP_request_wait (&QMP_global_m, sreq);
    QMP_RELEASE_REQUEST((&QMP_global_m), sreq);
    return QMP_SUCCESS;
  }
  return status;
}


/**
 * Blocking Send 
 */
QMP_status_t
QMP_recv  (void* buf, QMP_u32_t count, QMP_datatype_t datatype,
	   QMP_u16_t src, QMP_u16_t tag, QMP_s16_t direction)

{
  QMP_request_t* req;
  QMP_status_t   status;

  QMP_TRACE ("QMP_recv");
  
  if ((status = QMP_irecv (buf, count, datatype, src, tag, direction,
			   &QMP_global_m,
			   &req)) == QMP_SUCCESS) {
    QMP_request_wait (&QMP_global_m, req);
    QMP_RELEASE_REQUEST((&QMP_global_m), req);
    return QMP_SUCCESS;
  }
  return status;
}


/**
 * Blocking Direct Send using physical node id pdest
 *
 * @param: remove_buf if true this buffer will be removed from my table
 */
static QMP_status_t
qmp_direct_send_p_i  (QMP_machine_t* glm,
		      void* buf, QMP_u32_t count, QMP_datatype_t datatype,
		      QMP_u16_t pdest, QMP_u16_t tag, QMP_s16_t direction,
		      QMP_bool_t remove_buf)

{
  QMP_request_t* sreq;
  QMP_gige_port_t* port;
  QMP_status_t   status;
  
  QMP_TRACE ("qmp_direct_send_p_i");

  port = QMP_get_connection_port (glm, pdest, direction, QMP_MH_SEND);
  if (port->type == QMP_CONN_DIRECT) {
    if ((status = QMP_isend_direct (buf, count, datatype, pdest, tag,
				    port, glm, &sreq)) == QMP_SUCCESS) {
      QMP_request_wait (glm, sreq);
      QMP_RELEASE_REQUEST(glm, sreq);
    }
  }
  else {
    QMP_error ("Fatal error: expecting direct send to node %d but cannot find a path.\n", pdest);
    exit (1);
  }

  if (status == QMP_SUCCESS && count > QMP_MEMCPY_THRESHOLD && remove_buf)
    QMP_regmem_complete_remove (glm, port, buf, count);
  return status;
}


/**
 * Blocking direct recv by physical id psrc
 */
static QMP_status_t
qmp_direct_recv_p_i  (QMP_machine_t* glm,
		      void* buf, QMP_u32_t count, QMP_datatype_t datatype,
		      QMP_u16_t psrc, QMP_u16_t tag, QMP_s16_t direction,
		      QMP_bool_t remove_buf)

{
  QMP_request_t* req;
  QMP_gige_port_t* port;
  QMP_status_t   status;


  QMP_TRACE ("qmp_direct_recv_p_i");

  port = QMP_get_connection_port (glm, psrc, direction, QMP_MH_RECV);
  
  if (port->type == QMP_CONN_DIRECT) {
    if ((status = QMP_irecv_direct (buf, count, datatype, psrc, tag, 
				    port, glm,
				    &req)) == QMP_SUCCESS) {
      QMP_request_wait (glm, req);
      QMP_RELEASE_REQUEST(glm, req);
    }
  }
  else {
    QMP_error ("Fatal : expecting to receive data directly from %d node but found no path to it.\n", psrc);
    exit (1);
  }
  if (status == QMP_SUCCESS && count > QMP_MEMCPY_THRESHOLD && remove_buf)
    QMP_regmem_complete_remove (glm, port, buf, count);

  return status;
}


/***********************************************************************
 * QMP communication routines                                          *
 **********************************************************************/

/**
 * Prestage send memory for strided memory blocks
 */
static void inline
qmp_prestage_send_memory_i (QMP_msgmem_i_t* mm)
{
  int i, j, k;

  if (mm->type == QMP_MM_STRIDED_BUF) {
    QMP_strided_mem_t* smem = (QMP_strided_mem_t *)mm->special_mem;
    char* sendbuf = (char *)mm->mem;

    k = 0;
    for (i = 0; i < smem->nblocks; i++) {
      memcpy (&sendbuf[k], 
	      (char *)smem->base + i * (smem->stride + smem->blksize),
	      smem->blksize);
      k += smem->blksize;
    }
  }
  else {
    QMP_array_strided_mem_t* asmem =(QMP_array_strided_mem_t *)mm->special_mem;
    char* sendbuf = (char *)mm->mem;

    k = 0;
    for (i = 0; i < asmem->num; i++) {
      for (j = 0; j < asmem->smem[i].nblocks; j++) {
	memcpy (&sendbuf[k], 
		(char *)asmem->smem[i].base + j * (asmem->smem[i].stride + asmem->smem[i].blksize), asmem->smem[i].blksize);
	k += asmem->smem[i].blksize;
      }
    }
  }
}


/**
 * Post proces received memory for strided memory blocks
 */
static void inline
qmp_poststage_recv_memory_i (QMP_msgmem_i_t* mm)
{
  int i, j, k;

  if (mm->type == QMP_MM_STRIDED_BUF) {
    QMP_strided_mem_t* smem = (QMP_strided_mem_t *)mm->special_mem;
    char* recvbuf = (char *)mm->mem;

    k = 0;
    for (i = 0; i < smem->nblocks; i++) {
      memcpy ((char *)smem->base + i * (smem->stride + smem->blksize),
	      &recvbuf[k],
	      smem->blksize);
      k += smem->blksize;
    }
  }
  else {
    QMP_array_strided_mem_t* asmem=(QMP_array_strided_mem_t *)mm->special_mem;
    char* recvbuf = (char *)mm->mem;

    k = 0;
    for (i = 0; i < asmem->num; i++) {
      for (j = 0; j < asmem->smem[i].nblocks; j++) {
	memcpy ((char *)asmem->smem[i].base + j * (asmem->smem[i].stride + asmem->smem[i].blksize),
		&recvbuf[k],
		asmem->smem[i].blksize);
	k += asmem->smem[i].blksize;
      }
    }
  }
}

/**
 * Start of QMP communication from a message handle
 */
QMP_status_t
QMP_start (QMP_msghandle_t msgh)
{
  QMP_msghandle_i_t* mh = (QMP_msghandle_i_t *)msgh;
  QMP_msgmem_i_t* mm;
  QMP_status_t status = QMP_SUCCESS;

  QMP_TRACE ("QMP_start");

  if (mh) {
    switch (mh->type) {
    case QMP_MH_SEND:
      mm = QMP_MSGHANDLE_MEM(mh);
      
      if (mm->type == QMP_MM_USER_BUF || mm->type == QMP_MM_LEXICO_BUF)
	;
      else 
	qmp_prestage_send_memory_i (mm);

      if (mh->sh_port->type == QMP_CONN_DIRECT)
	status = QMP_isend_direct (mm->mem, mm->nbytes, QMP_CHAR,
				   mh->sh_remnode, mh->sh_tag, mh->sh_port,
				   mh->glm, &(mh->sh_request));
      else
	status = QMP_isend_switch (mm->mem, mm->nbytes, QMP_CHAR,
				   mh->sh_remnode, mh->sh_tag, mh->sh_port,
				   mh->glm, &(mh->sh_request));
      break;
    case QMP_MH_RECV:

      mm = QMP_MSGHANDLE_MEM(mh);

      if (mh->sh_port->type == QMP_CONN_DIRECT) 
	status = QMP_irecv_direct (mm->mem, mm->nbytes, QMP_CHAR,
				   mh->sh_remnode, mh->sh_tag, mh->sh_port,
				   mh->glm, &(mh->sh_request));
      else
	status = QMP_irecv_switch (mm->mem, mm->nbytes, QMP_CHAR,
				   mh->sh_remnode, mh->sh_tag, mh->sh_port,
				   mh->glm, &(mh->sh_request));
      break;
    case QMP_MH_MULTIPLE:
      {
	int i;

	for (i = 0; i < mh->mh_num; i++) 
	  QMP_start (mh->mh_handles[i]);
      }
      break;
    default:
      QMP_error ("Fatal: QMP_start tryting a msghandle with wrong type.\n");
      exit (1);
      break;
    }
  }
  else {
    QMP_error ("Cannot start a NULL message handle.\n");
    exit (1);
  }

  if (status == QMP_SUCCESS)
    QMP_MSGHANDLE_ACTIVATE(mh);

  return status;
}


/**
 * Check wehther a message handle's send/recv is done
 */
QMP_bool_t
QMP_is_complete (QMP_msghandle_t msgh)
{
  QMP_bool_t finished;
  QMP_msghandle_i_t* mh = (QMP_msghandle_i_t *)msgh;
  
  QMP_TRACE ("QMP_is_complete");

  finished = QMP_TRUE;
  if (QMP_MSGHANDLE_ACTIVE(mh)) {
    if (mh->type != QMP_MH_MULTIPLE) {
      if ((finished = QMP_request_complete (mh->glm, QMP_MSGHANDLE_REQ(mh)))==
	  QMP_TRUE) {

	/* Now I have to update tag number for this message handle */
	if (mh->type == QMP_MH_RECV && QMP_MSGHANDLE_TAG(mh) == QMP_ANY)
	  QMP_MSGHANDLE_SET_TAG(mh, mh->sh_request->hdr.tag);

	if (mh->type == QMP_MH_RECV) {
	  /* Post process memory for strided memory */
	  QMP_msgmem_i_t* mm = QMP_MSGHANDLE_MEM(mh);
	  if (mm->type == QMP_MM_USER_BUF || mm->type == QMP_MM_LEXICO_BUF)
	    ;
	  else 
	    qmp_poststage_recv_memory_i (mm);
	}

	QMP_RELEASE_REQUEST (mh->glm, mh->sh_request);
	QMP_MSGHANDLE_DEACTIVATE(mh);
	QMP_MSGHANDLE_SET_REQ(mh, 0);
      }
    }
    else if (mh->type == QMP_MH_MULTIPLE) {
      int i;

      for (i = 0; i < mh->mh_num; i++) {
	if (QMP_is_complete (mh->mh_handles[i]) != QMP_TRUE) 
	  finished = QMP_FALSE;
      }
      if (finished)
    	QMP_MSGHANDLE_DEACTIVATE(mh);
    }
  }
  
  return finished;
}

/**
 * Wait for communication to finish on a message handle
 */
QMP_status_t
QMP_wait (QMP_msghandle_t msgh)
{
  QMP_msghandle_i_t* mh = (QMP_msghandle_i_t *)msgh;

  QMP_TRACE ("QMP_wait");

  if (QMP_MSGHANDLE_ACTIVE(mh)) {
    if (mh->type != QMP_MH_MULTIPLE) {
      QMP_request_wait (mh->glm, QMP_MSGHANDLE_REQ(mh));

      /* Now I have to update tag number for this message handle */
      if (mh->type == QMP_MH_RECV && QMP_MSGHANDLE_TAG(mh) == QMP_ANY) 
	QMP_MSGHANDLE_SET_TAG(mh, mh->sh_request->hdr.tag);

      if (mh->type == QMP_MH_RECV) {
	/* Post process memory for strided memory */
	QMP_msgmem_i_t* mm = QMP_MSGHANDLE_MEM(mh);
	if (mm->type == QMP_MM_USER_BUF || mm->type == QMP_MM_LEXICO_BUF)
	  ;
	else 
	  qmp_poststage_recv_memory_i (mm);
      }

      /* release request */
      QMP_RELEASE_REQUEST (mh->glm, mh->sh_request);
      /* deactivate this message handle */
      QMP_MSGHANDLE_DEACTIVATE(mh);
      /* remove request pointer */
      QMP_MSGHANDLE_SET_REQ(mh, 0);
    }
    else if (mh->type == QMP_MH_MULTIPLE) {
      while (!QMP_is_complete (msgh))
	QMP_poll (mh->glm, 0);
    }
  }
  return QMP_SUCCESS;
}


/**
 * Wait for communication to finish for multiple message handles
 */
QMP_status_t
QMP_wait_all (QMP_msghandle_t h[], int num)
{
  int i, done;

  QMP_TRACE ("QMP_wait_all");

  done = 1;
  do {
    for (i = 0; i < num; i++) {
      if (QMP_is_complete (h[i]) != QMP_TRUE)
	done = 0;
    }
  }while (!done);
  
  return QMP_SUCCESS;
}


/************************************************************************
 *         Global communication Routines                                *
 ***********************************************************************/

static void qmp_sum_i (void* result, void* source,
		       QMP_u32_t count, QMP_datatype_t datatype)
{
  if (count == 1) {
    switch (datatype) {
    case QMP_INT:
      *(int *)result = *(int *)result + *(int *)source;
      break;
    case QMP_FLOAT:
      *(float *)result = *(float *)result + *(float *)source;
      break;
    case QMP_DOUBLE:
      *(double *)result = *(double *)result + *(double *)source;
      break;
    default:
      QMP_error ("qmp sum only supports integer, float and double\n");
      exit (1);
      break;
    }
  }
  else {
    int i;
    
    switch (datatype) {
    case QMP_INT:
      {
	int* retvalue = (int *)result;
	int* src = (int *)source;
	for (i = 0; i < count; i++) 
	  retvalue[i] = retvalue[i] + src[i];
      }
      break;
    case QMP_FLOAT:
      {
	float* retvalue = (float *)result;
	float* src = (float *)source;
	for (i = 0; i < count; i++) 
	  retvalue[i] = retvalue[i] + src[i];
      }
      break;
    case QMP_DOUBLE:
      {
	double* retvalue = (double *)result;
	double* src = (double *)source;
	for (i = 0; i < count; i++) 
	  retvalue[i] = retvalue[i] + src[i];
      }
      break;
    default:
      QMP_error ("qmp sum only supports integer, float and double\n");
      exit (1);
      break;
    }
  }
}


static void qmp_max_i (void* result, void* source,
		       QMP_u32_t count, QMP_datatype_t datatype)
{
  if (count == 1) {
    switch (datatype) {
    case QMP_INT:
      *(int *)result = ((*(int *)result) > (*(int *)source)) ? (*(int *)result): (*(int *)source);
      break;
    case QMP_FLOAT:
      *(float *)result = ((*(float *)result) > (*(float *)source)) ? (*(float *)result): (*(float *)source);
      break;
    case QMP_DOUBLE:
      *(double *)result = ((*(double *)result) > (*(double *)source)) ? (*(double *)result): (*(double *)source);
      break;
    default:
      QMP_error ("qmp sum only supports integer, float and double\n");
      exit (1);
      break;
    }
  }
  else {
    int i;
    
    switch (datatype) {
    case QMP_INT:
      {
	int* retvalue = (int *)result;
	int* src = (int *)source;
	for (i = 0; i < count; i++) 
	  retvalue[i] = (retvalue[i] > src[i]) ? retvalue[i] : src[i];
      }
      break;
    case QMP_FLOAT:
      {
	float* retvalue = (float *)result;
	float* src = (float *)source;
	for (i = 0; i < count; i++) 
	  retvalue[i] = (retvalue[i] > src[i]) ? retvalue[i] : src[i];
      }
      break;
    case QMP_DOUBLE:
      {
	double* retvalue = (double *)result;
	double* src = (double *)source;
	for (i = 0; i < count; i++) 
	  retvalue[i] = (retvalue[i] > src[i]) ? retvalue[i] : src[i];
      }
      break;
    default:
      QMP_error ("qmp sum only supports integer, float and double\n");
      exit (1);
      break;
    }
  }
}

static void qmp_min_i (void* result, void* source,
		       QMP_u32_t count, QMP_datatype_t datatype)
{
  if (count == 1) {
    switch (datatype) {
    case QMP_INT:
      *(int *)result = ((*(int *)result) < (*(int *)source)) ? (*(int *)result): (*(int *)source);
      break;
    case QMP_FLOAT:
      *(float *)result = ((*(float *)result) < (*(float *)source)) ? (*(float *)result): (*(float *)source);
      break;
    case QMP_DOUBLE:
      *(double *)result = ((*(double *)result) < (*(double *)source)) ? (*(double *)result): (*(double *)source);
      break;
    default:
      QMP_error ("qmp sum only supports integer, float and double\n");
      exit (1);
      break;
    }
  }
  else {
    int i;
    
    switch (datatype) {
    case QMP_INT:
      {
	int* retvalue = (int *)result;
	int* src = (int *)source;
	for (i = 0; i < count; i++) 
	  retvalue[i] = (retvalue[i] < src[i]) ? retvalue[i] : src[i];
      }
      break;
    case QMP_FLOAT:
      {
	float* retvalue = (float *)result;
	float* src = (float *)source;
	for (i = 0; i < count; i++) 
	  retvalue[i] = (retvalue[i] < src[i]) ? retvalue[i] : src[i];
      }
      break;
    case QMP_DOUBLE:
      {
	double* retvalue = (double *)result;
	double* src = (double *)source;
	for (i = 0; i < count; i++) 
	  retvalue[i] = (retvalue[i] < src[i]) ? retvalue[i] : src[i];
      }
      break;
    default:
      QMP_error ("qmp sum only supports integer, float and double\n");
      exit (1);
      break;
    }
  }
}

static void qmp_xor_i (void* result, void* source,
		       QMP_u32_t count, QMP_datatype_t datatype)
{
  if (count == 1) {
    switch (datatype) {
    case QMP_INT:
    case QMP_64BIT_INT:
      (*(long *)result) =  (*(long *)result) ^ (*(long *)source);
      break;
    case QMP_UNSIGNED_INT:
    case QMP_UNSIGNED_64BIT_INT:
      (*(unsigned long *)result) =  (*(unsigned long *)result) ^ (*(unsigned long *)source);      
      break;
    default:
      QMP_error ("qmp or only supports integer\n");
      exit (1);
      break;
    }
  }
  else {
    int i;
    
    switch (datatype) {
    case QMP_INT:
    case QMP_64BIT_INT:
      {
	long* retvalue = (long *)result;
	long* src = (long *)source;
	for (i = 0; i < count; i++) 
	  retvalue[i] =  retvalue[i] ^ src[i];
      }
      break;
    case QMP_UNSIGNED_INT:
    case QMP_UNSIGNED_64BIT_INT:
      {
	unsigned long* retvalue = (unsigned long *)result;
	unsigned long* src = (unsigned long *)source;
	for (i = 0; i < count; i++) 
	  retvalue[i] =  retvalue[i] ^ src[i];
      }      
    default:
      QMP_error ("qmp or only supports long integer\n");
      exit (1);
      break;
    }
  }
}


/**
 * Global arithmatic operator table.
 */
QMP_rop_t QMP_operator_table[]={
  {QMP_SUM, QMP_TRUE,  qmp_sum_i},
  {QMP_MAX, QMP_TRUE,  qmp_max_i},
  {QMP_MIN, QMP_TRUE,  qmp_min_i},
  {QMP_XOR, QMP_TRUE,  qmp_xor_i}
};


/**
 * Check whether this node is invovled in the bcast operation
 */
static inline QMP_bool_t
qmp_bcast_reduce_involved_i (QMP_u32_t* mycoord, QMP_u32_t dim, QMP_u32_t loop)
{
  int i;
  QMP_bool_t ok = QMP_TRUE;

  for (i = loop + 1; i < dim; i++) {
    if (mycoord[i] != 0) {
      ok = QMP_FALSE;
      break;
    }
  }
  return ok;
}


/**
 * Real broadcast for a meshed connection
 */
QMP_status_t
qmp_bcast_i (QMP_machine_t* glm,
	     void* buffer, QMP_u32_t count, QMP_datatype_t datatype,
	     QMP_u16_t root)
{
  QMP_status_t status = QMP_SUCCESS;
  QMP_u16_t    rank, size, left, right;
  QMP_s32_t    i;
  QMP_u32_t*    mycoord;

  QMP_TRACE ("qmp_bcast_i");

  if (count == 0) return status;
  
  size = QMP_SIZE(glm);

  if (size == 1) {
    QMP_error ("only one process in qmp_broadcast :-).");
    return QMP_INVALID_ARG;
  }

  /* Get rank and coordinate information */
  rank = QMP_MY_RANK(glm);
  mycoord = QMP_MY_COORDINATE(glm);

  for (i = 0; i < QMP_NUM_DIMENSION(glm); i++) {
    /**
     * Check whether this node involved in the bcast operation in this 
     * round: e.g. for i = 0, only nodes with coordinates like (x, 0 , 0)
     * participating bcast operation.
     */
    if (QMP_DIM_SIZE(glm,i) != 1 && qmp_bcast_reduce_involved_i (mycoord, QMP_NUM_DIMENSION(glm), i)) {
      left = QMP_MINUS_NEIGHBOR(glm,i);
      right = QMP_PLUS_NEIGHBOR(glm,i);
      if (mycoord[i] == 0) {
	/* This the root so send message out */
      
	if (left != right) {
	  /* Send to left */
	  if ((status = QMP_send(buffer,count,datatype, 
				 left, QMP_BCAST, -1)) != QMP_SUCCESS){
	    QMP_error ("BCast cannot send to the left neighbor on axis %d\n", i);
	    return status;
	  }
	}
      
	/* Send to right */
	if ((status = QMP_send(buffer,count,datatype, 
			       right, QMP_BCAST, 1)) != QMP_SUCCESS){
	  QMP_error ("BCast cannot send to the right neighbor on axis %d\n", i);
	  return status;
	}
      }
      else if (mycoord[i] < QMP_DIM_SIZE(glm,i) / 2) {
	/* Receive from left and send to the right */
	if ((status = QMP_recv (buffer, count, datatype,
				left, QMP_BCAST, -1)) != QMP_SUCCESS) {
	  QMP_error ("Bcast cannot receive from left on axis %d.\n", i);
	  return status;
	}
      
	if ((status = QMP_send (buffer, count, datatype,
				right, QMP_BCAST, 1)) != QMP_SUCCESS) {
	  QMP_error ("Bcast cannot send to right on axis %d.\n", i);
	  return status;	
	}
      }
      else if (mycoord[i] > QMP_DIM_SIZE(glm,i)/2 + 1) {
	/* Receive from right and send to the left */
	if ((status = QMP_recv (buffer, count, datatype,
				right, QMP_BCAST, 1)) != QMP_SUCCESS) {
	  QMP_error ("Bcast cannot receive from right on axis %d.\n", i);
	  return status;
	}
      
	if ((status = QMP_send (buffer, count, datatype,
				left, QMP_BCAST, -1)) != QMP_SUCCESS) {
	  QMP_error ("Bcast cannot send to left on axis %d.\n", i);
	  return status;	
	}	  
      }
      else if (mycoord[i] == QMP_DIM_SIZE(glm,i)/2) {
	/* Receive from left only */
	if ((status = QMP_recv (buffer, count, datatype,
				left, QMP_BCAST, -1)) != QMP_SUCCESS) {
	  QMP_error ("Bcast cannot receive from left on axis %d.\n", i);
	  return status;
	}
      }
      else {
	/* Receive from right only */
	if ((status = QMP_recv (buffer, count, datatype,
				right, QMP_BCAST, 1)) != QMP_SUCCESS) {
	  QMP_error ("Bcast cannot receive from right on axis %d.\n", i);
	  return status;
	}
      }
    }
  }
  return status;
}


/**
 * Broadcast from root (node 0) to every other nodes
 */
QMP_status_t
QMP_broadcast (void* buffer, QMP_u32_t nbytes)
{
  QMP_TRACE("QMP_broadcast");

  if (nbytes == QMP_DATA_SIZE (QMP_INT))
    return qmp_bcast_i (&QMP_global_m, buffer, 1, QMP_INT, 0);
  else if (nbytes == QMP_DATA_SIZE (QMP_DOUBLE))
    return qmp_bcast_i (&QMP_global_m, buffer, 1, QMP_DOUBLE, 0);
  else
    return qmp_bcast_i (&QMP_global_m, buffer, nbytes, QMP_BYTE, 0);
}


/**
 * Reduction operation: This is the opposite of broadcast
 */
static QMP_status_t
qmp_reduce_i (QMP_machine_t* glm,
	      void* sendbuf, void* recvbuf,
	      QMP_u32_t count, QMP_datatype_t datatype,
	      QMP_rop_t* op_ptr, QMP_u32_t root)
{
  QMP_opfunc uop;
  void*      buffer;
  QMP_u16_t  left, right;
  QMP_u16_t  rank, size;
  QMP_u32_t *mycoord, buflen;
  QMP_s32_t  i;
  QMP_status_t status = QMP_SUCCESS;
  
  QMP_TRACE ("qmp_reduce_i");

  if (count == 0)
    return QMP_SUCCESS;

  /* Number of nodes participating */
  size = QMP_SIZE(glm);

  if (size == 1) {
    QMP_error ("only one process in qmp_reduce :-) \n");
    return QMP_INVALID_ARG;
  }

  if (!op_ptr->commute) {
    QMP_error ("non commutitive operations should be managed by applications.");
    return QMP_NOTSUPPORTED;
  }

  /* Get rank and coordinates information */
  rank = QMP_MY_RANK (glm);
  mycoord = QMP_MY_COORDINATE(glm);

  /* Get function pointer */
  uop = op_ptr->func;

  /* Create temporary buffer */
  buflen = count * QMP_DATA_SIZE (datatype);
  buffer = QMP_memalign (buflen, QMP_MEM_ALIGNMENT);

  /* If I am not the root, then my receiver buffer may not be valid, therefore
   * I have to allocate a temporary one
   */
  if (rank != root)
    recvbuf = QMP_memalign (buflen, QMP_MEM_ALIGNMENT);
  
  /* Copy send buffer to my receiver buffer */
  memcpy( recvbuf, sendbuf, buflen);

  /**
   * Now start from higher dimension to reduce to lower dimension
   */
  for (i = QMP_NUM_DIMENSION(glm) - 1; i >= 0; i--) {
    /**
     * Check whether this node involved in the reduce operation in this 
     * round: e.g. for i = 0, only nodes with coordinates like (x, 0 , 0)
     * participating reduce operation.
     */
    if (QMP_DIM_SIZE(glm, i) != 1 && qmp_bcast_reduce_involved_i (mycoord, QMP_NUM_DIMENSION(glm), i)) {
      /* Get my left and right neighbors */
      left = QMP_MINUS_NEIGHBOR(glm,i);
      right = QMP_PLUS_NEIGHBOR(glm,i);

      if (mycoord[i] == 0) {
	/* Receive from right */
	if ((status = QMP_recv (buffer, count, datatype,
				right, QMP_REDUCE, 1)) != QMP_SUCCESS) {
	  QMP_error ("Reduce cannot receice from right on axis %d.\n", i);
	  return status;
	}

	/**
	 * Function looks like (recvbuf = recvbuf op buffer)
	 */
	(*uop) (recvbuf, buffer, count, datatype);

	if (left != right) {
	  /* More than 2 nodes */
	  if ((status = QMP_recv (buffer, count, datatype,
				  left, QMP_REDUCE, -1)) != QMP_SUCCESS) {
	    QMP_error ("Reduce cannot receive from left on axis %d .\n", i);
	    return status;
	  }
	  (*uop) (recvbuf, buffer, count, datatype);
	}
      }
      else if (mycoord[i] < QMP_DIM_SIZE(glm,i)/2) {
	/* Receive from my right and send to my left */
	if ((status = QMP_recv (buffer, count, datatype,
				right, QMP_REDUCE, 1)) != QMP_SUCCESS) {
	  QMP_error ("Reduce cannot receive from right on axis %d.\n", i);
	  return status;
	}
	/* Get result */
	(*uop) (recvbuf, buffer, count, datatype);

	if ((status = QMP_send (recvbuf, count, datatype,
				left, QMP_REDUCE, -1)) != QMP_SUCCESS) {
	  QMP_error ("Reduce cannot send to left on axis %d.\n", i);
	  return status;
	}
      }
      else if (mycoord[i] > QMP_DIM_SIZE(glm, i)/2 + 1) {
	/* Receive from left and send to my right */
	if ((status = QMP_recv (buffer, count, datatype,
				left, QMP_REDUCE, -1)) != QMP_SUCCESS) {
	  QMP_error ("Reduce cannot receive from lef on axis %d.\n", i);
	  return status;
	}
      	/* Get result */
	(*uop) (recvbuf, buffer, count, datatype);

	if ((status = QMP_send (recvbuf, count, datatype,
				right, QMP_REDUCE, 1)) != QMP_SUCCESS) {
	  QMP_error ("Reduce cannot send to right on axis %d.\n", i);
	  return status;	
	}
      }
      else if (mycoord[i] == QMP_DIM_SIZE(glm, i)/2) {
	/* Send to my left only */
	if ((status = QMP_send (recvbuf, count, datatype,
				left, QMP_REDUCE, -1)) != QMP_SUCCESS) {
	  QMP_error ("Reduce cannot send to left on axis %d.\n", i);
	  return status;
	}
      }
      else {
	/* Send to my right only */
	if ((status = QMP_send (recvbuf, count, datatype,
				right, QMP_REDUCE, 1)) != QMP_SUCCESS) {
	  QMP_error ("Reduce cannot send to right on axis %d.\n", i);
	  return status;
	}
      }
    }
  }

  if (rank != root)
    free (recvbuf);

  free (buffer);
      
  return status;
}



/**
 * There are alternatives to this algorithm, 
 *
 * This is a simple hack for now
 */
QMP_status_t
qmp_simple_all_reduce_i ( QMP_machine_t* glm, 
			  void* sendbuf, void* recvbuf, QMP_u32_t count,
			  QMP_datatype_t datatype, 
			  QMP_rop_t* op_ptr)
{
  QMP_status_t status;

  /* reduce to 0, the bcast */
  status = qmp_reduce_i (glm, sendbuf, recvbuf, count, datatype, op_ptr, 0);
  
  if (status != QMP_SUCCESS)
    return status;

  status = qmp_bcast_i (glm, recvbuf, count, datatype, 0);

  return status;
}

/**
 * This is a better all reduce algorithm compared to the above
 */
QMP_status_t
qmp_quick_all_reduce_i (QMP_machine_t* glm, 
			void* sendbuf, void* recvbuf, QMP_u32_t count,
			QMP_datatype_t datatype, 
			QMP_rop_t* op_ptr)
{
  QMP_opfunc uop;
  void       *leftrbuff, *rightrbuff;
  void       *leftsbuff, *rightsbuff;
  QMP_u16_t  left, right;
  QMP_u16_t  rank, size;
  QMP_u32_t *mycoord, buflen;
  QMP_s32_t  i, numrecved, dimsize;
  QMP_request_t *recvreql, *recvreqr, *sendreql, *sendreqr;
  QMP_status_t status = QMP_SUCCESS;
  
  QMP_TRACE ("qmp_quick_all_reduce_i");

  if (count == 0)
    return QMP_SUCCESS;

  /* Number of nodes participating */
  size = QMP_SIZE(glm);

  if (size == 1) {
    QMP_error ("only one process in qmp_reduce :-) \n");
    return QMP_INVALID_ARG;
  }

  if (!op_ptr->commute) {
    QMP_error ("non commutitive operations should be managed by applications.");
    return QMP_NOTSUPPORTED;
  }

  /* Get rank and coordinates information */
  rank = QMP_MY_RANK (glm);
  mycoord = QMP_MY_COORDINATE(glm);

  /* Get function pointer */
  uop = op_ptr->func;

  /* Algorithm works like this: Along each axis every one send to 
   * left and right of if node value or (previous step) value, and receive
   * from left and right.
   */
  
  /* Create several buffers to receive */
  buflen = count * QMP_DATA_SIZE (datatype);
  leftrbuff = QMP_memalign (buflen, QMP_MEM_ALIGNMENT);
  if (!leftrbuff) {
    QMP_error ("Cannot allocate memory for left receiving buffer. \n");
    exit (1);
  }
  rightrbuff = QMP_memalign (buflen, QMP_MEM_ALIGNMENT);
  if (!rightrbuff) {
    QMP_error ("Cannot allocate memory for right receiving buffer .\n");
    exit (1);
  }

  leftsbuff = QMP_memalign (buflen, QMP_MEM_ALIGNMENT);
  if (!leftsbuff) {
    QMP_error ("Cannot allocate memory for left sending buffer. \n");
    exit (1);
  }
  rightsbuff = QMP_memalign (buflen, QMP_MEM_ALIGNMENT);
  if (!rightsbuff) {
    QMP_error ("Cannot allocate memory for right sendinging buffer .\n");
    exit (1);
  }

  /* Copy send buffer to my receiver buffer */
  memcpy(recvbuf, sendbuf, buflen);

  /* Now start communication on each axis */
  for (i = QMP_NUM_DIMENSION(glm) - 1; i >= 0; i--) {
    /* Get dimension size on this direction */
    dimsize = QMP_DIM_SIZE(glm, i);
    if (dimsize != 1) {
      numrecved = 1;

      memcpy (leftsbuff, recvbuf, buflen);
      memcpy (rightsbuff, recvbuf, buflen);
      /* Get my left and right neighbors */
      left = QMP_MINUS_NEIGHBOR(glm,i);
      right = QMP_PLUS_NEIGHBOR(glm,i);
      
      while (numrecved < dimsize) {
	/* Post recv buffer for left and right */
	if ((status = QMP_irecv (leftrbuff, count, datatype,
				 left, QMP_ALL_REDUCE, -1,
				 glm, &recvreql)) != QMP_SUCCESS) {
	  QMP_error ("All reduce cannot receive from left on axis %d \n", i);
	  return status;
	}
	if ((status = QMP_irecv (rightrbuff, count, datatype,
				 right, QMP_ALL_REDUCE, 1,
				 glm, &recvreqr)) != QMP_SUCCESS) {
	  QMP_error ("All reduce cannot receive from right on axis %d \n", i);
	  return status;
	}

	/* Send previous left buffer to right and right buffer to left */
	if ((status = QMP_isend (leftsbuff, count, datatype,
				 left, QMP_ALL_REDUCE, -1,
				 glm, &sendreql)) != QMP_SUCCESS) {
	  QMP_error ("All reduce cannot send to left on axis %d \n", i);
	  return status;
	}
	if ((status = QMP_isend (rightsbuff, count, datatype,
				 right, QMP_ALL_REDUCE, 1,
				 glm, &sendreqr)) != QMP_SUCCESS) {
	  QMP_error ("All reduce cannot send to right on axis %d \n", i);
	  return status;
	}

	/* Wait for send to finish */
	QMP_request_wait (glm, sendreql);
	QMP_request_wait (glm, sendreqr);
	QMP_RELEASE_REQUEST(glm, sendreql);
	QMP_RELEASE_REQUEST(glm, sendreqr);

	/* Wait for receive to finish */
	QMP_request_wait (glm, recvreqr);
	QMP_request_wait (glm, recvreql);
	QMP_RELEASE_REQUEST(glm, recvreqr);
	QMP_RELEASE_REQUEST(glm, recvreql);

	if (numrecved == dimsize - 1) {
	  /* Left and right should have the same buffer */
	  (*uop) (recvbuf, leftrbuff, count, datatype);
	  numrecved += 1;
	}
	else {
	  (*uop) (recvbuf, leftrbuff, count, datatype);
	  (*uop) (recvbuf, rightrbuff, count, datatype);
	  numrecved += 2;
	}

	/* Update next send buffer using current receiving buffer */
	memcpy (leftsbuff, rightrbuff, buflen);
	memcpy (rightsbuff, leftrbuff, buflen);
      }
    }
  }
    
  /* Free memory */
  free (leftsbuff);
  free (rightsbuff);

  free (leftrbuff);  
  free (rightrbuff);

  return status;
}


#define qmp_all_reduce_i qmp_simple_all_reduce_i
/* #define qmp_all_reduce_i qmp_quick_all_reduce_i */

/**
 * My static binary reduction function which call user 
 * provided reduction function.
 */

/**
 * This is a pure hack because multiple binary reductions cannot
 * be called simultaneously 
 */
static QMP_binary_func qmp_user_bfunc_ = 0;

static void
qmp_reduce_func_i (void* inout, void* in,
		   QMP_u32_t count, QMP_datatype_t type)
{
  if (qmp_user_bfunc_)
    (*qmp_user_bfunc_)(inout, in);
}  

/**
 * Binary reduction.
 */
QMP_status_t
QMP_binary_reduction (void* lbuffer, QMP_u32_t buflen,
		      QMP_binary_func bfunc)
{
  QMP_rop_t    op_ptr;
  QMP_status_t status;
  void*        rbuffer;

  QMP_TRACE ("QMP_binary_reduction");

  /* first check whether there is a binary reduction is in session */
  if (qmp_user_bfunc_) 
    QMP_error_exit ("Another binary reduction is in progress.\n");

  rbuffer = QMP_memalign (buflen, QMP_MEM_ALIGNMENT);
  if (!rbuffer)
    return QMP_NOMEM_ERR;

  /* set up user binary reduction pointer */
  qmp_user_bfunc_ = bfunc;

  op_ptr.op = 0;
  op_ptr.commute = QMP_TRUE;
  op_ptr.func = qmp_reduce_func_i;

  status = qmp_all_reduce_i (&QMP_global_m, lbuffer, 
			     rbuffer, buflen, QMP_BYTE, &op_ptr);

  if (status == QMP_SUCCESS) 
    memcpy (lbuffer, rbuffer, buflen);
  free (rbuffer);

  /* signal end of the binary reduction session */
  qmp_user_bfunc_ = 0;

  return status;
}


/**
 * GLobal Sum of an integer
 */
QMP_status_t
QMP_sum_int (QMP_s32_t *value)
{
  QMP_s32_t rvalue;
  QMP_status_t status;
  QMP_u32_t count;

  QMP_TRACE ("QMP_sum_int");
  count = 1;
  status = qmp_all_reduce_i (&QMP_global_m, value, &rvalue,
			     count, QMP_INT, 
			     &QMP_operator_table[QMP_SUM]);
  if (status == QMP_SUCCESS)
    *value = rvalue;

  return status;
}

/**
 * GLobal Sum of a float
 */
QMP_status_t
QMP_sum_float (QMP_float_t *value)
{
  QMP_float_t rvalue;
  QMP_status_t status;

  QMP_TRACE ("QMP_sum_float");

  status = qmp_all_reduce_i (&QMP_global_m, value, &rvalue,
			     1, QMP_FLOAT, 
			     &QMP_operator_table[QMP_SUM]);

  if (status == QMP_SUCCESS)
    *value = rvalue;

  return status;
}


/**
 * GLobal Sum of a double
 */
QMP_status_t
QMP_sum_double (QMP_double_t *value)
{
  QMP_double_t rvalue;
  QMP_status_t status;

  QMP_TRACE ("QMP_sum_double");

  status = qmp_all_reduce_i (&QMP_global_m, value, &rvalue,
			     1, QMP_DOUBLE, 
			     &QMP_operator_table[QMP_SUM]);

  if (status == QMP_SUCCESS)
    *value = rvalue;

  return status;
}

/**
 * GLobal Sum of a double
 */
QMP_status_t
QMP_sum_double_extended (QMP_double_t *value)
{
  QMP_double_t rvalue;
  QMP_status_t status;

  QMP_TRACE ("QMP_sum_double_extended");

  status = qmp_all_reduce_i (&QMP_global_m, value, &rvalue,
			     1, QMP_DOUBLE, 
			     &QMP_operator_table[QMP_SUM]);

  if (status == QMP_SUCCESS)
    *value = rvalue;

  return status;
}

/**
 * Global sum of a float array.
 */
QMP_status_t
QMP_sum_float_array (QMP_float_t value[], int length)
{
  QMP_float_t* rvalue;
  QMP_status_t status;
  int          i;

  QMP_TRACE ("QMP_sum_float_array");

  rvalue = (QMP_float_t *)QMP_memalign (length * sizeof (QMP_float_t),
					QMP_MEM_ALIGNMENT);
  if (!rvalue) {
    QMP_error ("cannot allocate receiving memory in QMP_sum_float_array.");
    return QMP_NOMEM_ERR;
  }

  status = qmp_all_reduce_i (&QMP_global_m, value, rvalue,
			     length, QMP_FLOAT, 
			     &QMP_operator_table[QMP_SUM]);

  if (status == QMP_SUCCESS) {
    for (i = 0; i < length; i++)
      value[i] = rvalue[i];
  }

  free (rvalue);
  return status;
}


/**
 * Global sum of a double array.
 */
QMP_status_t
QMP_sum_double_array (QMP_double_t value[], int length)
{
  QMP_double_t* rvalue;
  QMP_status_t status;
  int          i;

  QMP_TRACE ("QMP_sum_double_array");

  rvalue = (QMP_double_t *)QMP_memalign (length * sizeof (QMP_double_t),
					 QMP_MEM_ALIGNMENT);
  if (!rvalue) {
    QMP_error ("cannot allocate receiving memory in QMP_sum_double_array.");
    return QMP_NOMEM_ERR;
  }
  status = qmp_all_reduce_i (&QMP_global_m, value, rvalue,
			     length, QMP_DOUBLE, 
			     &QMP_operator_table[QMP_SUM]);

  if (status == QMP_SUCCESS) {
    for (i = 0; i < length; i++)
      value[i] = rvalue[i];
  }

  free (rvalue);
  return status;
}

/**
 * Get maximum value of all floats
 */
QMP_status_t
QMP_max_float (QMP_float_t* value)
{
  QMP_float_t rvalue;
  QMP_status_t status;

  QMP_TRACE ("QMP_max_float");

  status = qmp_all_reduce_i (&QMP_global_m, value, &rvalue,
			     1, QMP_FLOAT, 
			     &QMP_operator_table[QMP_MAX]);

  if (status == QMP_SUCCESS)
    *value = rvalue;

  return status;
}

/**
 * Get maximum value of all doubles
 */
QMP_status_t
QMP_max_double (QMP_double_t* value)
{
  QMP_double_t rvalue;
  QMP_status_t status;

  QMP_TRACE ("QMP_max_double");

  status = qmp_all_reduce_i (&QMP_global_m, value, &rvalue,
			     1, QMP_DOUBLE, 
			     &QMP_operator_table[QMP_MAX]);

  if (status == QMP_SUCCESS)
    *value = rvalue;

  return status;
}  


/**
 * Get minimum value of all floats
 */
QMP_status_t
QMP_min_float (QMP_float_t* value)
{
  QMP_float_t rvalue;
  QMP_status_t status;

  QMP_TRACE ("QMP_min_float");

  status = qmp_all_reduce_i (&QMP_global_m, value, &rvalue,
			     1, QMP_FLOAT, 
			     &QMP_operator_table[QMP_MIN]);

  if (status == QMP_SUCCESS)
    *value = rvalue;

  return status;
}

/**
 * Get minimum value of all doubles
 */
QMP_status_t
QMP_min_double (QMP_double_t* value)
{
  QMP_double_t rvalue;
  QMP_status_t status;

  QMP_TRACE ("QMP_min_double");

  status = qmp_all_reduce_i (&QMP_global_m, value, &rvalue,
			     1, QMP_DOUBLE, 
			     &QMP_operator_table[QMP_MIN]);

  if (status == QMP_SUCCESS)
    *value = rvalue;

  return status;
}  

/**
 * Get the ored value of all long integers
 */
QMP_status_t
QMP_xor_ulong (unsigned long* value)
{
  QMP_datatype_t type;
  QMP_status_t   status;

#ifdef QMP_64BIT_LONG
  QMP_u64_t      rvalue;
  type = QMP_UNSIGNED_64BIT_INT;
#else
  QMP_u32_t    rvalue;
  type = QMP_UNSIGNED_INT;
#endif

  QMP_TRACE ("QMP_xor_ulong");

  status = qmp_all_reduce_i (&QMP_global_m, value, &rvalue,
			     1, type, &QMP_operator_table[QMP_XOR]);

  if (status == QMP_SUCCESS)
    *value = rvalue;

  return status;
}


/**
 * Synchronization barrier call.
 * This is a non efficient implementation.
 *
 */
QMP_status_t
QMP_barrier (void)
{

  QMP_s32_t value, rvalue;
  QMP_status_t status;
  QMP_u32_t count;

  QMP_TRACE ("QMP_wait_for_barrier");
  
  count = 1;
  rvalue = value = 1;
  status = qmp_all_reduce_i (&QMP_global_m, &value, &rvalue,
			     count, QMP_INT, 
			     &QMP_operator_table[QMP_SUM]);

  if (status == QMP_SUCCESS)
    value = rvalue;

  return status;
}

/**
 * Forward decleration of qmp_route_i routine
 */
static QMP_status_t qmp_route_i (QMP_machine_t* glm, 
				 void* buffer, QMP_u32_t nbytes,
				 QMP_u32_t source, QMP_u32_t dest);

/**
 * Internbal QMP Scatter (One to All personalized communication)
 *
 * Send messages from root to every other node in the parallel process
 * 
 *
 * sendbuf[i * sendcnt] will be sent to node i
 * recvcnt must be equal to sendcnt
 *
 * Routing Paths used looks like [src, x, x, x, x, x, dest];
 */
static QMP_status_t 
qmp_scatter_i (QMP_machine_t* glm, 
	       void* sendbuf, QMP_u32_t sendcnt,
	       void* recvbuf, QMP_u32_t recvcnt,
	       QMP_u32_t root)
{
  int i;
  QMP_u32_t num_nodes, myrank;
  void      *mysendbuf;
  QMP_status_t status;

  QMP_TRACE ("qmp_scatter_i");

  status = QMP_SUCCESS;

  if (recvcnt != sendcnt) {
    QMP_error ("QMP_scatter: receive count has to be the same as send count.\n");
    status = QMP_INVALID_ARG;
    goto err_scatter;
  }

  /**
   * Get physical dimension information
   */
  num_nodes = QMP_PHYS_NUMNODES(glm->phys);

  /**
   * Get my rank number 
   */
  myrank = QMP_PHYS_RANK(glm->phys);

  if (myrank == root) {
    /* Route messages from root to all other nodes */
    for (i = 0; i < num_nodes; i++) {
      /* Sending buffer for the root */
      mysendbuf =(void *) ((char *)sendbuf + i * sendcnt);

      if (i == root) 
	memcpy (recvbuf, mysendbuf, sendcnt);
      else {
	status = qmp_route_i (glm, mysendbuf, sendcnt, root, i);
	if (status != QMP_SUCCESS) {
	  QMP_error ("QMP_scatter: cannot route from root %d to node %d\n",
		     root, i);
	  goto err_scatter;
	}
      }
    }
  }
  else {
    for (i = 0; i < num_nodes; i++) {
      if (i == root)
	continue;
      else {
	status = qmp_route_i (glm, recvbuf, sendcnt, root, i);
	if (status != QMP_SUCCESS) {
	  QMP_error ("QMP_scatter: cannot route from root %d to node %d\n",
		     root, i);
	  goto err_scatter;
	}
      }
    }
  }
  
  /* Free memory of paths */
 err_scatter:
  return status;
}


/**
 * QMP Scatter (One to All personalized communication)
 *
 * Send messages from root to every other node in the parallel process
 * 
 *
 * sendbuf[i * sendcnt] will be sent to node i
 * recvcnt must be equal to sendcnt
 */
QMP_status_t QMP_scatter (void* sendbuf, QMP_u32_t sendcnt,
			  void* recvbuf, QMP_u32_t recvcnt,
			  QMP_u32_t root)
{
  QMP_TRACE ("QMP_scatter");
  return qmp_scatter_i (&QMP_global_m, sendbuf, sendcnt,
			recvbuf, recvcnt,
			root);
}

/**
 * Internal implementation of Gather operation
 *
 * Send messages from all nodes to the root in the parallel process
 * 
 *
 * recvbuf[i * recvcnt] will be sent to node i
 * recvcnt must be equal to sendcnt
 *
 * Routing Paths used looks like [src, x, x, x, x, x, dest];
 */
static QMP_status_t
qmp_gather_i (QMP_machine_t* glm,
	      void *sendbuf, QMP_u32_t sendcnt,
	      void *recvbuf, QMP_u32_t recvcnt,
	      QMP_u32_t root)
{
  int i;
  QMP_u32_t num_nodes;
  QMP_u32_t myrank;
  void      *myrecvbuf;
  QMP_status_t status;

  QMP_TRACE("QMP_gather_i");

  status = QMP_SUCCESS;

  if (recvcnt != sendcnt) {
    QMP_error ("QMP_gather: receive count has to be the same as send count.\n");
    status = QMP_INVALID_ARG;
    goto err_gather;
  }
  
  /**
   * Get physical dimension information
   */
  num_nodes = QMP_PHYS_NUMNODES(glm->phys);

  /**
   * Get my rank number 
   */
  myrank = QMP_PHYS_RANK(glm->phys);

  /**
   * Now real algorithm
   */
  if (myrank != root) {
    /* All other nodes send messages back to the root */
    for (i = 0; i < num_nodes; i++) {
      if (i == root)
	continue;
      else {
	status = qmp_route_i (glm, sendbuf, recvcnt, i, root);
	if (status != QMP_SUCCESS) {
	  QMP_error ("QMP_gather: cannot do qmp_route from %d to %d \n",
		     i, root);
	  goto err_gather;
	}
      }
    }
  }
  else {
    /* Now I am the root node, receive from all other nodes */
    for (i = 0; i < num_nodes; i++) {
      myrecvbuf = (void *) ((char *)recvbuf + i * recvcnt);
      
      if (i == root)
	memcpy (myrecvbuf, sendbuf, recvcnt);
      else {
	status = qmp_route_i (glm, myrecvbuf, recvcnt, i, root);
	if (status != QMP_SUCCESS) {
	  QMP_error ("QMP_gather: cannot do qmp_route from %d to %d %d.\n", i,
		     root);
	  goto err_gather;
	}
      }
    }
  }

 err_gather:
  return status;
}


/**
 * QMP Gather (All to one personalized communication)
 *
 * Send messages from all nodes to the root in the parallel process
 * 
 *
 * recvbuf[i * recvcnt] will be sent to node i
 * recvcnt must be equal to sendcnt
 */
QMP_status_t QMP_gather (void* sendbuf, QMP_u32_t sendcnt,
			 void* recvbuf, QMP_u32_t recvcnt,
			 QMP_u32_t root)
{
  QMP_TRACE ("QMP_gather");
  return qmp_gather_i (&QMP_global_m, sendbuf, sendcnt,
		       recvbuf, recvcnt,
		       root);
}


/**
 * Application level routing (Message from one node to another node)
 * But everynode have to call this routine in order to allow message
 * to travel through our mesh
 *
 * @param src dest are physical node number
 */
static QMP_status_t
qmp_route_i (QMP_machine_t* glm, 
	     void* buffer, QMP_u32_t nbytes,
	     QMP_u32_t source, QMP_u32_t dest)
{
  int k, onpath;
  QMP_u32_t num_nodes, path_size, num_steps, numdims;
  QMP_u32_t myrank, sendnode, recvnode;
  QMP_u32_t *paths, *dimsize;
  QMP_status_t status;

  /* Make temp buffer a static to avoid alloc a new buffer */
  static void  *myrecvbuf = 0;
  static QMP_u32_t alloced_bytes = 0;


  QMP_TRACE ("qmp_routing_i");

  status = QMP_SUCCESS;
  paths = 0;
  onpath = 0;
  sendnode = recvnode = 0;

  if (source == dest) {
    QMP_error ("QMP_routing: source is the same as destination. \n");
    status = QMP_INVALID_ARG;
    goto err_routing;
  }
      
  /**
   * Get physical dimension information
   */
  numdims = QMP_PHYS_DIMENSION(glm->phys);
  dimsize = QMP_PHYS_DIMSIZE(glm->phys);
  num_nodes = QMP_PHYS_NUMNODES(glm->phys);

  /**
   * Get my rank number 
   */
  myrank = QMP_PHYS_RANK(glm->phys);


  /**
   * Allocate space for routing paths.
   */
  path_size = 0;
  for (k = 0; k < numdims; k++)
    path_size += dimsize[k];

  /* allocate space for path */
  paths = (QMP_u32_t *)malloc(path_size * sizeof (QMP_u32_t));
  if (!paths) {
    paths = 0;
    QMP_error ("QMP_gather: Cannot allocate space for routing path.\n");
    status = QMP_NOMEM_ERR;
    goto err_routing;
  }
  

  if (myrank == source) {
    /* Now check whether the source and destination are neighbors */
    if (QMP_are_neighbors (glm, source, dest)) {
      QMP_DEBUG (QMP_DBGLVL_ROUTING, "Send message of size %d from %d to %d directly.\n", nbytes, source, dest);
      sendnode = dest;
    }
    else {
      num_steps = path_size;
      QMP_set_routing_path (glm, source, dest, paths, &num_steps);
      sendnode = paths[1];
      QMP_DEBUG (QMP_DBGLVL_ROUTING, "Send message of size %d from %d to %d through %d.\n", nbytes, source, dest, sendnode);
    }
    status = qmp_direct_send_p_i (glm, buffer, nbytes, QMP_BYTE, sendnode,
				  QMP_ROUTING_TAG + dest, QMP_DIR_UNKNOWN,
				  QMP_FALSE);
    if (status != QMP_SUCCESS) {
      QMP_error ("QMP_routing: source %d cannot send to node %d .\n", 
		 source, sendnode);
      goto err_routing;
    }
  }
  else if (myrank == dest) {
    /* Now check whether the source and destination are neighbors */
    if (QMP_are_neighbors (glm, source, dest)) {
      QMP_DEBUG (QMP_DBGLVL_ROUTING, "Recv message of size %d from %d to %d directly.\n", nbytes, source, dest);
      recvnode = source;
    }
    else {
      num_steps = path_size;
      QMP_set_routing_path (glm, source, dest, paths, &num_steps);
      recvnode = paths[num_steps - 2];
      QMP_DEBUG (QMP_DBGLVL_ROUTING, "Recv message of size %d from %d to %d through %d.\n", nbytes, source, dest, recvnode);

    }
    status = qmp_direct_recv_p_i (glm, buffer, nbytes, QMP_BYTE, recvnode,
				  QMP_ROUTING_TAG + dest, QMP_DIR_UNKNOWN,
				  QMP_FALSE);
    if (status != QMP_SUCCESS) {
      QMP_error ("QMP_routing: destination %d cannot receive from node %d .\n", 
		 dest, recvnode);
      goto err_routing;
    }
  }
  else {
    if (!QMP_are_neighbors (glm, source, dest)) {
      onpath = 0;
      num_steps = path_size;
      QMP_set_routing_path (glm, source, dest, paths, &num_steps);
      
      /* Check this node is on the path */
      for (k = 0; k < num_steps; k++) {
	if (myrank == paths[k]) {
	  onpath = 1;
	  break;
	}
      }
      
      if (onpath) {
	/* If previous allocated buffer size is smaller than we request, allocate
	 * a new buffer, otherwise reuse the old one
	 */
	if (!myrecvbuf || alloced_bytes < nbytes) {
	  if (myrecvbuf) {
	    /* remove registered memory from my cash table and via table */
	    QMP_regmem_remove_from_all (glm, myrecvbuf, alloced_bytes);
	    free (myrecvbuf);
	    myrecvbuf = 0;
	  }

	  /* Now allocate new memory which will be pinned inside send/recv code */
	  myrecvbuf = (void *)QMP_memalign (nbytes, QMP_MEM_ALIGNMENT);

	  if (!myrecvbuf) {
	    QMP_error ("QMP_routing: cannot allocate space for receiving buffer.\n");
	    status = QMP_NOMEM_ERR;
	    goto err_routing;
	  }
	  alloced_bytes = nbytes;
	}
	  
	sendnode = paths[k + 1];
	recvnode = paths[k - 1];
	QMP_DEBUG (QMP_DBGLVL_ROUTING, "Intermediate node receive from %d and send to %d for src %d dest %d.\n", recvnode, sendnode, source, dest);

	status = qmp_direct_recv_p_i (glm, myrecvbuf, nbytes,
				      QMP_BYTE, recvnode, 
				      QMP_ROUTING_TAG + dest,
				      QMP_DIR_UNKNOWN,
				      QMP_FALSE);
	if (status != QMP_SUCCESS) {
	  QMP_error ("QMP_routing: intermediate node cannot receive from %d node.\n", recvnode);
	  goto err_routing;
	}

	status = qmp_direct_send_p_i (glm, myrecvbuf, nbytes,
				      QMP_BYTE, sendnode, 
				      QMP_ROUTING_TAG + dest,
				      QMP_DIR_UNKNOWN, QMP_FALSE);
	if (status != QMP_SUCCESS) {
	  QMP_error ("QMP_routing: intermediate node cannot send to %d node.\n", sendnode);
	  goto err_routing;
	}

	QMP_DEBUG (QMP_DBGLVL_ROUTING, "Done Intermediate node receive from %d and send to %d for src %d dest %d.\n", recvnode, sendnode, source, dest);
      }
    }
  }

 err_routing:
  if (paths)
    free (paths);
  return status;
}

/**
 * Public function for QMP_routing
 */
QMP_status_t QMP_route (void* buffer, QMP_u32_t count,
			QMP_u32_t src, QMP_u32_t dest)
{
  QMP_TRACE ("QMP_route");
  return qmp_route_i (&QMP_global_m, buffer, count, src, dest);
}

/****************************************************************************
 *         MPI Implementation supporting routines                           *
 ***************************************************************************/

/**
 * Synchronized send: when this send is finished, the corresponding
 * receive must been posted. We use RDMA 3 way handshake protocol to
 * achieve this.
 *
 * Reason: MPI_SSend
 */

/**
 * Fast send to a neighbor using a VIA connection
 */
QMP_status_t
QMP_issend_direct (void* buf, QMP_u32_t count, QMP_datatype_t datatype,
		   QMP_u16_t dest, QMP_u16_t tag, QMP_gige_port_t *port, 
		   QMP_machine_t* glm, QMP_request_t** request)
{
  QMP_u32_t len, protocol;
  QMP_status_t status = QMP_SUCCESS;
  QMP_request_t* sendreq = 0;
  QMP_regmem_entry_t* regmem = 0;

  QMP_TRACE ("QMP_issend_direct");

  /**
   * Check whether we can send or not
   * If there is no remote credit, or there are no qbuf
   */
  len = count * QMP_DATA_SIZE(datatype);

  /* Get a send request from send request free list */
  QMP_GET_REQUEST(glm, sendreq, QMP_MH_SEND);

  regmem = QMP_regmem_register (glm, 
				QMP_PORT_REGMEM_TABLE(port),
				buf, len);
  if (!regmem) {
    QMP_error ("Fatal: cannot register memory for buf %p and length %d\n",
	       buf, len);
    QMP_abort (1);      
  }
  protocol = QMP_RDMA_PUT;


  /* Set packet header information inside the request */
  QMP_SET_PACKET ((&(sendreq->hdr)), protocol,
		  port->conn->local_tokens,port->conn->remote_tokens,
		  QMP_PHYS_RANK(port->phys), dest, tag);
  
  /* Set send request information */
  QMP_SET_REQ_SID(sendreq,port->conn);
  QMP_SET_REQ_USERBUF(sendreq,buf);
  QMP_SET_REQ_USERBUFLEN(sendreq,len);
  QMP_SET_REQ_COUNT(sendreq,count);
  QMP_SET_REQ_DATATYPE(sendreq,datatype);
  QMP_SET_REQ_PORT(sendreq,port);
  if (regmem) 
    QMP_SET_REQ_MEMHANDLE(sendreq,regmem->mem_handle);

  QMP_DEBUG(QMP_DBGLVL_REQUEST, "post a send %s request .\n", 
	    qmp_protocol_names[protocol-QMP_PSTART]);
  QMP_DUMP_REQUEST(sendreq);
  QMP_DEBUG(QMP_DBGLVL_REQUEST, "\n"); 

  status = qmp_isend_rdmaw_request_i (sendreq, port, glm);

  if (status == QMP_SUCCESS)
    *request = sendreq;
  else
    *request = 0;

  return status;
}



/**
 * Synchronized Send to a switched port using a VIA connection
 */
QMP_status_t
QMP_issend_switch (void* buf, QMP_u32_t count, QMP_datatype_t datatype,
		   QMP_u16_t dest, QMP_u16_t tag, QMP_gige_port_t *port, 
		   QMP_machine_t* glm, 
		   QMP_request_t** request)
{
  QMP_status_t status;

  QMP_TRACE ("QMP_Issend_switch");

  status = QMP_issend_direct (buf, count, datatype, dest, tag, port, glm,
			      request);

  if (status != QMP_SUCCESS) {
    qmp_close_via_connection_i (port);
    QMP_remove_viacq (glm, port->viadev->cq);
  }

  return status;
}

/**
 * Start a synchronized general message sending
 *
 * Direction either -1 or +1 for positive and negative direction
 * along axis.
 *
 * For switched port, this argument is not used
 */
QMP_status_t
QMP_issend (void* buf, QMP_u32_t count, QMP_datatype_t datatype,
	    QMP_u16_t dest, QMP_u16_t tag, QMP_s16_t direction,
	    QMP_machine_t* glm,
	    QMP_request_t** request)
{
  QMP_u16_t pdest;
  QMP_gige_port_t* port;

  QMP_TRACE ("QMP_issend");

  /**
   * First convert destination rank to physical rank
   */
  if (!glm->tpl)
    pdest = dest;
  else 
    pdest = QMP_logical_to_allocated (dest);

  /**
   * Secondly check whether this destination can be reached
   * by mesh conenctions.
   */
  port = QMP_get_connection_port (glm, pdest, direction, QMP_MH_SEND);

  if (port->type == QMP_CONN_DIRECT) 
    /* This is a directly connected */
    return QMP_issend_direct (buf, count, datatype,
			      pdest, tag, port, glm,
			      request);
  else
    return QMP_issend_switch (buf, count, datatype,
			      pdest, tag, port, glm, request);
}



/**
 * Blocking Synchronized Send 
 */
QMP_status_t
QMP_ssend  (void* buf, QMP_u32_t count, QMP_datatype_t datatype,
	    QMP_u16_t dest, QMP_u16_t tag, QMP_s16_t direction)

{
  QMP_request_t* sreq;
  QMP_status_t   status;

  QMP_TRACE ("QMP_ssend");
  
  if ((status = QMP_issend (buf, count, datatype, dest, tag, direction,
			    &QMP_global_m,
			    &sreq)) == QMP_SUCCESS) {
    QMP_request_wait (&QMP_global_m, sreq);
    QMP_RELEASE_REQUEST((&QMP_global_m), sreq);
    return QMP_SUCCESS;
  }
  return status;
}
