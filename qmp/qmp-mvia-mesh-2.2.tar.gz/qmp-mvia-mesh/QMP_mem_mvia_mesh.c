/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Memory handling routines for QMP over MVIA with meshed connections
 *
 * Author:  
 *      Jie Chen, Chip Watson and Robert Edwards
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_mem_mvia_mesh.c,v $
 *   Revision 1.8  2004/11/01 20:34:39  chen
 *   Change QMP_declare_multiple to conform to 2.0 spec
 *
 *   Revision 1.7  2004/10/29 14:58:18  chen
 *   add multiple msghandle inside declare_multiple
 *
 *   Revision 1.6  2004/10/08 19:59:29  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.5  2003/12/17 20:25:07  chen
 *   Change QMP_allocate/free_aligned_memory to deregister memory from system
 *
 *   Revision 1.4  2003/12/15 18:53:11  chen
 *   Add QMP_free and correct regmem refcount
 *
 *   Revision 1.3  2003/12/01 16:53:08  chen
 *   Fixed a minor bug for local loopback devices
 *
 *   Revision 1.2  2003/11/25 14:51:41  chen
 *   Remove some output messages
 *
 *   Revision 1.1.1.1  2003/11/18 18:55:36  chen
 *   First CVS QMP_mvia_gigeD_mesh
 *
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#include "qmp.h"
#include "QMP_P_MVIA_MESH.h"


/**
 * Message Handle State String.
 */
static char* QMP_msghandle_states[] = {"QMP_MH_INVALID",
				       "QMP_MH_IDLE",
				       "QMP_MH_WAITING"
};



/**
 * Allocate memory according to alignment.
 * calling glibc memalign code.
 */
#ifndef DMALLOC
extern void* memalign (unsigned int aignment, unsigned int size);
#endif

/**
 * allocate memory with right alignment.
 */
void *
QMP_memalign (QMP_u32_t size, QMP_u32_t alignment)
{
  return memalign (alignment, size);
}

/**
 * QMP 2.0 SPEC function
 * QMP_allocate_aligned_memory
 *
 * Allocate aligned memory with alignement and memory flag
 */
QMP_mem_t *
QMP_allocate_aligned_memory (size_t nbytes, size_t alignment, int flags)
{
  QMP_mem_t* mem;
  char       *aptr;
  unsigned long mask = alignment - 1;

  QMP_TRACE ("QMP_allocate_aligned_memory");

  if (alignment < 0)
    alignment = 0;

  if (alignment > 0) {
    mem = (QMP_mem_t *)malloc (nbytes + alignment - 1 + sizeof(QMP_mem_t));
    if (!mem)
      return 0;
    /* get aligned pointer address */
    if (((unsigned long)mem->mem) & mask) 
      aptr = (char *)(((unsigned long)mem->mem + mask) & ~mask);
    else
      aptr = mem->mem;
    mem->aligned_ptr = aptr;
    mem->nbytes = nbytes;
  }
  else {
    mem = (QMP_mem_t *)malloc (nbytes + sizeof (QMP_mem_t));
    if (!mem)
      return 0;
    mem->aligned_ptr = mem->mem;
    mem->nbytes = nbytes;
  }
  return mem;
}

/**
 * Allocate memory of length nbytes with default alignment and type.
 */
QMP_mem_t *
QMP_allocate_memory (size_t nbytes)
{
  QMP_TRACE ("QMP_allocate_memory");
  return QMP_allocate_aligned_memory (nbytes, QMP_ALIGN_DEFAULT, 
				      QMP_MEM_DEFAULT);
}

/**
 * Get pointer to memory from a memory structure.
 */
void *
QMP_get_memory_pointer (QMP_mem_t* mem)
{
  QMP_TRACE ("QMP_get_memory_pointer");
  return mem->aligned_ptr;
}

/**
 * Free aligned memory
 * This memory also removed from RDMA registered table and VIA table
 */
void
QMP_free_memory (QMP_mem_t* mem)
{
  int i;
  QMP_machine_t* glm = &QMP_global_m;
  QMP_gige_port_t  *port0, *port1;

  QMP_TRACE ("QMP_free_memory");

  QMP_DEBUG(QMP_DBGLVL_REGMEM, "Free memory user address %p realaddr = %p and len = %d\n", mem->aligned_ptr, mem->mem, mem->nbytes);

  if (glm->inited && mem->nbytes > QMP_MEMCPY_THRESHOLD) {
    /* Deregister and remove from all devices */
    for (i = 0; i < QMP_PHYS_DIMENSION(glm->phys); i++) {
      /* minus direction first                        */
      port0 = &(glm->phys->ports[i][0]);

      /* check positive direction of this axis        */
      port1 = &(glm->phys->ports[i][1]);

      QMP_regmem_complete_remove (glm, port0, mem->aligned_ptr, mem->nbytes);
      QMP_regmem_complete_remove (glm, port1, mem->aligned_ptr, mem->nbytes);
    }
    QMP_regmem_complete_remove (glm, &glm->phys->switch_ports[0], 
				mem->aligned_ptr, mem->nbytes);
  }

  /* Finally we free everything */
  free (mem);
}


#if 0
/**
 * A Quick way to let applications to deregister memory from
 * VIA and my hash table
 */
void
QMP_free (void* buf, QMP_u32_t len)
{
  int i;
  QMP_machine_t* glm = &QMP_global_m;
  QMP_gige_port_t  *port0, *port1;

  QMP_TRACE ("QMP_free");

  if (len > QMP_MEMCPY_THRESHOLD) {
    /* Deregister and remove from all devices */
    for (i = 0; i < QMP_PHYS_DIMENSION(glm->phys); i++) {
      /* minus direction first                        */
      port0 = &(glm->phys->ports[i][0]);

      /* check positive direction of this axis        */
      port1 = &(glm->phys->ports[i][1]);

      QMP_regmem_complete_remove (glm, port0, buf, len);
      QMP_regmem_complete_remove (glm, port1, buf, len);
    }
    QMP_regmem_complete_remove (glm, &glm->phys->switch_ports[0], buf, len);
  }

  /* Now finally free memory */
  free (buf);
}

/**
 * allocate memory with right alignment (16 bytes).
 */
void *
QMP_allocate_aligned_memory (QMP_u32_t nbytes)
{
  void* realaddr;
  void* retaddr;

  /* Allocate some extra space to keep track number bytes we
   * are allocating
   */
  realaddr = memalign (QMP_MEM_ALIGNMENT, nbytes + QMP_MEM_ALIGNMENT);

  /* Assign first 4 bytes to number of bytes */
  memcpy (realaddr, &nbytes, sizeof(QMP_u32_t));

  retaddr = (void *) ((char *)realaddr + QMP_MEM_ALIGNMENT);

  QMP_DEBUG(QMP_DBGLVL_REGMEM, "Allocate memory realaddr = %p return addr = %p and len = %d\n", realaddr, retaddr, *(int *)(realaddr));

  return retaddr;
}


/**
 * Free memory allocated by the above routine.
 */
void
QMP_free_aligned_memory (void* buf)
{
  int i;
  QMP_gige_port_t  *port0, *port1;
  void*     realaddr;
  QMP_u32_t len;
  QMP_machine_t* glm = &QMP_global_m;

  /* Get number of bytes from preallocated space */
  realaddr = (void *) ((char *)buf - QMP_MEM_ALIGNMENT);
  len = *(int *)(realaddr);

  QMP_DEBUG(QMP_DBGLVL_REGMEM, "Free memory user address %p realaddr = %p and len = %d\n", buf, realaddr, *(int *)(realaddr));

  if (glm->inited && len > QMP_MEMCPY_THRESHOLD) {
    /* Deregister and remove from all devices */
    for (i = 0; i < QMP_PHYS_DIMENSION(glm->phys); i++) {
      /* minus direction first                        */
      port0 = &(glm->phys->ports[i][0]);

      /* check positive direction of this axis        */
      port1 = &(glm->phys->ports[i][1]);

      QMP_regmem_complete_remove (glm, port0, buf, len);
      QMP_regmem_complete_remove (glm, port1, buf, len);
    }
    QMP_regmem_complete_remove (glm, &glm->phys->switch_ports[0], buf, len);
  }

  /* Now finally free memory */
  free (realaddr);
}
#endif

/**
 * Real implementation of strided memory
 */
static QMP_status_t
qmp_declare_strided_msgmem_i (QMP_machine_t* glm, 
			      void* base, 
			      size_t     blksize,
			      int        nblocks,
			      ptrdiff_t  stride,
			      QMP_msgmem_i_t** pptr)
{
  QMP_msgmem_i_t* retmem;
  QMP_strided_mem_t* strided_mem;
  void* buffer;
  QMP_u32_t nbytes, i;

  QMP_TRACE ("qmp_declare_strided_msgmem_i");

  if (glm->inited == QMP_FALSE) {
    QMP_error ("QMP messaging system has not been initialized yet.");
    return QMP_NOT_INITED;
  }

  /* allocated both returning memory structure and strided memory */
  retmem = (QMP_msgmem_i_t *)malloc(sizeof(QMP_msgmem_i_t));
  if (!retmem) {
    QMP_error ("Cannot allocate QMP_msgmem_t object.\n");
    return QMP_NOMEM_ERR;
  }
  strided_mem = (QMP_strided_mem_t *)malloc(sizeof(QMP_strided_mem_t));
  if (!strided_mem) {
    QMP_error ("Cannot allocate strided memory structure .\n");
    free (retmem);
    return QMP_NOMEM_ERR;
  }
  strided_mem->base = base;
  strided_mem->blksize = blksize;
  strided_mem->stride = stride;
  strided_mem->nblocks = nblocks;

  /* Now calculate how much memory we need */
  nbytes = 0;
  for (i = 0; i < nblocks; i++) 
    nbytes += blksize;
  buffer = (void *)malloc(nbytes*sizeof(char));
  if (buffer) {
    QMP_error ("Cannot allocate storage space for strided memories .\n");
    free (retmem);
    free (strided_mem);
    return QMP_NOMEM_ERR;
  }

  /* Now set up attribute of msgmem structure */
  retmem->type = QMP_MM_STRIDED_BUF;
  retmem->mem = buffer;
  retmem->nbytes = nbytes;
  retmem->ref_count = 0;
  retmem->glm = glm;
  retmem->special_mem = (void *)strided_mem;

  *pptr = retmem;

  return QMP_SUCCESS;
}
     

/**
 * Declare strided memory
 * For now we are doing simple way: copy in and out
 */
QMP_msgmem_t
QMP_declare_strided_msgmem (void*      base, 
			    size_t     blksize,
			    int        nblocks,
			    ptrdiff_t  stride)
{
  QMP_status_t status;
  QMP_msgmem_i_t* mem = 0;
  QMP_machine_t* glm = &QMP_global_m;

  
  QMP_TRACE ("QMP_declare_strided_msgmem");

  status = qmp_declare_strided_msgmem_i (glm, base, blksize, 
					 nblocks, stride, &mem);
  QMP_SET_STATUS_CODE (glm, status);

  return (QMP_msgmem_t)mem;
}


static QMP_status_t
qmp_declare_strided_array_msgmem_i (QMP_machine_t* glm,
				    void* base[], 
				    size_t blksize[],
				    int nblocks[],
				    ptrdiff_t stride[],
				    int num,
				    QMP_msgmem_i_t** pptr)
{
  QMP_msgmem_i_t* retmem;
  QMP_array_strided_mem_t* asmem;
  void* buffer;
  QMP_u32_t nbytes, i, k;

  QMP_TRACE ("qmp_declare_strided_array_msgmem_i");

  if (glm->inited == QMP_FALSE) {
    QMP_error ("QMP messaging system has not been initialized yet.");
    return QMP_NOT_INITED;
  }

  /* allocated both returning memory structure and strided memory */
  retmem = (QMP_msgmem_i_t *)malloc(sizeof(QMP_msgmem_i_t));
  if (!retmem) {
    QMP_error ("Cannot allocate QMP_msgmem_t object.\n");
    return QMP_NOMEM_ERR;
  }

  asmem = (QMP_array_strided_mem_t *)malloc(sizeof(QMP_array_strided_mem_t));
  if (!asmem) {
    QMP_error ("Cannot allocate array strided memory structure .\n");
    free (retmem);
    return QMP_NOMEM_ERR;
  }
  asmem->num = num;
  asmem->smem = (QMP_strided_mem_t *)malloc(sizeof(QMP_strided_mem_t)*num);
  if (!asmem->smem) {
    QMP_error ("Cannot allocate space for internal strided array structures.\n");
    free (retmem);
    free (asmem);
    return QMP_NOMEM_ERR;
  }
  for (i = 0; i < num; i++) {
    asmem->smem[i].base = base[i];
    asmem->smem[i].blksize = blksize[i];
    asmem->smem[i].stride = stride[i];
    asmem->smem[i].nblocks = nblocks[i];
  }

  /* Now we have figure out how much memory we have to allocate */
  nbytes = 0;
  for (i = 0; i < num; i++) {
    for (k = 0; k < asmem->smem[i].nblocks; k++)
      nbytes += (asmem->smem[i].blksize);
  }
  buffer = (void *)malloc(sizeof(char)*nbytes);
  if (!buffer) {
    QMP_error ("Cannot allocate storage space for array strided memory .\n");
    free (retmem);
    free (asmem->smem);
    free (asmem);
  }

  /* Finally set up returning memory structure */
  retmem->type = QMP_MM_STRIDED_ARRAY_BUF;
  retmem->mem = buffer;
  retmem->nbytes = nbytes;
  retmem->ref_count = 0;
  retmem->glm = glm;
  retmem->special_mem = (void *)asmem;

  *pptr = retmem;

  return QMP_SUCCESS;

}

/**
 * Declare a strided array memory.
 * Not yet implemented
 */
QMP_msgmem_t
QMP_declare_strided_array_msgmem (void* base[], 
				  size_t blksize[],
				  int nblocks[],
				  ptrdiff_t stride[],
				  int num)
{
  QMP_status_t status;
  QMP_msgmem_i_t* mem = 0;
  QMP_machine_t* glm = &QMP_global_m;

  
  QMP_TRACE ("QMP_declare_strided_array_msgmem");

  status = qmp_declare_strided_array_msgmem_i (glm, base, blksize,
					       nblocks, stride, num,
					       &mem);

  QMP_SET_STATUS_CODE (glm, status);

  return (QMP_msgmem_t)mem;  
}

/**
 * Free strided memory handle
 */
static void inline
qmp_free_strided_msgmem_i (QMP_msgmem_i_t* mem)
{
  QMP_strided_mem_t* smem;
  QMP_array_strided_mem_t* asmem;

  if (mem->type == QMP_MM_STRIDED_BUF) {
    smem = (QMP_strided_mem_t *)mem->special_mem;
    free (smem);
    free (mem->mem);
  }
  else {
    asmem = (QMP_array_strided_mem_t *)mem->special_mem;
    free (asmem->smem);
    free (asmem);
    free (mem->mem);
  }
}

/**
 * Internal memory allocation for user buffer
 */
static QMP_status_t
qmp_declare_msgmem_i (QMP_machine_t* glm,
		      const void* buf,
		      QMP_u32_t nbytes,
		      QMP_msgmem_i_t** pptr)
{
  QMP_msgmem_i_t* retmem;

  QMP_TRACE ("qmp_declare_msgmem_i");

  if (glm->inited == QMP_FALSE) {
    QMP_error ("QMP messaging system has not been initialized yet.");
    return QMP_NOT_INITED;
  }
  /*
  if (nbytes > glm->max_msg_length) {
    QMP_error ("Trying to allocate memory is bigger than system limit %d\n",
	       glm->max_msg_length);
    return QMP_MEMSIZE_TOOBIG;
  } 
  */

  retmem = (QMP_msgmem_i_t *)malloc(sizeof(QMP_msgmem_i_t));
  if (!retmem) {
    QMP_error ("Cannot allocate QMP_msgmem_t object.\n");
    return QMP_NOMEM_ERR;
  }

  /* Now set fields of msg memory */
  retmem->type = QMP_MM_USER_BUF;
  retmem->mem = (void *)buf;
  retmem->nbytes = nbytes;
  retmem->ref_count = 0;
  retmem->glm = glm;
  retmem->special_mem = 0;

  *pptr = retmem;

  return QMP_SUCCESS;
}

  

/**
 * Allocate msg_memory handle for applications
 */
QMP_msgmem_t
QMP_declare_msgmem (const void* buf, QMP_u32_t nbytes)
{
  QMP_status_t status;
  QMP_msgmem_i_t* mem = 0;
  QMP_machine_t *glm = &QMP_global_m;

  QMP_TRACE ("QMP_declare_msgmem");

  status =  qmp_declare_msgmem_i (glm, buf, nbytes, &mem);
  QMP_SET_STATUS_CODE(glm, status);

  return (QMP_msgmem_t)mem;
}

void
QMP_free_msgmem (QMP_msgmem_t m)
{
  QMP_msgmem_i_t* mem;

  QMP_TRACE("QMP_free_msgmem");

  mem = (QMP_msgmem_i_t *)m;
  
  if (!mem->mem)
    return;

  mem->ref_count--;

  if (mem->ref_count <= 0) {
    /* nobody uses this msg memory */
    QMP_DEBUG(QMP_DBGLVL_MSGMEM, "Remove msg_memory handle %p for memory %p len %d .\n", mem, mem->mem, mem->nbytes);

    if (mem->type == QMP_MM_LEXICO_BUF)
      free (mem->mem);
    else if (mem->type == QMP_MM_STRIDED_BUF ||
	     mem->type == QMP_MM_STRIDED_ARRAY_BUF) 
      qmp_free_strided_msgmem_i (mem);

    mem->mem = 0;
    mem->nbytes = 0;
    mem->glm = 0;
    mem->special_mem = 0;

    /* Free memory handle itself */
    free (mem);
  }
}


/**
 * Real declare send code (physical dest node)
 */
static void
qmp_declare_send_i (QMP_msgmem_i_t* mm, QMP_u16_t dest, QMP_s16_t direction,
		    QMP_machine_t* glm, QMP_msghandle_i_t** mh)
{
  QMP_msghandle_i_t* retmh = 0;
  QMP_gige_port_t* port = 0;

  QMP_TRACE ("qmp_declare_send_i");

  /* Get message handle from the free list */
  QMP_GET_MSGHANDLE(glm, retmh, QMP_MH_SEND, dest);

  /* Set memory and increase memory reference count */
  QMP_MSGHANDLE_SET_MEM(retmh,mm);

  /* Set Direction */
  QMP_MSGHANDLE_SET_DIR(retmh, direction);

  /* Get a gige port assocaited with this message handle */
  /* The dest rank is already a physical rank */
  port = QMP_get_connection_port (glm, dest, direction, QMP_MH_SEND);

  if (port->type == QMP_CONN_DIRECT) 
    ;
  else {
    /* If this is a switched port, I should start connection if it not open */
    if (!port->active) {
      if (QMP_open_via_switch_port (glm, port) != QMP_SUCCESS) 
	exit (1);

      QMP_info ("Send Switched %s to %s port is open.\n",
		port->eth_device, port->peer_via_host);
    }
  }
  
  QMP_MSGHANDLE_SET_PORT(retmh,port);

  /* Check whether there are handles having the same memory length on this
   * port. If yes, we use largest tag + 1 for the new message handle
   */
  QMP_MSGHANDLE_SET_TAG(retmh, QMP_get_send_tag (port, retmh));

  /* Add this handle to the port send list */
  QMP_PORT_ADD_SEND_HANDLE (port->conn, retmh);

  *mh = retmh;

  QMP_DEBUG(QMP_DBGLVL_MSGHANDLE, "Declare Send message handle %p mem = %p len = %d refcount = %d remote = %d tag = %d\n", retmh, retmh->sh_memory->mem, retmh->sh_memory->nbytes, retmh->refcount, retmh->sh_remnode, retmh->sh_tag);
}

/**
 * Declare an endpoint for message channel send operation bewteen this node
 * and its neighbor
 *
 * The neighbor is described by an axis and direction.
 * The axes are from 0 to dim, and direction and 1 and -1
 */
QMP_msghandle_t
QMP_declare_send_relative (QMP_msgmem_t m, QMP_s32_t axis,
			   QMP_s32_t direction,
			   QMP_s32_t priority)
{
  QMP_status_t status;
  QMP_msghandle_i_t* mh;
  QMP_msgmem_i_t* mm;
  int          idx;
  QMP_u32_t    dest;
  QMP_machine_t* glm;
  
  status = QMP_SUCCESS;
  mh = 0;
  mm = (QMP_msgmem_i_t *)m;

  /** 
   * Check whether axis and direction are all valid.
   */
  if (axis >= QMP_get_logical_number_of_dimensions () || axis < 0) {
    QMP_error ("QMP_declare_send_relative has invalid axis argument.");
    status = QMP_INVALID_ARG;
  }
  if (direction != 1 && direction != -1) {
    QMP_error ("QMP_declare_send_relative has invalid direction argument.");
    status = QMP_INVALID_ARG;
  }
  if (status != QMP_SUCCESS) {
    QMP_SET_STATUS_CODE(mm->glm, status);
    return (QMP_msghandle_t)0;
  } 

  /* Real axis index for direction */
  idx = (direction > 0) ? 1 : 0;

  glm = mm->glm;

  /* We are always dealing with physical node here */
  if (glm->tpl) {
    dest = glm->tpl->neighbors[axis][idx].rank;
    dest = QMP_logical_to_allocated(dest);    
  }
  else
    dest = glm->phys->ports[axis][idx].peer->rank;

  qmp_declare_send_i (mm, dest, direction, glm, &mh);

  return (QMP_msghandle_t)mh;
}

/**
 * Declares an endpoint for a message channel send operation.
 * Note: according to QMP spec, the rem_node_rank is a physical rank
 */
QMP_msghandle_t
QMP_declare_send_to (QMP_msgmem_t m, int rem_node_rank,
		     int priority)
{
  QMP_msghandle_i_t* mh;
  QMP_msgmem_i_t* mm;

  QMP_TRACE ("QMP_declare_send_to");


  mh = 0;
  mm = (QMP_msgmem_i_t *)m;

  /* We are dealing physical node here */
  if (QMP_has_unique_connection (mm->glm, rem_node_rank, QMP_MH_SEND)) {
    qmp_declare_send_i (mm, rem_node_rank, QMP_DIR_UNKNOWN, mm->glm, &mh);
    return (QMP_msghandle_t)mh;
  }
  else {
    QMP_error ("There are multiple ways to destination %d. Which way to go\n",
	       rem_node_rank);
    return 0;
  }
}

/**
 * Real declare receive code (physical node)
 */
static void
qmp_declare_recv_i (QMP_msgmem_i_t* mm, QMP_u16_t src, QMP_s16_t direction,
		    QMP_machine_t* glm, QMP_msghandle_i_t** mh)
{
  QMP_msghandle_i_t* retmh = 0;
  QMP_gige_port_t* port = 0;

  QMP_TRACE ("qmp_declare_recv_i");

  /* Get message handle from the free list */
  QMP_GET_MSGHANDLE(glm, retmh, QMP_MH_RECV, src);

  /* Set memory and increase memory reference count */
  QMP_MSGHANDLE_SET_MEM(retmh,mm);

  /* Set direction for this message handle */
  QMP_MSGHANDLE_SET_DIR(retmh,direction);

  /* Get a gige port assocaited with this message handle */
  /* The src rank is already a physical rank */
  port = QMP_get_connection_port (glm, src, direction, QMP_MH_RECV);

  if (port->type == QMP_CONN_DIRECT) 
    ;
  else {
    /* If this is a switched port, I should start connection if it not open */
    if (!port->active) {
      if (QMP_open_via_switch_port (glm, port) != QMP_SUCCESS) 
	exit (1);

      QMP_info ("Recv switched %s to %s port is open.\n",
		port->eth_device, port->peer_via_host);
    }
  }

  QMP_MSGHANDLE_SET_PORT(retmh,port);


  /* Check whether there are handles having the same memory length on this
   * port. If yes, we use largest tag + 1 for the new message handle
   */  
  QMP_MSGHANDLE_SET_TAG(retmh, QMP_get_recv_tag (port, retmh));


  /* Add this handle to the port's recv handle list */
  QMP_PORT_ADD_RECV_HANDLE (port->conn, retmh);

  *mh = retmh;

  QMP_DEBUG(QMP_DBGLVL_MSGHANDLE, "Declare Recv message handle %p mem = %p len = %d refcount = %d remote = %d tag = %d\n", retmh, retmh->sh_memory->mem, retmh->sh_memory->nbytes, retmh->refcount, retmh->sh_remnode, retmh->sh_tag);
}  


/**
 * Declare an endpoint for message channel communication bwteen
 * this node and it's neighbor
 *
 * The neighbor is described by an axis and direction.
 * The axes are from 0 to dim, and directions are 1 and -1.
 */
QMP_msghandle_t 
QMP_declare_receive_relative (QMP_msgmem_t m, QMP_s32_t axis,
			      QMP_s32_t direction,
			      QMP_s32_t priority)
{
  QMP_status_t status;
  QMP_msghandle_i_t* mh;
  QMP_msgmem_i_t* mm;
  QMP_u16_t    src;
  int          idx;
  QMP_machine_t* glm;

  QMP_TRACE ("QMP_declare_receive_relative");

  status = QMP_SUCCESS;
  mm = (QMP_msgmem_i_t *)m;
  mh = 0;

  /** 
   * Check whether axis and direction are all valid.
   */
  if (axis >= QMP_get_logical_number_of_dimensions () || axis < 0) {
    QMP_error ("QMP_declare_receive_relative has invalid axis argument.");
    status = QMP_INVALID_ARG;
  }
  if (direction != 1 && direction != -1) {
    QMP_error ("QMP_declare_receive_relative has invalid direction argument.");
    status = QMP_INVALID_ARG;
  }

  if (status != QMP_SUCCESS) {
    QMP_SET_STATUS_CODE(mm->glm, status);
    return (QMP_msghandle_t)0;
  }
    
  /* Real axis index for direction */
  idx = (direction > 0) ? 1 : 0;
  
  glm = mm->glm;

  if (glm->tpl) {
    /* convert logical to physical node */
    src = glm->tpl->neighbors[axis][idx].rank;
    src = QMP_logical_to_allocated(src);
  }
  else
    src = glm->phys->ports[axis][idx].peer->rank;

  qmp_declare_recv_i (mm, src, direction, glm, &mh);

  return (QMP_msghandle_t)mh;
}


/**
 * Declare an endpoint for message channel operation using remote
 * node's number (physical node number)
 *
 */
QMP_msghandle_t 
QMP_declare_receive_from (QMP_msgmem_t m, int rem_node_rank,
			  int priority)
{
  QMP_msghandle_i_t* mh;
  QMP_msgmem_i_t* mm;

  QMP_TRACE("QMP_declare_receive_from");

  mh = 0;
  mm = (QMP_msgmem_i_t *)m;

  /* We are dealing with physical node */
  if (QMP_has_unique_connection (mm->glm, rem_node_rank, QMP_MH_RECV)) {
    qmp_declare_recv_i (mm, rem_node_rank, QMP_DIR_UNKNOWN, mm->glm, &mh);

    return (QMP_msghandle_t)mh;
  }
  else {
    QMP_error ("There are multiple ways to src %d. Which way to go\n",
	       rem_node_rank);
    return 0;
  }
}


/**
 * Declare multiple message handles so that multiple send/recv can
 * be handled inside the declared handle.
 */
QMP_msghandle_t
QMP_declare_multiple (QMP_msghandle_t mhs[], int nhandles)
{
  QMP_msghandle_i_t *retmh, *tmh, *tmph;
  QMP_s32_t i, k, l, num;
  QMP_machine_t* glm;

  QMP_TRACE("QMP_declare_multiple");

  if (nhandles <= 0) {
    QMP_error ("Cannot declare multiple handles with number handles <= 0.\n");
    return (QMP_msghandle_t)0;
  }

  /* First find out how many handles are really there ? */
  num = 0;
  for (i = 0; i < nhandles; i++) {
    tmh = (QMP_msghandle_i_t *)mhs[i];
    if (tmh->type != QMP_MH_MULTIPLE) {
      if (QMP_MSGHANDLE_PARENT(tmh)) {
	/* This message handle does belong to another multiple handle */
	QMP_error ("QMP_declare_multiple cannot have a single handle that belonmgs to another multiple handles. \n");
	return 0;
      }
      num++;
    }
    else 
      num += tmh->mh_num;
  }

  /* Get a new message handle */
  retmh = 0;
  glm = &QMP_global_m;
  QMP_GET_MSGHANDLE(glm, retmh, QMP_MH_MULTIPLE, 0);

  /* Set number of handles */
  retmh->mh_num = num;

  /* Allocate array of QMP_msghandle_i_t pointer */
  retmh->mh_handles =(QMP_msghandle_i_t **)malloc(sizeof(QMP_msghandle_i_t *) * num);
  if (!retmh->mh_handles) {
    QMP_error ("Cannot allocate memory for multiple handles.\n");
    exit (1);
  }

  /**
   * We want to put send message handle in the front because we like to
   * do send first when we do qmp_start
   */
  k = 0;
  for (i = 0; i < nhandles; i++) {
    tmh = (QMP_msghandle_i_t *)mhs[i];
    if (tmh->type == QMP_MH_SEND) {
      retmh->mh_handles[k++] = tmh;
      /* Set parent pointer to the new handle */
      QMP_MSGHANDLE_SET_PARENT(tmh,retmh);
    }
    else if (tmh->type == QMP_MH_MULTIPLE) {
      for (l = 0; l < tmh->mh_num; l++) {
	tmph = (QMP_msghandle_i_t *)tmh->mh_handles[l];
	if (tmph->type == QMP_MH_SEND) {
	  retmh->mh_handles[k++] = tmph;
	  /* Set parent pointer to the new handle */
	  QMP_MSGHANDLE_SET_PARENT(tmph, retmh);
	}
      }
    }
  }
  
  /**
   * Now add message handle of type receiving
   */
  for (i = 0; i < nhandles; i++) {
    tmh = (QMP_msghandle_i_t *)mhs[i];
    if (tmh->type == QMP_MH_RECV) {
      retmh->mh_handles[k++] = tmh;
      /* Set parent pointer to the new handle */
      QMP_MSGHANDLE_SET_PARENT(tmh, retmh);
    }
    else if (tmh->type == QMP_MH_MULTIPLE) {
      for (l = 0; l < tmh->mh_num; l++) {
	tmph = (QMP_msghandle_i_t *)tmh->mh_handles[l];
	if (tmph->type == QMP_MH_RECV) {
	  retmh->mh_handles[k++] = tmph;
	  /* Set parent pointer to the new handle */
	  QMP_MSGHANDLE_SET_PARENT(tmph, retmh);
	}
      }
    }
  }

  if (k != num) {
    QMP_error ("QMP_declare_multiple internal error inconsistent handles.\n");
    QMP_abort (QMP_INVALID_ARG);
  }

  /* Now finally we remove all multiple handles in the input array */
  /* This is version 2 spec requirment                             */
  for (i = 0; i < nhandles; i++) {
    tmh = (QMP_msghandle_i_t *)mhs[i];
    if (tmh->type == QMP_MH_MULTIPLE) {
      free (tmh->mh_handles);
      QMP_RELEASE_MSGHANDLE(tmh->glm, tmh);
    }
  }

  QMP_DEBUG (QMP_DBGLVL_MSGHANDLE, 
	     "This multiple handle %p will contain %d single handles\n",
	     retmh, num);

  return (QMP_msghandle_t)retmh;
}


/**
 * Free resources associated with a message handle
 */
void
QMP_free_msghandle (QMP_msghandle_t msgh)
{
  int i;
  QMP_msghandle_i_t* mh = (QMP_msghandle_i_t *)msgh;

  QMP_TRACE ("QMP_free_msghandle");

  if (QMP_MSGHANDLE_ACTIVE(mh)) {
    QMP_error ("This message handle is still active, delete it may cause problems.\n");
    return;
  }

  if (mh->type != QMP_MH_MULTIPLE) {
    if (QMP_MSGHANDLE_PARENT(mh)) {
      /* This message handle belongs to a multiple handle, user cannot delete this one */
      QMP_info ("This message handle should be no longer used since it belongs to another.\n");
      return;
    }
    QMP_MSGHANDLE_DEC_REFCOUNT(mh);
    
    if (QMP_MSGHANDLE_REFCOUNT(mh) <= 0) {
      QMP_DEBUG (QMP_DBGLVL_MSGHANDLE, "Release this single message handle %p type = %d mem = %p len = %d refcount = %d remote = %d tag = %d port = %p\n", mh, mh->type, mh->sh_memory->mem, mh->sh_memory->nbytes, mh->refcount, mh->sh_remnode, mh->sh_tag, mh->sh_port);
      /* Now remove from port port send/recv list */
      if (mh->type == QMP_MH_SEND) {
	QMP_PORT_RM_SEND_HANDLE (mh->sh_port->conn, mh);
      }
      else {
	QMP_PORT_RM_RECV_HANDLE (mh->sh_port->conn, mh);
      }

      /* Now it is time to put back to the free list */
      QMP_RELEASE_MSGHANDLE(mh->glm, mh);
    }
  }
  else if (mh->type == QMP_MH_MULTIPLE) {
    /* This is a multiple message handle */

    /* Set parent handle of every single message handle to null so that
     * they can delete themselves
     */
    for (i = 0; i < mh->mh_num; i++) {
      QMP_MSGHANDLE_SET_PARENT(mh->mh_handles[i], 0);
      QMP_free_msghandle (mh->mh_handles[i]);
    }

    /* Decrease refcount of this message handle */
    QMP_MSGHANDLE_DEC_REFCOUNT(mh);
    if (QMP_MSGHANDLE_REFCOUNT(mh) <= 0) {
      QMP_DEBUG (QMP_DBGLVL_MSGHANDLE, "Release this multiple message handle %p type = %d num handles = %d\n", mh, mh->type, mh->mh_num);
      free (mh->mh_handles);

      QMP_RELEASE_MSGHANDLE(mh->glm, mh);
    }
  }
  else {
    QMP_error ("Fatal: try to release a message handle with a wrong type.\n");
    exit (1);
  }
}

