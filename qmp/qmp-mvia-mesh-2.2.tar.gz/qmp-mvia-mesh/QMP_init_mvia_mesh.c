/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Initialization of lqcd messaging system using Meshed Gigbit Ethernet
 *
 * Author:  
 *      Jie Chen, Chip Watson and Robert Edwards
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_init_mvia_mesh.c,v $
 *   Revision 1.5  2004/11/22 18:42:21  chen
 *   minor change to conform to qmp.h header
 *
 *   Revision 1.4  2004/10/08 19:59:29  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.3  2004/03/12 19:00:53  chen
 *   Add support for new version of dmalloc
 *
 *   Revision 1.2  2004/02/25 16:47:28  chen
 *   Add local debug file output option
 *
 *   Revision 1.1.1.1  2003/11/18 18:55:36  chen
 *   First CVS QMP_mvia_gigeD_mesh
 *
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <stdarg.h>

#include "qmp.h"
#include "QMP_P_MVIA_MESH.h"


/**
 * Global instance of this machine.
 */

QMP_machine_t QMP_global_m = {0, 1, QMP_THREAD_SERIALIZED, QMP_MESH,
			      {0, {0,}, 0, 0},
			      0, 0, 65536, 0,
			      0, 0, 0,
			      {0,}, 0,
			      0,
			      {0,}, 0,
			      0,QMP_SUCCESS,
};

/**
 * Runtime verbose mode. (default is off)
 */
QMP_bool_t QMP_rt_verbose = QMP_FALSE;

/**
 * Runtime debug output stream
 */
#ifdef _QMP_LOG_LOCAL
FILE* QMP_debugfd = 0;
#endif


/**
 * Check whether we have an empty line.
 *
 * @param line a char string we are checking
 * @param size length of this char string
 * @return QMP_TRUE if we do have an empty line
 */
static QMP_bool_t
qmp_empty_line_i (char line[], QMP_u32_t size)
{
  char* p;

  QMP_TRACE("empty_line");

  p = line;

  while (p && *p) {
    if (isprint(*p))
      return QMP_FALSE;
    p++;
  }
  return QMP_TRUE;
}


/**
 * Get number of CPUs for this linux box.
 *
 * @return number of CPU this machine has
 *      
 */
static QMP_u32_t
qmp_get_num_cpus_i (void)
{
  FILE* fd;
  char  line[80];
  int   numcpu = 0;

  QMP_TRACE ("qmp_get_num_cpus_i");

  fd = fopen ("/proc/cpuinfo", "r");
  if (!fd) {
    QMP_error ("cannot open /proc/cpuinfo file.");
    return 0;
  }

#if defined (__linux) && defined (__i386)
  while (!feof (fd)) {
    memset (line, 0, sizeof (line));
    if (fgets (line, sizeof (line) - 1, fd) &&
	!qmp_empty_line_i (line, sizeof (line) - 1)) {
      if (strstr (line, "processor"))
	numcpu++;
    }
  }
#endif

#if defined (__linux) && defined (__alpha)
    while (!feof (fd)) {
      memset (line, 0, sizeof (line));
      if (fgets (line, sizeof (line) - 1, fd) &&
	  !empty_line (line, sizeof (line) - 1)) {
	if (strstr (line, "cpus detected")) {
	  char token0[32], token1[32], sep;
	  if (sscanf (line,"%s %s %c %d", token0, token1, &sep, &numcpu) <4){
	    QMP_error ("/proc/cpuinfo format error.");
	    return 0;
	  }
	}
      }
    }
#endif    
    
    fclose (fd);
    return numcpu;
}

/**
 * Print out Run Time Env Information.
 */
void
QMP_print_rtenv (QMP_rtenv_t* rtenv)
{
  int i, k;

  QMP_TRACE ("QMP_print_rtenv");

  fprintf (stderr, "QMP Run Time Environment has %d participants: \n",
	   rtenv->num_nodes);
  fprintf (stderr, "QMP Run Time Environment has dimensionality of %d\n",
	   rtenv->dimension);
  fprintf (stderr, "QMP Run Time Environment has dimension size [");
  for (i = 0; i < rtenv->dimension; i++) 
    fprintf (stderr,"%d ", rtenv->size[i]);
  fprintf (stderr, "]\n");
    
  for (i = 0; i < rtenv->num_nodes; i++) {
    fprintf (stderr, "%d:    Host %s Rank %d Coordinate [",
	     i, rtenv->all_nodes[i].host, 
	     rtenv->all_nodes[i].rank);

    for (k = 0; k < rtenv->dimension; k++) 
      fprintf (stderr, " %d", rtenv->all_nodes[i].coordinates[k]);
    
    fprintf (stderr, "]\n");
  }
}

/**
 * Parsing a string containing multiple integers seperated by white spaces
 *
 * @param  line a string containing multiple integers
 * @param  ret  an allocated array of integers
 * @param  size size of the above array
 * @return number of integers obtained.
 */
static int
qmp_get_integers_i (char* line, int ret[], int size)
{
  int i;
  char* token;

  QMP_TRACE ("qmp_get_integers_i");

  i = 0;
  token = strtok (line, " ");
  if (!token) 
    return 0;
  
  if (sscanf (token, "%d", &ret[i]) < 1) 
    return 0;

  i = 1;
  while ((token = strtok (0, " ")) != NULL && i < size) {
    if (sscanf (token, "%d", &ret[i]) < 1) 
      return i;
    i++;
  }

  return i;
}

/**
 * Load a QMP configuration file
 *
 * @param glm a QMP global machine instance
 * @param fname a configuration filename
 * @return QMP_SUCCESS if everything is ok.
 */
static QMP_status_t
qmp_load_configuration_i (QMP_machine_t* glm, char* fname)
{
  FILE* fd;
  int   i, j, k, m, num, type, dim, hosttype;
  int   ret[QMP_PHYS_NMD];
  char  line[128], hname[QMP_HOSTNAME_LEN];

  QMP_TRACE ("qmp_load_configuration_i");

  fd = fopen (fname, "r");
  if (!fd) {
    QMP_error ("Cannot open configuration file %s .\n", fname);
    return QMP_RTENV_ERR;
  }
  
  num = 0;
  type = 0;
  dim = 0;
  hosttype = 0;
  k = m = 0;

  /**
   * Scan the configuration file to find out how many nodes and dimension
   * information of the mesh
   */
  while (!feof (fd)) {
    memset (line, 0, sizeof (line));
    if (fgets (line, sizeof (line) - 1, fd) && 
	!qmp_empty_line_i (line, sizeof (line) - 1) && line[0] != '#') {
      switch (type) {
      case 0:
	/* get dimension information */
	if (sscanf (line, "%d", &dim) < 1) {
	  QMP_error ("configuration %s provide no dimension information.\n",
		     fname);
	  fclose (fd);
	  return QMP_RTENV_ERR;
	}
	if (dim <= 0 || dim > QMP_PHYS_NMD) {
	  QMP_error ("configuration %s provide wrong dimension information (dimension = %d) .\n",
		     fname, dim);
	  fclose (fd);
	  return QMP_RTENV_ERR;
	}

	/* set dimension information */
	QMP_PHYS_SET_DIMENSION (glm->phys, dim);
	
	type++;
	break;
      case 1:
	/* Find out dimension size information */
	i = qmp_get_integers_i (line, ret, QMP_PHYS_NMD);
	
	if (i < dim - 1) {
	  QMP_error ("configuration %s has wrong dimension size information.\n",
		     fname);
	  fclose (fd);
	  return QMP_RTENV_ERR;
	}

	/* update geometry information */
	QMP_PHYS_SET_DIMSIZE (glm->phys, ret);

	/* calculate total number of nodes */
	QMP_PHYS_CALC_NUMNODES(glm->phys);

	/**
	 * Get number of nodes information created by the previous step
	 */
	num = QMP_PHYS_NUMNODES(glm->phys);
	if (num <= 0) {
	  QMP_error ("configuration %s has wrong number of nodes. \n", fname);
	  fclose (fd);
	  return QMP_RTENV_ERR;
	}

	/* now allocate memory for all physical nodes information */
	QMP_RTENV_SET_NUMNODES(glm->rtenv,num);
	QMP_RTENV_SET_DIMENSION(glm->rtenv, QMP_PHYS_DIMENSION(glm->phys));
	QMP_RTENV_SET_DIMSIZE(glm->rtenv, QMP_PHYS_DIMSIZE(glm->phys));

	/**
	 * Create an empty via host switch table 
	 */
	if (QMP_create_rtenv_swtable (&glm->rtenv,num) != QMP_SUCCESS) {
	  QMP_error ("cannot allocated space for via switched host table.\n");
	  fclose (fd);
	  return QMP_RTENV_ERR;
	}
	
	type++;

	break;
      case 2:
	if(QMP_insert_rtenv_swtable (&glm->rtenv, line, m)!= QMP_SUCCESS) {
	  QMP_error ("configuration format error for switched via hosts.\n");
	  fclose (fd);
	  QMP_delete_rtenv_swtable (&glm->rtenv);
	  return QMP_RTENV_ERR;
	}
	m++;
	if (m >= num) {
	  /* done with switched via host information */
	  if (QMP_create_rtenv_nodes(&glm->rtenv,num) != QMP_SUCCESS) {
	    QMP_error ("cannot allocate memory for run time physical nodes information. \n");
	    fclose (fd);
	    return QMP_NOMEM_ERR;
	  }    

	  /* create all switched port for this physical geometry */
	  if (QMP_create_switched_ports (glm->phys, num) != QMP_SUCCESS) {
	    QMP_error ("cannot create all switched gige ports.\n");
	    fclose (fd);
	    return QMP_RTENV_ERR;
	  }

	  type++;
	}
	break;
      case 3:
	switch (hosttype) {
	case 0:
	  /* get host name */
	  if (strchr (line, '{') != 0) 
	    hosttype = 1;
	  else {
	    sscanf (line, "%s", hname);
	    QMP_RTENV_NODE_SET_HOST(glm->rtenv, hname, k);
	  }
	  break;
	case 1:
	  /* inside the left brackt */
	  if (strchr (line, '}') != 0) {
	    hosttype = 0;
	    k++;
	  }
	  else {
	    if (strstr (line, "/dev") == 0) {
	      /* get coordinates of this host */
	      j = qmp_get_integers_i (line, ret, QMP_PHYS_NMD);
	      if (j < QMP_PHYS_DIMENSION(glm->phys) - 1) {
		QMP_error ("configuration %s for host %s has wrong coordinates.\n",
			   fname, QMP_RTENV_NODE_HOST(glm->rtenv, k));
		QMP_delete_rtenv_nodes (&glm->rtenv);
		QMP_delete_rtenv_swtable (&glm->rtenv);
		fclose (fd);
		return QMP_RTENV_ERR;
	      }
	      
	      /* calculate rank number of this node              */
	      QMP_RTENV_NODE_SET_RANK(glm->rtenv,
		      QMP_calc_node_rank(ret,
					 QMP_PHYS_DIMSIZE(glm->phys),
					 QMP_PHYS_DIMENSION(glm->phys)), k);

	      /* Set coordinate for this rtenv node              */
	      QMP_RTENV_NODE_SET_COORDINATES(glm->rtenv, ret, k);
	      
	      if (strcmp (QMP_RTENV_NODE_HOST(glm->rtenv, k),glm->host) == 0) {
		/* update physical geometry coordinate information */
		QMP_PHYS_SET_COORDINATES(glm->phys, ret);
	      
		/* update physical rank of this node               */
		QMP_PHYS_SET_RANK(glm->phys, QMP_RTENV_NODE_RANK(glm->rtenv, k));
	      }
	    }
	    else {
	      /* This is gige mesh port information */
	      if (strcmp (QMP_RTENV_NODE_HOST(glm->rtenv, k), glm->host) == 0) {

		/* Only process gige port information for this host */
		if (QMP_setup_gige_port (line, glm->phys, &glm->rtenv) != QMP_SUCCESS) {
		  QMP_error ("configuration %s error for ethernet port. \n",
			     fname);
		  QMP_delete_rtenv_nodes (&glm->rtenv);
		  QMP_delete_rtenv_swtable (&glm->rtenv);
		  fclose (fd);
		  return QMP_RTENV_ERR;
		}
	      }
	    }
	  }
	  break;
	default:
	  break;
	}
      }
    }
  }
  fclose (fd);

  /* Now I need to set up neighboring information for geometry and gig port */
  if (QMP_update_port_peer_info (glm, glm->phys,
				 &glm->rtenv, 
				 QMP_RTENV_NUMNODES(glm->rtenv)) != QMP_SUCCESS)
    return QMP_RTENV_ERR;

  return QMP_SUCCESS;
}
  

/**
 * Local initialization of global machine.
 */
static QMP_status_t
qmp_init_machine_i (QMP_machine_t* glm)
{
  char* host;
  int   i;

  QMP_TRACE ("qmp_init_machine_i");

  /* This machine is not initialized yet */
  glm->inited = QMP_FALSE;

  /* get host name */
  glm->host = (char *)malloc (QMP_HOSTNAME_LEN*sizeof (char));
  if (!glm->host) {
    QMP_error ("cannot allocate memory for host name\n");
    return QMP_NOMEM_ERR;
  }

  /* get host name from an environment variable */
  /* this environment should be set by a script */
  host = getenv ("QMP_HOST");
  if (!host) {
    if (gethostname (glm->host, QMP_HOSTNAME_LEN - 1) != 0) {
      QMP_error ("cannot get host name for this machine.\n");
      return QMP_HOSTNAME_ERR;
    }
  }
  else
    strncpy (glm->host, host, QMP_HOSTNAME_LEN - 1);
  

  /* get number of CPUs */
  glm->num_cpus = qmp_get_num_cpus_i ();

  if (glm->num_cpus == 0) {
    QMP_error ("This machine has no cpu information.\n");
    return QMP_CPUINFO_ERR;
  }
    
  glm->th_level  = QMP_THREAD_SERIALIZED;
  glm->ic_type  = QMP_MESH;

  /* allocate memory for physical geometry */
  glm->phys = QMP_create_phys_geometry ();
  if (!glm->phys) 
    return QMP_NOMEM_ERR;

  /* initialize the mesh geometry */
  QMP_init_phys_geometry (glm->phys, host);

  glm->tpl = 0;

  glm->max_msg_length = QMP_MAX_MSGLEN;

  /* Send tag to distinguaish different channnels */
  glm->send_tag = 0;

  /* initialize all free lists */
  glm->regmem_free_list = 0;
  glm->regmem_free_list_inited = 0;

  glm->num_free_lists = 0;
  for (i = 0; i < QMP_NUM_FREELISTS; i++)
    glm->allocated_free_lists[i] = 0;

  QMP_init_req_free_list(glm);

  /* Initialize the msg handles free list */
  QMP_init_msghandle_free_list (glm);

  /* Initialize all completion queue table */
  glm->numcqs = 0;
  for (i = 0; i < QMP_MAX_VIADEV; i++)
    glm->allcqs[i] = 0;

  glm->err_code = QMP_SUCCESS;

  return QMP_SUCCESS;
}


/**
 * a real routine that is doing initialization using
 * a global machine pointer.
 */
static QMP_bool_t
qmp_init_msg_passing_i (QMP_machine_t* glm,
			QMP_thread_level_t required,
			QMP_thread_level_t *provided)
{
  /* load run time environment */
  char         conf[256];
  char*        rtconf;
  QMP_status_t status;

  QMP_TRACE ("qmp_init_msg_passing_i");

#ifdef DMALLOC
  /* I have to pass DMALLOC_OPTIONS here since sometimes dmalloc
   * will not pick up DMALLOC_OPTIONS in my environment setup
   */
#define DMALLOC_ENV "DMALLOC_OPTIONS"

 {
   char* dmalloc_options;

   dmalloc_options = getenv (DMALLOC_ENV);
   if (!dmalloc_options) {
     fprintf (stderr, "Cannot getenv for %s \n", DMALLOC_ENV);
     exit (1);
   }
   dmalloc_debug_setup(dmalloc_options);
 }
#endif

  if (glm->inited == QMP_TRUE) {
    if (QMP_rt_verbose)
      fprintf (stderr, "This QMP system is initialized already\n");
    return QMP_SUCCESS;
  }

  /* initialize this machine */
  if ((status = qmp_init_machine_i (glm)) != QMP_SUCCESS)
    return status;

  rtconf = getenv (QMP_CONF_ENV);
  if (rtconf) 
    strcpy (conf, rtconf);
  else 
    sprintf (conf, "%s", QMP_DEFAULT_CONF);

  status = qmp_load_configuration_i (glm, conf);

  if (status != QMP_SUCCESS) {
    fprintf (stderr, "Loading configuration file <%s> error.\n", conf);
    return status;
  }

#ifndef _QMP_LOCAL_DEBUG
  if (glm->phys->my_node.rank == 0)
    status = QMP_init_root_socket (glm);
  else
    status = QMP_init_socket (glm);    
#endif

  /* set thread level to our qmp gige level */
  *provided = glm->th_level;

  glm->inited = QMP_TRUE;

  /*
  if (QMP_rt_verbose)
    QMP_print_machine_info (glm);
  */

#if defined(_QMP_DEBUG) && defined(_QMP_LOG_LOCAL)
 {
   char localfile[128];
   sprintf (localfile, "/scratch/qmp-debug.%s", glm->host);
   QMP_debugfd = fopen (localfile, "w");
   if (!QMP_debugfd) {
     QMP_fprintf (stderr, "Cannot open local debug file %s.\n", localfile);
     exit (1);
   }
 }
#endif

#ifndef _QMP_LOCAL_DEBUG
  /* Now initialize low level via code */
  if ((status = QMP_open_viadev (glm)) != QMP_SUCCESS ||
      (status = QMP_open_connections_to_neighbors (glm)) != QMP_SUCCESS) {
    glm->inited = QMP_FALSE;

    free (glm->host);
    glm->host = 0;

    QMP_delete_topology (glm->tpl);
    glm->tpl = 0;

    QMP_delete_rtenv_nodes (&glm->rtenv);
    QMP_delete_rtenv_swtable (&glm->rtenv);

    QMP_delete_phys_geometry (glm->phys);
    glm->phys = 0;
    return status;
  }
#endif

  if (QMP_rt_verbose)
    QMP_info ("QMP_init successfully done.\n");


  return QMP_SUCCESS;
}
  
/**
 * Initialize a data structure associated with a node.
 * 
 * This initialization is helped by several environment variable.
 * QMP_OPTS=m0,n20 tells this machine is number 0 in rank and
 * total number of nodes is 20.
 */
QMP_status_t
QMP_init_msg_passing (int* argc, char*** argv,
		      QMP_thread_level_t required,
		      QMP_thread_level_t *provided)

{
  QMP_machine_t* glm = &QMP_global_m;
  QMP_status_t status = qmp_init_msg_passing_i (glm, required, provided);

  QMP_SET_STATUS_CODE(glm, status);
  return status;
}

/**
 * Real routine that finalize message passing
 */
static void 
qmp_finalize_msg_passing_i (QMP_machine_t* glm)
{
  QMP_TRACE ("qmp_finalize_msg_passing_i");

  if (glm->inited == QMP_FALSE)
    return;

#ifndef _QMP_LOCAL_DEBUG
  /* Close sockets createed       */
  if (QMP_MY_RANK(glm) == 0)
    QMP_finalize_root_socket (glm);
  else
    QMP_finalize_socket (glm);

  /* wait for everyone to reach here */
  /* QMP_wait_for_barrier (100000); */

  /* Close all VIA connections    */
  QMP_close_via_connections (glm);

  /* Close VIA devices            */
  QMP_close_viadev (glm);
#endif

  /* Clean out all free lists     */
  QMP_cleanup_free_lists (glm);

  /* Release memory for host name */
  free (glm->host);
  glm->host = 0;

  /* Release memory for logical topology            */
  QMP_delete_topology (glm->tpl);
  glm->tpl = 0;

  /* Release memory for physical nodes within rtenv */
  QMP_delete_rtenv_nodes (&glm->rtenv);
  QMP_delete_rtenv_swtable (&glm->rtenv);

  /* release memory for physical geometry information */
  QMP_delete_phys_geometry (glm->phys);
  glm->phys = 0;

  glm->inited = QMP_FALSE;

#if defined(_QMP_DEBUG) && defined(_QMP_LOG_LOCAL)
  fclose (QMP_debugfd);
#endif
}

/**
 * Shutdown this machine.
 */
void QMP_finalize_msg_passing (void)
{
  qmp_finalize_msg_passing_i (&QMP_global_m);
}

/**
 * Abort the program 
 */
void 
QMP_abort(QMP_s32_t error_code)
{
  /* Shutdown gm and so on */
  QMP_finalize_msg_passing ();

  /* Now quit */
  exit(error_code);
}

/**
 * Print out error message and exit
 */
void
QMP_abort_string (int error_code, char* string)
{
  QMP_error (string);
  fprintf (stderr, "\n");

  QMP_abort (error_code);
}

/**
 * Enable or Disable verbose mode.
 */
int
QMP_verbose (int level)
{
  int oldlevel = QMP_rt_verbose;
  QMP_rt_verbose = level;
  return oldlevel;
}


/**
 * return smp count for this job on this box.
 */
static QMP_u32_t
qmp_get_SMP_count_i (QMP_machine_t* glm)
{
  QMP_TRACE ("qmp_get_smp_count_i");

  if (!glm->inited)
    return 0;

  return (QMP_u32_t)glm->num_cpus;
}

/**
 * Get smp count for this job on this box.
 */
QMP_u32_t
QMP_get_SMP_count (void)
{
  return qmp_get_SMP_count_i (&QMP_global_m);
}

/**
 * Return Interconnect type.
 * Currently we have switched network only.
 */
static const QMP_ictype_t 
qmp_get_msg_passing_type_i (QMP_machine_t* glm)
{
  QMP_TRACE ("qmp_get_msg_passing_type_i");
  return glm->ic_type;
}

/**
 * Return Interconnect type.
 * Currently we have switched network only.
 */
QMP_ictype_t 
QMP_get_msg_passing_type (void)
{
  return qmp_get_msg_passing_type_i (&QMP_global_m);
}


/**
 * Get number of allocated physical nodes for this parallel jobs.
 *
 * This number may be greater than the number of nodes a job really needs.
 */
QMP_u32_t
qmp_get_allocated_number_of_nodes_i (QMP_machine_t* glm)
{
  QMP_TRACE ("qmp_get_allocated_number_of_nodes_i");

  if (!glm->inited || !glm->phys) {
    QMP_error ("QMP system is not initialized.");
    exit (1);
  }
  return QMP_PHYS_NUMNODES(glm->phys);
}

/**
 * Return number of dimensions for hardware configuration.
 * Currently we always return 0 since we have switched configuration.
 */
static QMP_u32_t
qmp_get_allocated_number_of_dimensions_i  (QMP_machine_t* glm)
{
  QMP_TRACE ("qmp_get_allocated_number_of_dimensions_i");

  if (!glm->inited || !glm->phys) {
    QMP_error ("QMP system is not initialized.");
    exit (1);
  }
  return QMP_PHYS_DIMENSION(glm->phys);
}


/**
 * Return number of dimensions for hardware configuration.
 * Currently we always return 0 since we have switched configuration.
 */
int
QMP_get_allocated_number_of_dimensions  (void)
{
  return qmp_get_allocated_number_of_dimensions_i (&QMP_global_m);
}


/**
 * Return size of allocated dimensions of grid machines.
 * Return null if network configuration is a switched configuration.
 */
static const int *
qmp_get_allocated_dimensions_i (QMP_machine_t* glm)
{
  QMP_TRACE ("qmp_get_allocated_dimensions_i");

  if (!glm->inited || !glm->phys) {
    QMP_error ("QMP system is not initialized.");
    exit (1);
  }
  return QMP_PHYS_DIMSIZE(glm->phys);
}

/**
 * Return size of allocated dimensions of grid machines.
 * Return null if network configuration is a switched configuration.
 */
const int *
QMP_get_allocated_dimensions (void)
{
  return qmp_get_allocated_dimensions_i (&QMP_global_m);
}


/**
 * Get coordinate information about allocated machines.
 * Return 0 if the configuration is a network switched configuration.
 *
 * caller should not free memory associated with this pointer.
 */
static const int *
qmp_get_allocated_coordinates_i (QMP_machine_t* glm)
{
  QMP_TRACE ("qmp_get_allocated_coordinates_i");

  if (!glm->inited || !glm->phys) {
    QMP_error ("QMP system is not initialized.");
    exit (1);
  }
  return QMP_PHYS_COORDINATES(glm->phys);
}


/**
 * Get coordinate information about allocated machines.
 * Return 0 if the configuration is a network switched configuration.
 *
 * caller should not free memory associated with this pointer.
 */
const int *
QMP_get_allocated_coordinates (void)
{
  return qmp_get_allocated_coordinates_i (&QMP_global_m);
}



/**
 * Get hostname for a physical rank
 */
char *
QMP_get_allocated_hostname (QMP_machine_t* glm, QMP_u16_t rank)
{
  int i;

  QMP_TRACE("QMP_get_allocated_hostname");

  for (i = 0; i < QMP_RTENV_NUMNODES(glm->rtenv); i++) {
    if (rank == QMP_RTENV_NODE_RANK(glm->rtenv, i))
      return QMP_RTENV_NODE_HOST(glm->rtenv, i);
  }
  return 0;
}


/**
 * Return whether this node is a root
 */
QMP_bool_t
QMP_is_primary_node (void)
{
  return (QMP_PHYS_RANK(QMP_global_m.phys) == 0);
}
