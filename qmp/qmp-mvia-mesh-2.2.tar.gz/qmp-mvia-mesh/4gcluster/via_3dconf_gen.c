/* Generator for configuration file for 3d complete 6x8x8 cluster */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#define HOST_PREFIX "qcd4g"
#define VIAH_PREFIX "via4g"

#define VIADEV_PREFIX "/dev/via_"

#define NUM_DIM 3
static int dimsize[]={6, 8, 8};

/**
 * Physical Z coordinate to Logical Z coordinate
 */
static int z_ptol[8] = {0, 1, 3, 2, 7, 6, 4, 5};

/**
 * Logical Z coordinate to physical Z coordinate
 */
static int z_ltop[8] = {0, 1, 3, 2, 6, 7, 5, 4};

/* Physicsl connection by ethernet devices */
static char eth_connections[3][8][8][16]={
  {
    {"n/a", "eth2", "n/a", "n/a", "n/a", "eth3", "n/a", "n/a"},
    {"eth3", "n/a", "eth2", "n/a", "n/a", "n/a", "n/a", "n/a"},
    {"n/a", "eth3", "n/a", "eth2", "n/a", "n/a", "n/a", "n/a"},
    {"n/a", "n/a", "eth3", "n/a", "eth2", "n/a", "n/a", "n/a"},
    {"n/a", "n/a", "n/a", "eth3", "n/a", "eth2", "n/a", "n/a"},
    {"eth2", "n/a", "n/a", "n/a", "eth3", "n/a", "n/a", "n/a"},
    {"n/a", "n/a", "n/a", "n/a", "n/a", "n/a", "n/a", "n/a"},
    {"n/a", "n/a", "n/a", "n/a", "n/a", "n/a", "n/a", "n/a"},
  },
  {
    {"n/a", "eth6", "n/a", "n/a", "n/a", "n/a", "n/a", "eth7"},
    {"eth7", "n/a", "eth6", "n/a", "n/a", "n/a", "n/a", "n/a"},
    {"n/a", "eth7", "n/a", "eth6", "n/a", "n/a", "n/a", "n/a"},
    {"n/a", "n/a", "eth7", "n/a", "eth6", "n/a", "n/a", "n/a"},
    {"n/a", "n/a", "n/a", "eth7", "n/a", "eth6", "n/a", "n/a"},
    {"n/a", "n/a", "n/a", "n/a", "eth7", "n/a", "eth6", "n/a"},
    {"n/a", "n/a", "n/a", "n/a", "n/a", "eth7", "n/a", "eth6"},
    {"eth6", "n/a", "n/a", "n/a", "n/a", "n/a", "eth7", "n/a"},
  },
  {
    {"n/a", "eth4", "eth5", "n/a", "eth1", "n/a", "n/a", "n/a"},
    {"eth4", "n/a", "n/a", "eth5", "n/a", "eth1", "n/a", "n/a"},
    {"eth5", "n/a", "n/a", "eth4", "n/a", "n/a", "eth1", "n/a"},
    {"n/a", "eth5", "eth4", "n/a", "n/a", "n/a", "n/a", "eth1"},
    {"eth1", "n/a", "n/a", "n/a", "n/a", "eth4", "eth5", "n/a"},
    {"n/a", "eth1", "n/a", "n/a", "eth4", "n/a", "n/a", "eth5"},
    {"n/a", "n/a", "eth1", "n/a", "eth5", "n/a", "n/a", "eth4"},
    {"n/a", "n/a", "n/a", "eth1", "n/a", "eth5", "eth4", "n/a"},
  },
};



static void
write_header (FILE* fd, int dim, int dim_size[])
{
  int i;

  fprintf (fd, "# This is a sample configuration file\n");
  fprintf (fd, "# Dimension\n");
  fprintf (fd, "%d\n", dim);

  fprintf (fd, "# Dimension size\n");
  i = 0;
  while (i < dim) {
    fprintf (fd, "%d ", dim_size[i]);
    i++;
  }
  fprintf (fd, "\n");
}

static void
write_switch_info (char* host, FILE* fd)
{
  int i;
  char via_host[80], tmp[32];

  sprintf (via_host, "%s%s-eth0", VIAH_PREFIX, &host[strlen(HOST_PREFIX)]);

  fprintf (fd, "%s         %s\n", host, via_host);
}


/* Get physical coordinate from logical coordinate */
   
static void
get_phys_coord (int* lcoord, int* pcoord, int dim)
{
  /* X and Y coordinate values are the same */
  pcoord[0] = lcoord[0];
  pcoord[1] = lcoord[1];

  /* Z values are diffrent */
  pcoord[2] = z_ltop[lcoord[2]];
}


/**
 * Get physical connection information for two neighbor points
 *
 * return physical axis
 */
static void
get_phys_connection_info (int* pcoord, int* pnp, int dims, int* paxis)
{
  int i;

  for (i = 0; i < dims; i++) {
    if (pnp[i] != pcoord[i]) {
      *paxis = i;
      return;
    }
  }
  fprintf (stderr, "Should never reach here. \n");
  exit (1);
}



static void
get_logic_coord (int* pcoord, int* lcoord, int dim)
{
  /* X and Y coordinates are the same */
  lcoord[0] = pcoord[0];
  lcoord[1] = pcoord[1];

  /* Z coordinate is different */
  lcoord[2] = z_ptol[pcoord[2]];
}


static void
write_host (char* host, int* pcoord, int* lcoord, int dims,
	    FILE* fd, FILE* lfd)

{
  int i, k, paxis;
  char viadev[32], viahost[48], tmp[32];
  int lnp[NUM_DIM], lnm[NUM_DIM], pnp[NUM_DIM], pnm[NUM_DIM];

  fprintf (fd, "# Host %s configuration \n", host);
  fprintf (fd, "%s\n", host);
  fprintf (fd, "{\n");

  for(i = 0; i < dims; i++) 
    fprintf (fd, "%d ", lcoord[i]);
  fprintf (fd, "\n");

  fprintf (fd, "# device vip_host direction (+1 -1) and axis.\n");
  for (i = 0; i < dims; i++) {

    /* Calculate logical neighbors */
    for (k = 0; k < dims; k++) {
      lnp[k] = lnm[k] = lcoord[k];
    }
    lnp[i] = (lnp[i] + 1) % dimsize[i];
    lnm[i] = lnm[i] - 1;
    if (lnm[i] < 0)
      lnm[i] = dimsize[i] - 1;

    /* plus side information */
    get_phys_coord (lnp, pnp, dims);

    /* Figure out which physical axis this is on */
    get_phys_connection_info (pcoord, pnp, dims, &paxis);


    /* Get via device name */
    sprintf (viadev, "%s%s", VIADEV_PREFIX, eth_connections[paxis][pcoord[paxis]][pnp[paxis]]);

    /* Get neighbor's via hostname */
    strcpy (viahost, VIAH_PREFIX);
    for (k = 0; k < dims; k++) {
      sprintf (tmp, "%d", pnp[k]);
      strcat (viahost, tmp);
    }
    strcat (viahost, "-");
    strcat (viahost, eth_connections[paxis][pnp[paxis]][pcoord[paxis]]);
    /* Finally print out */
    fprintf (fd, "%s       %s       1             %d\n",
	     viadev, viahost, i);

    /* Minus side information */
    get_phys_coord (lnm, pnm, dims);

    /* Figure out which physical direction and +/- */
    get_phys_connection_info (pcoord, pnm, dims, &paxis);

    /* Get via device name */
    sprintf (viadev, "%s%s", VIADEV_PREFIX, eth_connections[paxis][pcoord[paxis]][pnm[paxis]]);


    /* Get neighbors via host name */
    strcpy (viahost, VIAH_PREFIX);
    for (k = 0; k < dims; k++) {
      sprintf (tmp, "%d", pnm[k]);
      strcat (viahost, tmp);
    }
    strcat (viahost, "-");
    strcat (viahost, eth_connections[paxis][pnm[paxis]][pcoord[paxis]]);

    /* Finally print out */
    fprintf (fd, "%s       %s       -1             %d\n",
	     viadev, viahost, i);
  }
  fprintf (fd, "#connection to switch.\n");
  fprintf (fd, "/dev/via_eth0 \n");
  fprintf (fd, "}\n");

  /* write host name to list file */
  fprintf (lfd, "%s\n", host);
}



int
main (int argc, char** argv)
{
  int num_nodes, i, k, l;
  int dimension, nodimsize;
  int pcoord[NUM_DIM], lcoord[NUM_DIM];
  char line[80], hostp[32], hostname[80];
  char *fname, *lfname;
  FILE *fd, *lfd;

  if (argc < 3) {
    fprintf (stderr, "usage: %s conf-fname list-fname.\n", argv[0]);
    exit (1);
  }

  fname = argv[1];
  lfname = argv[2];

  /* host prefix */
  strcpy (hostp, HOST_PREFIX);

  fd = fopen (fname, "w");
  if (!fd) {
    fprintf (stderr, "Cannot open file %s to write configuration.\n", fname);
    exit (1);
  }

  lfd = fopen (lfname, "w");
  if (!fd) {
    fprintf (stderr, "Cannot open file %s to write list.\n", lfname);
    exit (1);
  }
  
  dimension = NUM_DIM;
  num_nodes = 1;
  for (i = 0; i < dimension; i++)
    num_nodes = num_nodes * dimsize[i];
  fprintf (stderr, "Total number of nodes is %d.\n", num_nodes);

  write_header (fd, dimension, dimsize);

  /* write switched information to the beginning */
  fprintf (fd, "# Switch information\n");
  fprintf (fd, "# Hostname               ViaHost\n");

  
  /* Get switch information */
  for (i = 0; i < dimsize[0]; i++) {
    for (k = 0; k < dimsize[1]; k++) {
      for (l = 0; l < dimsize[2]; l++) {
	sprintf (hostname, "%s%d%d%d", hostp, i, k, l);
	write_switch_info (hostname, fd);
      }
    }
  }

  /* Write individual host information */
  for (i = 0; i < dimsize[0]; i++) {
    for (k = 0; k < dimsize[1]; k++) {
      for (l = 0; l < dimsize[2]; l++) {
      sprintf (hostname, "%s%d%d%d", hostp, i, k, l);

      /* Set physical coordinate information */
      pcoord[0] = i;
      pcoord[1] = k;
      pcoord[2] = l;


      get_logic_coord(pcoord, lcoord, NUM_DIM);

      write_host (hostname, pcoord, lcoord, NUM_DIM, fd, lfd);
      }
    }
  }
      
  fclose (fd);
  fclose (lfd);

  return 0;
}

  
