/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Simple LQCD Style Communication Test using declare_sendto
 *      and declare_recv_from
 *
 * Author:  
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_sendto_test.c,v $
 *   Revision 1.3  2004/11/01 20:34:40  chen
 *   Change QMP_declare_multiple to conform to 2.0 spec
 *
 *   Revision 1.2  2004/10/08 19:59:30  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.1.1.1  2003/11/18 18:55:36  chen
 *   First CVS QMP_mvia_gigeD_mesh
 *
 *
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include <qmp.h>

/* This is the memory size for 4x4x4x4: SIZE = 48XPHASE SIZE */

#define Nd 4
#define Nc 3
#define Ns 4
#define Ns2 2

typedef struct prog_arg_
{
  int loops;
  int msgsize;
  int verify;
  unsigned int grids[Nd];
  unsigned int numd;
}prog_arg_t;

/**
 * Get current time in milli seconds.
 */
static double
get_current_time (void)
{
  struct timeval tv;

  gettimeofday (&tv, 0);

  return tv.tv_sec*1000.0 + tv.tv_usec/1000.0;
}

#define MEM_SIZE 81920 


/* Nearest neighbor communication channels */
static int total_comm = 0;
static void* forw_mem[Nd][2];
static void* back_mem[Nd][2];

static void* mess_rmem;
static void* mess_smem;
static QMP_msgmem_t mess_rmsg, mess_smsg;
static QMP_msghandle_t mess_rmh, mess_smh;

static QMP_msgmem_t forw_msg[Nd][2];
static QMP_msgmem_t back_msg[Nd][2];
static QMP_msghandle_t forw_mh[Nd][2];
static QMP_msghandle_t back_mh[Nd][2];
static QMP_msghandle_t forw_all_mh;
static QMP_msghandle_t back_all_mh;
static int num = 0;
static int mem_size = MEM_SIZE;
static int verify = 0;


void init_wnxtsu3dslash(void)
{
  int mu, i;
  unsigned int *mycoord;
  int left[Nd], right[Nd];
  unsigned int leftnode, rightnode;
  const unsigned int *size = QMP_get_logical_dimensions();
  unsigned int num_dim = QMP_get_logical_number_of_dimensions();

  /* First get my logical coordinates */
  mycoord = QMP_get_logical_coordinates ();

  /* Loop over all communicating directions and build up the two message
   * handles. If there is no communications, the message handles will not
   * be initialized 
   */
  num = 0;
  
  for(mu=0; mu < num_dim; ++mu)
  {
    if(size[mu] > 1)
    {
      forw_mem[num][0] = malloc(mem_size*sizeof(char));
      forw_mem[num][1] = malloc(mem_size*sizeof(char));

      forw_msg[num][0] = QMP_declare_msgmem(forw_mem[num][0], mem_size);
      forw_msg[num][1] = QMP_declare_msgmem(forw_mem[num][1], mem_size);

      for (i = 0; i < num_dim; i++) {
	left[i] = right[i] = mycoord[i];
      }
    
      /* Get left neightbor */
      left[mu] = left[mu] - 1;
      if (left[mu] < 0)
	left[mu] = size[mu] - 1;

      leftnode = QMP_get_node_number_from (left);

      /* Get Right neighbour */
      right[mu] = (right[mu] + 1) % size[mu];
      rightnode = QMP_get_node_number_from (right);

      /*
      forw_mh[num][0]  = QMP_declare_receive_relative(forw_msg[num][1], mu, +1, 0);
      forw_mh[num][1]  = QMP_declare_send_relative(forw_msg[num][0], mu, -1, 0);
      */
      forw_mh[num][0]  = QMP_declare_receive_from (forw_msg[num][1], rightnode, 0);
      forw_mh[num][1]  = QMP_declare_send_to (forw_msg[num][0], leftnode, 0);
      

      back_mem[num][0] = malloc(mem_size*sizeof(char));
      back_mem[num][1] = malloc(mem_size*sizeof(char));

      back_msg[num][0] = QMP_declare_msgmem(back_mem[num][0], mem_size);
      back_msg[num][1] = QMP_declare_msgmem(back_mem[num][1], mem_size);

      /*
      back_mh[num][0]  = QMP_declare_receive_relative(back_msg[num][1], mu, -1, 0); 
      back_mh[num][1]  = QMP_declare_send_relative(back_msg[num][0], mu, +1, 0);
      */
      back_mh[num][0]  = QMP_declare_receive_from (back_msg[num][1], leftnode, 0);
      back_mh[num][1]  = QMP_declare_send_to (back_msg[num][0], rightnode, 0);

      num++;
    }
  }

  if (num > 0)
  {
    forw_all_mh = QMP_declare_multiple(&(forw_mh[0][0]), 2*num);
    back_all_mh = QMP_declare_multiple(&(back_mh[0][0]), 2*num); 
  }

  total_comm = num;

#if 0
  mess_rmem = QMP_allocate_aligned_memory (mem_size);
  mess_smem = QMP_allocate_aligned_memory (mem_size);

  mess_rmsg = QMP_declare_msgmem(mess_rmem, mem_size);
  mess_smsg = QMP_declare_msgmem(mess_smem, mem_size);
#endif
}


int main (int argc, char** argv)
{
  int i, j, k, loops;
  QMP_status_t err, status;
  double it, ft, dt, bwval;
  prog_arg_t pargs;
  QMP_thread_level_t th_level;

  status = QMP_init_msg_passing (&argc, &argv, 
				 QMP_THREAD_MULTIPLE, &th_level);

  if (status != QMP_SUCCESS) {
    QMP_error ("QMP_init failed: %s\n", QMP_error_string(status));
    exit (1);
  }

  if (QMP_is_primary_node()) {
    fprintf (stderr, "Input numberloops messagesize verify or not.\n");
    scanf ("%d %d %d", &pargs.loops, &pargs.msgsize, &pargs.verify);
    fprintf (stderr, "Input number of dimensions for physics problem.\n");
    scanf ("%d", &pargs.numd);
    fprintf (stderr, "Input dimension sizes for %d dimensions\n",
	     pargs.numd);
    for (i = 0; i < pargs.numd; i++)
      scanf ("%d", &pargs.grids[i]);
  }
  QMP_broadcast (&pargs, sizeof (pargs));

  QMP_info ("Number loops = %d message size = %d verify = %d\n",
	    pargs.loops, pargs.msgsize, pargs.verify);

  loops = pargs.loops;
  mem_size = pargs.msgsize;
  verify = pargs.verify;

  QMP_layout_grid (pargs.grids, pargs.numd);
  
  init_wnxtsu3dslash();

  i = 0;

  it = get_current_time ();
  while (i < loops) {
    
    if (verify) {
      for (j = 0; j < num; j++) {
	memset (forw_mem[j][1], 0xff, mem_size);
	memset (forw_mem[j][0], (char)i, mem_size);

	memset (back_mem[j][1], 0xff, mem_size);
	memset (back_mem[j][0], (char)(i + 10), mem_size);
      }
    }

    if ((err = QMP_start (forw_all_mh))!= QMP_SUCCESS)
      QMP_printf ("Start forward operations failed: %s\n", 
		  QMP_error_string(err));

    if (QMP_wait (forw_all_mh) != QMP_SUCCESS)
      QMP_printf ("Error in sending %d\n", i);

    if ((err = QMP_start (back_all_mh)) != QMP_SUCCESS)
      QMP_printf ("Start backward failed: %s\n", QMP_error_string(err));


    if (QMP_wait (back_all_mh) != QMP_SUCCESS)
      QMP_printf ("Error in wait receiving %d\n", i);

#if 0
    if (i % 10 == 0) {
      QMP_free_msghandle (mess_smh);
      QMP_free_msghandle (mess_rmh);
    }
#endif

    if (verify) {
      char* fmem;
      char* bmem;
      for (j = 0; j < num; j++) {
	fmem = (char *)forw_mem[j][1];
	bmem = (char *)back_mem[j][1];
	for (k = 0; k < mem_size; k++) {
	  if (fmem[k] != (char)i)
	    QMP_fprintf (stderr, "Forwared Receiving error %d != %d\n",
			 fmem[k], (char)i);
	}
	for (k = 0; k < mem_size; k++) {
	  if (bmem[k] != (char)(i + 10))
	    QMP_fprintf (stderr, "Backward Receiving error %d != %d\n",
			 bmem[k], (char)(i + 10));
	}
      }
    }

    i++;
  }
  ft = get_current_time ();

  dt = (ft - it); /* actual send time milli seconds */
  
  /* bandwidth in MB/second */
  bwval = 2*num*(double)mem_size/dt/(double)1000.0*loops;

  QMP_fprintf (stderr, "Sending using %d channels with memory size %d yields %lf (mriro seconds) total time and bandwidth %lf (MB/s)\n", 2*num, mem_size, dt/(loops)*1000.0, bwval);

  QMP_free_msghandle (forw_all_mh);
  QMP_free_msghandle (back_all_mh);

  /* No need to delete indididual handle */
  QMP_finalize_msg_passing ();

  /**
   * Free memory
   */
  for (i = 0; i < num; i++) {
    free (forw_mem[i][0]);
    free (forw_mem[i][1]);
    free (back_mem[i][0]);
    free (back_mem[i][1]);
  }

  return 0;
}

