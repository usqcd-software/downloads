/* Generator for 1d configuration file along X direction */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#define MAX_DIM 3
#define HOST_PREFIX "qcd3g"

static char* host_prefix={"qcd3g"};
static char* via_prefix={"via"};


static char* via_device[]={"/dev/via_eth6", "/dev/via_eth7"};

static char* via_host[]={"eth7", "eth6"};


/**
 * Calculate logic coordinates (allocated already) with a given logic
 * node number (rank), dimensionality and size of the grid.
 */
static void
calculate_coordinates_from_rank (int rank,
				 int dimension,
				 int* size,
				 int coordinates[])

{
  int i;
  int pos;


  /* Calculate the Cartesian coordinates of the VALUE of IPOS where the 
   * value is defined by
   *
   *     for i =  0 to NDIM - 1 {
   *        X_i  <- mod( IPOS, L(i) )
   *        IPOS <- int( IPOS / L(i) )
   *     }
   *
   * NOTE: here the coord(i) and IPOS have their origin at 0. 
   * for 3 dimension, pos = z * Ny * Nx + y * Nx + x;
   */
  pos = rank;

  for (i = 0; i < dimension; i++) {
    coordinates[i] = pos % size[i];
    pos = pos / size[i];
  }
}

static void
write_header (FILE* fd, int dim, int dim_size[])
{
  int i;

  fprintf (fd, "# This is a sample configuration file\n");
  fprintf (fd, "# Dimension\n");
  fprintf (fd, "%d\n", dim);

  fprintf (fd, "# Dimension size\n");
  i = 0;
  while (i < dim) {
    fprintf (fd, "%d ", dim_size[i]);
    i++;
  }
  fprintf (fd, "\n");
}

static void
write_switch_info (FILE* fd, FILE* lfd, int dim, int coord[], int y, int z)
{
  int i;
  char host[80], via_host[80], tmp[32];

  sprintf (host, "%s%d%d%d", host_prefix, coord[0], y, z);
  sprintf (via_host, "%s%d%d%d-eth4", host_prefix, coord[0], y, z);

  fprintf (fd, "%s         %s\n", host, via_host);
}

static void
write_host (FILE* fd, FILE* lfd, int dim, int dim_size[], 
	    int coord[], int y, int z)
{
  int i, k;
  char host[80], tmp[32], plus[80], minus[80];
  int nbp[MAX_DIM], nbm[MAX_DIM];

  sprintf (host, "%s%d%d%d", host_prefix, coord[0], y, z);


  fprintf (fd, "# Host %s configuration \n", host);
  fprintf (fd, "%s\n", host);
  fprintf (fd, "{\n");

  fprintf (fd, "%d ", coord[0]);
  fprintf (fd, "\n");

  fprintf (fd, "# device vip_host direction (+1 -1) and axis.\n");

  /* calculate neighbors */
  nbm[0] = nbp[0] = coord[0];

  /* positive direction */
  nbp[0] = (nbp[0] + 1) % dim_size[0];
  sprintf (plus, "%s%d%d%d-eth7", via_prefix, nbp[0], y, z);

  /* negative direction */
  nbm[0] = nbm[0] - 1;
  if (nbm[0] < 0)
    nbm[0] = dim_size[0] - 1;

  sprintf (minus, "%s%d%d%d-eth6", via_prefix, nbm[0], y, z);

  fprintf (fd, "%s   %s      1        0\n", 
	   via_device[0], plus);
  fprintf (fd, "%s   %s     -1       0\n", 
	   via_device[1], minus);

  fprintf (fd, "#connection to switch.\n");
  fprintf (fd, "/dev/via_eth4 \n");
  fprintf (fd, "}\n");

  /* write host name to list file */
  fprintf (lfd, "%s\n", host);
}

#define CONF_FILE_PREFIX "1d_conf_l"
#define LIST_FILE_PREFIX "1d_list_l"

int
main (int argc, char** argv)
{
  int num_nodes, i, k, m;
  int dimension, nodimsize;
  int dim_size[MAX_DIM], coord[MAX_DIM];
  char line[80], host[80];
  char fname[80], lfname[80];
  FILE *fd, *lfd;

  for (i = 0; i < 8; i++) {
    for (k = 0; k < 8; k++) {
      sprintf (fname, "%s_0%d%d", CONF_FILE_PREFIX, i, k);
      sprintf (lfname, "%s_0%d%d", LIST_FILE_PREFIX, i, k);
      

      fd = fopen (fname, "w");
      if (!fd) {
	fprintf (stderr, "Cannot open file %s to write configuration.\n", fname);
	exit (1);
      }

      lfd = fopen (lfname, "w");
      if (!fd) {
	fprintf (stderr, "Cannot open file %s to write list.\n", lfname);
	exit (1);
      }
  
      dimension = 1;
      dim_size[0] = 4;
      num_nodes = 4;

      write_header (fd, dimension, dim_size);

      /* write switched information to the beginning */
      fprintf (fd, "# Switch information\n");
      fprintf (fd, "# Hostname               ViaHost\n");


      for (m = 0; m < num_nodes; m++) {
	calculate_coordinates_from_rank (m, dimension, dim_size, coord);
	write_switch_info (fd, lfd, dimension, coord, i, k);
      }

      for (m = 0; m < num_nodes; m++) {
	calculate_coordinates_from_rank (m, dimension, dim_size, coord);
	write_host(fd, lfd, dimension, dim_size, coord, i, k);
      }

      fclose (fd);
      fclose (lfd);
    }
  }

  return 0;
}
