/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Test large memory usage
 *
 * Author:  
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_large_mem_test.c,v $
 *   Revision 1.3  2004/10/08 19:59:29  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.2  2004/04/08 15:34:36  chen
 *   Simple change
 *
 *   Revision 1.1  2004/03/21 07:42:39  edwards
 *   Test code producing VIA memory corruption on large mem jobs.
 *
 *   Revision 1.2  2003/12/17 20:25:07  chen
 *   Change QMP_allocate/free_aligned_memory to deregister memory from system
 *
 *   Revision 1.1.1.1  2003/11/18 18:55:36  chen
 *   First CVS QMP_mvia_gigeD_mesh
 *
 *
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include <qmp.h>


#include "QMP_P_MVIA_MESH.h"

struct Prop {
  char *F;
};

typedef struct Prop  Prop_t;


int main (int argc, char** argv)
{
  QMP_status_t status;
  Prop_t      *prop;
  int          Ls = 32;
  int          s;
  double       sum = 0;
  int          nsites_per_node = 8192;
  int          nbytes_per_site = 1152;
  int          nbytes;
  QMP_thread_level_t th_level;

  status = QMP_init_msg_passing (&argc, &argv, QMP_THREAD_MULTIPLE,
				 &th_level);
  if (status != QMP_SUCCESS) 
    QMP_error_exit ("QMP_init failed: %s\n", QMP_error_string(status));

#if 1
  {
    QMP_fprintf(stderr,"test global sum: A\n");
    QMP_sum_double_array(&sum, 1);
    QMP_fprintf(stderr,"finished global sum: A\n");
  }
#endif

  nbytes = nsites_per_node*nbytes_per_site;

  if ((prop = (Prop_t*)malloc(sizeof(Prop_t)*Ls)) == 0)
    QMP_error_exit ("malloc failed");

  for(s=0;s<Ls;s++)
    if ((prop[s].F = (char*)malloc(nbytes)) == 0)
      QMP_error_exit ("malloc with prop failed");

  for(s=0;s<Ls;s++)
  {
    QMP_fprintf(stderr, "prop[%d]=0x%x,  p.F=0x%x, p.F.end=0x%x, len=%d, size=%d\n",
		s,(void*)&(prop[s]),prop[s].F,
		(char*)(prop[s].F)+nbytes-1,
		nsites_per_node,nbytes_per_site);

    /* 
     * My suspicion is comm bufs are not pinned until needed, but are allocated
     * This line causes page faults on a 256MB machine. When the lines are
     * finally pinned, they have junk??? This will make the VIP CQ generate
     * think there is a message (because the CQ is polled). The message is
     * bogus and the VIP RecvDone/SendDone throw an error when called down
     * below in the global sum.
     */
    memset((void*)(prop[s].F),0,nbytes);  /* this induces a bug */
  }

#if 1
  {
    QMP_fprintf(stderr,"test global sum: B\n");
    QMP_sum_double_array(&sum, 1);
    QMP_fprintf(stderr,"finished global sum: B\n");
  }
#endif
    
#if 1
  {
    QMP_fprintf(stderr,"test global sum: C\n");
    QMP_sum_double_array(&sum, 1);
    QMP_fprintf(stderr,"finished global sum: C\n");
  }
#endif
    
  QMP_finalize_msg_passing ();

  return 0;
}

