/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *     Qcd Message Passing Pacakge Layout Part of code
 *
 * Author:  
 *      Jie Chen, Chip Watson and Robert Edwards
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_grid_mesh.c,v $
 *   Revision 1.3  2004/11/01 20:34:39  chen
 *   Change QMP_declare_multiple to conform to 2.0 spec
 *
 *   Revision 1.2  2004/10/08 19:59:29  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.1.1.1  2003/11/18 18:55:36  chen
 *   First CVS QMP_mvia_gigeD_mesh
 *
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "qmp.h"
#include "QMP_P_MVIA_MESH.h"

extern QMP_bool_t
QMP_declare_ordered_logical_topology (const QMP_u32_t* dims,
				      QMP_u32_t ndim,
				      QMP_u32_t* ordering);

#define QMP_MAX_NMD 4

/**
 * Physical lattice problem geometry
 */
typedef struct QMP_prob_geometry_
{
  /* Dimension of problem geometry                              */
  QMP_u32_t dimension;

  /* Virtual lattice size                                       */
  QMP_u32_t length[QMP_MAX_NMD];

  /* Number of virtual processors to physical processors        */
  /* Lattice volume on each physical node                       */
  QMP_u32_t subgrid_vol;

  /* Subgrid length each logical (rotated) direction            */
  QMP_u32_t subgrid_length[QMP_MAX_NMD];

  /* Surface to volume ratio                                    */
  QMP_u32_t sftovol;

  /* Subgrid matched physical geometry length                   */
  QMP_u32_t phys_length[QMP_MAX_NMD];

  /* Layout ordering for physical axes                          */
  QMP_s32_t ordering[QMP_MAX_NMD];

}QMP_prob_geometry_t;

/**
 * A simple linked list of unsigned integers
 */
typedef struct QMP_u32_node_
{
  
  QMP_u32_t    value;
  QMP_u32_t    index;
  struct QMP_u32_node_* next;

}QMP_u32_node_t;
  
/**
 * Bi-graph data structure 
 */
typedef struct QMP_bigraph_node_
{
  /* A graph node on the left side                              */
  QMP_u32_t left;

  /* An index for this node                                     */
  QMP_u32_t ldx;

  /* A list of node on the right side connected to this node    */
  QMP_u32_node_t* right;

}QMP_bigraph_node_t;

/**
 * Some of the static variables
 */
static QMP_prob_geometry_t _PAR_geometry_;
static QMP_prob_geometry_t* qmp_prob_geometry_ = &_PAR_geometry_;

/**
 * Macros for the bigraph linked list
 */
#define QMP_ADD_BIGRAPH_RIGHT_NODE(bleft_node,bright_node) { \
   bright_node->next = bleft_node->right;                    \
   bleft_node->right = bright_node;                          \
}

/**
 * maximum number of unique problem geometry
 * For 4 and 3 problem, Total number is (4,3) 3! = 4 X 6 = 24
 */
#define QMP_MAX_PROB_GEOS 124

/**
 * Print out the content of bigraph
 */
static void
qmp_print_bigraph_i (QMP_bigraph_node_t* bnodes[],
		     QMP_u32_t num_nodes)
{
  int i;
  QMP_u32_node_t* rnode;

  QMP_fprintf (stderr, "The bigraph has %d number of left nodes.\n", 
	       num_nodes);
  for (i = 0; i < num_nodes; i++) {
    fprintf (stderr, "Left node[%d] of index %d = %d has ", i, 
	     bnodes[i]->ldx, bnodes[i]->left);
    rnode = bnodes[i]->right;
    while (rnode) {
      fprintf (stderr, " physical geometry %d index %d ", 
	       rnode->value, rnode->index);
      rnode = rnode->next;
    }
    fprintf (stderr, " \n\n");
  }
}


/**
 * Find out whether a declared grid layout can match the physical
 * mesh geometry
 */
static QMP_status_t
qmp_match_phys_geometry_i (QMP_bigraph_node_t* bigraph[],
			   QMP_u32_t num_dims,
			   QMP_u32_t* fix_size,
			   QMP_u32_t  fix_dims)
{
  QMP_status_t status;
  QMP_u32_node_t* tmp_node;
  int          i, k, num_matches;

  status = QMP_SUCCESS;

  for (i = 0; i < num_dims; i++) {
    /* Check whether this direction can be divided by any 
     * direction in the physical geometry
     */
    for (k = 0; k < fix_dims; k++) {
      if (bigraph[i]->left % fix_size[k] == 0) {
	/* Create a node for right side of bigraph */
	tmp_node = (QMP_u32_node_t *)malloc(sizeof(QMP_u32_node_t));
	if (!tmp_node) {
	  QMP_error ("qmp_match_phys_geometry_i: Cannot allocate space for QMP_u32_node_t.\n");
	  exit (1);
	}
	tmp_node->value = fix_size[k];
	tmp_node->index = k;
	tmp_node->next = 0;
	
	/* Add this node to the right side of bigraph */
	QMP_ADD_BIGRAPH_RIGHT_NODE(bigraph[i], tmp_node);
      }
    }
  }

  /* Check whether we have correct layout */
  /* Check whether we have enough matches */
  num_matches = 0;
  for (i = 0; i < num_dims; i++) {  
    if (bigraph[i]->right)
      num_matches++;
  }

  if (num_dims > fix_dims) {
    if (num_matches < fix_dims) {
      QMP_error ("qmp_match_phys_geometry_i: only %d directions can be matched by the physical geometry.\n", num_matches);
      return QMP_ERROR;
    }
  }
  else {
    if (num_matches != num_dims) {
      QMP_error ("qmp_match_phys_geometry_i: %d matches !=  %d directions.\n", num_matches, num_dims);
      return QMP_ERROR;
    }
  }

  /**
   * Print out the bigraph information 
   */
#ifdef DEBUG
  qmp_print_bigraph_i (bigraph, num_dims);
#endif
  
  return QMP_SUCCESS;
}

/**
 * Find all possible geometry layouts that the physical
 * geometry will support.
 */
static void
qmp_get_all_prob_geometry_i(QMP_bigraph_node_t* bigraph[],
			    QMP_u32_t curr_index,
			    QMP_u32_t* dim_size,
			    QMP_u32_t num_dims, 
			    QMP_prob_geometry_t all_grids[],
			    QMP_u32_t* num_grids,
			    QMP_bigraph_node_t path_stack[])
{
  int num, i, k, m, found, matched;
  QMP_u32_node_t* rnode;

  rnode = bigraph[curr_index]->right;
  if (!rnode) 
    /* Skip this one by setting path_stack[i] left to 0 */
    path_stack[curr_index].left = 0;
    
  while (rnode) {
    found = 0;
    for (i = 0; i < curr_index; i++) {
      if (path_stack[i].left !=0 && 
	  rnode->value == path_stack[i].right->value &&
	  rnode->index == path_stack[i].right->index) {
	/* This is no good, some one is using this physical direction */
	found = 1;
	break;
      }
    }
    if (!found) {
      /* Good: now add this to the path_stack */
      path_stack[curr_index].left = bigraph[curr_index]->left;
      path_stack[curr_index].ldx  = bigraph[curr_index]->ldx;
      path_stack[curr_index].right = rnode;

      /* Do more permutations */
      if (curr_index < num_dims - 1) 
	qmp_get_all_prob_geometry_i(bigraph,
				    curr_index + 1,
				    dim_size,
				    num_dims, 
				    all_grids,
				    num_grids,
				    path_stack);
      else {
	matched = 1;
	  
	if (QMP_logical_topology_is_declared ()) {
	  /* Check whether stack is the same as the declared dimsize */
	  for (k = 0; k < num_dims; k++) {
	    if (dim_size[k] != path_stack[k].right->value) {
		matched = 0;
		break;
	    }
	  }
	}
	
	if (matched) {
	  num = *num_grids;

	  /* Now build final geometry from the path stack */
	  for (k = 0; k < num_dims; k++) {
	    m = bigraph[k]->ldx;
	    all_grids[num].length[m] = bigraph[k]->left;
	  }
	  
	  for (k = 0; k < num_dims; k++) {
	    if (path_stack[k].left != 0) {
	      m = bigraph[k]->ldx;
	      all_grids[num].phys_length[m] = path_stack[k].right->value;
	      all_grids[num].ordering[m] = path_stack[k].right->index;
	    }
	    else {
	      all_grids[num].phys_length[k] = 0;
	    all_grids[num].ordering[k] = -1;
	    }
	  }

	  num++;
	  *num_grids = num;
	}
      }
    }
    rnode = rnode->next;
  }
}

/**
 * Simple C(m, n) function for combination n out m
 */
void
qmp_simple_cmn_i (int a[], int aindex, int path[], int pindex, 
		  int m, int n, int psize, int* perm[], int* num)
{
  int i, ix;

  if (m == n || n == 0) {
    /* End condition */
    if (n != 0) {
      for (i = 0; i < n; i++) 
	path[i + pindex] = a[i + aindex];
    }
    else
      path[pindex] = a[aindex];
    pindex = 0;

    ix = *num;
    for (i = 0; i < psize; i++)
      perm[ix][i] = path[i];
    
    ix++;
    *num = ix;
  }
  else {
    qmp_simple_cmn_i (a, aindex + 1, path, pindex, 
		      m - 1, n, psize, perm, num);
    path[pindex] = a[aindex];
    qmp_simple_cmn_i (a, aindex + 1, path, pindex + 1, 
		      m - 1, n - 1, psize, perm, num);
  }
}

/**
 * Find all possible geometry layouts that the physical
 * geometry will support.
 */
static void
qmp_all_prob_geometry_i(QMP_bigraph_node_t* bigraph[],
			QMP_u32_t curr_index,
			QMP_u32_t num_dims, 
			QMP_u32_t* fixed_size,
			QMP_u32_t fixed_dims,
			QMP_prob_geometry_t all_grids[],
			QMP_u32_t* num_grids,
			QMP_bigraph_node_t path_stack[])
{
  QMP_bigraph_node_t* perm_nodes[QMP_MAX_NMD];
  int i, k, num;

  if (num_dims <= fixed_dims) 
    qmp_get_all_prob_geometry_i (bigraph, curr_index, fixed_size, num_dims,
				 all_grids, num_grids, path_stack);
  else {
    num = 0;
    for (i = 0; i < num_dims; i++) {
      if (bigraph[i]->right)
	num++;
    }

    if (num > fixed_dims) {
      /* We have to do all combinations */
      int *a, *p;
      int *all_coms[100];
      int num_coms;

      a = (int *)malloc(num_dims * sizeof(int));
      for (i = 0; i < num_dims; i++)
	a[i] = i;

      p = (int *)malloc(num_dims * sizeof(int));
      for (i = 0; i < num_dims; i++)
	p[i] = 0;

      for (i = 0; i < 100; i++) 
	all_coms[i] = (int *)malloc(fixed_dims * sizeof(int));
      num_coms = 0;
    
      qmp_simple_cmn_i (a, 0, p, 0, num_dims, fixed_dims, fixed_dims, 
			all_coms, &num_coms);
      
#ifdef DEBUG
      for (i = 0; i < num_coms; i++) {
	fprintf (stderr, "Combination[%d] = ", i);
	for (k = 0; k < fixed_dims; k++) 
	  fprintf (stderr, " %d ", all_coms[i][k]);
	fprintf (stderr, "\n");
      }
#endif

      /* Create a temp bigraph */
      for (i = 0; i < fixed_dims; i++) {
	perm_nodes[i] = (QMP_bigraph_node_t *)malloc(sizeof(QMP_bigraph_node_t));
	if (!perm_nodes[i]) {
	  QMP_fprintf (stderr, "Memory allocation error for QMP_layout_grid.\n");
	  exit (1);
	}
      }

      /* For each combination get right layout */
      for (i = 0; i < num_coms; i++) {
	for (k = 0; k < fixed_dims; k++) {
	  perm_nodes[k]->left = bigraph[all_coms[i][k]]->left;
	  perm_nodes[k]->ldx = bigraph[all_coms[i][k]]->ldx;
	  perm_nodes[k]->right = bigraph[all_coms[i][k]]->right;
	}
	
	qmp_get_all_prob_geometry_i (perm_nodes, curr_index, fixed_size, fixed_dims,
				     all_grids, num_grids, path_stack);
      }

      /* Free memory */
      free (a); free (p);
      for (i = 0; i < 100; i++)
	free (all_coms[i]);
      for (i = 0; i < fixed_dims; i++) 
	free (perm_nodes[i]);
    }
    else {
      /* Create a temp bigraph */
      k = 0;
      for (i = 0; i < fixed_dims; i++) {
	perm_nodes[i] = (QMP_bigraph_node_t *)malloc(sizeof(QMP_bigraph_node_t));
	if (!perm_nodes[i]) {
	  QMP_fprintf (stderr, "Memory allocation error for QMP_layout_grid.\n");
	  exit (1);
	}
	while (bigraph[k]->right == 0)
	  k++;
	perm_nodes[i]->left = bigraph[k]->left;
	perm_nodes[i]->ldx = bigraph[k]->ldx;
	perm_nodes[i]->right = bigraph[k]->right;
	k++;
      }

      qmp_get_all_prob_geometry_i (perm_nodes, curr_index, fixed_size, fixed_dims,
				   all_grids, num_grids, path_stack);

      for (i = 0; i < fixed_dims; i++) 
	free (perm_nodes[i]);      
    }
  }
}

/**
 * Calculate all grids volume and surface to volume ratio
 */
static void 
qmp_calc_grid_info_i (QMP_prob_geometry_t all_grids[],
		      QMP_u32_t num_grids,
		      QMP_u32_t num_dims,
		      QMP_u32_t phys_dims)
{
  int i, k, type, done;
  QMP_u32_t sfsize;

  for (i = 0; i < num_grids; i++) {
    /* Now calculate other attributes of the above grids */
    all_grids[i].subgrid_vol = 1;
    for (k = 0; k < num_dims; k++) {
      if (all_grids[i].phys_length[k] != 0)
	all_grids[i].subgrid_length[k] =  all_grids[i].length[k]/all_grids[i].phys_length[k];
      else
	all_grids[i].subgrid_length[k] =  all_grids[i].length[k];
      all_grids[i].subgrid_vol *= all_grids[i].subgrid_length[k];
    }

    /* Now calculate all surface area sizes */
    all_grids[i].sftovol = 0;
    type = 0;
    done = 0;
    k = 0;

    while (!done) {
      if (type == 0) {
	sfsize = 1;
	while (all_grids[i].phys_length[k] == 0) 
	  k++;
	sfsize *= all_grids[i].subgrid_length[k++];
	type = 1;
      }
      else {
	while (k < num_dims && all_grids[i].phys_length[k] == 0) 
	  k++;
	if (k >= num_dims) {
	  /* This will be the last one */
	  k = 0;
	  done = 1;
	}
	while (all_grids[i].phys_length[k] == 0) 
	  k++;

	sfsize *= all_grids[i].subgrid_length[k];
	all_grids[i].sftovol += sfsize;
	type = 0;
      }
    }
    if (phys_dims > 2)
      all_grids[i].sftovol *= 2;
    
    /* Actually we are not interested in surface to volume ration. We are
     * Interested in whole byte counts travelling from all surfaces.
     */
    for (k = 0; k < num_dims; k++) {
      if (all_grids[i].phys_length[k] == 0) 
	all_grids[i].sftovol = all_grids[i].sftovol * all_grids[i].subgrid_length[k];
    }
  }
}


/**
 * QMP_layout_grid
 *
 * General geometry constructor. Automatically determine sthe
 * optimal layout -> decides the optimal ordering of axes.
 *
 * Returns QMP_SUCCESS on success
 */
QMP_status_t
QMP_layout_grid (const int dims[], int num_dims)
{
  int i, k, num_grids;
  QMP_status_t status;
  QMP_u32_node_t *r, *rn;
  QMP_bigraph_node_t* bigraph[QMP_MAX_NMD];
  QMP_prob_geometry_t all_grids[QMP_MAX_PROB_GEOS];
  QMP_bigraph_node_t path_stack[QMP_MAX_NMD];
  QMP_u32_t minsftovol;
  QMP_u32_t fixed_dims = QMP_get_logical_number_of_dimensions ();
  QMP_u32_t* fixed_size = (QMP_u32_t *)QMP_get_logical_dimensions ();

  if (num_dims < 1 || num_dims > QMP_MAX_NMD) {
    QMP_fprintf (stderr, "QMP_layout_grid: invalid num_dims = %d\n",
		 num_dims);
    exit (1);
  }

  if (num_dims < fixed_dims) {
    QMP_error ("Currently we are not supporting grid layout geometry that has smaller dimensionality than that of the physical geometry.\n");
    exit (1);
  }

  status = QMP_SUCCESS;

  /**
   * Get fixed topology information 
   * If logical topology is not declared, the physical geometry
   * information is returned
   */
  
  /* Create an empty bigraph */
  for (i = 0; i < num_dims; i++) {
    bigraph[i] = (QMP_bigraph_node_t *)malloc(sizeof(QMP_bigraph_node_t));
    if (!bigraph[i]) {
      QMP_fprintf (stderr, "Memory allocation error for QMP_layout_grid.\n");
      exit (1);
    }
    bigraph[i]->left = dims[i];
    bigraph[i]->ldx = i;
    bigraph[i]->right = 0;
  }

  /* Populate this bigraph with physical geometry information */
  if ((status=qmp_match_phys_geometry_i(bigraph, num_dims, 
					fixed_size,fixed_dims))!= QMP_SUCCESS){
    QMP_error ("Our physical geometry Cannot accormadate declared grid layout.\n");
    return status;
  }

  /* Check all possible combination of layouts from this bi-graph */
  for (i = 0; i < num_dims; i++) 
    path_stack[i].left = 0;

  /* Initialize all grids to the proper values first */
  for (k = 0; k < QMP_MAX_PROB_GEOS; k++) {
    all_grids[k].dimension = num_dims;
    for (i = 0; i < num_dims; i++) {
      all_grids[k].length[i] = dims[i];
      all_grids[k].ordering[i] = -1;
      all_grids[k].phys_length[i] = 0;
    }
  }

  num_grids = 0;
  qmp_all_prob_geometry_i(bigraph, 0, num_dims, fixed_size, fixed_dims,
			  all_grids, &num_grids, path_stack);
  if (num_grids == 0) {
    QMP_error ("QMP_layout_grid: cannot find a unique problem geometry.\n");
    return QMP_ERROR;
  }

  /* Now calculate other information for the above obtained layout info */
  qmp_calc_grid_info_i (all_grids, num_grids, num_dims, fixed_dims);


  /* Dump out all matched grid */
#ifdef DEBUG
  for (i = 0; i < num_grids; i++) {
    fprintf (stderr, "Matched Grid[%d] dimension = %d: subgrid vol = %d surface/vol = %d \n", 
	     i,all_grids[i].dimension, all_grids[i].subgrid_vol,
	     all_grids[i].sftovol);
    
    for (k = 0; k < num_dims; k++) {
      fprintf (stderr, "Direction %d : Length = %d Physical Len = %d Index = %d\n",
	       k, all_grids[i].length[k], all_grids[i].phys_length[k],
	       all_grids[i].ordering[k]);
    }
    fprintf (stderr, "---------------------------------------\n");
  }
#endif

  /* Now find a grid layout with minumum surface to volume ratio */
  minsftovol = 0x0fffffff;
  k = 0;

  if (!QMP_logical_topology_is_declared ()) {
    for (i = 0; i < num_grids; i++) {
      if (all_grids[i].sftovol < minsftovol) {
	minsftovol = all_grids[i].sftovol;
	k = i;
      }
    }
  }

  /* Now we have found an optimal layout */
  memcpy (&_PAR_geometry_, &all_grids[k], sizeof (QMP_prob_geometry_t));
  
  /* Now print out the information */
#ifdef DEBUG
  fprintf (stderr, "Optimal Layout dimension = %d: subgrid vol = %d surface/vol = %d \n", 
	   _PAR_geometry_.dimension, _PAR_geometry_.subgrid_vol,
	   _PAR_geometry_.sftovol);
    
  for (k = 0; k < num_dims; k++) {
    fprintf (stderr, "Direction %d : Length = %d Physical Len = %d Index = %d\n",
	     k, _PAR_geometry_.length[k], _PAR_geometry_.phys_length[k],
	     _PAR_geometry_.ordering[k]);
  }
  fprintf (stderr, "---------------------------------------\n");
#endif

  if (!QMP_logical_topology_is_declared ()) {
    /* We have to declare a logical topology which consistent with our optimal
     * layout, i.e. ordering 
     */
    QMP_u32_t ldims[QMP_MAX_NMD];
    QMP_u32_t lordering[QMP_MAX_NMD];
    
    /* We collapse a dimension which does not have mapped physical direction */
    for (i = 0; i < num_dims; i++) {
      if (_PAR_geometry_.phys_length[i] != 0)
	ldims[i] = _PAR_geometry_.phys_length[i];
      else
	ldims[i] = 1;
      lordering[i] = _PAR_geometry_.ordering[i];
    }

#ifdef DEBUG
    fprintf (stderr, "Declear logical topology with size [ ");
    for (i = 0; i < num_dims; i++) 
      fprintf (stderr, " %d ", ldims[i]);
    fprintf (stderr, "]");

    fprintf (stderr, " with ordering of [ ");
    for (i = 0; i < num_dims; i++) 
      fprintf (stderr, " %d ", lordering[i]);
    fprintf (stderr, "]");

    fprintf (stderr, "\n");
#endif

    
    if (!QMP_declare_ordered_logical_topology (ldims, num_dims,lordering)) {
      QMP_error ("Cannot declare logical topology, cannot be true\n");
      exit (1);
    }
  }

  /* Free memory for bigraph node */
  for (i = 0; i < num_dims; i++) {
    r = bigraph[i]->right;
    rn = 0;
    while (r) {
      rn = r->next;
      free (r);
      r = rn;
    }
    free (bigraph[i]);
  }
    
  return QMP_SUCCESS;
}


/* Return the logical subgrid size on each node */
const int *
QMP_get_subgrid_dimensions (void)
{
  return qmp_prob_geometry_->subgrid_length;
}

/* Return the logical subgrid number of sites */
int
QMP_get_number_of_subgrid_sites (void)
{
  return qmp_prob_geometry_->subgrid_vol;
}


/* Slow send-receive (blocking) */
void
QMP_sendrecv_wait(void *send_buf, void *recv_buf, 
		  int count, int isign, int dir)
{
  QMP_msgmem_t msg[2];
  QMP_msghandle_t mh_a[2], mh;

  msg[0]  = QMP_declare_msgmem(send_buf, count);
  msg[1]  = QMP_declare_msgmem(recv_buf, count);
  mh_a[0] = QMP_declare_send_relative(msg[0], dir, isign, 0);
  mh_a[1] = QMP_declare_receive_relative(msg[1], dir, -isign, 0);
  mh = QMP_declare_multiple(mh_a, 2);

  QMP_start(mh);
  QMP_wait(mh);

  /** 
   * QMP SPEC 2.0 states the individual handles being released inside 
   * the multiple
   */
#if 0
  QMP_free_msghandle(mh_a[1]);
  QMP_free_msghandle(mh_a[0]);
#endif
  QMP_free_msghandle(mh);

  QMP_free_msgmem(msg[1]);
  QMP_free_msgmem(msg[0]);
}


/* Internal op used for shifting */
static void QMP_m_site(int site,int *s_p,int *s_v)
{
  int i,k;  
  int coord[4];
  const unsigned int *logical_size = QMP_get_logical_dimensions();


  /* The lattice coordinates corresponding to this site */
  for(i=0; i< qmp_prob_geometry_->dimension; ++i)
  {
    coord[i] = site % qmp_prob_geometry_->length[i];
    site = site / qmp_prob_geometry_->length[i];
  }

  /* The logical site and logical node */
  k = 0;
  for(i= qmp_prob_geometry_->dimension-1;i>=0;i--)
    k = k*(logical_size[i]) + coord[i]/qmp_prob_geometry_->subgrid_length[i];
  *s_p = k;
  k = 0;
  for(i=qmp_prob_geometry_->dimension-1;i>=0;i--)
    k = k*(qmp_prob_geometry_->subgrid_length[i]) + (coord[i] % qmp_prob_geometry_->subgrid_length[i]);
  *s_v = k;
}


int 
QMP_shift(int site, unsigned char *data, int prim_size, int sn)
{
  static int save_old_node;
  static int cur_src[4];
  static int cur_lsite[4];
  int nd;
  const unsigned int *logical_size = QMP_get_logical_dimensions();
  
  int old_node,cur_node,i,j,shift_size,dir;
  int local_site;
  unsigned int b1;
  int send_dir = -1;
  
  nd = qmp_prob_geometry_->dimension;
  
  if(site == sn)
  {
    save_old_node = 0;
    for(i=0;i<nd;i++)
      cur_lsite[i] = cur_src[i] = 0;
  }  

  QMP_m_site(site,&cur_node,&local_site);
  old_node = save_old_node;
  save_old_node = cur_node;

#ifdef DEBUG
  fprintf(stderr," logical site %d node %d local_site %d old_node %d\n",site,cur_node,local_site,old_node);
#endif

  shift_size = prim_size;
  for(dir = 0;dir < nd;dir++)
  {
    shift_size *= qmp_prob_geometry_->subgrid_length[dir];
    b1 =  logical_size[dir];
    i = cur_node % b1;
    j = old_node % b1;
    cur_node = cur_node / b1;
    old_node = old_node / b1;

    if(j != i)
    { 
      /* the coordinates are different, i.e. we have to do a shift */
#ifdef DEBUG
      fprintf(stderr," diff coordinates for dir = %d new %d old %d\n",dir,i,j);
#endif

      if(((i-j+b1) % b1) != 1)
      {
	fprintf(stderr," par_shift: internal error 1\n");
	exit(1);
      }
      if(i != 0)
	cur_lsite[dir] = local_site;
    
#ifdef DEBUG
      fprintf(stderr,"shift in dir %d, offset = %d size = %d\n",
	     dir,cur_src[dir]*qmp_prob_geometry_->subgrid_vol + cur_lsite[dir],shift_size);
#endif

      if (b1 > 1)
      { /* machine_size[dir] > 1 */
	QMP_sendrecv_wait(
	  (void *)(data + (cur_src[dir]*qmp_prob_geometry_->subgrid_vol
			   + cur_lsite[dir])*prim_size),
	  (void *)(data + ((1-cur_src[dir])*qmp_prob_geometry_->subgrid_vol
			   + cur_lsite[dir])*prim_size),
	  shift_size, send_dir, dir);
      }
      else /* machine_size[dir] = 1 */
      {
	/* Has arguments memcpy(dest, src, count) */
	memcpy((void *)(data + ((1-cur_src[dir])*qmp_prob_geometry_->subgrid_vol
				+ cur_lsite[dir])*prim_size),
	       (void *)(data + (cur_src[dir]*qmp_prob_geometry_->subgrid_vol
				+ cur_lsite[dir])*prim_size),
	       shift_size);
      }

      cur_src[dir] = 1 - cur_src[dir];
      for(j=0;j<dir;j++)
	cur_src[j] = cur_src[dir];
    }
  }

#ifdef DEBUG
  fprintf(stderr,"new offset for read %d\n",local_site + cur_src[0]*qmp_prob_geometry_->subgrid_vol);
#endif

  return local_site + cur_src[0]*qmp_prob_geometry_->subgrid_vol;
}
