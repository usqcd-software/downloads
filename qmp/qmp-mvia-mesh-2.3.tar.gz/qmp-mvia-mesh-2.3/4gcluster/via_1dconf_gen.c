/* Generator for configuration file for 1d configuration */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#define NUM_DIM 1
#define HOST_PREFIX "qcd4g"
#define VIAH_PREFIX "via4g"

#define YPLUS_ETHNAME "-eth7"
#define YMINUS_ETHNAME "-eth6"

#define NUM_CONF 8
#define CONF_Z 0
#define CONF_Y 1

/* Mapping from node name to rank number along z direction */
static int znode_to_rank[8]= {0, 1, 3, 2, 7, 6, 4, 5};

static int zrank_to_node[8]= {0, 1, 3, 2, 6, 7, 5, 4};

/* ethernet names for forward connection for the ranks */
static char* zplus_ethnames[] = {"eth4", "eth5", "eth4", "eth1",
				 "eth4", "eth5", "eth4", "eth1"};

static char* zminus_ethnames[] = {"eth1", "eth4", "eth5", "eth4",
				  "eth1", "eth4", "eth5", "eth4"};


static int dimsize[] = {8};

/**
 * Calculate logic coordinates (allocated already) with a given logic
 * node number (rank), dimensionality and size of the grid.
 */
static void
calculate_coordinates_from_host (char* host,
				 int x, int y,
				 int dimension,
				 int* size,
				 int namecoord[],
				 int coordinates[])

{
  coordinates[0] = node_to_rank[0][x];
  coordinates[1] = node_to_rank[1][y];

  namecoord[0] =  x;
  namecoord[1] =  y;
}

static void
write_header (FILE* fd, int dim, int dim_size[])
{
  int i;

  fprintf (fd, "# This is a sample configuration file\n");
  fprintf (fd, "# Dimension\n");
  fprintf (fd, "%d\n", dim);

  fprintf (fd, "# Dimension size\n");
  i = 0;
  while (i < dim) {
    fprintf (fd, "%d ", dim_size[i]);
    i++;
  }
  fprintf (fd, "\n");
}

static void
write_switch_info (char* host, FILE* fd)
{
  int i;
  char via_host[80], tmp[32];

  sprintf (via_host, "%s%s-eth0", VIAH_PREFIX, &host[strlen(HOST_PREFIX)]);

  fprintf (fd, "%s         %s\n", host, via_host);
}

static void
write_host (char* host, int panel, FILE* fd, FILE* lfd, 
	    int dim, int dim_size[], int namecoord[], int coord[])
{
  int i, k;
  char tmp[32], plus[80], minus[80];
  int nbp[NUM_DIM], nbm[NUM_DIM];

  fprintf (fd, "# Host %s configuration \n", host);
  fprintf (fd, "%s\n", host);
  fprintf (fd, "{\n");

  i = 0;
  while (i < dim) {
    fprintf (fd, "%d ", coord[i]);
    i++;
  }
  fprintf (fd, "\n");

  fprintf (fd, "# device vip_host direction (+1 -1) and axis.\n");
  for (i = 0; i < dim; i++) {

    /* calculate neighbors */
    for (k = 0; k < dim; k++) {
      nbm[k] = nbp[k] = coord[k];
    }
    /* positive direction */
    nbp[i] = (nbp[i] + 1) % dim_size[i];

    /* Plus side of hostname */
    sprintf (plus, "%s%d", VIAH_PREFIX, panel);
    if (i == 0) {
      k = 0;
      while (k < dim) {
	sprintf (tmp, "%d", ((k == i) ? nbp[k] : namecoord[k]));
	strcat (plus, tmp);
	k++;
      }
      strcat (plus, PLUS_ETHNAME);
      fprintf (fd, "/dev/via_eth6   %s      1        %d\n", 
	       plus, i);
    }
    else {
      k = 0;
      while (k < dim) {
	sprintf (tmp, "%d", rank_to_node[k][nbp[k]]);
	strcat (plus, tmp);
	k++;
      }
      strcat (plus, "-");
      strcat (plus, plus_ethnames[coord[i]]);
      fprintf (fd, "/dev/via_%s   %s      1        %d\n", 
	       plus_ethnames[coord[i]], plus, i);
    }


    /* negative direction */
    nbm[i] = nbm[i] - 1;
    if (nbm[i] < 0)
      nbm[i] = dim_size[i] - 1;


    /* Minus side of hostname */
    sprintf (minus, "%s%d", VIAH_PREFIX, panel);
    if (i == 0) {
      k = 0;
      while (k < dim) {
	sprintf (tmp, "%d", ((k == i) ? nbm[k] : namecoord[k]));
	strcat (minus, tmp);
	k++;
      }
      strcat (minus, MINUS_ETHNAME);
      fprintf (fd, "/dev/via_eth7   %s     -1       %d\n", 
	       minus, i);
    }
    else {
      k = 0;
      while (k < dim) {
	sprintf (tmp, "%d", rank_to_node[k][nbm[k]]);
	strcat (minus, tmp);
	k++;
      }
      strcat (minus, "-");
      strcat (minus, minus_ethnames[coord[i]]);
      fprintf (fd, "/dev/via_%s   %s     -1       %d\n", 
	       minus_ethnames[coord[i]], minus, i);
    }
  }
  fprintf (fd, "#connection to switch.\n");
  fprintf (fd, "/dev/via_eth0 \n");
  fprintf (fd, "}\n");

  /* write host name to list file */
  fprintf (lfd, "%s\n", host);
}



int
main (int argc, char** argv)
{
  int num_nodes, i, k, panel, conf_dir;
  int dimension, nodimsize;
  int coord[NUM_DIM], namecoord[NUM_DIM];
  char line[80], hostp[32], hostname[80], dirname[8];
  char *fname, *lfname;
  FILE *fd, *lfd;

  if (argc < 3) {
    fprintf (stderr, "usage: %s panelnum direction (y, z).\n", argv[0]);
    exit (1);
  }
  panel = atoi (argv[1]);

  strcpy (dirname, argv[2]);
  if (dirname[0] == 'z')
    conf_dir = CONF_Z;
  else if (dirname[0] == 'y')
    conf_dir = CONF_Y;
  else {
    fprintf (stderr, "Error in direction specification.\n");
    exit (1);
  }

  
  /* host prefix */
  sprintf (hostp, "%s%d", HOST_PREFIX, panel);

  fd = fopen (fname, "w");
  if (!fd) {
    fprintf (stderr, "Cannot open file %s to write configuration.\n", fname);
    exit (1);
  }

  lfd = fopen (lfname, "w");
  if (!fd) {
    fprintf (stderr, "Cannot open file %s to write list.\n", lfname);
    exit (1);
  }
  
  dimension = NUM_DIM;
  num_nodes = 1;
  for (i = 0; i < dimension; i++)
    num_nodes = num_nodes * dimsize[i];
  fprintf (stderr, "Total number of nodes is %d.\n", num_nodes);

  write_header (fd, dimension, dimsize);

  /* write switched information to the beginning */
  fprintf (fd, "# Switch information\n");
  fprintf (fd, "# Hostname               ViaHost\n");

  
  /* Get switch information */
  for (i = 0; i < dimsize[0]; i++) {
    for (k = 0; k < dimsize[1]; k++) {
      sprintf (hostname, "%s%d%d", hostp, i, k);
      write_switch_info (hostname, fd);
    }
  }

  /* Write individual host information */
  for (i = 0; i < dimsize[0]; i++) {
    for (k = 0; k < dimsize[1]; k++) {
      sprintf (hostname, "%s%d%d", hostp, i, k);
      calculate_coordinates_from_host (hostname, i, k, dimension,
				       dimsize, namecoord, coord);
      write_host (hostname, panel, fd, lfd, 
		  dimension, dimsize, namecoord, coord);
    }
  }
      
  fclose (fd);
  fclose (lfd);

  return 0;
}

  
