/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *     Qcd Message Passing Pacakge Topology part of code
 *
 * Author:  
 *      Jie Chen, Chip Watson and Robert Edwards
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_topology_mvia_mesh.c,v $
 *   Revision 1.6  2004/10/08 19:59:30  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.5  2004/09/23 14:12:54  chen
 *   Add support for MPI port
 *
 *   Revision 1.4  2004/09/01 19:25:48  chen
 *   Add some MPI required routines
 *
 *   Revision 1.3  2003/12/12 20:12:58  chen
 *   Add global routing, scatter, gather
 *
 *   Revision 1.2  2003/12/01 16:53:08  chen
 *   Fixed a minor bug for local loopback devices
 *
 *   Revision 1.1.1.1  2003/11/18 18:55:36  chen
 *   First CVS QMP_mvia_gigeD_mesh
 *
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "qmp.h"
#include "QMP_P_MVIA_MESH.h"

/**
 * Create a physical mesh geometry structure
 */
QMP_phys_geometry_t *
QMP_create_phys_geometry (void)
{
  QMP_phys_geometry_t* phys;

  QMP_TRACE("QMP_create_phys_geometry");

  phys = (QMP_phys_geometry_t *)malloc (sizeof (QMP_phys_geometry_t));
  if (!phys) {
    QMP_error ("Cannot allocate memory for physical geometry.\n");
    return 0;
  }

  return phys;
}

/**
 * Create a physical mesh geometry structure
 */
void
QMP_delete_phys_geometry (QMP_phys_geometry_t* phys)
{
  QMP_TRACE("QMP_delete_phys_geometry");

  if (phys->switch_ports)
    free (phys->switch_ports);
  free (phys);
}

/**
 * Initialize a mesh geometry structure.
 * 
 * @param phys pointer to a physical mesh geometry structure
 */
void
QMP_init_phys_geometry (QMP_phys_geometry_t* phys, char* host)
{
  int i, j;

  QMP_TRACE ("qmp_init_geometry_i");

  phys->type = QMP_MESH;
  phys->num_nodes = 0;

  for (i = 0; i < QMP_PHYS_NMD; i++)
    phys->size[i] = 0;

  phys->my_node.rank = 0;
  strncpy (phys->my_node.host, host, QMP_HOSTNAME_LEN - 1);
  for (i = 0; i < QMP_PHYS_NMD; i++)
    phys->my_node.coordinates[i] = 0;
  
  for (i = 0; i < QMP_PHYS_NMD; i++) 
    for (j = 0; j < 2; j++)
      QMP_init_gige_port (&phys->ports[i][j]);

  phys->switch_ports = 0;
}

/**
 * Check whether two physical node are the same
 */
static QMP_bool_t
qmp_same_physical_node_i (QMP_phys_node_t* p1,
			  QMP_phys_node_t* p2,
			  QMP_u32_t dim)
{
  int i;
  QMP_TRACE("qmp_same_physical_node_i");

  if (p1->rank == p2->rank && strcmp (p1->host, p2->host) == 0) {
    for (i = 0; i < dim; i++) {
      if (p1->coordinates[i] != p2->coordinates[i])
	return QMP_FALSE;
    }
    return QMP_TRUE;
  }
  return QMP_FALSE;
}

/**
 * Create all switched ports for a physical geometry.
 */
QMP_status_t
QMP_create_switched_ports (QMP_phys_geometry_t* phys,
			   QMP_u32_t num_ports)
{
  int i;

  QMP_TRACE ("QMP_create_switched_ports");

  if (QMP_PHYS_NUMNODES(phys) != num_ports) {
    QMP_error ("this should never happen for num_ports != PHYS_NUM_NODES\n");
    return QMP_ERROR;
  }

  phys->switch_ports = (QMP_gige_port_t *)malloc(num_ports * sizeof (QMP_gige_port_t));
  if (!phys->switch_ports) 
    return QMP_NOMEM_ERR;
  else {
    for (i = 0; i < num_ports; i++)
      QMP_init_gige_port (&phys->switch_ports[i]);
  }
  return QMP_SUCCESS;
}


/**
 * Calculate rank number from coordinates along with dimension and 
 * dimension size information.
 *
 * @param coordinates (x,y,z) coordinates of this machine
 * @param dim_size    size of this mesh
 * @param dim         number of dimension of this mesh
 *
 * @return rank number for this machine
 */
QMP_u32_t
QMP_calc_node_rank (QMP_u32_t* coordinates, 
		    QMP_u32_t* dim_sizes,
		    QMP_u32_t dim)
{
  int i;
  QMP_u32_t rank;

  QMP_TRACE ("QMP_calc_node_rank");

  rank = 0;

  for (i = dim - 1; i >=0; i--)
    rank = rank * dim_sizes[i] + coordinates[i];

  return rank;
}


/**
 * Calculate coordinates from a rank along with dimension and
 * dimension size information.
 *
 * @param rank rank of a node
 * @param dim_size    size of this mesh
 * @param dim         number of dimension of this mesh
 * @param coord       return coordinates
 *
 * @return rank number for this machine
 */
void
QMP_calc_node_coordinates (QMP_u32_t  rank,
			   QMP_u32_t* dim_sizes,
			   QMP_u32_t dim,
			   QMP_u32_t coordinates[])
{
  int i;
  QMP_u32_t pos;
  QMP_TRACE ("QMP_calc_node_coordinates");

  pos = rank;

  for (i = 0; i < dim; i++) {
    coordinates[i] = pos % dim_sizes[i];
    pos = pos / dim_sizes[i];
  }
}

/**
 * Check whether two coordinates are the same or not.
 *
 */
QMP_bool_t
QMP_coordinates_equal (QMP_u32_t* coord1, QMP_u32_t* coord2, QMP_u32_t dim)
{
  int i;

  QMP_TRACE ("qmp_coordinates_equal_i");

  for (i = 0; i < dim; i++) {
    if (coord1[i] != coord2[i])
      return QMP_FALSE;
  }
  return QMP_TRUE;
}

/**
 * Find a physical node information from a rank and coordinates
 */
QMP_phys_node_t *
qmp_find_phys_node_i (QMP_machine_t* glm, QMP_u32_t prank)
{
  int i;

  QMP_TRACE("qmp_find_phys_node_i");

  for (i = 0; i < QMP_RTENV_NUMNODES(glm->rtenv); i++) {
    if (prank == QMP_RTENV_NODE_RANK(glm->rtenv, i))
	return &(QMP_RTENV_NODE(glm->rtenv, i));
  }
  return 0;
}

/**
 * Setup all switched node information for a logical topology
 */
static QMP_status_t
qmp_setup_switched_node_info_i (QMP_machine_t* glm, QMP_topology_t* tpl)
{
  int i;
  QMP_u32_t phys_rank, tc[QMP_PHYS_NMD];

  QMP_TRACE ("qmp_setup_switched_node_info_i");
  
  /**
   * Allocate all switched nodes 
   */
  tpl->switched_nodes = (QMP_logic_node_t *)malloc(tpl->num_nodes * sizeof (QMP_logic_node_t));
  if (!tpl->switched_nodes) {
    QMP_error ("cannot allocate memory for logic switched nodes.\n");
    return QMP_NOMEM_ERR;
  }

  /**
   * Walk through each node with logic rank from 0 to num_nodes - 1 
   */
  for (i = 0; i < tpl->num_nodes; i++) {
    tpl->switched_nodes[i].rank = i;
    QMP_calc_node_coordinates (i, tpl->size, tpl->dimension, 
			       tpl->switched_nodes[i].coordinates);

    /* get physical coordinates for this logical coordinates */
    QMP_LOGIC_TO_PHYS_COORDINATES(tpl->switched_nodes[i].coordinates,
				  tc,tpl,tpl->phys);
    phys_rank = QMP_calc_node_rank (tc,
				    QMP_PHYS_DIMSIZE(tpl->phys),
				    QMP_PHYS_DIMENSION(tpl->phys));
    /* Find physical node from this prank and coordinates within 
     * the run time environment.
     */
    tpl->switched_nodes[i].phys_node = qmp_find_phys_node_i (glm, phys_rank);
  }
  return QMP_SUCCESS;
}


/**
 * Setup neighboring information for a logical topology 
 */
static void
qmp_setup_neighboring_info_i (QMP_machine_t* glm, QMP_topology_t* tpl)
{
  int i, k, phys_rank, prank, mrank;
  QMP_u32_t* dsize;
  QMP_u32_t nbp[QMP_LOGIC_NMD], nbm[QMP_LOGIC_NMD];
  QMP_u32_t tc[QMP_PHYS_NMD];

  QMP_TRACE("qmp_setup_neighboring_info_i");

  /* dimension size information */
  dsize = QMP_LOGIC_DIMSIZE(tpl);
  
  /* work for each dimension */
  for (i = 0; i < QMP_LOGIC_DIMENSION(tpl); i++) {
    if (dsize[i] == 1) {
      /* This is the collapsed dimension, neighbor is myself */
      memcpy (&tpl->neighbors[i][0], &tpl->my_node,
	      sizeof (QMP_logic_node_t));
      memcpy (&tpl->neighbors[i][1], &tpl->my_node,
	      sizeof (QMP_logic_node_t));
    }
    else {
      /* find neighboring coordinates for this axis in both directions */
      for (k = 0; k < QMP_LOGIC_DIMENSION(tpl); k++) {
	nbp[k] = nbm[k] = QMP_LOGIC_COORDINATES(tpl)[k];
      }
    
      /* First check for the positive direction */
      nbp[i] = (nbp[i] + 1) % dsize[i];
      nbm[i] = nbm[i] == 0 ? dsize[i] - 1 : nbm[i] - 1;

      prank = QMP_calc_node_rank (nbp,
				  QMP_LOGIC_DIMSIZE(tpl),
				  QMP_LOGIC_DIMENSION(tpl));

      mrank = QMP_calc_node_rank (nbm,
				  QMP_LOGIC_DIMSIZE(tpl),
				  QMP_LOGIC_DIMENSION(tpl));

      /* minus direction */
      tpl->neighbors[i][0].rank = mrank;
      for (k = 0; k < QMP_LOGIC_DIMENSION(tpl); k++)
	tpl->neighbors[i][0].coordinates[k] = nbm[k];
      /* get physical coordinates for this logical coordinates */
      QMP_LOGIC_TO_PHYS_COORDINATES(nbm,tc,tpl,tpl->phys);
      
      phys_rank = QMP_calc_node_rank (tc,
				      QMP_PHYS_DIMSIZE(tpl->phys),
				      QMP_PHYS_DIMENSION(tpl->phys));

      /* Find physical node from this prank and coordinates within 
       * the run time environment.
       */
      tpl->neighbors[i][0].phys_node = qmp_find_phys_node_i (glm, phys_rank);
    
      if (!tpl->neighbors[i][0].phys_node) {
	QMP_error ("fatal error: no physical node information for neighboring logic node.\n");
	exit (1);
      }

      /* plus direction */
      tpl->neighbors[i][1].rank = prank;
      for (k = 0; k < QMP_LOGIC_DIMENSION(tpl); k++)
	tpl->neighbors[i][1].coordinates[k] = nbp[k];
      /* get physical coordinates for this logical coordinates */
      QMP_LOGIC_TO_PHYS_COORDINATES(nbp,tc,tpl,tpl->phys);
      phys_rank = QMP_calc_node_rank (tc,
				      QMP_PHYS_DIMSIZE(tpl->phys),
				      QMP_PHYS_DIMENSION(tpl->phys));
      /* Find physical node from this prank and coordinates within 
       * the run time environment.
       */
      tpl->neighbors[i][1].phys_node = qmp_find_phys_node_i (glm, phys_rank);
    
      if (!tpl->neighbors[i][1].phys_node) {
	QMP_error ("fatal error: no physical node information for neighboring logic node.\n");
	exit (1);
      }
    }
  }
}

/**
 * Check a logical topology is consistent with a physical topology
 * This is a debug routine. This routine should be called after
 * the logical topology is contructed.
 */
static QMP_bool_t
qmp_logical_topology_consistent_i (QMP_topology_t* tpl)
				   
{
  int i;
  QMP_phys_node_t *np, *mp;
  QMP_gige_port_t *port;

  QMP_TRACE("qmp_logical_topology_consistent_i");

  for (i = 0; i < tpl->dimension; i++) {
    if (tpl->size[i] == 1) {
      /* This is the collapsed dimension */
      /* My neighbor is myslef in this dimension */
      if (memcmp (&tpl->my_node, &tpl->neighbors[i][0],
		  sizeof (QMP_logic_node_t)) != 0) 
	return QMP_FALSE;

      if (memcmp (&tpl->my_node, &tpl->neighbors[i][1],
		  sizeof (QMP_logic_node_t)) != 0) 
	return QMP_FALSE;
    }
    else {
      
      /* MINUS direction */
      /* get neighbor's corresponding physical node */
      np = tpl->neighbors[i][0].phys_node;

      /* get this physical node */
      port = &tpl->phys->ports[tpl->ordering[i]][0];
      mp = port->peer;
      
      if (!qmp_same_physical_node_i (np, mp, tpl->phys->dimension))
	return QMP_FALSE;

      /* PLUS direction */
      /* get neighbor's corresponding physical node */
      np = tpl->neighbors[i][1].phys_node;

      /* get this physical node */
      port = &tpl->phys->ports[tpl->ordering[i]][1];
      mp = port->peer;

      if (!qmp_same_physical_node_i (np, mp, tpl->phys->dimension))
	return QMP_FALSE;
    }
  }
  return QMP_TRUE;
}

/**
 * Set up logical topology mapping index. If a mapping index for
 * a particular direction is -1, no mapping for this direction.
 * This also means, the dimension size for this direction = 1
 */
static QMP_status_t
qmp_setup_logical_mapping_i (QMP_phys_geometry_t* phys,
			     QMP_topology_t* tpl,
			     const QMP_u32_t* dims,
			     QMP_u32_t ndim,
			     QMP_u32_t* ordering)
{
  int i, j, k, realsize, numchecked;
  QMP_u32_t *checked, *phys_size;

  QMP_TRACE ("qmp_setup_logical_mapping_i");

  /* First set the ordering array to -1 for all */
  for (i = 0; i < QMP_LOGIC_NMD; i++)
    tpl->ordering[i] = -1;

  
  if (!ordering) {
    /* First create a checked array */
    checked = (QMP_u32_t *)malloc(QMP_PHYS_DIMENSION(phys) * sizeof (QMP_u32_t));
    if (!checked) {
      QMP_fprintf (stderr, "Cannot allocated memory for qmp_setup_logical_mapping_i.\n");
      exit (1);
    }
    for (i = 0; i < QMP_PHYS_DIMENSION(phys); i++)
      checked[i] = 0;

    /* Find out real size of dims excluding element = 1 */
    realsize = ndim;
    for (i = 0; i < ndim; i++) {
      if (dims[i] == 1)
	realsize--;
    }

    /* Get physical geometry size */
    phys_size = QMP_PHYS_DIMSIZE(phys);
    
    numchecked = 0;
    for (k = 0; k < ndim; k++) {
      for (i = 0; i < QMP_PHYS_DIMENSION(phys); i++) {
	if (!checked[i] && dims[k] == phys_size[i]) {
	  checked[i] = 1;
	  tpl->ordering[k] = i;
	  numchecked++;
	  break;
	}
      }
    }

    /* Find out which direction is not checked */
    /* This is for the cases where logical dimension is < physical dimension */
    for (i = ndim; i < QMP_PHYS_DIMENSION(phys); i++) {
      /* Get ordering information for a direction that is not inside
       * the logical topology. These ordering should be the same as
       * the physical direction
       */
      for (j = 0; j < QMP_PHYS_DIMENSION(phys); j++) {
	/* Check out which dicrection is not appeared in the ordering
	 * array yet
	 */
	for (k = 0; k < QMP_PHYS_DIMENSION(phys); k++) {
	  if (j == tpl->ordering[k]) /* appeared */
	    break;
	}
	if (k < QMP_PHYS_DIMENSION(phys)) 
	  /* This direction is in the ordering array */
	  continue;
	/* Now this direction is not in the ordering array */
	break;
      }
      tpl->ordering[i] = j;
    }

    /* Free memory for checked array */
    free (checked);

    if (numchecked != realsize) {
      QMP_error ("Fatal error: number of checked indeices != real dimension size.\n");
      exit (1);
    }
  }
  else {
    for (i = 0; i < ndim; i++) 
      tpl->ordering[i] = ordering[i];


    /* Find out which direction is not checked */
    /* This is for the cases where logical dimension is < physical dimension */
    for (i = ndim; i < QMP_PHYS_DIMENSION(phys); i++) {
      /* Get ordering information for a direction that is not inside
       * the logical topology. These ordering should be the same as
       * the physical direction
       */
      for (j = 0; j < QMP_PHYS_DIMENSION(phys); j++) {
	/* Check out which dicrection is not appeared in the ordering
	 * array yet
	 */
	for (k = 0; k < QMP_PHYS_DIMENSION(phys); k++) {
	  if (j == tpl->ordering[k]) /* appeared */
	    break;
	}
	if (k < QMP_PHYS_DIMENSION(phys)) 
	  /* This direction is in the ordering array */
	  continue;
	/* Now this direction is not in the ordering array */
	break;
      }
      tpl->ordering[i] = j;
    }


  }
  return QMP_SUCCESS;
}

/**
 * Set up a logical topology
 */
static QMP_status_t
qmp_setup_logical_topology_i (QMP_machine_t* glm,
			      QMP_topology_t* tpl,
			      const QMP_u32_t* dims,
			      QMP_u32_t ndim,
			      QMP_u32_t* ordering)
{
  QMP_u32_t lrank;
  QMP_status_t status;

  QMP_TRACE("qmp_setup_logical_topology_i");

  QMP_LOGIC_SET_DIMENSION(tpl,ndim);
  QMP_LOGIC_SET_DIMSIZE(tpl,dims);
  QMP_LOGIC_CALC_NUMNODES(tpl);

  /** 
   * Set mapping indices 
   * even though ndim may < than phys dimension, we still assign ordering to
   * those axes.
   */
  qmp_setup_logical_mapping_i (tpl->phys,
			       tpl, dims, ndim, ordering);

  /* Set logical coordinates */
  QMP_PHYS_TO_LOGIC_COORDINATES(QMP_PHYS_COORDINATES(glm->phys),
				tpl->my_node.coordinates, tpl);
  /* Calculate the logic rank */
  lrank = QMP_calc_node_rank (tpl->my_node.coordinates,
			      QMP_LOGIC_DIMSIZE(tpl),
			      QMP_LOGIC_DIMENSION(tpl));
  /* Set rank for this topology */
  QMP_LOGIC_SET_RANK(tpl, lrank);

  /* Set up my logical node's counter part of physical node */
  tpl->my_node.phys_node = &glm->phys->my_node;

  /* Set up physical geometry corresponding to this logical geometry */
  tpl->phys = glm->phys;

  /* Set up neighboring information for this node */
  qmp_setup_neighboring_info_i (glm, tpl);

  /* Set up all switched node information         */
  if ((status = qmp_setup_switched_node_info_i (glm, tpl)) != QMP_SUCCESS)
    return status;

  return QMP_SUCCESS;
}

/**
 * Check whether a topology dimension is valid for the physical
 * topology with an optional axes mapping array
 * return -1: invalidtopology
 * return 0:  ok
 */
static QMP_s32_t
qmp_valid_logic_topology_i (QMP_machine_t* glm,
			    const QMP_u32_t* dims,
			    QMP_u32_t ndim,
			    QMP_u32_t* ordering)
{
  int i, k;
  QMP_u32_t  realdim;
  QMP_u32_t* phys_sizes;

  QMP_TRACE("qmp_valid_logic_topology_i");

  /** 
   * logical topology dimension must be <= to
   * the dimension of physical topology.
   */
  if (ndim > QMP_PHYS_DIMENSION(glm->phys)) {
    realdim = ndim;
    for (i = 0; i < ndim; i++)
      if (dims[i] == 1)
	realdim--;
    
    if (realdim > QMP_PHYS_DIMENSION(glm->phys)) {
      QMP_error ("logical dimension is larger than physical dimension.\n");
      return -1;
    }
  }

  /**
   * Get physical topology dimension size information
   */
  phys_sizes = QMP_PHYS_DIMSIZE(glm->phys);

  if (!ordering) {
    /* Check whether a physical topology contains logical topology */
    if (QMP_array_contains (phys_sizes, QMP_PHYS_DIMENSION(glm->phys),
			    (QMP_u32_t *)dims, ndim) != QMP_TRUE) {
      QMP_error ("Declareed logical topology cannot be accomadated by this mesh machine.\n");
      return -1;
    }
  }
  else {
    /* caller provides a mapping indices */
    for (k = 0; k < ndim; k++) {
      if (dims[k] != 1) {
	if (dims[k] != phys_sizes[ordering[k]]) {
	  QMP_error ("mismatched topology dimension size information.\n");
	  return -1;
	}
      }
    }
  }
  return 0;
}
  
/**
 * Destroy a logical topology
 */
void
QMP_delete_topology (QMP_topology_t* tpl)
{
  QMP_TRACE("QMP_delete_topology");

  if (tpl) {
    /* all phys node information are stored inside rtenv */
    free (tpl->switched_nodes);
    
    free (tpl);
  }
}


/**
 * Create a new logical grid topology with grid dimension and grid size
 */
static QMP_status_t
qmp_declare_logical_topology_i (QMP_machine_t* glm,
				const QMP_u32_t* dims,
				QMP_u32_t ndim)
{
  int             mapped_index;
  QMP_topology_t* tpl;
  QMP_status_t    status;
  

  QMP_TRACE ("qmp_declare_logical_topology_i");

  if (glm->inited == QMP_FALSE) {
    QMP_error ( "QMP has not been initialized.");
    QMP_SET_STATUS_CODE(glm, QMP_NOT_INITED);
    return QMP_NOT_INITED;
  }

  /* If a topology is created, we cannot create a different one. */
  tpl = glm->tpl;
  if (tpl) {
    QMP_error ("a logical topology exists already.");
    QMP_SET_STATUS_CODE(glm, QMP_TOPOLOGY_EXISTS);
    return QMP_TOPOLOGY_EXISTS;
  }

  /* check whether the topology is valid */
  mapped_index = qmp_valid_logic_topology_i (glm, dims, ndim, 0);
  if (mapped_index == -1)
    return QMP_INVALID_TOPOLOGY;

  /* create memory for topology */
  tpl = (QMP_topology_t *)malloc(sizeof (QMP_topology_t));
  if (!tpl) {
    QMP_error ("cannot allocated memory for logical topology.\n");
    return QMP_NOMEM_ERR;
  }
  tpl->phys = glm->phys;

  if ((status = qmp_setup_logical_topology_i (glm, tpl, dims, ndim, 0)) !=
      QMP_SUCCESS)
    return status;

  if (QMP_rt_verbose)
    QMP_print_topology (tpl);

  if (!qmp_logical_topology_consistent_i (tpl)) {
    QMP_error ("inconsistent logical topology with the underlying physical topology, check your list and configuration file.");
    return QMP_INVALID_TOPOLOGY;
  }

  glm->tpl = tpl;
  return QMP_SUCCESS;

}

/**
 * Create a new logical grid topology with grid dimension and grid size
 *
 * This is a public function.
 */
QMP_status_t    
QMP_declare_logical_topology (const int dims[],
			      int ndim)
{
  QMP_TRACE ("QMP_declare_logical_topology");
  return qmp_declare_logical_topology_i (&QMP_global_m, dims, ndim);
}


/**
 * Create a new logical grid topology with grid dimension and grid size
 */
static QMP_bool_t    
qmp_declare_ordered_logical_topology_i (QMP_machine_t* glm,
					const QMP_u32_t* dims,
					QMP_u32_t ndim,
					QMP_u32_t* ordering)
{
  int             mapped_index;
  QMP_topology_t* tpl;
  

  QMP_TRACE ("qmp_declare_logical_topology_i");

  if (glm->inited == QMP_FALSE) {
    QMP_error ( "QMP has not been initialized.");
    QMP_SET_STATUS_CODE(glm, QMP_NOT_INITED);
    return QMP_FALSE;
  }

  /* If a topology is created, we cannot create a different one. */
  tpl = glm->tpl;
  if (tpl) {
    QMP_error ("a logical topology exists already.");
    QMP_SET_STATUS_CODE(glm, QMP_TOPOLOGY_EXISTS);
    return QMP_FALSE;
  }

  /* check whether the topology is valid */
  mapped_index = qmp_valid_logic_topology_i (glm, dims, ndim, ordering);
  if (mapped_index == -1)
    return QMP_FALSE;

  /* create memory for topology */
  tpl = (QMP_topology_t *)malloc(sizeof (QMP_topology_t));
  if (!tpl) {
    QMP_error ("cannot allocated memory for logical topology.\n");
    return QMP_FALSE;
  }
  tpl->phys = glm->phys;

  if (qmp_setup_logical_topology_i (glm, tpl, dims, ndim, ordering) !=
      QMP_SUCCESS)
    return QMP_FALSE;

  if (QMP_rt_verbose)
    QMP_print_topology (tpl);

  if (!qmp_logical_topology_consistent_i (tpl)) {
    QMP_error ("inconsistent logical topology with the underlying physical topology, check your list and configuration file.");
    return QMP_FALSE;
  }

  glm->tpl = tpl;
  return QMP_TRUE;

}


/**
 * Create a new logical topology with a grid dimension and dimension size
 * along with mapping information for axes.
 */
QMP_bool_t
QMP_declare_ordered_logical_topology (const QMP_u32_t* dims,
				      QMP_u32_t ndim,
				      QMP_u32_t* ordering)
{
  QMP_TRACE("QMP_declare_ordered_logical_topology");

  return qmp_declare_ordered_logical_topology_i (&QMP_global_m, dims,
						 ndim, ordering);
}

/**
 * Print out this topology information.
 */
void
QMP_print_topology (QMP_topology_t* tpl)
{
  int i, j;

  QMP_TRACE("QMP_print_topology");

  fprintf (stderr, "++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
  fprintf (stderr, "Topology has %d dimension with size [", tpl->dimension);
  for (i = 0; i < tpl->dimension; i++) 
    fprintf (stderr, "%d ", tpl->size[i]);
  fprintf (stderr, "]\n");

  fprintf (stderr, "Number of logical nodes is %d\n", tpl->num_nodes);
  fprintf (stderr, "Logic rank of this node is %d\n", tpl->my_node.rank);
  fprintf (stderr, "Logic coordinates of this node is [");
  for (i = 0; i < tpl->dimension; i++)
    fprintf (stderr, "%d ", tpl->my_node.coordinates[i]);
  fprintf (stderr, "]\n");

  fprintf (stderr, "Neighbors are : \n");
  for (i = 0; i < tpl->dimension; i++) {
    fprintf (stderr, "Axis %d direction MINUS: rank %d coordinates [",
	     i, tpl->neighbors[i][0].rank);
    for (j = 0; j < tpl->dimension; j++) 
      fprintf (stderr, "%d ", tpl->neighbors[i][0].coordinates[j]);
    fprintf (stderr, "]\n");
    fprintf (stderr, "Physical node looks like: rank %d host %s coordinates [",
	     tpl->neighbors[i][0].phys_node->rank,
	     tpl->neighbors[i][0].phys_node->host);
    for (j = 0; j < QMP_PHYS_DIMENSION(tpl->phys); j++)
      fprintf (stderr, "%d ", tpl->neighbors[i][0].phys_node->coordinates[j]);
    fprintf (stderr, "]\n");

    fprintf (stderr, "Axis %d direction PLUS: rank %d coordinates [",
	     i, tpl->neighbors[i][1].rank);
    for (j = 0; j < tpl->dimension; j++) 
      fprintf (stderr, "%d ", tpl->neighbors[i][1].coordinates[j]);
    fprintf (stderr, "]\n");
    fprintf (stderr, "Physical node looks like: rank %d host %s coordinates [",
	     tpl->neighbors[i][1].phys_node->rank,
	     tpl->neighbors[i][1].phys_node->host);
    for (j = 0; j < QMP_PHYS_DIMENSION(tpl->phys); j++)
      fprintf (stderr, "%d ", tpl->neighbors[i][1].phys_node->coordinates[j]);
    fprintf (stderr, "]\n");
  }


  fprintf (stderr, "Switched connections are : \n");
  for (i = 0; i < tpl->num_nodes; i++) {
    fprintf (stderr, "rank %d coordinates [", tpl->switched_nodes[i].rank);
    for (j = 0; j < tpl->dimension; j++) 
      fprintf (stderr, "%d ", tpl->switched_nodes[i].coordinates[j]);
    fprintf (stderr, "]\n");
    fprintf (stderr, "Physical node looks like: rank %d host %s coordinates [",
	     tpl->switched_nodes[i].phys_node->rank,
	     tpl->switched_nodes[i].phys_node->host);
    for (j = 0; j < QMP_PHYS_DIMENSION(tpl->phys); j++)
      fprintf (stderr, "%d ", tpl->switched_nodes[i].phys_node->coordinates[j]);
    fprintf (stderr, "]\n");
  }

  fprintf (stderr, "Corresponding physical node is : rank %d host %s coordinates [",
	   tpl->phys->my_node.rank,
	   tpl->phys->my_node.host);
  for (j = 0; j < QMP_PHYS_DIMENSION(tpl->phys); j++)
    fprintf (stderr, "%d ", tpl->phys->my_node.coordinates[j]);
  fprintf (stderr, "]\n");
  
  fprintf (stderr, "++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
}

/**
 * Check whether a topology is declared or not.
 */
static QMP_bool_t
qmp_logical_topology_is_declared_i (QMP_machine_t* glm)
{
  QMP_TRACE ("qmp_logical_topology_is_declared_i");

  if (glm->tpl)
    return QMP_TRUE;
  return QMP_FALSE;
}


/**
 * Check whether a topology is declared or not.
 */
QMP_bool_t
QMP_logical_topology_is_declared (void)
{
  return qmp_logical_topology_is_declared_i (&QMP_global_m);
}


/**
 * Return dimensionality of the logical topology. If there is no
 * logical topology,  return physical topology information.
 */
static const int
qmp_get_logical_number_of_dimensions_i (QMP_machine_t* glm)
{
  QMP_TRACE ("qmp_get_number_of_logical_dimensions_i");

  if (glm->inited && glm->tpl)
    return glm->tpl->dimension;
  else
    return QMP_get_allocated_number_of_dimensions ();
}

/**
 * Return dimensionality of the logical topology. If there is no
 * logical topology,  return physical topology information.
 *
 * This is a public function.
 */
int
QMP_get_logical_number_of_dimensions (void)
{
  return qmp_get_logical_number_of_dimensions_i (&QMP_global_m);
}

/**
 * Return dimension size of the logical topology.
 *
 * If there is no logical topology, return information from
 * physical geometry.
 */
static const int*  
qmp_get_logical_dimensions_i (QMP_machine_t* glm)
{
  QMP_TRACE ("qmp_get_logical_dimensions_i");

  if (glm->inited && glm->tpl)
    return glm->tpl->size;
  else
    return QMP_get_allocated_dimensions ();
}


/**
 * Return dimension size of the logical topology.
 *
 * If there is no logical topology, return information from
 * physical geometry.
 */
const int*  
QMP_get_logical_dimensions (void)
{
  return qmp_get_logical_dimensions_i (&QMP_global_m);
}

/**
 * Return logical node number of this machine, where first logical
 * dimension increases most rapidly.
 */
const int
qmp_get_logical_node_number_i (QMP_machine_t* glm)
{
  QMP_TRACE ("qmp_get_logical_node_number_i");

  if (glm->inited && glm->tpl)
    return QMP_LOGIC_RANK(glm->tpl);
  else if (glm->inited)
    return QMP_PHYS_RANK(glm->phys);
  else {
    QMP_error ("no logical and physical node number available yet.");
    exit (1);
    /* make compiler happy */
    return 0;
  }
}

/**
 * Return logical node number of this machine, where first logical
 * dimension increases most rapidly.
 *
 * This is a public function.
 */
int
QMP_get_logical_node_number (void)
{
  return qmp_get_logical_node_number_i (&QMP_global_m);
}


/**
 * Get coordinates within the logical topology.
 * If no logical topology declared, return information from physical
 * geometry.
 */
static const int*   
qmp_get_logical_coordinates_i (QMP_machine_t* glm)
{
  QMP_TRACE ("qmp_get_logical_coordinates_i");

  if (glm->inited && glm->tpl)
    return QMP_LOGIC_COORDINATES(glm->tpl);
  else
    return QMP_get_allocated_coordinates ();
}


/**
 * Get coordinates within the logical topology.
 * If no logical topology declared, return information from physical
 * geometry.
 *
 * This is a public function.
 */
const int*   
QMP_get_logical_coordinates (void)
{
  return qmp_get_logical_coordinates_i (&QMP_global_m);
}
    
/**
 * Returns logical node number from a physical node number.
 * In a switched environment, these two are the same.
 */
static const QMP_u32_t
qmp_allocated_to_logical_i (QMP_machine_t* glm, QMP_u32_t pnode)
{
  QMP_u32_t pcoord[QMP_PHYS_NMD], lcoord[QMP_LOGIC_NMD];
  QMP_TRACE ("qmp_allocated_to_logical_i");

  if (!glm->inited || !glm->tpl) {
    QMP_error ("QMP has no logical topology information yet.");
    exit (1);
  }

  /* Obtain physical coordinates from the physical node rank */
  QMP_calc_node_coordinates (pnode, QMP_PHYS_DIMSIZE(glm->phys),
			     QMP_PHYS_DIMENSION(glm->phys),
			     pcoord);

  /* Translate physical coordinates to new logical coordinates */
  QMP_PHYS_TO_LOGIC_COORDINATES(pcoord,lcoord,glm->tpl);

  /* Finally calculate logical rank from logical coordinates */
  return QMP_calc_node_rank (lcoord, 
			     QMP_LOGIC_DIMSIZE(glm->tpl),
			     QMP_LOGIC_DIMENSION(glm->tpl));
}


/**
 * Returns logical node number from a physical node number.
 * In a switched environment, these two are the same.
 *
 * This is a public function.
 */
QMP_u32_t
QMP_allocated_to_logical (QMP_u32_t node)
{
  return qmp_allocated_to_logical_i (&QMP_global_m, node);
}

/**
 * Internal function to get logical coordinate for a physical  node number
 */
static int*   
qmp_get_logical_coordinates_from_i (QMP_machine_t* glm, int pnode)
{
  QMP_u32_t* nc;
  QMP_u32_t  lnode;

  QMP_TRACE ("qmp_get_logical_coordinates_from_i");

  if (glm->inited == QMP_FALSE) {
    QMP_error ( "QMP has not been initialized.");
    QMP_SET_STATUS_CODE(glm, QMP_NOT_INITED);
    return 0;
  }

  /* If a topology is created, we cannot create a different one. */
  if (!glm->tpl) {
    QMP_error ("No logical topology exists.");
    QMP_SET_STATUS_CODE(glm, QMP_NOT_INITED);
    return 0;
  }
  
  /* Convert physical node to logical node */
  lnode = qmp_allocated_to_logical_i (glm, pnode);

  /* allocate memory for coordinate */
  nc = (QMP_u32_t *)malloc(glm->tpl->dimension*sizeof (QMP_u32_t));

  QMP_calc_node_coordinates (lnode,
			     QMP_LOGIC_DIMSIZE(glm->tpl),
			     QMP_LOGIC_DIMENSION(glm->tpl),
			     nc);
  return nc;
}


/**
 * Get a logical coordinate from a physical node number
 * If no logical topology declared, return information from physical
 * geometry.
 *
 * This is a public function.
 */
int*
QMP_get_logical_coordinates_from (int node)
{
  return qmp_get_logical_coordinates_from_i (&QMP_global_m, node);
}


/**
 * Get the logical node number from its coordinates inside the logical
 * topology.
 */
static const int
qmp_get_logical_node_number_from_i (QMP_machine_t* glm,
				    const QMP_u32_t* coordinates)
{

  QMP_TRACE ("qmp_get_logical_node_number_from_i");

  if (!glm->inited || !glm->tpl) {
    QMP_error ("QMP has no logical topology information yet.");
    exit (1);
  }
  return QMP_calc_node_rank ((QMP_u32_t *)coordinates, 
			     QMP_LOGIC_DIMSIZE(glm->tpl),
			     QMP_LOGIC_DIMENSION(glm->tpl));
}

/**
 * Get the logical node number from its coordinates inside the logical
 * topology.
 *
 * This is a public function.
 */
const int
QMP_get_logical_node_number_from (const QMP_u32_t* coordinates)
{
  return qmp_get_logical_node_number_from_i(&QMP_global_m,
					    coordinates);
}


/**
 * Get the physical node number from its coordinates inside the logical
 * topology.
 *
 * This is a public function.
 */
int
QMP_get_node_number_from (const int coordinates[])
{
  QMP_u32_t pcoord[QMP_PHYS_NMD];
  QMP_TRACE ("QMP_get_node_number_from");

  if (!QMP_global_m.inited) {
    QMP_error ("QMP has not yet been initialized.\n");
    exit (1);
  }

  if (QMP_global_m.tpl) {
    /* Get physical coordinates from the logical coordinates */
    QMP_LOGIC_TO_PHYS_COORDINATES(coordinates,pcoord,QMP_global_m.tpl,
				  QMP_global_m.phys);

    /* Get physical node from physical coordinates */
    return QMP_calc_node_rank ((QMP_u32_t *)pcoord,
			       QMP_PHYS_DIMSIZE(QMP_global_m.phys),
			       QMP_PHYS_DIMENSION(QMP_global_m.phys));
  }
  else 
    return QMP_calc_node_rank ((QMP_u32_t *)coordinates,
			       QMP_PHYS_DIMSIZE(QMP_global_m.phys),
			       QMP_PHYS_DIMENSION(QMP_global_m.phys));
}

const QMP_u32_t 
qmp_get_logical_number_of_nodes_i (QMP_machine_t* glm)
{
  QMP_TRACE ("qmp_get_number_of_logical_nodes_i");

  if (!glm->inited) {
    QMP_error ("QMP has not been initialized yet.");
    exit (1);
  }

  if (glm->tpl)
    return QMP_LOGIC_NUMNODES(glm->tpl);
  else 
    /* If no topology, use physical topology instead */
    return QMP_PHYS_NUMNODES (glm->phys);
}  

QMP_u32_t 
QMP_get_logical_number_of_nodes (void)
{
  return qmp_get_logical_number_of_nodes_i (&QMP_global_m);
}

/**
 * Return a physical node number from a logical node number.
 */
static const QMP_u32_t    
qmp_logical_to_allocated_i (QMP_machine_t* glm, QMP_u32_t logic_rank)
{
  QMP_u32_t lcoord[QMP_LOGIC_NMD], pcoord[QMP_PHYS_NMD];
  QMP_TRACE ("qmp_logical_to_allocated_i");

  if (!glm->inited || !glm->tpl) {
    QMP_error ("QMP has no logical topology information yet.");
    exit (1);
  }

  /* find logic coordinates using the logic rank */
  QMP_calc_node_coordinates (logic_rank,
			     QMP_LOGIC_DIMSIZE(glm->tpl),
			     QMP_LOGIC_DIMENSION(glm->tpl),
			     lcoord);

  /* Convert logic coordinates to physical coordinates */
  QMP_LOGIC_TO_PHYS_COORDINATES(lcoord,pcoord,glm->tpl,glm->phys);
  
  /* return physical rank from the physical coordinates */
  return QMP_calc_node_rank (pcoord,
			     QMP_PHYS_DIMSIZE(glm->phys),
			     QMP_PHYS_DIMENSION(glm->phys));
}

/**
 * Return a physical node number from a logical node number.
 *
 * This is a public function.
 */
QMP_u32_t    
QMP_logical_to_allocated (QMP_u32_t logic_rank)
{
  return qmp_logical_to_allocated_i (&QMP_global_m, logic_rank);
}


/**
 * Return node number of this machine
 *
 * 
 * Always return physical node number
 *
 * This is a public function.
 */
int
QMP_get_node_number (void)
{
  QMP_machine_t* glm = &QMP_global_m;

  QMP_TRACE ("QMP_get_node_number");

  if (!glm->inited) {
    QMP_error ("QMP system has not been properly initialized. \n");
    exit (1);
    return 0;
  }
  else 
    return QMP_PHYS_RANK(glm->phys);
}


/**
 * Get number of nodes for this parallel jobs.
 *
 * If there is a logical topology, then number of logical number of nodes
 * is returned. 
 *
 * Otherwise number of allocated physical nodes is returned
 *
 * This number should be the same as the number requested by
 * a logical topology.
 */
int
QMP_get_number_of_nodes (void)
{
  QMP_machine_t* glm = &QMP_global_m;

  QMP_TRACE ("QMP_get_node_number");

  if (!glm->inited) {
    QMP_error ("QMP system has not been properly initialized. \n");
    exit (1);
    return 0;
  }
  else {
    if (glm->tpl) 
      return QMP_LOGIC_NUMNODES(glm->tpl);
    else
      return QMP_PHYS_NUMNODES(glm->phys);
  }
}


/**
 * Given a destination physical node, return a gige_port that connect
 * this node to that node.
 *
 * If this is a directly connected node, return a direct gige port.
 * Otherwise, return a switched gige port.
 */
QMP_gige_port_t *
QMP_get_connection_port (QMP_machine_t* glm, QMP_u16_t dest,
			 QMP_s16_t direction, QMP_mh_type_t type)
{
  int i;
  QMP_gige_port_t *p, *m;

  QMP_TRACE ("QMP_get_connection_port");

  /* Check mesh connections first */
  for (i = 0; i < QMP_PHYS_DIMENSION(glm->phys); i++) {
    m = &(glm->phys->ports[i][0]);
    p = &(glm->phys->ports[i][1]);
    
    if (m->peer->rank != p->peer->rank) {
      /* This is not a back to back connections */
      if (m->peer->rank == dest)
	return m;
    
      if (p->peer->rank == dest)
	return p;
    }
    else {
      /* Now send always on positive direction and recv always on minus 
       * if there is no direction specified
       */
      if (direction != -1 && direction != 1) {
	if (type == QMP_MH_SEND)
	  direction = 1;
	else if (type == QMP_MH_RECV)
	  direction = -1;
	else {
	  QMP_error ("Get connection port direction error.\n");
	  exit (1);
	}
      }
      
      if (m->peer->rank == dest && direction == -1)
	return m;
    
      if (p->peer->rank == dest && direction == 1)
	return p;
    }
  }

  /* Now check switched ports */
  for (i = 0; i < QMP_PHYS_NUMNODES(glm->phys); i++) {
    p = &(glm->phys->switch_ports[i]);
    if (p->peer->rank == dest) 
      return p;
  }

  QMP_error ("Cannot reach here: there are no connections to reach destination %d.\n", dest);
  exit (1);

  return 0;
}


/**
 * Given a destination physical node, find out whether there is a
 * unique connection to the destination node.
 *
 */
QMP_bool_t
QMP_has_unique_connection (QMP_machine_t* glm, QMP_u16_t dest,
			   QMP_mh_type_t type)
{
  int i, direction;
  QMP_gige_port_t *p, *m;

  QMP_TRACE ("QMP_has_unique_connection");

  /* Check mesh connections first */
  for (i = 0; i < QMP_PHYS_DIMENSION(glm->phys); i++) {
    m = &(glm->phys->ports[i][0]);
    p = &(glm->phys->ports[i][1]);

    if (m->peer->rank != p->peer->rank) {
      /* This is not back to back link */
      if (m->peer->rank == dest)
	return QMP_TRUE;
    
      if (p->peer->rank == dest)
	return QMP_TRUE;
    }
    else {
      /* Now send always on positive direction and recv always on minus 
       * if there is no direction specified
       */
      if (type == QMP_MH_SEND)
	direction = 1;
      else if (type == QMP_MH_RECV)
	direction = -1;
      else {
	QMP_error ("Get connection port direction error.\n");
	exit (1);
      }

      if (m->peer->rank == dest && direction == -1) 
	return QMP_TRUE;
    
      if (p->peer->rank == dest && direction == 1) 
	return QMP_TRUE;
    }
  }

  /* Now check switched ports */
  for (i = 0; i < QMP_PHYS_NUMNODES(glm->phys); i++) {
    p = &(glm->phys->switch_ports[i]);
    if (p->peer->rank == dest)
      return QMP_TRUE;
  }

  QMP_error ("Cannot reach here: there are no connections to reach destination %d.\n", dest);
  exit (1);

  return QMP_FALSE;
}


/**
 * Check whether two nodes are ajacent to each other in any direction
 *
 * @param node1 and node2 are physical node number
 * @return QMP_TRUE if these two nodes are adjacent to each other
 */
QMP_bool_t
QMP_are_neighbors (QMP_machine_t* glm, 
		   QMP_u32_t node1, QMP_u32_t node2)
{
  int i, k;
  QMP_u32_t numdims;
  QMP_u32_t *coord1, *coord2, *dimsize;
  QMP_s32_t left[QMP_PHYS_NMD], right[QMP_PHYS_NMD];


  QMP_TRACE("QMP_are_neighbors");

  /**
   * Get physical dimension information
   */
  numdims = QMP_PHYS_DIMENSION(glm->phys);
  dimsize = QMP_PHYS_DIMSIZE(glm->phys);

  /**
   * Get destination physical coordinates
   */
  coord1 = QMP_NODEP_COORDINATES(qmp_find_phys_node_i (glm, node1));
  coord2 = QMP_NODEP_COORDINATES(qmp_find_phys_node_i (glm, node2));

  for (i = 0; i < numdims; i++) {
    /* For each direction calculate two neighbors coordinates */
    for (k = 0; k < numdims; k++) {
      left[k] = coord1[k];
      right[k] = coord1[k];
    }
    left[i] = coord1[i] - 1;
    if (left[i] < 0)
      left[i] = dimsize[i] - 1;
    right[i] = (coord1[i] + 1) % (dimsize[i]);

    /* Now compare whether left or right == coord2 */
    if (QMP_coordinates_equal (coord2, left, numdims))
      return QMP_TRUE;

    if (QMP_coordinates_equal (coord2, right, numdims))
      return QMP_TRUE;
  }
  return QMP_FALSE;
}

/**
 * Construct a routing path from a src to a destination
 *
 * Routing using physical geomemtry only. This is based on logical topology
 * and physical geometry only diffs by directions.
 *
 * Always use the direction that has shortest distance to the destination
 * E.G. (0, 0, 1) --> (2, 4, 4) will use x direction, z direction and then y
 *
 *
 * The final results are stored in the pre-allocated array of rank number
 * 
 * Initial num_steps = size of allocated path. Upon return, num_steps will be
 * number of entries in the path.
 *
 * This routine is called after src and destination are determined not to
 * be neighbors
 *
 * Note: src and destination are physical node id
 */
QMP_status_t
QMP_set_routing_path (QMP_machine_t* glm,
		      QMP_u32_t src, QMP_u32_t dest,
		      QMP_u32_t path[], QMP_u32_t* num_steps)
{
  int path_size, i, k;
  QMP_u32_t numdims, direct, rank, nextrank;
  QMP_u32_t *rcoord, *dcoord, *dimsize;
  QMP_s32_t nextcoord[QMP_LOGIC_NMD];
  QMP_s32_t dist[QMP_LOGIC_NMD], sign[QMP_LOGIC_NMD], tmp;

  QMP_TRACE("QMP_set_routing_path");

  direct = 0;
  path_size = *num_steps;

  /**
   * Get physical dimension information
   */
  numdims = QMP_PHYS_DIMENSION(glm->phys);
  dimsize = QMP_PHYS_DIMSIZE(glm->phys);

  /**
   * Get destination physical coordinates
   */
  dcoord = QMP_NODEP_COORDINATES(qmp_find_phys_node_i (glm, dest));
  
  /**
   * Calculate each step until it is done
   */
  k = 0;
  rank = src;
  path[k++] = rank;

  while (rank != dest) {
    /* calculate coordinates for current rank */
    rcoord = QMP_NODEP_COORDINATES(qmp_find_phys_node_i (glm, rank));
    
    /* Calculate distances along each direction */
    for (i = 0; i < numdims; i++) {
      tmp = dcoord[i] - rcoord[i];
      dist[i] =(abs(tmp) <= dimsize[i]/2) ? abs(tmp) : (dimsize[i] - abs(tmp));
      sign[i] =(abs(tmp) <= dimsize[i]/2) ? tmp : (-1)*tmp;
    }

    /* Now find out shortest non zero distance */
    tmp = 1234567;
    for (i = 0; i < numdims; i++) {
      if (dist[i] != 0 && dist[i] < tmp) {
	tmp = dist[i];
	direct = i;
      }
    }

    /* Now we should move along direction 'direct' */
    for (i = 0; i < numdims; i++) 
      nextcoord[i] = rcoord[i];

    /* Increase or decrease step in direction direct */
    nextcoord[direct] += ((sign[direct] > 0) ? 1 : -1);
  
    if (nextcoord[direct] < 0) 
      nextcoord[direct] = dimsize[direct] - 1;
    else if (nextcoord[direct] >= dimsize[direct])
      nextcoord[direct] = 0;

    /* Calculte next rank from next coordinates */
    nextrank = QMP_calc_node_rank ((QMP_u32_t *)nextcoord,
				   dimsize, numdims);

    if (k >= path_size) {
      QMP_error ("Number of routing steps exceeds the allcated array size %d.\n", path_size);
      return QMP_MEMSIZE_ERR;
    }
    path[k] = nextrank;
    rank = nextrank;

    k++;
  }
  
  *num_steps = k;
  return QMP_SUCCESS;
}

/**
 * Check routing table for a node
 */
void
QMP_check_routing_paths (QMP_machine_t* glm, QMP_u32_t root)
{
  int i, k, m;
  QMP_u32_t num_nodes, path_size, num_steps, numdims;
  QMP_u32_t *rcoord, *coord, *pcoord;
  QMP_u32_t *paths, *dimsize;

  QMP_TRACE("QMP_check_routing_paths");

  /**
   * Get physical dimension information
   */
  numdims = QMP_PHYS_DIMENSION(glm->phys);
  dimsize = QMP_PHYS_DIMSIZE(glm->phys);
  num_nodes = QMP_PHYS_NUMNODES(glm->phys);

  path_size = 0;
  for (i = 0; i < numdims; i++)
    path_size += dimsize[i];

  /* allocate space for path */
  paths = (QMP_u32_t *)malloc(path_size * sizeof (QMP_u32_t));
  if (!paths) {
    QMP_error ("Cannot allocate space for routing path.\n");
    exit (1);
  }

  rcoord = QMP_NODEP_COORDINATES(qmp_find_phys_node_i (glm, root));
  for (i = 0; i < num_nodes; i++) {
    if (i != root) {
      num_steps = path_size;

      coord = QMP_NODEP_COORDINATES(qmp_find_phys_node_i (glm, i));

      if (QMP_are_neighbors (glm, root, i)) {
	QMP_fprintf (stderr, "Node root %d [ ", root);
	for (k = 0; k < numdims; k++)
	  fprintf (stderr, " %d ", rcoord[k]);
	fprintf (stderr, " ] and node %d [ ", i);
	for (k = 0; k < numdims; k++)
	  fprintf (stderr, " %d ", coord[k]);
	fprintf (stderr, " ] are neighbors\n");
      }
      else {
	QMP_set_routing_path (glm, root, i, paths, &num_steps);
	QMP_fprintf (stderr, "Routing path from root node %d [ ", root);
	for (k = 0; k < numdims; k++)
	  fprintf (stderr, " %d ", rcoord[k]);
	fprintf (stderr, " ] to node %i [ ", i);
	for (k = 0; k < numdims; k++)
	  fprintf (stderr, " %d ", coord[k]);
	fprintf (stderr, " ] looks like : \n");

	for (k = 0; k < num_steps; k++) {
	  pcoord = QMP_NODEP_COORDINATES(qmp_find_phys_node_i (glm, paths[k]));
	  fprintf (stderr, "  node %d [ ", paths[k]);
	  
	  for (m = 0; m < numdims; m++) 
	    fprintf (stderr, " %d ", pcoord[m]);
	  fprintf (stderr, " ] ");
	}	    
	fprintf (stderr, "\n\n");
      }
    }
  }
  
  free (paths);
}
			 
void
QMP_show_routing_paths (QMP_u32_t root)
{
  QMP_check_routing_paths (&QMP_global_m, root);
}

/***************************************************************************
 *            Supporting routines for MPI porting                          *
 **************************************************************************/

/**
 * Create a new logical topology for MPI group
 *
 * Currently periods always return 1 since we have torus configuration
 * 
 * machine rank number is always changed regardless of the input reorder
 */
QMP_topology_t *
QMP_create_new_topology (int ndim, int *dims, int *periods, 
			 int reorder, int *ordering)
{
  int             i, mapped_index;
  QMP_topology_t* tpl;
  QMP_machine_t* glm = &QMP_global_m;
  
  QMP_TRACE ("qmp_create_new_topology");

  if (glm->inited == QMP_FALSE) {
    QMP_error ( "QMP has not been initialized.");
    QMP_SET_STATUS_CODE(glm, QMP_NOT_INITED);
    return 0;
  }

  /* check whether the topology is valid */
  mapped_index = qmp_valid_logic_topology_i (glm, dims, ndim, ordering);
  if (mapped_index == -1)
    return 0;

  /* create memory for topology */
  tpl = (QMP_topology_t *)malloc(sizeof (QMP_topology_t));
  if (!tpl) {
    QMP_error ("cannot allocated memory for logical topology.\n");
    return 0;
  }
  /* make sure all initial value are zero */
  memset (tpl, 0, sizeof (QMP_topology_t));

  tpl->phys = glm->phys;


  if (qmp_setup_logical_topology_i (glm, tpl, dims, ndim, ordering) !=
      QMP_SUCCESS)
    return 0;

  if (QMP_rt_verbose)
    QMP_print_topology (tpl);

  if (!qmp_logical_topology_consistent_i (tpl)) {
    QMP_error ("inconsistent logical topology with the underlying physical topology, check your list and configuration file.");
    free (tpl);
    return 0;
  }

  /* we do torus */
  for (i = 0; i < ndim; i++)
    periods[i] = 1;
  return tpl;
}

