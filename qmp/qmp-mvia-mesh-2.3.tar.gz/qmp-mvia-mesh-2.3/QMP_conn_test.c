/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Simple Test Program for QMP Conn/Disconnection
 *
 * Author:  
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_conn_test.c,v $
 *   Revision 1.2  2004/10/08 19:59:29  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.1.1.1  2003/11/18 18:55:36  chen
 *   First CVS QMP_mvia_gigeD_mesh
 *
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

#include <qmp.h>

#define LOOPS 100

int main (int argc, char** argv)
{
  int i;
  QMP_bool_t status;
  QMP_thread_level_t th_level;

  for (i = 0; i < LOOPS; i++) {
    status = QMP_init_msg_passing (&argc, &argv, 
				   QMP_THREAD_MULTIPLE, &th_level);

    if (status != QMP_SUCCESS) {
      QMP_printf ( "QMP_init failed\n");
    return -1;
    }

    QMP_finalize_msg_passing ();
  }

  return 0;
}


