/**
 * An optmized one to all personalized message passing algorithm
 * for 8x8 panel only
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "qmp.h"
#include "QMP_P_MVIA_MESH.h"

/* #define DEBUG 1 */

#define QMP_XDIM 8
#define QMP_YDIM 8

/**
 * array holding information about which messages to send
 *
 * 4 arrays of up, down, left, right nodes
 */
#define QMP_NUM_ARRAYS 4
#define QMP_ARRAY_SIZE 16


typedef struct _QMP_distance
{
  QMP_phys_node_t* node;
  QMP_u32_t       num_steps;
}QMP_dist_t;

/**
 * Simple routing table element
 */
typedef struct _QMP_rt_
{
  QMP_u16_t recvnode;
  QMP_u16_t sendnode;
  QMP_u16_t dest;
}QMP_rt_t;

/**
 * Message table for each node
 */
typedef struct _QMP_msg_table_
{
  QMP_u16_t num_msgs;
  QMP_rt_t  rt[QMP_ARRAY_SIZE];
}QMP_msg_table_t; 

/**
 * Do selection sort on number of steps decreasing order
 */
static void
qmp_selection_sort_i (QMP_dist_t* array, int size)
{
  int i, max_idx, k;
  QMP_u32_t max_ns;
  QMP_dist_t tmp;

  for (i = 0; i < size - 1; i++) {
    max_ns = array[i].num_steps;
    max_idx = i;
    for (k = i + 1; k < size; k++) {
      if (array[k].num_steps > max_ns) {
	max_ns = array[k].num_steps;
	max_idx = k;
      }
    }
    tmp = array[i];
    array[i] = array[max_idx];
    array[max_idx] = tmp;
  }
}

/**
 * Get a node information from a coordinate 
 */
static QMP_phys_node_t *
qmp_get_node_i (QMP_machine_t* glm, QMP_u32_t x, QMP_u32_t y)
{
  int i;
  
  for (i = 0; i < glm->rtenv.num_nodes; i++) {
    if (x == glm->rtenv.all_nodes[i].coordinates[0] &&
	y == glm->rtenv.all_nodes[i].coordinates[1])
      return &(glm->rtenv.all_nodes[i]);
  }

  return 0;
}

/**
 * Root node message order information
 * but these arrays are used by everyone 
 * so let everyone to calculate these
 */
static QMP_status_t
qmp_setup_partition_i (QMP_machine_t* glm, QMP_dist_t* arrays[])
{
  int i, j, k;
  QMP_u32_t num_nodes;

  for (i = 0; i < QMP_NUM_ARRAYS; i++) {
    arrays[i] = (QMP_dist_t *)malloc(QMP_ARRAY_SIZE * sizeof (QMP_dist_t));
    if (!arrays[i]){
      QMP_fprintf (stderr, "Cannot allocate array for partitioin array \n");
      exit (1);
    }
  }

  /* Array[0] = LEFT, array[1] = right, array[2] = DOWN,
   * array[3] = UP
   */

  num_nodes = glm->rtenv.num_nodes;

  /* Now array[0] */
  k = 0;
  while (k <= 15) {
    for (i = 7; i >= 5; i--) 
      for (j = 0; j <= 3; j++) {
	arrays[0][k].node = qmp_get_node_i (glm, i, j);
	arrays[0][k].num_steps = (8 - i) % 8 + j;
	k++;
      }
    i = 5;
    for (j = 7; j >= 4; j--) {
	arrays[0][k].node = qmp_get_node_i (glm, i, j);
	arrays[0][k].num_steps = (8 - i) % 8 + (8 - j) % 8;
	k++;
    }
  }

  /* Now array[1] */
  k = 0;
  while (k <= 15) {
    for (i = 1; i <= 4; i++)
      for (j = 8; j >= 5; j--) {
	arrays[1][k].node = qmp_get_node_i (glm, i, j % 8);
	arrays[1][k].num_steps =  i + (8 - j % 8) % 8;
	k++;
      }
  }

  
  /* Now array[2] */
  k = 0;
  while (k <= 15) {
    for (i = 8; i >= 6; i--)
      for (j = 7; j >= 4; j--) {
	arrays[2][k].node = qmp_get_node_i (glm, i % 8 , j);
	arrays[2][k].num_steps = (8 - i % 8) % 8 + (8 - j % 8) % 8;
	k++;
      }

    j = 4;
    for (i = 1; i <= 4; i++) {
	arrays[2][k].node = qmp_get_node_i (glm, i , j);
	arrays[2][k].num_steps = i + j;
	k++;
    }      
  }


  /* Now array[3] */
  k = 0;
  while (k <= 14) {
    for (i = 0; i <= 4; i++)
      for (j = 1; j <= 3; j++) {
	arrays[3][k].node = qmp_get_node_i (glm, i, j);
	arrays[3][k].num_steps = i + j;
	k++;
      }
  }
  arrays[3][15].node = qmp_get_node_i (glm, 0, 0);
  arrays[3][15].num_steps = 0;

  /* Sort these 4 arrays */
  qmp_selection_sort_i (arrays[0], QMP_ARRAY_SIZE);
  qmp_selection_sort_i (arrays[1], QMP_ARRAY_SIZE);
  qmp_selection_sort_i (arrays[2], QMP_ARRAY_SIZE);
  qmp_selection_sort_i (arrays[3], QMP_ARRAY_SIZE);
  return 0;
}

/**
 * Dump routing table
 */
static void
qmp_dump_msg_table_i (QMP_machine_t* glm,
		      QMP_msg_table_t* table)
{
  int k;
  QMP_u32_t x, y;
  QMP_u32_t dimsize[] = {8, 8};
  QMP_u32_t dims = 2;
  QMP_u32_t rcoord[2], scoord[2], dcoord[2];

  x = glm->phys->my_node.coordinates[0];
  y = glm->phys->my_node.coordinates[1];

  QMP_fprintf (stderr, "[%d %d] Message table looks like \n",x ,y);
  for (k = 0; k < table->num_msgs; k++) {
    QMP_calc_node_coordinates (table->rt[k].recvnode,
			       dimsize, dims, rcoord);
    QMP_calc_node_coordinates (table->rt[k].sendnode,
			       dimsize, dims, scoord);
    QMP_calc_node_coordinates (table->rt[k].dest,
			       dimsize, dims, dcoord);
				   
    fprintf (stderr, "%d: recv (%d %d) send (%d %d) dest (%d %d) \n", 
	     k, rcoord[0], rcoord[1],
	     scoord[0], scoord[1],
	     dcoord[0], dcoord[1]);
  }
}


static QMP_msg_table_t*
qmp_setup_routing_table (QMP_machine_t* glm,
			 QMP_dist_t* array[])
{
  int i, j, k, idx;
  int x, y;
  QMP_msg_table_t all_tables[QMP_XDIM][QMP_YDIM];
  QMP_u32_t coord[2];
  QMP_u32_t rcoord[2], scoord[2], dcoord[2];
  QMP_u32_t dimsize[] = {8, 8};
  QMP_u32_t dims = 2;
  QMP_msg_table_t* ret;

  for (i = 0; i < QMP_XDIM; i++)
    for (j = 0; j < QMP_YDIM; j++)
      all_tables[i][j].num_msgs = 0;

  idx = 0;

  /* For array[0] */
  for (i = 0; i < QMP_ARRAY_SIZE; i++) {
    x = array[0][i].node->coordinates[0];
    y = array[0][i].node->coordinates[1];

    /*  X direction */
    for (k = QMP_XDIM - 1; k >= x ; k--) {
      idx = all_tables[k][0].num_msgs;
      coord[0] = (k + 1) % QMP_XDIM;
      coord[1] = 0;
      all_tables[k][0].rt[idx].recvnode= QMP_get_node_number_from (coord);

      coord[0] = (k - 1) % QMP_XDIM;
      coord[1] = 0;
      all_tables[k][0].rt[idx].sendnode= QMP_get_node_number_from (coord);
      
      coord[0] = x;
      coord[1] = y;
      all_tables[k][0].rt[idx].dest = QMP_get_node_number_from (coord);
      all_tables[k][0].num_msgs++; 
    }
    if (y == 0) {
      coord[0] = x;
      coord[1] = y;
      all_tables[x][y].rt[idx].sendnode= QMP_get_node_number_from (coord);
    }
    else {
      /* Changing X direction */
      if (y < QMP_YDIM / 2) {
        coord[0] = x;
        coord[1] = 1;
        all_tables[x][0].rt[idx].sendnode= QMP_get_node_number_from(coord);

        for (k = 1; k <= y; k++) {
          idx = all_tables[x][k].num_msgs;
          coord[0] = x;
	  coord[1] = k - 1;
          all_tables[x][k].rt[idx].recvnode= QMP_get_node_number_from (coord);

          coord[0] = x;
          coord[1] = k + 1;
          all_tables[x][k].rt[idx].sendnode= QMP_get_node_number_from (coord);

          coord[0] = x;
          coord[1] = y;
          all_tables[x][k].rt[idx].dest = QMP_get_node_number_from (coord);

          all_tables[x][k].num_msgs++;    
        }
      }
      else {
        coord[0] = x;
        coord[1] = QMP_YDIM -1;
        all_tables[x][0].rt[idx].sendnode= QMP_get_node_number_from (coord);

        for (k = QMP_YDIM - 1; k >= y; k--) {
          idx = all_tables[x][k].num_msgs;
          coord[0] = x;
          coord[1] = (k + 1) % QMP_YDIM;
          all_tables[x][k].rt[idx].recvnode= QMP_get_node_number_from (coord);

          coord[0] = x;
          coord[1] = k - 1;
          all_tables[x][k].rt[idx].sendnode= QMP_get_node_number_from (coord);
	  
	  coord[0] = x;
          coord[1] = y;
          all_tables[x][k].rt[idx].dest = QMP_get_node_number_from (coord);
          all_tables[x][k].num_msgs++;
        }
      }
      coord[0] = x;
      coord[1] = y;
      all_tables[x][y].rt[idx].sendnode= QMP_get_node_number_from (coord);
    }
  }


  /* For array[1] */
  for (i = 0; i < QMP_ARRAY_SIZE; i++) {
    x = array[1][i].node->coordinates[0];
    y = array[1][i].node->coordinates[1];

    /*  X direction */
    for (k = 1; k <= x ; k++) {
      idx = all_tables[k][0].num_msgs;
      coord[0] = k - 1;
      coord[1] = 0;
      all_tables[k][0].rt[idx].recvnode= QMP_get_node_number_from (coord);
      coord[0] = k + 1;
      coord[1] = 0;
      all_tables[k][0].rt[idx].sendnode= QMP_get_node_number_from (coord);

      coord[0] = x;
      coord[1] = y;
      all_tables[k][0].rt[idx].dest = QMP_get_node_number_from (coord);

      all_tables[k][0].num_msgs++; 
    }
    if (y == 0) {
      coord[0] = x;
      coord[1] = y;
      all_tables[x][y].rt[idx].sendnode= QMP_get_node_number_from (coord);
    }
    else {
      /* Changing X direction */
      coord[0] = x;
      coord[1] = QMP_YDIM - 1;
      all_tables[x][0].rt[idx].sendnode= QMP_get_node_number_from (coord);
    
      /* Y direction */
      for (k = QMP_YDIM - 1; k >= y; k--) {
	/* Check whether this message go through all those nodes */
	idx = all_tables[x][k].num_msgs;
	coord[0] = x;
	coord[1] = (k + 1) % QMP_YDIM;
	all_tables[x][k].rt[idx].recvnode= QMP_get_node_number_from (coord);

	coord[0] = x;
	coord[1] = (k - 1) % QMP_YDIM;
	all_tables[x][k].rt[idx].sendnode= QMP_get_node_number_from (coord);

	coord[0] = x;
	coord[1] = y;
	all_tables[x][k].rt[idx].dest = QMP_get_node_number_from (coord);

	all_tables[x][k].num_msgs++;
      }
      /* Destination */;
      coord[0] = x;
      coord[1] = y;
      all_tables[x][y].rt[idx].sendnode= QMP_get_node_number_from (coord);
    }
  }

  /* For array[2] */
  for (i = 0; i < QMP_ARRAY_SIZE; i++) {
    x = array[2][i].node->coordinates[0];
    y = array[2][i].node->coordinates[1];

    /* Y direction */
    for (k = QMP_YDIM - 1; k >= y; k--) {
      idx = all_tables[0][k].num_msgs;
      coord[0] = 0;
      coord[1] = (k + 1) % QMP_YDIM;
      all_tables[0][k].rt[idx].recvnode= QMP_get_node_number_from (coord);

      coord[0] = 0;
      coord[1] = k - 1;
      all_tables[0][k].rt[idx].sendnode= QMP_get_node_number_from (coord);
      
      coord[0] = x;
      coord[1] = y;
      all_tables[0][k].rt[idx].dest = QMP_get_node_number_from (coord);

      all_tables[0][k].num_msgs++;
    }
    if (x == 0) {
      coord[0] = x;
      coord[1] = y;
      all_tables[x][y].rt[idx].sendnode= QMP_get_node_number_from (coord);
    }
    else {
      if (x <= QMP_XDIM / 2) {
	coord[0] = 1;
	coord[1] = y;
	all_tables[0][y].rt[idx].sendnode= QMP_get_node_number_from (coord);
   
	for (k = 1; k <= x; k++) {
	  idx = all_tables[k][y].num_msgs;
	  coord[0] = k - 1;
	  coord[1] = y;
	  all_tables[k][y].rt[idx].recvnode= QMP_get_node_number_from(coord);
	  coord[0] = k + 1;
	  coord[1] = y;
	  all_tables[k][y].rt[idx].sendnode= QMP_get_node_number_from(coord);

	  coord[0] = x;
	  coord[1] = y;
	  all_tables[k][y].rt[idx].dest = QMP_get_node_number_from(coord);

	  all_tables[k][y].num_msgs++;
	}
      }
      else {
	coord[0] = QMP_XDIM - 1;
	coord[1] = y;
	all_tables[0][y].rt[idx].sendnode= QMP_get_node_number_from (coord);
   
	for (k = QMP_XDIM - 1; k >= x; k--) {
	  idx = all_tables[k][y].num_msgs;
	  coord[0] = (k + 1) % QMP_XDIM;
	  coord[1] = y;
	  all_tables[k][y].rt[idx].recvnode= QMP_get_node_number_from(coord);

	  coord[0] = k - 1;
	  coord[1] = y;
	  all_tables[k][y].rt[idx].sendnode= QMP_get_node_number_from(coord);

	  coord[0] = x;
	  coord[1] = y;
	  all_tables[k][y].rt[idx].dest = QMP_get_node_number_from(coord);

	  all_tables[k][y].num_msgs++; 
	}
      }
      coord[0] = x;
      coord[1] = y;
      all_tables[x][y].rt[idx].sendnode= QMP_get_node_number_from (coord);
    }
  }

  /* For array[3] */
  for (i = 0; i < QMP_ARRAY_SIZE - 1; i++) {
    x = array[3][i].node->coordinates[0];
    y = array[3][i].node->coordinates[1];

    /* Y direction */
    for (k = 1; k <= y; k++) {
      /* Check whether this message go through all those nodes */
      idx = all_tables[0][k].num_msgs;
      coord[0] = 0;
      coord[1] = k - 1;
      all_tables[0][k].rt[idx].recvnode= QMP_get_node_number_from (coord);

      coord[0] = 0;
      coord[1] = k + 1;
      all_tables[0][k].rt[idx].sendnode= QMP_get_node_number_from (coord);

      coord[0] = x;
      coord[1] = y;
      all_tables[0][k].rt[idx].dest = QMP_get_node_number_from (coord);
      all_tables[0][k].num_msgs++;
    }
    
    if (x == 0) {
      coord[0] = x;
      coord[1] = y;
      all_tables[x][y].rt[idx].sendnode= QMP_get_node_number_from (coord);
    }
    else {
      /* Changing Y direction */
      coord[0] = 1;
      coord[1] = y;
      all_tables[0][y].rt[idx].sendnode= QMP_get_node_number_from (coord);    

    
      /*  X direction */
      for (k = 1; k <= x ; k++) {
	idx = all_tables[k][y].num_msgs;
	coord[0] = k - 1;
	coord[1] = y;
	all_tables[k][y].rt[idx].recvnode= QMP_get_node_number_from (coord);

	coord[0] = k + 1;
	coord[1] = y;
	all_tables[k][y].rt[idx].sendnode= QMP_get_node_number_from (coord);

	coord[0] = x;
	coord[1] = y;
	all_tables[k][y].rt[idx].dest = QMP_get_node_number_from (coord);

	all_tables[k][y].num_msgs++; 
      }
    
      /* Last one destination */
      coord[0] = x;
      coord[1] = y;
      all_tables[x][y].rt[idx].sendnode= QMP_get_node_number_from (coord);
    }
  }

  /* Now return the table of myself */
  x = glm->phys->my_node.coordinates[0];
  y = glm->phys->my_node.coordinates[1];

  ret = (QMP_msg_table_t *)malloc(sizeof(QMP_msg_table_t));
  ret->num_msgs = all_tables[x][y].num_msgs;
  for (i = 0; i < ret->num_msgs; i++) {
    ret->rt[i].recvnode = all_tables[x][y].rt[i].recvnode;
    ret->rt[i].sendnode = all_tables[x][y].rt[i].sendnode;
    ret->rt[i].dest = all_tables[x][y].rt[i].dest;
  }

#if 0
  /* Now print out all routing tables */
  for (i = 0; i < QMP_XDIM; i++) {
    for (j = 0; j < QMP_YDIM; j++) {
      fprintf (stderr, "Routing table [%d %d]: \n", i, j);
      for (k = 0; k < all_tables[i][j].num_msgs; k++) {
	QMP_calc_node_coordinates (all_tables[i][j].rt[k].recvnode,
				   dimsize, dims, rcoord);
	QMP_calc_node_coordinates (all_tables[i][j].rt[k].sendnode,
				   dimsize, dims, scoord);
	QMP_calc_node_coordinates (all_tables[i][j].rt[k].dest,
				   dimsize, dims, dcoord);
				   
	fprintf (stderr, "%d: recv (%d %d) send (%d %d) dest (%d %d) \n", 
		 k, rcoord[0], rcoord[1],
		 scoord[0], scoord[1],
		 dcoord[0], dcoord[1]);
      }
    }
  }
#endif


  return ret;
}

/**
 * Root send out all messages using 4 arrays
 */
static void
qmp_root_send_all_messages_i (QMP_machine_t* glm,
			      QMP_dist_t** tables,
			      int num,
			      int* buffer[],
			      int bufsize)
{
  int i, k;
  QMP_u32_t      sendnode[4];
  QMP_u32_t      sendcoord[4][2];
  QMP_request_t *sreq[4];
  QMP_gige_port_t *port[4];
  QMP_status_t status;

  /* Create 4 send node */
  /* Array 0 goes to left */
  sendcoord[0][0] = QMP_XDIM - 1;
  sendcoord[0][1] = 0;

  /* Array 1 goes to right */
  sendcoord[1][0] = 1;
  sendcoord[1][1] = 0;

  /* Array 2 goes to down */
  sendcoord[2][0] = 0;
  sendcoord[2][1] = QMP_YDIM - 1;

  /* Array 3 goes to up */
  sendcoord[3][0] = 0;
  sendcoord[3][1] = 1;

  for (i = 0; i < num; i++) 
    sendnode[i] = QMP_get_node_number_from (sendcoord[i]);

  /* Loop thorugh array size */
  for (k = 0; k < QMP_ARRAY_SIZE; k++) {

    /* Round robin each array */
    for (i = 0; i < num; i++) {
#ifdef DEBUG
      {
	int m;
	for (m = 0; m < bufsize/4; m++)
	  buffer[i][m] = tables[i][k].node->rank;
      }
#endif


      if (tables[i][k].num_steps == 0)
	port[i] = 0;
      else {
	port[i] = QMP_get_connection_port (glm, 
					   sendnode[i],
					   QMP_DIR_UNKNOWN, QMP_MH_SEND);
	if (port[i]->type != QMP_CONN_DIRECT) {
	  QMP_error ("Impossible: I need to send to rank %d which should be my neighbor \n",  sendnode[i]);
	  exit (1);
	}
	  
	if ((status = QMP_isend_direct (buffer[i], bufsize, QMP_BYTE,
					sendnode[i],
					QMP_ROUTING_TAG+tables[i][k].node->rank,
					port[i], glm, &sreq[i])) != QMP_SUCCESS){
	  QMP_error ("Sending to my neightbor %d to destination %d failed\n",
		     sendnode[i], QMP_ROUTING_TAG+tables[i][k].node->rank);
	  exit (1);
	}

#ifdef DEBUG
	{
	  QMP_u32_t dimsize[] = {8, 8};
	  QMP_u32_t dims = 2;
	  QMP_u32_t scoord[2], tcoord[2];

	  QMP_calc_node_coordinates (sendnode[i],
				     dimsize, dims, scoord);
	  QMP_calc_node_coordinates (tables[i][k].node->rank,
				     dimsize, dims, tcoord);
	  QMP_fprintf (stderr, "Sending data to node %d (%d %d) and destination %d (%d %d) with tag %d \n", sendnode[i], scoord[0], scoord[1], tables[i][k].node->rank, tcoord[0], tcoord[1],QMP_ROUTING_TAG+tables[i][k].node->rank);
	}
#endif 

      }
    }

    /* Now wait for the 4 sends to finish */
    for (i = 0; i < num; i++) {
      if (port[i] != 0) {
	QMP_request_wait (glm, sreq[i]);
	QMP_RELEASE_REQUEST(glm, sreq[i]);
      }
    }

  }

}

/**
 * This is the code all other node are using to receive messages
 */
static void
qmp_recv_all_messages_i (QMP_machine_t* glm, QMP_msg_table_t* table,
			 int* recvbuf ,int bufsize)
{
  int i;
  QMP_status_t status;
  QMP_u32_t rank;
  int*     mybuffer;
  
  /* Get my own rank */
  rank = QMP_get_node_number ();

  for (i = 0; i < table->num_msgs; i++) {
#ifdef DEBUG
    {
      QMP_u32_t dimsize[] = {8, 8};
      QMP_u32_t dims = 2;
      QMP_u32_t rcoord[2], tcoord[2];

      QMP_calc_node_coordinates (table->rt[i].recvnode,
				 dimsize, dims, rcoord);
      QMP_calc_node_coordinates (table->rt[i].dest,
				 dimsize, dims, tcoord);

      QMP_fprintf (stderr, "Receiving data from %d (%d %d) for destination %d (%d %d) with tag %d \n", table->rt[i].recvnode, rcoord[0], rcoord[1], table->rt[i].dest, tcoord[0], tcoord[1], QMP_ROUTING_TAG + table->rt[i].dest);
    }
#endif
    mybuffer = (int *)QMP_memalign (bufsize, QMP_MEM_ALIGNMENT);
    status = qmp_direct_recv_p_i (glm, mybuffer, bufsize, QMP_BYTE,
				  table->rt[i].recvnode,
				  QMP_ROUTING_TAG + table->rt[i].dest,
				  QMP_DIR_UNKNOWN,
				  QMP_FALSE);
    if (status != QMP_SUCCESS) {
      QMP_error ("QMP cannot route message from %d to %d \n",
		 table->rt[i].recvnode,QMP_ROUTING_TAG + table->rt[i].dest);
      exit (-1);
    }
    if (rank == table->rt[i].sendnode) {
#ifdef DEBUG
      {
	int k;
	QMP_fprintf (stderr, "Get message from root for myself.\n");

	memcpy (recvbuf, mybuffer, bufsize);
	for ( k = 0; k < bufsize/4; k++)
	  if (recvbuf[k] != rank)
	    QMP_error ("Receiving data %d mismatch %d != %d \n", k, recvbuf[k], rank);
      }
#endif
      /* I am done */
      continue;
    }
    else {
      status = qmp_direct_send_p_i (glm, mybuffer, bufsize, QMP_BYTE,
				    table->rt[i].sendnode,
				    QMP_ROUTING_TAG + table->rt[i].dest,
				    QMP_DIR_UNKNOWN,
				    QMP_FALSE);
      if (status != QMP_SUCCESS) {
	QMP_error ("Cannot send message to %d route to %d \n",
		   table->rt[i].sendnode, QMP_ROUTING_TAG + table->rt[i].dest);
	exit (-1);
      }
      free (mybuffer);

#ifdef DEBUG
      {
	QMP_u32_t dimsize[] = {8, 8};
	QMP_u32_t dims = 2;
	QMP_u32_t scoord[2], tcoord[2];

	QMP_calc_node_coordinates (table->rt[i].sendnode,
				   dimsize, dims, scoord);
	QMP_calc_node_coordinates (table->rt[i].dest,
				   dimsize, dims, tcoord);

	QMP_fprintf (stderr, "Routing data from %d (%d %d) for destination %d (%d %d) with tag %d \n", table->rt[i].sendnode, scoord[0], scoord[1], table->rt[i].dest, tcoord[0], tcoord[1], QMP_ROUTING_TAG + table->rt[i].dest);
      }
#endif
    }   
  }

}


typedef struct res_time
{
  double it;
  double ft;
}res_time_t;

static int test_size[] = {4, 8, 16, 32, 64, 128, 
			  256, 400, 500, 600, 700,
			  800, 900, 1024, 
			  2048, 4096, 5000, 6000,
			  7000, 8000
};

/* 2d test */
static int test_loop[] = {1000, 1000, 1000, 1000, 800, 800,
			  800, 600, 600, 600, 600,
			  600, 500, 500,
			  400, 400, 300, 300,
			  200, 200
};

/*
static int test_loop[] = {500, 500, 500, 500, 400, 400,
			  400, 400, 400, 400, 400,
			  300, 300, 300,
			  200, 200, 200, 200,
			  100, 100
};
*/


static int num_tests = 20;

#define TIME_FILE        "test_t.dat"
static  FILE*            tf;

static double
get_current_time (void)
{
  struct timeval tv;

  gettimeofday (&tv, 0);

  return tv.tv_sec*1000.0 + tv.tv_usec/1000.0;
}

static void
output_result (QMP_u32_t size, QMP_u32_t loops,
	       res_time_t* results, QMP_u32_t num_nodes,
	       FILE* fd)
{
  double dt;
  double rit, rft;
  int i;

  /*
  for (i = 0; i < num_nodes; i++) {
    fprintf (stderr, "it[%d] = %lf ft[%d] = %lf \n", i, results[i].it,
	     i, results[i].ft);
  }
  */

  rit = results[0].it;
  rft = results[0].ft;

  for (i = 1; i < num_nodes; i++) {
    if (results[i].it < rit)
      rit = results[i].it;
    if (results[i].ft > rft)
      rft = results[i].ft;
  }
  dt = rft - rit;

  fprintf (stderr, "%d      %lf\n", size, dt/loops*1000.0);
  fprintf (fd, "%d      %lf\n", size, dt/loops*1000.0);
}


int
main (int argc, char** argv)
{
  QMP_status_t status;
  int i, k;
  QMP_msg_table_t* table;
  QMP_dist_t* root_table[4];
  int*      rootbuf[4];
  int*      recvbuf;
  double it, ft;
  res_time_t* final_result;
  res_time_t  my_result;
  QMP_u32_t   num_nodes;
  
  status = QMP_init_msg_passing (&argc, &argv, QMP_SMP_ONE_ADDRESS);

  num_nodes = QMP_get_number_of_nodes ();

  qmp_setup_partition_i (&QMP_global_m, root_table);

#if 0
  for (i = 0; i < QMP_NUM_ARRAYS; i++) {
    fprintf (stderr, "ARRAY[%d] looks like \n", i);
    for (j = 0; j < QMP_ARRAY_SIZE; j++) {
      coord = QMP_NODEP_COORDINATES(root_table[i][j].node);
      fprintf (stderr, "array[%d] (%d, %d) steps = %d\n",
	       j, coord[0], coord[1], root_table[i][j].num_steps);
    }
  }
#endif

  /* Now set up routing table */
  table = qmp_setup_routing_table (&QMP_global_m, root_table);

  /* qmp_dump_msg_table_i (&QMP_global_m, table); */

  /* allocate final result */
  final_result = (res_time_t *)malloc(num_nodes * sizeof(res_time_t));
  if (!final_result) {
    QMP_fprintf (stderr, "Cannot allocate space for final time result \n");
    exit (0);
  }

  if (QMP_is_primary_node ()) {
    tf = fopen (TIME_FILE, "w");
    if (!tf)
      tf = stderr;


    /* This is the root node just go ahead send messages */
    for (k = 0; k < num_tests; k++) {
      for (i = 0; i < 4; i++) {
	rootbuf[i] = (int *)QMP_memalign (test_size[k], QMP_MEM_ALIGNMENT);
	if (!rootbuf[i]) {
	  QMP_error ("Cannot allocate sendbuf \n");
	  exit (-1);
	}
      }

      /**
       * First send out data to all nodes
       */
      it = get_current_time ();
      for (i = 0; i < 4 * test_loop[k]; i++)
	qmp_root_send_all_messages_i (&QMP_global_m, root_table, 4, rootbuf, test_size[k]);
      ft = get_current_time ();

      /* Free memory */
      for (i = 0; i < 4; i++) 
	free (rootbuf[i]);

       my_result.it = it;
       my_result.ft = ft;

       /* Get data back to the root */
       QMP_gather (&my_result, sizeof(my_result),
		   final_result, sizeof(my_result),
		   0);

       output_result (test_size[k], 4 * test_loop[k], final_result, num_nodes, tf);
    }
  }
  else {
    for (k = 0; k < num_tests; k++) {    
      /* Each node receive all messages */
      recvbuf = (int *)QMP_memalign (test_size[k], QMP_MEM_ALIGNMENT);
      
      it = get_current_time ();
      for (i = 0; i < 4 * test_loop[k]; i++)
	qmp_recv_all_messages_i (&QMP_global_m, table, recvbuf, test_size[k]);
      ft = get_current_time ();

      /* Free memory */
      free (recvbuf);

      my_result.it = it;
      my_result.ft = ft;

      /* Get data back to the root */
      QMP_gather (&my_result, sizeof(my_result),
		  final_result, sizeof(my_result),
		  0);
    }
  }

  /* Free memory */
  free (table);

  for (i = 0; i < 4; i++)
    free (root_table[i]);
  
  QMP_finalize_msg_passing ();

  return 0;
}
