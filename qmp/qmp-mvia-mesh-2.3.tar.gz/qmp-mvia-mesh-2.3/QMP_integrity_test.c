/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Simple LQCD Style Data Integrity Test
 *
 * Author:  
 *      Jie Chen
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_integrity_test.c,v $
 *   Revision 1.3  2005/07/19 14:18:21  chen
 *   minor change
 *
 *   Revision 1.2  2005/07/19 14:13:22  chen
 *   Add hardware reporting message
 *
 *   Revision 1.1  2005/05/03 17:46:49  chen
 *   import
 *
 *
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>

#include <qmp.h>

/**
 * Get current time in milli seconds.
 */
static double
get_current_time (void)
{
  struct timeval tv;

  gettimeofday (&tv, 0);

  return tv.tv_sec*1000.0 + tv.tv_usec/1000.0;
}


#define Nd 4
#define Nc 3
#define Ns 4
#define Ns2 2


/* Nearest neighbor communication channels */
static int total_comm = 0;
static QMP_mem_t* forw_qmp_mem[Nd][2];
static QMP_mem_t* back_qmp_mem[Nd][2];
static void* forw_mem[Nd][2];
static void* back_mem[Nd][2];

static QMP_msgmem_t forw_msg[Nd][2];
static QMP_msgmem_t back_msg[Nd][2];
static QMP_msghandle_t forw_mh[Nd][2];
static QMP_msghandle_t back_mh[Nd][2];
static QMP_msghandle_t forw_all_mh;
static QMP_msghandle_t back_all_mh;
static int num = 0;
static int mem_size = 8192;

/* Size of msg data is 16 bytes */
typedef struct _msg_data_
{
  int loop;
  int rank;
  int value;
  int value2;
}msg_data;

void set_send_buffers (int loop)
{
  int mu, i, k;
  msg_data *fsbuf, *bsbuf;
  msg_data *frbuf, *brbuf;
  const unsigned int *size = QMP_get_logical_dimensions();
  unsigned int num_dim = QMP_get_logical_number_of_dimensions();

  /* Loop over all communicating directions and build up the two message
   * handles. If there is no communications, the message handles will not
   * be initialized 
   */
  k = 0;

  for(mu=0; mu < num_dim; ++mu) {
    if(size[mu] > 1) {
      fsbuf = (msg_data *)forw_mem[k][0];
      bsbuf = (msg_data *)back_mem[k][0];
      frbuf = (msg_data *)forw_mem[k][1];
      brbuf = (msg_data *)back_mem[k][1];
      
      fsbuf[0].loop = loop;
      fsbuf[0].rank = QMP_get_node_number ();
      fsbuf[0].value = rand()%1234567;
      fsbuf[0].value2 = rand()%14567;

      bsbuf[0].loop = loop;
      bsbuf[0].rank = fsbuf[0].rank;
      bsbuf[0].value = rand()%4567893;
      bsbuf[0].value2 = rand()%67893;

      frbuf[0].loop = 0;
      frbuf[0].rank = -1;
      frbuf[0].value = -1;
      frbuf[0].value2 = -1;

      brbuf[0].loop = 0;
      brbuf[0].rank = -1;
      brbuf[0].value = -1;
      brbuf[0].value2 = -1;

      for (i = 1; i < mem_size/sizeof(msg_data); i++) {
	memcpy (&fsbuf[i], &fsbuf[0], sizeof(msg_data));
	memcpy (&bsbuf[i], &bsbuf[0], sizeof(msg_data));

	memcpy (&frbuf[i], &frbuf[0], sizeof(msg_data));
	memcpy (&brbuf[i], &brbuf[0], sizeof(msg_data));
		
      }
      k++;
    }
  }
}



void check_recv_buffers (int loop)
{
  int mu, i, k;
  msg_data *fsbuf, *bsbuf;
  const unsigned int *size = QMP_get_logical_dimensions();
  unsigned int num_dim = QMP_get_logical_number_of_dimensions();

  k = 0;

  for(mu=0; mu < num_dim; ++mu) {
    if(size[mu] > 1) {
      fsbuf = (msg_data *)forw_mem[k][1];
      bsbuf = (msg_data *)back_mem[k][1];
      for (i = 0; i < mem_size/sizeof(msg_data); i++) {
	if (fsbuf[i].loop != loop) {
	  QMP_fprintf (stderr, "Loop number error %d: Forward direction %d array[%d] receiving error loop %d != %d\n",
		       loop, mu, i, fsbuf[i].loop, loop);
	  exit (255);
	}
	if (memcmp (&fsbuf[i], &fsbuf[0], sizeof (msg_data)) != 0) {
	  QMP_fprintf (stderr, "Loop %d: Forward direction %d array[%d] receiving error loop %d : %d rank %d : %d value %d : %d value2 %d : %d \n",
		       loop, mu, i, fsbuf[i].loop, fsbuf[0].loop, fsbuf[i].rank, fsbuf[0].rank,
		       fsbuf[i].value, fsbuf[0].value,
		       fsbuf[i].value2, fsbuf[0].value2); 
	  exit (255);
	}

	if (bsbuf[i].loop != loop) {
	  QMP_fprintf (stderr, "Loop number error %d: Back direction %d array[%d] receiving error loop %d != %d\n",
		       loop, mu, i, fsbuf[i].loop, loop);
	  exit (255);
	}
	if (memcmp (&bsbuf[i], &bsbuf[0], sizeof (msg_data)) != 0) {
	  QMP_fprintf (stderr, "Loop %d: Back direction %d array[%d] receiving error loop %d : %d rank %d : %d value %d : %d value2 %d : %d \n",
		       loop, mu, i, bsbuf[i].loop, bsbuf[0].loop, bsbuf[i].rank, bsbuf[0].rank,
		       bsbuf[i].value, bsbuf[0].value,
		       bsbuf[i].value2, bsbuf[0].value2);
	  exit (255);
	}
      }
      k++;
    }
  }

}

void init_wnxtsu3dslash(void)
{
  int mu;
  const unsigned int *size = QMP_get_logical_dimensions();
  unsigned int num_dim = QMP_get_logical_number_of_dimensions();

  /* Loop over all communicating directions and build up the two message
   * handles. If there is no communications, the message handles will not
   * be initialized 
   */
  num = 0;
  
  for(mu=0; mu < num_dim; ++mu) {
    if(size[mu] > 1) {
      forw_qmp_mem[num][0] = QMP_allocate_aligned_memory (mem_size*sizeof(char), 
							  32, 0);
      forw_qmp_mem[num][1] = QMP_allocate_aligned_memory(mem_size*sizeof(char),
							 32, 0);
      forw_mem[num][0] = QMP_get_memory_pointer (forw_qmp_mem[num][0]);
      forw_mem[num][1] =QMP_get_memory_pointer (forw_qmp_mem[num][1]); 

      forw_msg[num][0] = QMP_declare_msgmem(forw_mem[num][0], mem_size);
      forw_msg[num][1] = QMP_declare_msgmem(forw_mem[num][1], mem_size);
      
      forw_mh[num][0]  = QMP_declare_receive_relative(forw_msg[num][1], mu, +1, 0);
      forw_mh[num][1]  = QMP_declare_send_relative(forw_msg[num][0], mu, -1, 0);
      
      /* backward direction */
      back_qmp_mem[num][0] = QMP_allocate_aligned_memory(mem_size*sizeof(char),
							 32, 0);
      back_qmp_mem[num][1] = QMP_allocate_aligned_memory(mem_size*sizeof(char),
							 32, 0);
      back_mem[num][0] = QMP_get_memory_pointer (back_qmp_mem[num][0]);
      back_mem[num][1] =  QMP_get_memory_pointer (back_qmp_mem[num][1]);


      back_msg[num][0] = QMP_declare_msgmem(back_mem[num][0], mem_size);
      back_msg[num][1] = QMP_declare_msgmem(back_mem[num][1], mem_size);

      back_mh[num][0]  = QMP_declare_receive_relative(back_msg[num][1], mu, -1, 0); 
      back_mh[num][1]  = QMP_declare_send_relative(back_msg[num][0], mu, +1, 0);
      num++;
    }
  }

  if (num > 0)
  {
    forw_all_mh = QMP_declare_multiple(&(forw_mh[0][0]), 2*num);
    back_all_mh = QMP_declare_multiple(&(back_mh[0][0]), 2*num); 
  }

  total_comm = num;
}


int main (int argc, char** argv)
{
  int i, loops;
  QMP_status_t err, status;
  double it, ft, dt, bwval, value;
  unsigned int layout[]={8, 16, 16, 16, 32};
  unsigned int num_dims = Nd;
  QMP_thread_level_t th_level;

  /* Set random number seed */
  srand ((int)get_current_time());

  status = QMP_init_msg_passing (&argc, &argv, 
				 QMP_THREAD_SINGLE, &th_level);

  if (status != QMP_SUCCESS) {
    QMP_error ("QMP_init failed: %s\n", QMP_error_string(status));
    exit (status);
  }

#if 0
  QMP_layout_grid (layout, num_dims); 
#endif

  loops = 12000; 
  mem_size = 80000;

  init_wnxtsu3dslash();

  i = 0;

  it = get_current_time ();
  while (i < loops) {
    value = (double)(rand()%1789);

    /* Set send buffer */
    set_send_buffers (i);

    if ((err = QMP_start (forw_all_mh))!= QMP_SUCCESS)
      QMP_printf ("Start forward operations failed: %s\n", 
		  QMP_error_string(err));

    if (QMP_wait (forw_all_mh) != QMP_SUCCESS)
      QMP_printf ("Error in sending %d\n", i);

    
    if ((err = QMP_start (back_all_mh)) != QMP_SUCCESS)
      QMP_printf ("Start backward failed: %s\n", QMP_error_string(err));


    if (QMP_wait (back_all_mh) != QMP_SUCCESS)
      QMP_printf ("Error in wait receiving %d\n", i);

    /* QMP_sum_double (&value); */

    check_recv_buffers (i);

    if (i % 50000 == 0 && i != 0)
      QMP_fprintf (stderr, "Done loop %d\n", i);
    i++;
  }
  ft = get_current_time ();

  dt = (ft - it); /* actual send time milli seconds */
  
  /* bandwidth in MB/second */
  bwval = 2*num*(double)mem_size/dt/(double)1000.0*loops;

  QMP_fprintf (stderr, "Sending using %d channels with memory size %d yields %lf (mriro seconds) total time and bandwidth %lf (MB/s)\n", 2*num, mem_size, dt/(loops)*1000.0, bwval);

  /* Individual handles will be destroyed inside the multiple */
  QMP_free_msghandle (forw_all_mh);
  QMP_free_msghandle (back_all_mh);

  QMP_finalize_msg_passing ();

  /**
   * Free memory
   */
  for (i = 0; i < num; i++) {
    QMP_free_memory (forw_qmp_mem[i][0]);
    QMP_free_memory (forw_qmp_mem[i][1]);
    QMP_free_memory (back_qmp_mem[i][0]);
    QMP_free_memory (back_qmp_mem[i][1]);
  }

  return 0;
}

