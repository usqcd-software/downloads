/*----------------------------------------------------------------------------
 * Copyright (c) 2001      Southeastern Universities Research Association,
 *                         Thomas Jefferson National Accelerator Facility
 *
 * This software was developed under a United States Government license
 * described in the NOTICE file included as part of this distribution.
 *
 * Jefferson Lab HPC Group, 12000 Jefferson Ave., Newport News, VA 23606
 *----------------------------------------------------------------------------
 *
 * Description:
 *      Private header file for implementation of QMP over VIA only. 
 *      Users do not need this header file.
 *
 * Author:  
 *      Jie Chen, Chip Watson and Robert Edwards
 *      Jefferson Lab HPC Group
 *
 * Revision History:
 *   $Log: QMP_P_MVIA_MESH.h,v $
 *   Revision 1.15  2005/03/20 04:36:58  morten
 *   Added include for profiling
 *
 *   Revision 1.14  2005/03/03 15:47:08  chen
 *   Fix a bug on strided memory send/recv because of misunderstanding of SPEC
 *
 *   Revision 1.13  2004/12/17 15:42:01  chen
 *   port to gcc 3.4
 *
 *   Revision 1.12  2004/12/06 17:23:44  chen
 *   Add reliable filed to gige port
 *
 *   Revision 1.11  2004/11/01 20:34:39  chen
 *   Change QMP_declare_multiple to conform to 2.0 spec
 *
 *   Revision 1.10  2004/10/08 19:59:29  chen
 *   First implementation of QMP 2
 *
 *   Revision 1.9  2004/09/23 14:10:23  chen
 *   Add support for mpi port
 *
 *   Revision 1.8  2004/04/08 15:30:31  chen
 *   Add QMP_ALL_REDUCE Tag
 *
 *   Revision 1.7  2004/02/25 16:47:28  chen
 *   Add local debug file output option
 *
 *   Revision 1.6  2004/02/19 15:22:02  chen
 *   Use static buffer inside QMP_route
 *
 *   Revision 1.5  2003/12/15 18:53:10  chen
 *   Add QMP_free and correct regmem refcount
 *
 *   Revision 1.4  2003/12/12 20:12:58  chen
 *   Add global routing, scatter, gather
 *
 *   Revision 1.3  2003/12/05 18:45:54  chen
 *   Add more CQ entries to switched VIA connection
 *
 *   Revision 1.2  2003/12/01 16:53:08  chen
 *   Fixed a minor bug for local loopback devices
 *
 *   Revision 1.1.1.1  2003/11/18 18:55:36  chen
 *   First CVS QMP_mvia_gigeD_mesh
 *
 *
 *
 */
#ifndef _QMP_P_MVIA_MESH_H
#define _QMP_P_MVIA_MESH_H

#include <vipl.h>

#ifdef DMALLOC
#include <dmalloc.h>
#endif
#include "QMP_profiling.h"
/**
 * 64 bit os environment.
 */
#if defined (__sparcv9) || defined (__alpha)
#define QMP_64BIT_LONG
#endif 

/**
 * Define QCD Message passing own types for better portablity.
 */
typedef unsigned char      QMP_u8_t;
typedef unsigned short     QMP_u16_t;
typedef unsigned int       QMP_u32_t;
typedef char               QMP_s8_t;
typedef short              QMP_s16_t;
typedef int                QMP_s32_t;

#ifdef QMP_64BIT_LONG
typedef unsigned long      QMP_u64_t;
typedef long               QMP_s64_t;
#else
typedef unsigned long long QMP_u64_t;
typedef long long          QMP_s64_t;
#endif

typedef float              QMP_float_t;
typedef double             QMP_double_t;

/**
 * General data type for QMP
 */
typedef enum QMP_datatype
{
  QMP_UNSIGNED_CHAR = 0,
  QMP_CHAR,
  QMP_BYTE,
  QMP_UNSIGNED_SHORT,
  QMP_SHORT,
  QMP_UNSIGNED_INT,
  QMP_INT,
  QMP_UNSIGNED_64BIT_INT,
  QMP_64BIT_INT,
  QMP_FLOAT,
  QMP_DOUBLE,
  QMP_NUM_S_TYPES
}QMP_datatype_t;


/**
 * Adding an offset to VIA error callback error code
 */
#define VIP_ERRCBK_CODE_OFFSET 100

/**
 * Memory alignment size (SSE)
 */
#define QMP_MEM_ALIGNMENT 16

/**
 * Memory type
 */
typedef enum QMP_mm_type
{
  QMP_MM_LEXICO_BUF = 0,
  QMP_MM_STRIDED_BUF,
  QMP_MM_STRIDED_ARRAY_BUF,
  QMP_MM_USER_BUF
}QMP_mm_type_t;

/**
 * Memory handle type 
 */
typedef enum QMP_mh_type
{
  QMP_MH_SEND = 0x0001,
  QMP_MH_RECV = 0x0002,
  QMP_MH_MULTIPLE = 0x0004,
  QMP_MH_EMPTY = 0x0008,
}QMP_mh_type_t;

/**
 * Memory handle state.
 */
typedef enum QMP_mh_state
{
  QMP_MH_INVALID = 0,
  QMP_MH_IDLE,
  QMP_MH_WAITING
}QMP_mh_state_t;


/**
 * forward decleration of QMP_machine_t.
 */
typedef struct QMP_machine QMP_machine_t;

/**
 * forward decleration of QMP_phys_geometry
 */
typedef struct QMP_phys_geometry QMP_phys_geometry_t;

/**
 * forward decleration of QMP_msghandle_i_t;
 */
typedef struct QMP_msghandle_i QMP_msghandle_i_t;

/**
 * Forward decleration for sending and receiving request
 */
typedef struct QMP_request_  QMP_request_t;

/**
 * Forward decleration for qbuf handler
 */
typedef struct QMP_qbuf_manager_ QMP_qbuf_manager_t;

/**
 * Forward decleration of gige port
 */
typedef struct QMP_gige_port_ QMP_gige_port_t;

/**
 * Internal structure of memory
 * mem points to the real memory and aligned ptr points
 * to aligned address
 *
 * This structure and real memory ara allocated together
 */
struct QMP_mem_struct_t {
  int  nbytes;
  void *aligned_ptr;
  char mem[];
};


/**
 * Relative Direction for Messages.
 */
typedef enum QMP_dir
{
  QMP_DIRXP = 0,
  QMP_DIRXM,
  QMP_DIRYP,
  QMP_DIRYM,
  QMP_DIRZP,
  QMP_DIRZM,
  QMP_DIRTP,
  QMP_DIRTM,
  QMP_DIR_UNKNOWN
}QMP_dir_t;

/**
 * Axis Name for this mesh.
 */
typedef enum QMP_axis
{
  QMP_X = 0,
  QMP_Y,
  QMP_Z,
  QMP_T,
  QMP_U,
}QMP_axis_t;

/**
 * Type of gige connection
 */
typedef enum QMP_gige_conn_type
{
  QMP_CONN_DIRECT = 0,
  QMP_CONN_SWITCH,
}QMP_gige_conn_type_t;


/**
 * Internal structure for single strided memory structures
 */
typedef struct QMP_strided_mem
{
  /* Pointer of the beginning of all strided memory */
  void* base;
  /* Size of each strided memory block              */
  size_t blksize;
  /* Offset from beginning of one memory block to the
   * beginning of the next memory block             */
  ptrdiff_t stride;
  /* Number of memory blocks                        */
  int nblocks;
}QMP_strided_mem_t;


/**
 * Internal structure for array strided memory structures
 */
typedef struct QMP_array_strided_mem
{
  int num;
  QMP_strided_mem_t* smem;
}QMP_array_strided_mem_t;
  

/**
 * Internal message memory structure
 */
typedef struct QMP_msgmem_i
{
  QMP_mm_type_t      type;
  void*              mem;
  QMP_u32_t          nbytes;
  QMP_u32_t          ref_count;
  QMP_machine_t*     glm;
  void*              special_mem;
}QMP_msgmem_i_t;

/**
 * Several macros to access members of message memory
 */
#define QMP_INC_MEM_REFCOUNT(msgmem) (msgmem->refcount++)
#define QMP_DEC_MEM_REFCOUNT(msgmem) (msgmem->refcount--)
#define QMP_MEM_REFCOUNT(msgmem) (msgmem->refcount)
#define QMP_MEM_TYPE(msgmem) (msgmem->type)
#define QMP_MEM_LEN(msgmem)  (msgmem->nbytes)
#define QMP_MEM_ADDR(msgmem) (msgmem->mem)


/**
 * Internal message handle structure
 */
struct QMP_msghandle_i
{
  /* Message handle type (send or recv or multiple).                  */
  QMP_mh_type_t type;

  /* Error code for this message handle                               */
  QMP_status_t   errcode;

  /* Refcount in case this message handle appears in multiple handles 
   * that are of type QMP_MH_MULTIPLE
   */
  QMP_s32_t      refcount;

  /* whether this message handle is activly sending/or receiving      */
  QMP_bool_t     active;

  /* Machine of this parallel process                                 */
  QMP_machine_t* glm;

  /* Link to the next message handle                                  */
  struct QMP_msghandle_i* next;

  union {

    struct {
      /* Memory part of this handle:                                 */
      /* Now it is single threaded application, no locking           */
      QMP_msgmem_i_t* memory;

      /* several things for repeated send/recv                       */
      /* The rem node is a physical node rank                        */
      QMP_u16_t      remnode;
      QMP_u16_t      tag;
      QMP_s16_t      direction;

      /* A gige port associated with this message handle             */
      QMP_gige_port_t* port;
      
      /* A generic request associated with this message handle       */
      QMP_request_t* request;

      /* A parent or multiple handle containing this handle          */
      struct QMP_msghandle_i* parent;

      QMP_s16_t      _pad;

    }sh;

    struct {
      /* Multiple msghandles for QMP_MH_MULTIPLE type                     */
      struct QMP_msghandle_i** handles;

      /* Number of msg handles inside this message handle                 */
      QMP_u32_t  num;

    }mh;

  }_mh_fields;

};

/**
 * How to access those fields
 */
#define sh_memory      _mh_fields.sh.memory
#define sh_remnode     _mh_fields.sh.remnode
#define sh_tag         _mh_fields.sh.tag
#define sh_request     _mh_fields.sh.request
#define sh_parent      _mh_fields.sh.parent
#define sh_direction   _mh_fields.sh.direction
#define sh_port        _mh_fields.sh.port

#define mh_num         _mh_fields.mh.num
#define mh_handles     _mh_fields.mh.handles


/**
 * Macros to retrieve a request from free list
 * with proper type 'myt' and remote node rank
 */
#define QMP_GET_MSGHANDLE(glm,mh,mt,rmn)  {\
   mh = 0;                                 \
   while (!mh){                            \
      mh = glm->msg_handle_free_list;       \
      if (mh) {                            \
         glm->msg_handle_free_list = mh->next; \
         mh->next = 0;                     \
         mh->errcode = QMP_SUCCESS;        \
         mh->type = mt;                    \
         mh->glm = glm;                    \
         mh->refcount = 1;                 \
         mh->active = QMP_FALSE;           \
         mh->sh_port = 0;                  \
         mh->sh_parent = 0;                \
         mh->sh_remnode = rmn;             \
      }                                    \
      else                                 \
         QMP_init_msghandle_free_list(glm);\
   }                                       \
}

#define QMP_RELEASE_MSGHANDLE(glm,mh)  { \
   mh->next = glm->msg_handle_free_list;  \
   glm->msg_handle_free_list = mh;        \
}

#define QMP_MSGHANDLE_SET_MEM(msgh,mm) {   \
   (msgh->sh_memory) = mm;                 \
   (mm->ref_count)++;                      \
}

#define QMP_MSGHANDLE_MEM(msgh) (msgh->sh_memory)

#define QMP_MSGHANDLE_SET_TAG(msgh,myt) (msgh->sh_tag=myt)
#define QMP_MSGHANDLE_TAG(msgh) (msgh->sh_tag)

#define QMP_MSGHANDLE_SET_REQ(msgh,myrq) (msgh->sh_request=myrq)
#define QMP_MSGHANDLE_REQ(msgh) (msgh->sh_request)

#define QMP_MSGHANDLE_SET_PARENT(msgh,pa) (msgh->sh_parent=pa)
#define QMP_MSGHANDLE_PARENT(msgh) (msgh->sh_parent)

#define QMP_MSGHANDLE_INC_REFCOUNT(msgh) (msgh->refcount++)
#define QMP_MSGHANDLE_DEC_REFCOUNT(msgh) (msgh->refcount--)
#define QMP_MSGHANDLE_REFCOUNT(msgh) (msgh->refcount)

#define QMP_MSGHANDLE_SET_DIR(msgh, md) (msgh->sh_direction=md)
#define QMP_MSGHANDLE_DIR(msgh) (msgh->sh_direction)

#define QMP_MSGHANDLE_ACTIVATE(msgh) (msgh->active = QMP_TRUE)
#define QMP_MSGHANDLE_DEACTIVATE(msgh) (msgh->active = QMP_FALSE)
#define QMP_MSGHANDLE_ACTIVE(msgh) (msgh->active)

#define QMP_MSGHANDLE_SET_PORT(msgh,myp) (msgh->sh_port = myp)
#define QMP_MSGHANDLE_PORT(msgh) (msgh->sh_port)



/**
 * Runtime Environment Variables for QMP system.
 */
#define QMP_OPTS_ENV  (const char *)"QMP_OPTS"
#define QMP_CONF_ENV  (const char *)"QMP_CONF"

/**
 * QMP Messaging environment.
 */
#define QMP_HOSTNAME_LEN    64
#define QMP_ETHDEV_NAME_LEN 24
#define QMP_ERRSTR_MAXLEN   80
#define QMP_NUM_FREELISTS   64
#define QMP_MAX_VIADEV      8
#define QMP_RDMA_STATUS     (VIP_STATUS_OP_REMOTE_RDMA_WRITE | VIP_STATUS_IMMEDIATE | VIP_STATUS_DONE)

/**
 * Maximum message size limited by MVIA ERING Device. This
 * limit is defined inside mvia/src/vipk_devs/vipk_ering/vipk_ering.h
 *
 * This value is redefined by us to allow bigger messages
 */
#define QMP_MAX_MSGLEN      65536

/**
 * Connection timeout for neighboring nodes: in seconds
 */
#define QMP_NEIGHBOR_CONN_TIMEOUT 20
#define QMP_NEIGHBOR_CONN_TIMES   5

/**
 * Number of entries in the Completion QUEUE
 */
#define QMP_CQ_NUM_ENTRIES      1024
#define QMP_CQ_SWITCH_NUM_ENTRIES 32768

/**
 * Number of send /recv qbuf to allocate
 *
 * Size of QBUF is defined below (1024) default. The number of qbufs
 * should be changed acoordingly.
 */
#define QMP_NUM_RECV_QBUFS      60
#define QMP_NUM_SEND_QBUFS      30

/**
 * When a sender sends remote token that is less than the following
 * we have to notify the peer the real number of my local tokens
 */
#define QMP_TOKEN_NOTIFY_THRESHOLD 10

/**
 * When a sender reaches send token of the following value, the sender
 * will stop until the receiver notify us
 */
#define QMP_TOKEN_PRESERVE         5

/**
 * Page sizes of OS
 */
#ifdef QMP_64BIT_LONG
typedef QMP_u64_t QMP_along_t;
#define QMP_OS_PAGESIZE 8192
#define QMP_OS_PAGEBITS 13
#else
typedef QMP_u32_t QMP_along_t;
#define QMP_OS_PAGESIZE 4096
#define QMP_OS_PAGEBITS 12
#endif
#define QMP_OS_PAGEMASK (QMP_OS_PAGESIZE - 1)

/**
 * Post Receive message Buffer size: This size has to be Multiple of 64.
 * The reason VIP_DESCRIPTOR ALIGNMENT is 64.
 */
#define QMP_QBUF_TOTAL_SIZE 1024

#define QMP_QBUF_SIZE (QMP_QBUF_TOTAL_SIZE-sizeof(VIP_DESCRIPTOR)-sizeof(void *) - sizeof(QMP_qbuf_manager_t *))

/**
 * Register memory buffer for VIA send and receive
 */
typedef struct QMP_qbuf_
{
  /* Send or receiving descriptor which has next link to link qbuf */
  VIP_DESCRIPTOR descp;

  /* data buffer to hold incoming or outgoing messages includeing  */
  /* protocol header                                               */
  unsigned char buffer[QMP_QBUF_SIZE];

  /* Send or receiving request handle                              */
  void* req;

  /* buffer manager                                                */
  QMP_qbuf_manager_t* manager;

}QMP_qbuf_t;

#define QMP_QBUF_TRACK_REQ(qbuf,myrq) (qbuf->req = (void*)myrq)

/**
 * QBUF manager: we have fixed number of qbufs for sending and receiving.
 * When all buffers are exhuasted. Sending and receiving will stop.
 */
struct QMP_qbuf_manager_
{
  /* VIA register memory handle                                    */
  VIP_MEM_HANDLE mem_handle;

  /* Type of this qbuf manager (send/receive)                      */
  QMP_mh_type_t  type;

  /* number of qbuffers                                            */
  QMP_u32_t      count;

  /* memory information                                            */
  void*          addr;

  /* head of our chain                                             */
  QMP_qbuf_t*    head;
};


/**
 * Memory registration handler for large memory sizes
 */
typedef struct QMP_regmem_entry_
{
  /* VIA Memory Handle after registration                         */
  VIP_MEM_HANDLE mem_handle;

  /* refrence count                                                */
  int refcount;
  
  /* Page number and number of pages registered                   */
  QMP_along_t    page_num;
  QMP_u32_t      npages;

  /* Link to the next in the hash table chain                     */
  struct QMP_regmem_entry_* next;

  /* Link to unused list (double linked list)                     */
  struct QMP_regmem_entry_* next_u;
  struct QMP_regmem_entry_* prev_u;  

}QMP_regmem_entry_t;

/**
 * Hash table managing the registered memory for a VIA NIC
 */
#define QMP_REGMEM_HASHSIZE 128
#define QMP_REGMEM_HASHBITS 7   /* must be log2 of the above */
#define QMP_REGMEM_HASHMASK (QMP_REGMEM_HASHSIZE-1)
#define QMP_REGMEM_FREELIST_SIZE 512
#define QMP_REQS_FREELIST_SIZE 256
#define QMP_MSGHANDLE_FREELIST_SIZE 256
#define QMP_RORT_SPINCOUNT  100


#define QMP_REGMEM_HASH(addr) ( ( ((QMP_along_t)(addr)) >> QMP_OS_PAGEBITS) & QMP_REGMEM_HASHMASK)

/**
 * Forward decleration of a structure for VIA NIC Device
 */
typedef struct QMP_viadev_handle_ QMP_viadev_handle_t;

typedef struct QMP_regmem_table_
{
  /* Hash table of all registered memories                 */
  QMP_regmem_entry_t* slots[QMP_REGMEM_HASHSIZE];
  
  /* The head of unused list of registered memories        */
  QMP_regmem_entry_t* unused_head;

  /* The tail of unused list of registered memories        */
  QMP_regmem_entry_t* unused_tail;

  /* VIA Device Handler                                    */
  QMP_viadev_handle_t* viadev;

}QMP_regmem_table_t;

/**
 * Maximum number of dimension for a mesh connected cluster.
 */
#define QMP_PHYS_NMD 4


/**
 * A rank is a node id, but it is cannot be assigned randomly since
 * it has to be a row-major value of the coordinate of this node.
 */
typedef struct QMP_phys_node_
{
  QMP_u32_t   rank;
  QMP_u32_t   coordinates[QMP_PHYS_NMD];
  char        host[QMP_HOSTNAME_LEN];
}QMP_phys_node_t, *QMP_phys_node_ptr_t;

/**
 * Macros to manipulate the above node information
 */
#define QMP_NODE_SET_RANK(rt,num) (rt.rank=num)
#define QMP_NODE_RANK(rt) (rt.rank)
#define QMP_NODE_SET_COORDINATES(rt, coords,dim) { \
    int ix;                                        \
    for (ix = 0; ix < dim; ix++)                   \
        rt.coordinates[ix] = coords[ix];           \
}
#define QMP_NODE_COORDINATES(rt) (rt.coordinates)
#define QMP_NODE_SET_HOST(rt,name) (strncpy(rt.host, name, QMP_HOSTNAME_LEN - 1))
#define QMP_NODE_HOST(rt) (rt.host)

/**
 * Macros to manipulate pointer to a run time environment
 */
#define QMP_NODEP_SET_RANK(rt,num) (rt->rank=num)
#define QMP_NODEP_RANK(rt) (rt->rank)
#define QMP_NODEP_SET_COORDINATES(rt, coords, dim) { \
    int ix;                                          \
    for (ix = 0; ix < dim; ix++)                     \
        rt->coordinates[ix] = coords[ix];            \
}
#define QMP_NODEP_COORDINATES(rt) (rt->coordinates)
#define QMP_NODEP_SET_HOST(rt,name) (strncpy(rt->host, name, QMP_HOSTNAME_LEN - 1))
#define QMP_NODEP_HOST(rt) (rt->host)


/**
 * Data structure holding via hostnames that are connected to switches
 * for particular host.
 */
typedef struct QMP_switched_viahost_
{
  char host[QMP_HOSTNAME_LEN];
  char via_host[QMP_HOSTNAME_LEN];
}QMP_switched_viahost_t;
  

/**
 * Runtime environment provided by the cluster configuration file.
 */
typedef struct QMP_rtenv_
{
  QMP_u32_t  dimension;
  QMP_u32_t  size[QMP_PHYS_NMD];
  QMP_u32_t  num_nodes;
  QMP_phys_node_t* all_nodes;
  QMP_switched_viahost_t* switched_table;
}QMP_rtenv_t;

/**
 * Macros to manipulate the above run time environment information
 */
#define QMP_RTENV_SET_DIMENSION(rt,dim) (rt.dimension=dim)
#define QMP_RTENV_DIMENSION(rt) (rt.dimension)
#define QMP_RTENV_SET_NUMNODES(rt,num) (rt.num_nodes=num)
#define QMP_RTENV_NUMNODES(rt) (rt.num_nodes)
#define QMP_RTENV_SET_DIMSIZE(rt, vals) {      \
    int ix;                                     \
    for (ix = 0; ix < rt.dimension; ix++)         \
        rt.size[ix] = vals[ix];                  \
}
#define QMP_RTENV_SIZE(rt) (rt.size)

#define QMP_RTENV_NODE_SET_RANK(rt,num,idx) (rt.all_nodes[idx].rank=num)
#define QMP_RTENV_NODE_RANK(rt,idx) (rt.all_nodes[idx].rank)
#define QMP_RTENV_NODE_SET_COORDINATES(rt,vals,idx) {     \
    int ix;                                                \
    for (ix = 0; ix < rt.dimension; ix++)                    \
        rt.all_nodes[idx].coordinates[ix] = vals[ix];       \
}
#define QMP_RTENV_NODE_COORDINATES(rt,idx) (rt.all_nodes[idx].coordinates)
#define QMP_RTENV_NODE_SET_HOST(rt,name,idx) (strncpy(rt.all_nodes[idx].host, name, QMP_HOSTNAME_LEN - 1))
#define QMP_RTENV_NODE_HOST(rt,idx) (rt.all_nodes[idx].host)
#define QMP_RTENV_NODE(rt,idx) (rt.all_nodes[idx])


/**
 * Default name for QMP configuration file 
 * 
 */
#define QMP_DEFAULT_CONF "/etc/qmp.conf"
#define QMP_DEFAULT_LIST "/etc/qmp.list"

/**
 * Function pointer for VIA Error Callback
 */
typedef void (*viaErrorHandler)(VIP_PVOID Context,
				VIP_ERROR_DESCRIPTOR *ErrorDesc);

/**
 * Underlying VIA NIC Device Handler
 */
struct QMP_viadev_handle_
{
  /* MVIA Ethernet device this connection is using         */
  char       eth_device[QMP_ETHDEV_NAME_LEN];
  
  /* The VIA Device NIC Handle                             */
  VIP_NIC_HANDLE nic_handle;

  /* NIC Attributes of this nic                            */
  VIP_NIC_ATTRIBUTES nic_attrs;

  /* PTAG of this nic                                      */
  VIP_PROTECTION_HANDLE ptag;

  /* Completion QUEUE Handler                              */
  VIP_CQ_HANDLE         cq;

  /* Registered memories for this device                   */
  QMP_regmem_table_t   regmem_table;

  /* How many ports are using this device                  */
  int         count;

};

/**
 * Underlying VIA VI Connection Handle
 */
typedef struct QMP_via_connection_
{
  /* The NIC Handle passed from QMP_viadev_handle          */
  VIP_NIC_HANDLE nic_handle;

  /* Connection Handle or VI HANDLE                        */
  VIP_VI_HANDLE  vi_handle;

  /* Local and remote vi nic attritbutes                   */
  VIP_VI_ATTRIBUTES vi_attrs;
  VIP_VI_ATTRIBUTES remote_vi_attrs;

  /* Local and remote addresses                            */
  VIP_NET_ADDRESS *local, *remote;

  /* QBUF manager for this via device                      */
  QMP_qbuf_manager_t    send_qbufs;
  QMP_qbuf_manager_t    recv_qbufs;

  /* Local Token (Number of posted receive descriptors)    */
  QMP_u32_t             local_tokens;

  /* Number of tokens the remote side has                  */
  QMP_u32_t             remote_tokens;

  /* Flag to signal whether to send local number of tokens */
  /* to the peer                                           */
  QMP_bool_t            notify_peer;

  /* Send and receive request id                           */
  QMP_u32_t             send_id;
  QMP_u32_t             recv_id;

  /* Sent list: requests have been sent out but yet complete    */
  QMP_request_t*       sent_list;

  /* Send qbufs that have been queued because lack of tokens */
  QMP_qbuf_t*          pend_send_head;

  /* Post recv list: recv requests have been posted but not yet received */
  QMP_request_t*       posted_recv_list;

  /* Received messages that have not been claimed yet      */
  QMP_request_t*      not_claimed_buf_list;

  /* Not completed list that holds all requests that waiting for R3 reply */
  QMP_request_t*       rdmarecv_list;

  /* All send message handles using this port              */
  QMP_msghandle_i_t*   send_handles;

  /* All recv message handles using this port              */
  QMP_msghandle_i_t*   recv_handles;

}QMP_via_connection_t;


/**
 * Macros to check whether we can send data on this connection
 */
/* we always reserve this many tokens for query tokens */
#define QMP_PORT_CAN_SEND(conn) (conn->remote_tokens >= QMP_TOKEN_PRESERVE)
#define QMP_PORT_HAS_SEND_QBUFS(conn) (conn->send_qbufs.count)
#define QMP_PORT_NUM_SEND_QBUFS(conn) (conn->send_qbufs.count)

/**
 * Macros to handle send and recv id
 */
#define QMP_PORT_INCR_SENDID(conn) (conn->send_id++)
#define QMP_PORT_INCR_RECVID(conn) (conn->recv_id++)

/**
 * Add a message handle to the send message handle list
 */
#define QMP_PORT_ADD_SEND_HANDLE(conn,mymsgh) {   \
    mymsgh->next = conn->send_handles;            \
    conn->send_handles = mymsgh;                  \
}

/**
 * Remove a message handle from the send message handle list
 */

#define QMP_PORT_RM_SEND_HANDLE(conn,mymsgh) {          \
    QMP_msghandle_i_t* prev = 0;                        \
    QMP_msghandle_i_t* curr = conn->send_handles;       \
    while (curr) {                                      \
        if (curr == mymsgh)                             \
            break;                                      \
        prev = curr;                                    \
        curr = curr->next;                              \
    }                                                   \
    if (!prev)                                          \
        conn->send_handles = mymsgh->next;              \
    else                                                \
        prev->next = mymsgh->next;                      \
}


/**
 * Add a message handle to the recv message handle list
 */
#define QMP_PORT_ADD_RECV_HANDLE(conn,mymsgh) {   \
    mymsgh->next = conn->recv_handles;            \
    conn->recv_handles = mymsgh;                  \
}

/**
 * Remove a message handle from the recv message handle list
 */
#define QMP_PORT_RM_RECV_HANDLE(conn,mymsgh) {    \
    QMP_msghandle_i_t* prev = 0;                  \
    QMP_msghandle_i_t* curr = conn->recv_handles; \
    while (curr) {                                \
        if (curr == mymsgh)                       \
            break;                                \
        prev = curr;                              \
        curr = curr->next;                        \
    }                                             \
    if (!prev)                                     \
        conn->recv_handles = mymsgh->next;        \
    else                                          \
        prev->next = mymsgh->next;                \
}
 
/**
 * VIA connection Discriminator
 */
typedef struct QMP_via_conn_disc_
{
  /* Local Rank of this connection                         */
  QMP_u32_t local_rank;

  /* Remote rank of this connection                        */
  QMP_u32_t remote_rank;

  /* Axis of this connection (x, y , z)                    */
  QMP_axis_t axis;

  /* direction of this connection                          */
  QMP_dir_t  direction;

}QMP_via_conn_disc_t;


/**
 * GigaE port information
 */
struct QMP_gige_port_
{
  /* Type of this gige port (switched or direct connect)   */
  QMP_gige_conn_type_t type;

  /* MVIA Ethernet device this connection is using         */
  char       eth_device[QMP_ETHDEV_NAME_LEN];

  /* direction and axis for this port                      */
  /* if direction is QMP_UNKNOWN, this port is for         */
  /* an extra connection use for partition of the mesh     */
  QMP_dir_t  direction;
  QMP_axis_t axis;

  /* The other end of this connection VIA host info        */
  char        peer_via_host[QMP_HOSTNAME_LEN];

  /* The other end of this connection host information     */
  QMP_phys_node_t* peer;

  /* Whether this port is active or not                    */
  QMP_bool_t active;

  /* whether we use reliable transimission on this link    */
  QMP_bool_t reliable;

  /* Integer errcode  from VIA                             */
  QMP_status_t err_code;

  /* Physical geometry this port belongs to                */
  QMP_phys_geometry_t* phys;

  /* VIA NIC or Device Handler                             */
  QMP_viadev_handle_t* viadev;

  /* Is this the owner of the above viadev? This is        */
  /* useful if a viadev is shared by multiple ports        */
  QMP_bool_t            viadev_owner;

  /* VIA VI Handle for the above device                    */
  QMP_via_connection_t* conn;

};

/**
 * Get registered memory table from a port
 */
#define QMP_PORT_REGMEM_TABLE(port) ((&(port->viadev->regmem_table)))
  

/**
 * Physical geometry structure
 *
 * Now meshed configuration is the one we support.
 */
struct QMP_phys_geometry
{
  /* Type of this physical geometry: SWITCH, GRID etc.     */
  QMP_ictype_t type;

  /* total number of nodes available                       */
  QMP_u32_t    num_nodes;

  /* Dimension of  geometry                                */
  QMP_u32_t    dimension;

  /* size of this geometry                                 */
  QMP_u32_t    size[QMP_PHYS_NMD];

  /* physical node information                             */
  QMP_phys_node_t my_node;

  /* Gigabit ether net ports (cards) for the mesh          */
  /* This contains neighboring information                 */
  /* 0: minus direction, 1: plus direction                 */
  QMP_gige_port_t ports[QMP_PHYS_NMD][2];

  /* Gigabit ethernet connections used for switch          */
  /* this should be an table indexed by host rank          */
  QMP_gige_port_t* switch_ports;
};

/**
 * Macros to manipulate the above physical geometry
 */
#define QMP_PHYS_SET_RANK(phys,num) (phys->my_node.rank=num)
#define QMP_PHYS_RANK(phys) (phys->my_node.rank)
#define QMP_PHYS_SET_TYPE(phys,type) (phys->type=type)
#define QMP_PHYS_TYPE(phys) (phys->type)
#define QMP_PHYS_SET_NUMNODES(phys,num) (phys->num_nodes=num)
#define QMP_PHYS_NUMNODES(phys) (phys->num_nodes)
#define QMP_PHYS_SET_DIMENSION(phys,dim) (phys->dimension=dim)
#define QMP_PHYS_DIMENSION(phys) (phys->dimension)
#define QMP_PHYS_SET_DIMSIZE(phys,vals) {  \
    int ix;                                 \
    for (ix = 0; ix < phys->dimension; ix++)  \
        phys->size[ix] = vals[ix];           \
}
#define QMP_PHYS_DIMSIZE(phys) (phys->size)
#define QMP_PHYS_CALC_NUMNODES(phys) {     \
        int ix;                             \
        phys->num_nodes = 1;               \
        for (ix = 0; ix < phys->dimension; ix++) \
             phys->num_nodes = phys->num_nodes * phys->size[ix]; \
}
        
#define QMP_PHYS_SET_COORDINATES(phys, vals) {    \
    int ix;                                        \
    for (ix = 0; ix < phys->dimension; ix++)         \
        phys->my_node.coordinates[ix] = vals[ix];   \
}

#define QMP_PHYS_POS_IN_DIM(phys,dim) (phys->my_node.coordinates[dim])

#define QMP_PHYS_COORDINATES(phys) (phys->my_node.coordinates)
#define QMP_PHYS_GIGE_PORTS(phys) (phys->ports)

/**
 * Simple Logical Grid Topology
 */
#define QMP_LOGIC_NMD QMP_PHYS_NMD

/**
 * Logic node information
 */
typedef struct QMP_logic_node_
{
  QMP_u32_t rank;
  QMP_u32_t coordinates[QMP_LOGIC_NMD];
  QMP_phys_node_t* phys_node;
}QMP_logic_node_t;


typedef struct QMP_topology
{
  /* Dimension of  geometry                                */
  QMP_u32_t  dimension;

  /* size of this geometry                                 */
  QMP_u32_t  size[QMP_LOGIC_NMD];

  /* Total number of nodes                                 */
  QMP_u32_t  num_nodes;

  /* Logic node information                                */
  QMP_logic_node_t my_node;

  /* correspoing physical geometry information             */
  QMP_phys_geometry_t*  phys;

  /* Index mapping logical lattice axes to physical axes   */
  /* If value of ordering is -1, no mapping for this axis  */
  /* which also means, this dimension has size of 1        */
  QMP_s32_t  ordering[QMP_LOGIC_NMD];

  /* Logical Neighboring information                       */
  /* 2 neighbors for each dimension                        */
  /* 0: minus direction, 1: plus direction                 */
  QMP_logic_node_t neighbors[QMP_LOGIC_NMD][2];

  /* Switched nodes information, these nodes can be        */
  /* acccessed through a network switch                    */
  QMP_logic_node_t* switched_nodes;

}QMP_topology_t;

/**
 * Macros to manipulate the above physical geometry
 */
#define QMP_LOGIC_SET_RANK(logictp,num) (logictp->my_node.rank=num)
#define QMP_LOGIC_RANK(logictp) (logictp->my_node.rank)
#define QMP_LOGIC_SET_TYPE(logictp,type) (logictp->type=type)
#define QMP_LOGIC_TYPE(logictp) (logictp->type)
#define QMP_LOGIC_SET_NUMNODES(logictp,num) (logictp->num_nodes=num)
#define QMP_LOGIC_NUMNODES(logictp) (logictp->num_nodes)
#define QMP_LOGIC_SET_DIMENSION(logictp,dim) (logictp->dimension=dim)
#define QMP_LOGIC_DIMENSION(logictp) (logictp->dimension)
#define QMP_LOGIC_SET_DIMSIZE(logictp,vals) {  \
    int ix;                                 \
    for (ix = 0; ix < logictp->dimension; ix++)  \
        logictp->size[ix] = vals[ix];           \
}
#define QMP_LOGIC_DIMSIZE(logictp) (logictp->size)
#define QMP_LOGIC_CALC_NUMNODES(logictp) {     \
        int ix;                             \
        logictp->num_nodes = 1;               \
        for (ix = 0; ix < logictp->dimension; ix++) \
             logictp->num_nodes = logictp->num_nodes * logictp->size[ix]; \
}
        
#define QMP_LOGIC_SET_COORDINATES(logictp, vals) {    \
    int ix;                                           \
    for (ix = 0; ix < logictp->dimension; ix++)       \
        logictp->my_node.coordinates[ix] = vals[ix];  \
}
#define QMP_LOGIC_COORDINATES(logictp) (logictp->my_node.coordinates)
#define QMP_LOGIC_ORDERING(logictp) (logictp->ordering)

#define QMP_PHYS_TO_LOGIC_COORDINATES(pcor,tcor,logictp) { \
        int ix;                                            \
        for (ix = 0; ix < logictp->dimension; ix++){       \
            if (logictp->size[ix] != 1)                    \
               tcor[ix] = pcor[logictp->ordering[ix]];     \
            else                                           \
               tcor[ix] = 0;                               \
        }                                                  \
}

#define QMP_LOGIC_TO_PHYS_COORDINATES(tcor,pcor,logictp,physp) { \
        int ix, tpix;                                            \
        tpix = 0;                                                \
        for (ix = 0; ix < physp->dimension; ix++){               \
            while (logictp->size[tpix] == 1) tpix++;             \
            if (ix < logictp->dimension)                         \
                pcor[logictp->ordering[tpix]] = tcor[tpix];      \
            else                                                 \
                pcor[logictp->ordering[tpix]] = physp->my_node.coordinates[logictp->ordering[tpix]]; \
            tpix++;                                              \
        }                                                        \
}

/**
 * High Level Tag Values
 *
 * Application should use tag below the following tags 
 */
#define QMP_INTERNAL_TAG       (QMP_u16_t)0x1000

#define QMP_SYS_TAG            (QMP_u16_t)0x8000

/**
 * The scatter tag, gather tag and routing tags are seperated 
 * by 4096 which is large enough for any cluster for now
 */
#define QMP_SCATTER_TAG        (QMP_u16_t)0xa000
#define QMP_GATHER_TAG         (QMP_u16_t)0xb000
#define QMP_ROUTING_TAG        (QMP_u16_t)0xc000

#define QMP_SNDRCV             (QMP_u16_t)0xfffa
#define QMP_BCAST              (QMP_u16_t)0xfffb
#define QMP_REDUCE             (QMP_u16_t)0xfffc
#define QMP_ALLTOALL           (QMP_u16_t)0xfffd
#define QMP_RESERVED           (QMP_u16_t)0xfffe
#define QMP_ANY                (QMP_u16_t)0xffff
#define QMP_ALL_REDUCE         QMP_ALLTOALL


/**
 * QMP Protocol Operation code.
 */
#define QMP_IMMEDIATE_DATA            (QMP_u16_t)1000
#define QMP_QUERY                     (QMP_u16_t)1001
#define QMP_QUERY_REPLY               (QMP_u16_t)1002
#define QMP_RDMA_PUT                  (QMP_u16_t)1003
#define QMP_RDMA_PUT_REPLY            (QMP_u16_t)1004
#define QMP_RDMA_PUT_FINISH           (QMP_u16_t)1005
#define QMP_NO_OP                     (QMP_u16_t)1006

#define QMP_OP_UNKNOWN                (QMP_u16_t)1100

#define QMP_PSTART                    QMP_IMMEDIATE_DATA



/**
 * QMP VIA MESH Message Passing Protocol
 */
typedef struct QMP_packet_
{
  /* operation of this message                              */
  QMP_u16_t    op;

  /* Token number of this via on both ends                  */
  /* This credit is the number of posted buffers. This      */
  /* number will be always sent to the other end            */
  QMP_u16_t    num_qbufs;

  /* This is the number of tokens I think the other end has */
  QMP_u16_t    remote_qbufs;

  /* source and destination field of this message           */
  /* source and destination are represented by physical     */
  /* node ranks which can be used to find coordinates       */
  QMP_u16_t    source;
  QMP_u16_t    dest;

  /*  (tag)                                                 */
  QMP_u16_t     tag;

  /* This is for QMP channel id only                        */
  QMP_u16_t     id;
  QMP_u16_t     _reserved;
  
}QMP_packet_t;

/**
 * Set packet information
 */
#define QMP_SET_PACKET(p,operation,lt,rt,src,rmrank,t) {      \
  p->op = operation;                                          \
  p->num_qbufs = lt;                                          \
  p->remote_qbufs = rt;                                       \
  p->source = src;                                            \
  p->dest = rmrank;                                           \
  p->tag = t;                                                 \
}

/**
 * Set packet credit information
 */
#define QMP_SET_PACKET_TOKENS(p,lt,rt) {   \
  p->num_qbufs = lt;                        \
  p->remote_qbufs = rt;                     \
}

#define QMP_SET_PACKET_TAG(p,t) (p->tag = t)
#define QMP_PACKET_TAG(p) (p->tag)

/**
 * Check whether an incoming packet match a posted packet
 */
#define QMP_CAN_RECV(ip, pp) (ip->op == pp->op && ip->source == pp->source && ip->dest == pp->dest && (ip->tag == pp->tag || pp->tag == QMP_ANY))

/**
 * Check whether an incoming packet match a posted packet
 * regardless of protocol type
 */
#define QMP_MATCH(ip, pp) (ip->source == pp->source && ip->dest == pp->dest && (ip->tag == pp->tag || pp->tag == QMP_ANY))

typedef struct QMP_idata_part_
{
  /* total length of this packet                            */
  QMP_u32_t        total_len;
  /* Offset of this packet from the beginning of a buffer   */
  QMP_u32_t        offset;
  /* Payload length                                         */
  QMP_u32_t        payload_len;
}QMP_idata_part_t;


/**
 * Set packet header information
 */
#define QMP_SET_IDATA_HDR(p,operation,lt,rt,src,rmrank,t) {   \
  p->hdr.op = operation;                                      \
  p->hdr.num_qbufs = lt;                                      \
  p->hdr.remote_qbufs = rt;                                   \
  p->hdr.source = src;                                        \
  p->hdr.dest = rmrank;                                       \
  p->hdr.tag = t;                                             \
}

/**
 * This is the structure for data in the packet delivery
 */
typedef struct QMP_idata_packet_
{
  /* Message header for this data                           */
  QMP_packet_t hdr;

  QMP_idata_part_t idata;

}QMP_idata_packet_t;

/**
 * Set packet payload information
 */
#define QMP_SET_IDATA_LEN(p,len) (p->idata.total_len = len)
#define QMP_GET_IDATA_LEN(p,len) (len = p->idata.total_len)
#define QMP_IDATA_LEN(p) (p->idata.total_len)

#define QMP_SET_IDATA_PAYLOAD_LEN(p,plen) (p->idata.payload_len = plen)
#define QMP_IDATA_PAYLOAD_LEN(p) (p->idata.payload_len)

#define QMP_IDATA_OFFSET(p) (p->idata.offset)

#define QMP_IDATA_NUM_QBUFS_NEEDED(len) (len / (QMP_QBUF_SIZE - sizeof(QMP_idata_packet_t)) + 1)

#define QMP_CALC_IDATA_PAYLOAD_LEN(len,num_qbufs,idx) ((idx == num_qbufs - 1) ? (len - idx * (QMP_QBUF_SIZE - sizeof(QMP_idata_packet_t))) : (QMP_QBUF_SIZE - sizeof(QMP_idata_packet_t)))

#define QMP_CALC_IDATA_OFFSET(num_qbufs,idx) (idx * (QMP_QBUF_SIZE - sizeof(QMP_idata_packet_t)))


typedef struct QMP_memory_part_
{

  /* memory address and length                              */
  void*            address;
  QMP_u32_t        len;

  VIP_MEM_HANDLE   mem_handle;

  /* sending request id                                     */
  QMP_u32_t        sid;

  /* receiving request id                                   */
  QMP_u32_t        rid;

  /* Index of multiple segments of a rdma message           */
  QMP_u32_t        segindex;

}QMP_memory_part_t;


/**
 * This is the structure for remote memory write
 */
typedef struct QMP_rdma_packet_
{
  /* Message header for this data                           */
  QMP_packet_t hdr;

  QMP_memory_part_t rdma;

}QMP_rdma_packet_t;

/**
 * Set RDMA packet header information
 */

#define QMP_SET_RDMA_PACKET_OP(p,operation) (p->hdr.op = operation)
#define QMP_SET_RDMA_SEGINDEX(p,idx) (p->rdma.segindex = idx)
#define QMP_RDMA_GET_SEGINDEX(p) (p->rdma.segindex)

#define QMP_SET_RDMA_HDR(p,operation,lt,rt,src,rmrank,t) {    \
  p->hdr.op = operation;                                      \
  p->hdr.num_qbufs = lt;                                      \
  p->hdr.remote_qbufs = rt;                                   \
  p->hdr.source = src;                                        \
  p->hdr.dest = rmrank;                                       \
  p->hdr.tag = t;                                             \
}

/**
 * Set RDMA packet memory information
 */
#define QMP_SET_RDMA_MEMORY(p,buf,buflen,mh,sendid,recvid) {  \
  p->rdma.address=buf;                                        \
  p->rdma.len=buflen;                                         \
  p->rdma.mem_handle=mh;                                      \
  p->rdma.sid=sendid;                                         \
  p->rdma.rid=recvid;                                         \
}

/**
 * Find out how many qbufs are needed for a RDMA message
 */
#define QMP_RDMA_NUM_QBUFS_NEEDED(len) (len/QMP_MAX_MSGLEN + 1)

/**
 * Calculate rdma address for segment idx
 */
#define QMP_RDMA_GET_ADDR(start,idx) (start + idx * QMP_MAX_MSGLEN)
#define QMP_RDMA_GET_LEN(total,numseg,idx)  ((idx == numseg-1) ? (total - idx * QMP_MAX_MSGLEN) : QMP_MAX_MSGLEN)
 

typedef struct QMP_rdma_finish_part_
{
  /* Receiviing request id                                  */
  QMP_u32_t        rid;

}QMP_rdma_finish_part_t;

/**
 * Single message to indicate finished transfer (RDMA)
 */
typedef struct QMP_rdma_finish_packet_
{
  /* Message header for this data                           */
  QMP_packet_t hdr;
  
  QMP_rdma_finish_part_t rdmaf;

}QMP_rdma_finish_packet_t;

/**
 * QMP Global Operation Operator
 */
typedef enum QMP_op
{
  QMP_SUM,
  QMP_MAX,
  QMP_MIN,
  QMP_XOR,
}QMP_op_t;

/**
 * Function pointer for global operation.
 * inout = inout op in
 */
typedef void  (*QMP_opfunc) (void* inout, void* in,
			     QMP_u32_t count, QMP_datatype_t type);

/**
 * Structure mapping QMP_op to real operation
 */
typedef struct QMP_rop
{
  QMP_op_t    op;
  QMP_bool_t  commute;
  QMP_opfunc  func;
}QMP_rop_t;


/**
 * QMP Send and Receiving Request: The following is for the send request
 */
struct QMP_request_
{

  /* Protocol corresponding to this request                */
  QMP_packet_t  hdr;
  
  /* Type of this request (Send or Receive)                */
  QMP_mh_type_t type;

  /* What state this request is in (IDLE or WAITING)       */
  QMP_mh_state_t state;

  /* Used to handled freed (by user) but not complete      */
  QMP_s32_t      ref_count;

  /* Local memory and send receiving id information        */
  QMP_memory_part_t memory;

  /* Remote memory information                             */
  QMP_memory_part_t remote_memory;

  /* Number of elements                                    */
  QMP_u32_t       count;

  /* Data type                                             */
  QMP_datatype_t  datatype;

  /* Number of qbufs associated with this request          */
  QMP_u32_t       num_qbufs_needed;

  /* Number of qbufs finished so far                       */
  QMP_u32_t       num_qbufs_done;

  /* a buffer associated with this request                 */
  QMP_qbuf_t*    qbuf;

  /* A port assocaited with this request                   */
  QMP_gige_port_t* port;

  /* Link to the next request                              */
  struct QMP_request_ *next;

  /* Link to the prev request                              */
  struct QMP_request_ *prev;

};

/**
 * Macros to retrieve a request from free list
 * with proper type 'myt'
 */
#define QMP_GET_REQUEST(glm,myreq,myt)  {    \
   myreq = 0;                                \
   while (!myreq){                           \
      myreq = glm->req_free_list;            \
      if (glm->req_free_list) {              \
         glm->req_free_list = glm->req_free_list->next; \
         if (glm->req_free_list)             \
             glm->req_free_list->prev = 0;   \
         myreq->next = 0;                    \
         myreq->prev = 0;                    \
         myreq->state = QMP_MH_WAITING;      \
         myreq->type = myt;                  \
         myreq->ref_count = 1;               \
         myreq->num_qbufs_needed = 1;        \
         myreq->num_qbufs_done = 0;          \
         myreq->qbuf = 0;                    \
         myreq->port = 0;                    \
         myreq->memory.address = 0;          \
         myreq->memory.len = 0;              \
         myreq->memory.rid = 0;              \
         myreq->memory.sid = 0;              \
      }                                      \
      else{                                  \
         QMP_init_req_free_list(glm);        \
      }                                      \
   }                                         \
}

#define QMP_RELEASE_REQUEST(glm,sreq)  { \
   sreq->next = glm->req_free_list;      \
   if (glm->req_free_list)               \
       glm->req_free_list->prev = sreq;  \
   glm->req_free_list = sreq;            \
   glm->req_free_list->prev = 0;         \
}


#define QMP_SET_REQ_TYPE(sreq,mt) (sreq->type=mt)
#define QMP_REQ_TYPE(sreq) (sreq->type)

#define QMP_SET_REQ_STATE(sreq,st) (sreq->state=st)
#define QMP_REQ_STATE(sreq) (sreq->state)

#define QMP_SET_REQ_NUM_QBUFS_NEEDED(sreq,nq) (sreq->num_qbufs_needed = nq)
#define QMP_REQ_NUM_QBUFS_NEEDED(sreq) (sreq->num_qbufs_needed)

#define QMP_INC_REQ_NUM_QBUFS_DONE(sreq) ((sreq->num_qbufs_done)++)
#define QMP_REQ_NUM_QBUFS_DONE(sreq) (sreq->num_qbufs_done)

#define QMP_SET_REQ_SID(sreq,cn) (sreq->memory.sid=cn->send_id++)
#define QMP_SET_REQ_SENDID(sreq,num) (sreq->memory.sid=num)
#define QMP_GET_REQ_SID(sreq,num) (num=sreq->memory.sid)
#define QMP_REQ_SID(sreq) (sreq->memory.sid)

#define QMP_SET_REQ_RID(sreq,cn) (sreq->memory.rid=cn->recv_id++)
#define QMP_SET_REQ_RECVID(sreq,num) (sreq->memory.rid=num)
#define QMP_GET_REQ_RID(sreq,num) (num=sreq->memory.rid)
#define QMP_REQ_RID(sreq) (sreq->memory.rid)

#define QMP_SET_REQ_HDR(sreq,thd) (sreq->hdr=thd)
#define QMP_SET_REQ_QBUF(sreq,myq) (sreq->qbuf=myq)
#define QMP_SET_REQ_PORT(sreq,myp) (sreq->port=myp)
#define QMP_REQ_PORT(sreq) (sreq->port)

#define QMP_SET_REQ_USERBUF(sreq,ubuf) (sreq->memory.address = ubuf)
#define QMP_SET_REQ_USERBUFLEN(sreq,ulen) (sreq->memory.len = ulen)
#define QMP_GET_REQ_USERBUF(sreq,ubuf) (ubuf=sreq->memory.address)
#define QMP_GET_REQ_USERBUFLEN(sreq,ulen) (ulen = sreq->memory.len)
#define QMP_REQ_USERBUF(sreq) (sreq->memory.address)
#define QMP_REQ_USERBUFLEN(sreq) (sreq->memory.len)

#define QMP_SET_REQ_COUNT(sreq,num) (sreq->count = num)
#define QMP_SET_REQ_DATATYPE(sreq,t) (sreq->datatype = t)
#define QMP_GET_REQ_COUNT(sreq,num) (num=sreq->count)
#define QMP_GET_REQ_DATATYPE(sreq,t) (t = sreq->datatype)

#define QMP_SET_REQ_MEMHANDLE(sreq,mh) (sreq->memory.mem_handle=mh)
#define QMP_GET_REQ_MEMHANDLE(sreq,mh) (mh=sreq->memory.mem_handle)
#define QMP_REQ_MEMHANDLE(sreq) (sreq->memory.mem_handle)

#define QMP_SET_REQ_REM_MEMHANDLE(sreq,mh) (sreq->remote_memory.mem_handle=mh)
#define QMP_GET_REQ_REM_MEMHANDLE(sreq,mh) (mh=sreq->remote_memory.mem_handle)
#define QMP_REQ_REM_MEMHANDLE(sreq) (sreq->remote_memory.mem_handle)

#define QMP_SET_REQ_REM_USERBUF(sreq,ubuf) (sreq->remote_memory.address=ubuf)
#define QMP_SET_REQ_REM_USERBUFLEN(sreq,ulen) (sreq->remote_memory.len = ulen)
#define QMP_GET_REQ_REM_USERBUF(sreq,ubuf) (ubuf=sreq->remote_memory.address)
#define QMP_GET_REQ_REM_USERBUFLEN(sreq,ulen) (ulen = sreq->remote_memory.len)
#define QMP_REQ_REM_USERBUF(sreq) (sreq->remote_memory.address)
#define QMP_REQ_REM_USERBUFLEN(sreq) (sreq->remote_memory.len)

/**
 * Setting a request remote memory information from a rdma
 * reply packet
 */
#define QMP_SET_REQ_REM_MEMORY_FROM_RDMA_PACKET(sreq,rdmap) {  \
  sreq->remote_memory.address = rdmap->rdma.address;       \
  sreq->remote_memory.len = rdmap->rdma.len;               \
  sreq->remote_memory.mem_handle = rdmap->rdma.mem_handle; \
}


#define QMP_ADD_REQ_TO_SENTLIST(sreq,cn) {          \
   sreq->next = cn->sent_list;                      \
   sreq->prev = 0;                                  \
   if (cn->sent_list)                               \
       cn->sent_list->prev = sreq;                  \
   cn->sent_list = sreq;                            \
}

#define QMP_RM_REQ_FROM_SENTLIST(sreq,cn) {         \
   QMP_request_t* next = sreq->next;                \
   QMP_request_t* prev = sreq->prev;                \
   if (next)                                        \
       next->prev = prev;                           \
   if (prev)                                        \
       prev->next = next;                           \
   else                                             \
       cn->sent_list = next;                        \
}

#define QMP_GET_REQ_FROM_SENTLIST(sreq,cn,sendid) { \
   sreq = 0;                                        \
   QMP_request_t* curr = cn->sent_list;             \
   while (curr) {                                   \
      if (curr->hdr.op == QMP_RDMA_PUT && curr->memory.sid == sendid){\
          sreq = curr;                              \
          break;                                    \
      }                                             \
      curr = curr->next;                            \
   }                                                \
   if (sreq)                                        \
      QMP_RM_REQ_FROM_SENTLIST(sreq,cn);            \
}
    
/**
 * Macros related to pending send list 
 */
#define QMP_PEND_SENDLIST_EMPTY(cn) (cn->pend_send_head == 0)

#define QMP_ENQUEUE_QBUF_TO_PEND_SENDLIST(sq,cn) {  \
   sq->descp.CS.Next.Address = cn->pend_send_head;  \
   cn->pend_send_head = sq;                         \
}

#define QMP_DEQUEUE_QBUF_FROM_PEND_SENDLIST(sq,cn) { \
   QMP_qbuf_t* prev = 0;                            \
   sq = cn->pend_send_head;                         \
   while (sq->descp.CS.Next.Address) {              \
       prev = sq;                                   \
       sq = sq->descp.CS.Next.Address;              \
   }                                                \
   if (prev)                                        \
       prev->descp.CS.Next.Address = 0;             \
   else                                             \
       cn->pend_send_head = 0;                      \
}

/**
 * Add request to the end of queue (FIFO)
 * since we compare receiving from the head
 */
#define QMP_ADD_REQ_TO_RECVED_LIST(sreq,cn) {       \
   QMP_request_t* p = cn->not_claimed_buf_list;     \
   if (!p) {                                        \
      sreq->next = 0;                               \
      sreq->prev = 0;                               \
      cn->not_claimed_buf_list = sreq;              \
   }                                                \
   else {                                           \
      while (p->next)                               \
          p = p->next;                              \
      p->next = sreq;                               \
      sreq->prev = p;                               \
      sreq->next = 0;                               \
   }                                                \
}

#define QMP_RM_REQ_FROM_RECVED_LIST(sreq,cn) {      \
   QMP_request_t* next = sreq->next;                \
   QMP_request_t* prev = sreq->prev;                \
   if (next)                                        \
       next->prev = prev;                           \
   if (prev)                                        \
       prev->next = next;                           \
   else                                             \
       cn->not_claimed_buf_list = next;             \
}

/**
 * Add a request to the end of posted list (FIFO)
 */
#define QMP_ADD_REQ_TO_POSTED_LIST(sreq,cn) {       \
   QMP_request_t* p = cn->posted_recv_list;         \
   if (!p) {                                        \
      sreq->next = 0;                               \
      sreq->prev = 0;                               \
      cn->posted_recv_list = sreq;                  \
   }                                                \
   else {                                           \
      while (p->next)                               \
          p = p->next;                              \
      p->next = sreq;                               \
      sreq->prev = p;                               \
      sreq->next = 0;                               \
   }                                                \
}

#define QMP_RM_REQ_FROM_POSTED_LIST(sreq,cn) {      \
   QMP_request_t* next = sreq->next;                \
   QMP_request_t* prev = sreq->prev;                \
   if (next)                                        \
       next->prev = prev;                           \
   if (prev)                                        \
       prev->next = next;                           \
   else                                             \
       cn->posted_recv_list = next;                 \
}

#define QMP_ADD_REQ_TO_RDMALIST(sreq,cn) {          \
   sreq->next = cn->rdmarecv_list;                  \
   sreq->prev = 0;                                  \
   if (cn->rdmarecv_list)                           \
       cn->rdmarecv_list->prev = sreq;              \
   cn->rdmarecv_list = sreq;                        \
}


#define QMP_RM_REQ_FROM_RDMALIST(sreq,cn) {         \
   QMP_request_t* next = sreq->next;                \
   QMP_request_t* prev = sreq->prev;                \
   if (next)                                        \
       next->prev = prev;                           \
   if (prev)                                        \
       prev->next = next;                           \
   else                                             \
       cn->rdmarecv_list = next;                    \
}

#define QMP_GET_REQ_FROM_RDMALIST(sreq,cn,recvid) { \
   sreq = 0;                                        \
   QMP_request_t* curr = cn->rdmarecv_list;         \
   while (curr) {                                   \
      if (curr->hdr.op == QMP_RDMA_PUT && curr->memory.rid == recvid){\
          sreq = curr;                              \
          break;                                    \
      }                                             \
      curr = curr->next;                            \
   }                                                \
}

/**
 * Machine configuration information.
 */
struct QMP_machine
{
  /* host name of this machine.                              */
  char*        host;

  /* number of processors.                                   */
  QMP_u16_t  num_cpus;

  /* Thread level of this QMP implementation                 */
  QMP_thread_level_t th_level;

  /* interconnection type for this machine.                  */
  QMP_ictype_t ic_type;

  /* Runtime environment for this parallel machine(s)        */
  QMP_rtenv_t  rtenv;

  /* Physical geometry for this parallel job.                */
  QMP_phys_geometry_t* phys;

  /* logical topology information of this machine.           */
  QMP_topology_t* tpl;                          

  /* maximum length this messaging system supports for now   */
  QMP_u32_t max_msg_length;

  /* Send and receive tags for multiple qmp channels       */
  QMP_u16_t             send_tag;

  /* free list for registered memory entries                 */
  QMP_regmem_entry_t* regmem_free_list;
  QMP_s32_t           regmem_free_list_inited;

  /* Free list for send and receiving request objects        */
  QMP_request_t*      req_free_list;

  /* All allocated free lists are kept here for easy cleanup */
  void*               allocated_free_lists[QMP_NUM_FREELISTS];
  QMP_u32_t           num_free_lists;

  /* Free list for message handles                           */
  QMP_msghandle_i_t*  msg_handle_free_list;

  /* All completion queues are stored here for quick loop    */
  VIP_CQ_HANDLE       allcqs[QMP_MAX_VIADEV];
  QMP_u32_t           numcqs;

  /* whether this machine is initialized                     */
  QMP_bool_t inited;

  /* the last function status or error code                  */
  QMP_status_t err_code;
};

/**
 * Macro to handle send tag
 */
#define QMP_INC_SENDTAG(glm) {        \
   glm->send_tag++;                   \
   if (glm->send_tag >= QMP_SYS_TAG)  \
       glm->send_tag = 0;             \
}
#define QMP_SENDTAG(conn) (glm->send_tag)

/**
 * Macros returning some critical information
 */
#define QMP_MY_RANK(glm) (glm->tpl?glm->tpl->my_node.rank:glm->phys->my_node.rank)
#define QMP_SIZE(glm) (glm->tpl?glm->tpl->num_nodes:glm->phys->num_nodes)
#define QMP_NUM_DIMENSION(glm) (glm->tpl ? glm->tpl->dimension : glm->phys->dimension)
#define QMP_DIM_SIZE(glm,axis) (glm->tpl ? glm->tpl->size[axis] : glm->phys->size[axis])
#define QMP_MY_COORDINATE(glm) (glm->tpl?glm->tpl->my_node.coordinates:glm->phys->my_node.coordinates)
#define QMP_MINUS_NEIGHBOR(glm,axis) (glm->tpl?glm->tpl->neighbors[axis][0].rank : glm->phys->ports[axis][0].peer->rank)
#define QMP_PLUS_NEIGHBOR(glm,axis) (glm->tpl?glm->tpl->neighbors[axis][1].rank : glm->phys->ports[axis][1].peer->rank)


/**
 * Message size threshold to switch from memory copy to rdms put
 */
/* #define QMP_MEMCPY_THRESHOLD 6000 */
#define QMP_MEMCPY_THRESHOLD 16384 

/**
 * Simple MIN and MAX macros
 */
#define QMP_MIN_VAL(a,b) ((a <= b) ? a : b)
#define QMP_MAX_VAL(a,b) ((a >= b) ? a : b)
  
/**
 * Magic number
 */
#define QMP_MAGIC        (QMP_u16_t)0x9cdf

/**
 * Time out value = 50 seconds for regular message
 */
#define QMP_MSG_WAIT_TIMEOUT 50

/**
 * data size table for a QMP data type.
 */
extern QMP_u32_t QMP_data_size_table[];

#define QMP_DATA_SIZE(type) (QMP_data_size_table[type])

/**
 * QMP operator table.
 */
extern QMP_rop_t QMP_operator_table[];

#define QMP_OPERATOR(op) (QMP_operator_table[op])

/**
 * One global instance of this machine.
 */
extern QMP_machine_t QMP_global_m;

/**
 * verbose mode of this run.
 */
extern int   QMP_rt_verbose;

/**
 * Trace macro
 */
#ifdef _QMP_TRACE
#define QMP_TRACE(x) (QMP_fprintf(stderr, "%s at line %d of file %s\n", x, __LINE__, __FILE__))
#else
#define QMP_TRACE(x)
#endif

/**
 * Debug macros
 */
#if !defined(_QMP_DEBUG)
#define QMP_DEBUG(args...)

#define QMP_DUMP_IDATA_PACKET(packet)
#define QMP_DUMP_PACKET(packet)
#define QMP_DUMP_REQUEST(request)
#else

#undef QMP_DEBUG

extern unsigned int qmp_debug_level;

#define QMP_DBGLVL_FREELIST        0x00000001
#define QMP_DBGLVL_REQUEST         0x00000002
#define QMP_DBGLVL_PACKET          0x00000004
#define QMP_DBGLVL_IDATA           0x00000008
#define QMP_DBGLVL_TOKEN           0x00000010
#define QMP_DBGLVL_SEND            0x00000020
#define QMP_DBGLVL_RECV            0x00000040
#define QMP_DBGLVL_REGMEM          0x00000080
#define QMP_DBGLVL_RDMA            0x00000100
#define QMP_DBGLVL_MSGMEM          0x00000200
#define QMP_DBGLVL_MSGHANDLE       0x00000400
#define QMP_DBGLVL_CONNECTION      0x00000800
#define QMP_DBGLVL_INIT            0x00001000
#define QMP_DBGLVL_SCATTER         0x00002000
#define QMP_DBGLVL_GATHER          0x00004000
#define QMP_DBGLVL_ROUTING         0x00008000

#define QMP_DBGLVL_NONE            0x00000000
#define QMP_DBGLVL_ALL             0xFFFFFFFF

#ifdef _QMP_LOG_LOCAL
extern FILE* QMP_debugfd;

#define QMP_DEBUG(level,args...)                            \
   if (qmp_debug_level & (level)) {                         \
       QMP_fprintf(QMP_debugfd,##args);                     \
       fflush(QMP_debugfd);                                 \
}
#else
#define QMP_DEBUG(level,args...)                            \
   if (qmp_debug_level & (level)) {                         \
       QMP_fprintf(stderr,##args);                          \
       fflush(stderr);                                      \
}
#endif

void QMP_DUMP_IDATA_PACKET (QMP_idata_packet_t* packet);
void QMP_DUMP_PACKET (QMP_packet_t* packet);
void QMP_DUMP_REQUEST (QMP_request_t* request);
#endif


/**
 * Get and set error code macros.
 */
#define QMP_SET_STATUS_CODE(glm,code) (glm->err_code = code)

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Some utility functions used inside implementations.
 */
extern void QMP_add_viacq (QMP_machine_t* glm, VIP_CQ_HANDLE cq);

extern void QMP_remove_viacq (QMP_machine_t* glm, VIP_CQ_HANDLE cq);

extern void* QMP_memalign (QMP_u32_t size, QMP_u32_t alignment);

extern QMP_status_t QMP_init_req_free_list (QMP_machine_t* glm);

extern QMP_status_t QMP_init_msghandle_free_list (QMP_machine_t* glm);

extern QMP_status_t QMP_create_rtenv_nodes (QMP_rtenv_t* rt, QMP_u32_t num);

extern void QMP_delete_rtenv_nodes (QMP_rtenv_t* rt);

extern QMP_status_t QMP_create_rtenv_swtable (QMP_rtenv_t* rt, QMP_u32_t num);

extern void QMP_delete_rtenv_swtable (QMP_rtenv_t* rt);

extern QMP_status_t QMP_insert_rtenv_swtable (QMP_rtenv_t* rt, char* line, int idx);

extern void QMP_remember_free_list (QMP_machine_t* glm, void* free_list);

extern void QMP_cleanup_free_lists (QMP_machine_t* glm);

extern QMP_phys_geometry_t *QMP_create_phys_geometry (void);

extern void QMP_delete_phys_geometry (QMP_phys_geometry_t* phys);

extern QMP_status_t QMP_create_switched_ports (QMP_phys_geometry_t* phys,
					       QMP_u32_t num_ports);

extern void QMP_init_phys_geometry (QMP_phys_geometry_t* phys, char* host);

extern void QMP_calc_node_coordinates (QMP_u32_t  rank,
				       QMP_u32_t* dim_sizes,
				       QMP_u32_t dim,
				       QMP_u32_t coordinates[]);

extern QMP_u32_t QMP_calc_node_rank (QMP_u32_t* coordinates, 
				     QMP_u32_t* dim_sizes,
				     QMP_u32_t dim);

extern QMP_status_t QMP_setup_gige_port (char* line, 
					 QMP_phys_geometry_t* phys,
					 QMP_rtenv_t* rt);

extern QMP_status_t QMP_update_port_peer_info (QMP_machine_t* glm, 
					       QMP_phys_geometry_t* phys,
					       QMP_rtenv_t* rtenv, 
					       QMP_u32_t num);

extern void QMP_init_gige_port (QMP_gige_port_t* gige);

extern QMP_bool_t QMP_coordinates_equal (QMP_u32_t* coord1,
					 QMP_u32_t* coord2, 
					 QMP_u32_t dim);

extern void QMP_delete_topology (QMP_topology_t* tpl);

extern QMP_gige_port_t * QMP_get_connection_port (QMP_machine_t* glm, 
						  QMP_u16_t dest, 
						  QMP_s16_t direction,
						  QMP_mh_type_t type);

extern QMP_bool_t QMP_has_unique_connection (QMP_machine_t* glm, 
					     QMP_u16_t dest,
					     QMP_mh_type_t type);

extern QMP_bool_t QMP_are_neighbors (QMP_machine_t* glm, 
				     QMP_u32_t node1, QMP_u32_t node2);

extern QMP_status_t QMP_set_routing_path (QMP_machine_t* glm,
					  QMP_u32_t src, QMP_u32_t dest,
					  QMP_u32_t path[], 
					  QMP_u32_t* num_steps);


extern QMP_u32_t QMP_logical_to_allocated (QMP_u32_t logic_rank);

extern QMP_u32_t QMP_allocated_to_logical (QMP_u32_t node);

extern void QMP_print_topology (QMP_topology_t* tpl);

extern void QMP_print_rtenv (QMP_rtenv_t* rtenv);

extern char* QMP_get_allocated_hostname (QMP_machine_t* glm, QMP_u16_t rank);

extern void QMP_print_port_info (QMP_gige_port_t* port);

extern QMP_u16_t QMP_get_send_tag (QMP_gige_port_t* port,
				   QMP_msghandle_i_t* mh);

extern QMP_u16_t QMP_get_recv_tag (QMP_gige_port_t* port,
				   QMP_msghandle_i_t* mh);

extern void QMP_print_machine_info (QMP_machine_t* glm);

extern QMP_status_t QMP_open_viadev (QMP_machine_t* glm);

extern void QMP_close_viadev (QMP_machine_t* glm);

extern QMP_status_t QMP_close_via_connections (QMP_machine_t* glm);

extern QMP_status_t QMP_open_connections_to_neighbors (QMP_machine_t* glm);

extern QMP_status_t QMP_open_via_switch_port (QMP_machine_t* glm,
					      QMP_gige_port_t* port);

extern void QMP_set_qbuf_sendrecv_ready (QMP_qbuf_t* qbuf, QMP_u32_t len);

extern void QMP_set_qbuf_rdmaw_ready (QMP_qbuf_t* qbuf, 
				      void* local_addr, 
				      VIP_MEM_HANDLE local_memh,
				      void* remote_addr, 
				      VIP_MEM_HANDLE remote_memh,
				      QMP_u32_t len,
				      QMP_u32_t idata);


extern QMP_status_t QMP_qbuf_post_send (QMP_machine_t* glm,
					QMP_gige_port_t* port,
					QMP_qbuf_t* qbuf,
					QMP_bool_t rdma_send);

extern QMP_status_t QMP_qbuf_post_recv (QMP_machine_t* glm,
					QMP_gige_port_t* port,
					QMP_qbuf_t* qbuf);

extern void QMP_regmem_table_init (QMP_machine_t* glm, 
				   QMP_viadev_handle_t* viadev,
				   QMP_regmem_table_t* table);

extern void QMP_regmem_table_clean (QMP_viadev_handle_t* viadev);


extern QMP_regmem_entry_t * QMP_regmem_register (QMP_machine_t* glm,
						 QMP_regmem_table_t* table,
						 void* buf, QMP_u32_t len);

extern void QMP_regmem_complete_remove (QMP_machine_t* glm, 
					QMP_gige_port_t* port,
					void* buf, QMP_u32_t len);

extern void QMP_regmem_remove_from_all (QMP_machine_t* glm,
					void* buf, QMP_u32_t len);

extern QMP_status_t QMP_init_qbuf_manager (QMP_viadev_handle_t* h,
					   QMP_qbuf_manager_t* manager,
					   QMP_mh_type_t type,
					   QMP_gige_conn_type_t conn_type);

extern void QMP_finalize_qbuf_manager (QMP_viadev_handle_t* h,
				       QMP_qbuf_manager_t* manager);

extern QMP_qbuf_t* QMP_get_qbuf (QMP_qbuf_manager_t* manager);

extern void QMP_release_qbuf (QMP_qbuf_manager_t* manager,
			      QMP_qbuf_t* qbuf);

extern QMP_status_t QMP_isend (void* buf, QMP_u32_t count, 
			       QMP_datatype_t datatype,
			       QMP_u16_t dest, QMP_u16_t tag, 
			       QMP_s16_t direction,
			       QMP_machine_t* glm,
			       QMP_request_t** request);

extern QMP_status_t QMP_irecv (void* buf, QMP_u32_t count, 
			       QMP_datatype_t datatype,
			       QMP_u16_t src, QMP_u16_t tag, 
			       QMP_s16_t direction,
			       QMP_machine_t* glm, QMP_request_t** request);

extern QMP_bool_t QMP_request_complete (QMP_machine_t* glm, 
					QMP_request_t *request);

extern void QMP_request_wait (QMP_machine_t* glm, QMP_request_t *request);

extern void QMP_request_done (QMP_machine_t* glm,
			      QMP_request_t* request);

extern QMP_status_t QMP_recv  (void* buf, QMP_u32_t count, 
			       QMP_datatype_t datatype,
			       QMP_u16_t src, QMP_u16_t tag,
			       QMP_s16_t direction);

extern QMP_status_t QMP_send  (void* buf, QMP_u32_t count, 
			       QMP_datatype_t datatype,
			       QMP_u16_t dest, QMP_u16_t tag,
			       QMP_s16_t direction);

extern QMP_status_t QMP_isend_nodata (QMP_u16_t dest, QMP_u16_t protocol,
				      QMP_u32_t sendid, QMP_u32_t recvid,
				      QMP_gige_port_t *port, 
				      QMP_machine_t* glm);

#if __GNUC__ == 3 &&__GNUC_MINOR__ >= 4
extern QMP_status_t QMP_poll (QMP_machine_t* glm, QMP_gige_port_t* myport) __attribute__ ((noinline));
#else
extern inline QMP_status_t QMP_poll (QMP_machine_t* glm, QMP_gige_port_t* myport);
#endif

/**
 * Application vi data set and retrieve
 */
extern QMP_status_t QMP_mvia_set_vi_app_data (VIP_VI_HANDLE vi, void* data);
extern QMP_status_t QMP_mvia_get_vi_app_data (VIP_VI_HANDLE vi, void** data);

/**
 * A non-portable function
 */
extern QMP_u32_t QMP_number_posted_bufs (VIP_VI_HANDLE vi);


/**
 * Some of socket initialize routine
 */
extern QMP_status_t QMP_init_root_socket (QMP_machine_t* glm);
extern QMP_status_t QMP_init_socket (QMP_machine_t* glm);
extern void QMP_finalize_root_socket (QMP_machine_t* glm);
extern void QMP_finalize_socket (QMP_machine_t* glm);

/**
 * Report QMP error and exit
 */
extern void QMP_error_exit (const char* format, ...);

extern QMP_bool_t QMP_array_contains (QMP_u32_t* array1, QMP_u32_t size1,
				      QMP_u32_t* array2, QMP_u32_t size2);

#ifdef __cplusplus
}
#endif


#endif
