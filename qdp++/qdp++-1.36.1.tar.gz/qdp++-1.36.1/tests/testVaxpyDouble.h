#ifndef TEST_VAXPY3
#define TEST_VAXPY3


#ifndef UNITTEST_H
#include "unittest.h"
#endif


class testVaxpy4_1 : public TestFixture { public: void run(void); };
class testVaxpy4_2 : public TestFixture { public: void run(void); };
class testVaxpy4_3 : public TestFixture { public: void run(void); };

class testVaxpy4_RB0_1 : public TestFixture { public: void run(void); };
class testVaxpy4_RB0_2 : public TestFixture { public: void run(void); };
class testVaxpy4_RB0_3 : public TestFixture { public: void run(void); };

class testVaxpy4_RB1_1 : public TestFixture { public: void run(void); };
class testVaxpy4_RB1_2 : public TestFixture { public: void run(void); };
class testVaxpy4_RB1_3 : public TestFixture { public: void run(void); };

class testVaxpy4_RB30_1 : public TestFixture { public: void run(void); };
class testVaxpy4_RB30_2 : public TestFixture { public: void run(void); };
class testVaxpy4_RB30_3 : public TestFixture { public: void run(void); };

class testVaxpy4_RB31_1 : public TestFixture { public: void run(void); };
class testVaxpy4_RB31_2 : public TestFixture { public: void run(void); };
class testVaxpy4_RB31_3 : public TestFixture { public: void run(void); };

class testVaxpy4_RB0_PEQ_1: public TestFixture { public: void run(void); };
class testVaxpy4_RB0_PEQ_2 : public TestFixture { public: void run(void); };
class testVaxpy4_RB0_PEQ_3 : public TestFixture { public: void run(void); };
class testVaxpy4_RB30_PEQ : public TestFixture { public: void run(void); };



#endif
