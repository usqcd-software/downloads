#ifndef TEST_VAXPBY
#define TEST_VAXPBY


#ifndef UNITTEST_H
#include "unittest.h"
#endif


class testVaxpbyz4_1 : public TestFixture { public: void run(void); };
class testVaxpbyz4_2 : public TestFixture { public: void run(void); };
class testVaxpbyz4_3 : public TestFixture { public: void run(void); };

class testVaxpby4_1 : public TestFixture { public: void run(void); };
class testVaxpby4_2 : public TestFixture { public: void run(void); };
class testVaxpby4_3 : public TestFixture { public: void run(void); };

class testVaxmbyz4_1 : public TestFixture { public: void run(void); };
class testVaxmbyz4_2 : public TestFixture { public: void run(void); };
class testVaxmbyz4_3 : public TestFixture { public: void run(void); };

class testVaxmby4_1 : public TestFixture { public: void run(void); };
class testVaxmby4_2 : public TestFixture { public: void run(void); };
class testVaxmby4_3 : public TestFixture { public: void run(void); };



#endif
