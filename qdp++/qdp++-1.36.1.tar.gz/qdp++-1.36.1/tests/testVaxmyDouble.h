#ifndef TEST_VAXMY
#define TEST_VAXMY


#ifndef UNITTEST_H
#include "unittest.h"
#endif


class testVaxmyz4_1 : public TestFixture { public: void run(void); };
class testVaxmyz4_2 : public TestFixture { public: void run(void); };
class testVaxmyz4_3 : public TestFixture { public: void run(void); };

class testVaxmy4_1 : public TestFixture { public: void run(void); };
class testVaxmy4_2 : public TestFixture { public: void run(void); };
class testVaxmy4_3 : public TestFixture { public: void run(void); };



#endif
