// $Id: propagator.cc,v 1.1 2004/08/04 01:41:11 edwards Exp $
/*! \file
 *  \brief Main code for propagator generation
 */

#include <iostream>
#include <cstdio>

#include "qdp.h"
#include "qdp_util.h"
#include "propagator.h"

using namespace QDP;

int main(int argc, char **argv)
{
  // Put the machine into a known state
  QDP_initialize(&argc, &argv);

  // Setup the layout
  const int foo[] = {2,2,2,4};
  multi1d<int> nrow(Nd);
  nrow = foo;  // Use only Nd elements
  Layout::setLattSize(nrow);
  Layout::create();

  // Useful parameters that should be read from an input file
  int j_decay = Nd-1;
  multi1d<int> t_source(Nd);
  t_source = 0;

  Real wvf_param = 1.1;  // smearing width
  int  WvfIntPar = 10;   // number of hits for smearing

  Real Kappa = 0.1;
  Real RsdCG = 1.0e-5;
  int  MaxCG = 500;

  // Generate a hot start gauge field
  multi1d<LatticeColorMatrix> u(Nd);
  for(int mu=0; mu < u.size(); ++mu)
  {
    gaussian(u[mu]);
    reunit(u[mu]);
  }

  // Useful info
  XMLFileWriter xml("propagator.xml");
  push(xml,"propagator");

  push(xml,"lattice");
  write(xml,"Nd",Nd);
  write(xml,"Nc",Nc);
  write(xml,"Ns",Ns);
  write(xml,"nrow",nrow);
  pop(xml);

  //
  // Loop over the source color and spin, creating the source
  // and calling the relevant propagator routines. The QDP
  // terminology is that a propagator is a matrix in color
  // and spin space
  //
  // For this calculation, a smeared source is used. A point
  // source is first constructed and then smeared. If a user
  // only wanted a point source, then remove the smearing stuff
  //
  LatticePropagator quark_propagator;
  int ncg_had = 0;

  for(int color_source = 0; color_source < Nc; ++color_source)
  {
    if (Layout::primaryNode())
      cerr << "color = " << color_source << endl;

    LatticeColorVector src_color_vec = zero;

    // Make a point source at coordinates t_source
    srcfil(src_color_vec, t_source, color_source);

    // Smear the color source
    gausSmear(u, src_color_vec, wvf_param, WvfIntPar, j_decay);

    for(int spin_source = 0; spin_source < Ns; ++spin_source)
    {
      if (Layout::primaryNode())
        cerr << "spin = " << spin_source << endl;

      // Insert a ColorVector into spin index spin_source
      // This only overwrites sections, so need to initialize first
      LatticeFermion chi = zero;
      CvToFerm(src_color_vec, chi, spin_source);

      // primitive initial guess for the linear sys solution
      LatticeFermion psi = zero;  // note this is ``zero'' and not 0

      // Compute the propagator for given source color/spin.
      int n_count;
      NPQprop(u, chi, Kappa, RsdCG, psi, MaxCG, n_count);
      ncg_had += n_count;
	  
      /*
       *  Move the solution to the appropriate components
       *  of quark propagator.
       */
      FermToProp(psi, quark_propagator, color_source, spin_source);
    }
  }

  // Compute simple meson spectroscopy
  int length = Layout::lattSize()[j_decay]; // Define the temporal direction
  multi1d< multi1d<Real> > meson_prop;
  mesons(quark_propagator, quark_propagator, meson_prop, t_source, j_decay);

  push(xml,"wilson_meson_spectoscopy");
  write(xml,"meson_prop",meson_prop);
  pop(xml);

  pop(xml);

  // Close
  xml.close();

  // Time to bolt
  QDP_finalize();

  return 0;
}
