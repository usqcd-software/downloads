// -*- C++ -*-
// $Id: demo.h,v 1.1 2004/08/04 01:41:10 edwards Exp $

/*! \file
 *  \brief Include file for demonstration suite
 */

#include "qdp.h"

using namespace QDP;

#define START_CODE(a)
#define END_CODE(a)

#define PLUS 1
#define MINUS -1

enum Reunitarize {REUNITARIZE, REUNITARIZE_ERROR, REUNITARIZE_LABEL};


void reunit(LatticeColorMatrix& xa);
void reunit(LatticeColorMatrix& xa, LatticeBoolean& bad, int& numbad, enum Reunitarize ruflag);

void srcfil(LatticeFermion& a, multi1d<int>& coord, int color_index, int spin_index);
void srcfil(LatticeColorVector& a, multi1d<int>& coord, int color_index);

void gausSmear(const multi1d<LatticeColorMatrix>& u, 
	       LatticeColorVector& chi, 
	       const Real& width, int ItrGaus, int j_decay);

void CvToFerm(const LatticeColorVector& a, LatticeFermion& b, 
	      int spin_index);

void FermToProp(const LatticeFermion& a, LatticePropagator& b, 
		int color_index, int spin_index);

void PropToFerm(const LatticePropagator& b, LatticeFermion& a, 
		int color_index, int spin_index);

void NPQprop(const multi1d<LatticeColorMatrix>& u, 
	     const LatticeFermion& chi, 
	     const Real& Kappa, const Real& RsdCG, LatticeFermion& psi, int MaxCG, int& ncg_had);

void klein_gord(const multi1d<LatticeColorMatrix>& u, 
		const LatticeColorVector& psi, 
		LatticeColorVector& chi, 
		const Real& mass_sq, int j_decay);

void WlInvCG(const multi1d<LatticeColorMatrix>& u, 
	     const LatticeFermion& chi,
	     LatticeFermion& psi,
	     const Real& Kappa,
	     const Real& RsdCG, 
	     int MaxCG, int& n_count);

void WilsonDirac(const multi1d<LatticeColorMatrix>& u, 
		 const LatticeFermion& psi, 
		 const Real& Kappa,
		 LatticeFermion& chi,
		 int isign);

void mesons(const LatticePropagator& quark_prop_1, const LatticePropagator& quark_prop_2, 
	    multi1d< multi1d<Real> >& meson_propagator, 
	    const multi1d<int>& t_source, int j_decay);

void readSzin(multi1d<LatticeColorMatrix>& u, const string& cfg_file, Seed& seed_old);

void readSzinQprop(LatticePropagator& q, const string& file);
