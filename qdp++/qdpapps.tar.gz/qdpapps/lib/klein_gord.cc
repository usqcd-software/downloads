// $Id: klein_gord.cc,v 1.1 2004/08/04 01:41:10 edwards Exp $
/*! \file
 *  \brief Apply Klein-Gordon operator
 */

#include "qdp.h"

using namespace QDP;

//! Compute the covariant Klein-Gordon operator
/*!
 *  For 0 <= j_decay < Nd, the laplacian is only taken in the directions
 * other than j_decay.
 *
 *  Chi  :=  (mass_sq + 2*(Nd[-1]) * Psi -
 *           sum_{mu ne j_decay} [ U_mu(x) * Psi(x+mu) +
 *                                 U^dagger_mu(x-mu) * Psi(x-mu) ]  
 *
 *
 * Arguments:
 *
 *  \param u          Gauge field               (Read)
 *  \param psi        Color vector field        (Read)
 *  \param chi        Color vector field        (Write)
 *  \param mass_sq    square of the mass term   (Read)
 *  \param j_decay    'left out' direction      (Read) 
 */

void klein_gord(const multi1d<LatticeColorMatrix>& u, 
		const LatticeColorVector& psi, 
		LatticeColorVector& chi, 
		const Real& mass_sq, int j_decay)
{
  Real ftmp;

  if( j_decay < Nd )
    ftmp = Real(2*Nd-2) + mass_sq;
  else
    ftmp = Real(2*Nd) + mass_sq;

  chi = psi * ftmp;

  for(int mu = 0; mu < Nd; ++mu )
    if( mu != j_decay )
    {
      chi -= u[mu]*shift(psi, FORWARD, mu) + shift(adj(u[mu])*psi, BACKWARD, mu);
    }
}

