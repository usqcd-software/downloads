// $Id: wlinvcg_w.cc,v 1.1 2004/08/04 01:41:11 edwards Exp $
/*! \file
 *  \brief Conjugate-Gradient operator for the Wilson-Dirac operator
 */

//! Conjugate-Gradient operator for the Wilson-Dirac operator
/* This subroutine uses the Conjugate Gradient (CG) algorithm to find
 * the solution of the set of linear equations
 *
 *   	    Chi  =  A . Psi
 *
 * Algorithm:

 *  Psi[0]  :=  initial ;    	               Linear interpolation (argument)
 *  r[0]    :=  Chi  -  A . Psi[0] ;   	       Initial residual
 *  p[1]    :=  r[0] ;	       	       	       Initial direction
 *  IF |r[0]| <= RsdCG |Chi| THEN RETURN;      Converged?
 *  FOR k FROM 1 TO MaxCG DO    	       CG iterations
 *      a[k] := |r[k-1]|**2 / <p[k],Ap[k]> ;
 *      Psi[k] += a[k] p[k] ;   	       New solution vector
 *      r[k] -= a[k] A . p[k] ; 	       New residual
 *      IF |r[k]| <= RsdCG |Chi| THEN RETURN;  Converged?
 *      b[k+1] := |r[k]|**2 / |r[k-1]|**2 ;
 *      p[k+1] := r[k] + b[k+1] p[k];          New direction
 *
 * Arguments:
 *
 *  \param u       Gauge Field	    	       (Read)
 *  \param chi     Pseudofermion Source	       (Read)
 *  \param psi     Solution    	    	       (Modify)
 *  \param Kappa   Hopping parameter           (Read)
 *  \param RsdCG   CG residual accuracy        (Read)
 *  \param MaxCG   Maximum CG iterations       (Read)
 *  \param n_count Number of CG iteration      (Write)
 *
 * Local Variables:
 *
 *  p   	       Direction vector
 *  r   	       Residual vector
 *  cp  	       | r[k] |**2
 *  c   	       | r[k-1] |**2
 *  k   	       CG iteration counter
 *  a   	       a[k]
 *  b   	       b[k+1]
 *  d   	       < p[k], A.p[k] >
 *  R_Aux              Temporary for  M.Psi
 *  Mp  	       Temporary for  M.p
 *  MMp 	       Temporary for  A.p
 *
 * Subroutines:
 *                             +               
 *  WilsonDirac  Apply matrix M or M  to vector
 *
 * Operations:
 *
 *  2 A + 2 Nc Ns + N_Count ( 2 WilsonDirac + 10 Nc Ns )
 */

#include "qdp.h"
#include "demo.h"

using namespace QDP;

void WlInvCG(const multi1d<LatticeColorMatrix>& u, 
	     const LatticeFermion& chi,
	     LatticeFermion& psi,
	     const Real& Kappa,
	     const Real& RsdCG, 
	     int MaxCG, 
	     int& n_count)
{
  LatticeFermion p;
  LatticeFermion r;
  LatticeFermion r_aux;

  LatticeFermion mmp;
  LatticeFermion mp;
  Real a;
  Real b;
  Double c;
  Double d;
  Double cp;
  
  Real rsd_sq = (RsdCG * RsdCG) * Real(norm2(chi));

  //                                            +
  //  r[0]  :=  Chi - A . Psi[0]    where  A = M  . M
    
  //  r_Aux  :=  M(U) . Psi
  WilsonDirac(u, psi, Kappa, r_aux, PLUS);

  //           +                +
  //  r  :=  M(u)  . r_Aux  =  M  . M . Psi
  WilsonDirac(u, r_aux, Kappa, r, MINUS);

  //      	       	       	           +
  //  r  :=  ( Chi - R )  =  [ Chi  -  M(u)  . M(u) . psi ]
  
  r = chi - r;  	       	   /* Nc Ns  flops */
  //  p[1]  :=  r[0]
  p = r;
  
  //  Cp = |r[0]|^2
  cp = norm2(r);   	       	   /* 2 Nc Ns  flops */

  if (Layout::primaryNode())
    cerr << "WlInvCG: k = 0  cp = " << cp << "  rsd_sq = " << rsd_sq << endl;

  //  IF |r[0]| <= RsdCG |Chi| THEN RETURN;
  if ( toBool(cp  <=  rsd_sq) )
  {
    n_count = 0;
    return;
  }

  //
  //  FOR k FROM 1 TO MaxCG DO
  //
  for(int k = 1; k <= MaxCG; ++k)
  {
    //  c  =  | r[k-1] |**2
    c = cp;

    //  a[k] := | r[k-1] |**2 / < p[k], Ap[k] > ;
    //                                            +
    //  First compute  d  =  < p, A.p >  =  < p, M . M . p >  =  < M.p, M.p >
    //  Mp = M(u) * p
    WilsonDirac(u, p, Kappa, mp, PLUS);

    //  d = | mp | ** 2
    d = norm2(mp);	/* 2 Nc Ns  flops */

    a = Real(c)/Real(d);

    //  Psi[k] += a[k] p[k]
    psi += a * p;	/* 2 Nc Ns  flops */

    //  r[k] -= a[k] A . p[k] ;
    //              +           +
    //  Mmp  =  M(u)  . Mp  =  M  . M . p  =  A . p
    WilsonDirac(u, mp, Kappa, mmp, MINUS);

    //  r  =  r  -  a . mmp
    r -= a * mmp;	/* 2 Nc Ns  flops */

    //  IF |r[k]| <= RsdCG |Chi| THEN RETURN;

    //  cp  =  | r[k] |**2
    cp = norm2(r);	                /* 2 Nc Ns  flops */

    if (Layout::primaryNode())
      cerr << "WlInvCG: k = " << k << "  cp = " << cp << endl;

    if ( toBool(cp  <=  rsd_sq) )
    {
      n_count = k;
      return;
    }

    //  b[k+1] := |r[k]|**2 / |r[k-1]|**2
    b = Real(cp) / Real(c);

    //  p[k+1] := r[k] + b[k+1] p[k]
    p = r + b*p;	/* Nc Ns  flops */
  }
  n_count = MaxCG;
  QDP_error_exit("too many CG iterations: count = %d", n_count);
}
