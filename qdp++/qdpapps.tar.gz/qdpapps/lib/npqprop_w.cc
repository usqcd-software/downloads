// $Id: npqprop_w.cc,v 1.1 2004/08/04 01:41:10 edwards Exp $
/*! \file
 *  \brief Solve for Wilson-Dirac propagator (actually fermion)
 */

#include "qdp.h"
#include "demo.h"

using namespace QDP;

//! Non-preconditioned Wilson-Dirac quark solver
/*!
 * This routine is actually generic to all non-preconditioned (not red/black) fermions
 *
 * Compute the lattice fermion for a generic non-red/black fermion
 * using the source in "chi" - so, the source can
 * be of any desired form. The result will appear in "psi", which on input
 * contains an initial guess for the solution.

 * \param u        gauge field ( Read )
 * \param chi      source ( Read )
 * \param Kappa    unmodified Kappa (no u0 or whatever) ( Read )
 * \param RsdCG    CG (really MR) residual used here ( Read )
 * \param psi      quark propagator ( Modify )
 * \param ncg_had  number of CG iterations ( Write )
 */

void NPQprop(const multi1d<LatticeColorMatrix>& u, 
	     const LatticeFermion& chi, 
	     const Real& Kappa, const Real& RsdCG, LatticeFermion& psi, int MaxCG, int& ncg_had)
{
  LatticeFermion tmp1;
  
  // tmp1 = M_dag(u) * chi
  WilsonDirac(u, chi, Kappa, tmp1, MINUS);

  // psi = (M^dag * M)^(-1) chi
  WlInvCG(u, tmp1, psi, Kappa, RsdCG, MaxCG, ncg_had);
  
  if ( ncg_had == MaxCG )
    QDP_error_exit("no convergence in the inverter", ncg_had);
}
