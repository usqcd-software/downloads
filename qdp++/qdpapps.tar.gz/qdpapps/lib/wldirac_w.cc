// $Id: wldirac_w.cc,v 1.1 2004/08/04 01:41:11 edwards Exp $
/*! \file
 *  \brief Wilson-Dirac operator
 */

#include "qdp.h"
#include "demo.h"

using namespace QDP;

//! General Wilson-Dirac dslash
/*!
 * DSLASH
 *
 * This routine is specific to Wilson fermions!
 *
 * Description:
 *
 * This routine applies the operator D' to Psi, putting the result in Chi.
 *
 *	             Nd-1
 *	             ---
 *	             \
 * chi(x):= psi(x) -  >  U  (x) (1 - isign gamma  ) psi(x+mu)
 *	             /    mu			  mu
 *	             ---
 *	             mu=0
 *
 *	             Nd-1
 *	             ---
 *	             \    +
 *                -   >  U  (x-mu) (1 + isign gamma  ) psi(x-mu)
 *	             /    mu			   mu
 *	             ---
 *	             mu=0
 *
 * Arguments:
 *
 *  \param u	      Gauge field					(Read)
 *  \param psi	      Pseudofermion field				(Read)
 *  \param Kappa      Surprise, it is kappa 			        (Read) 
 *  \param chi	      Pseudofermion field				(Write)
 *  \param isign      D' or D'^dag  ( +1 | -1 ) respectively		(Read)
 */

void WilsonDirac(const multi1d<LatticeColorMatrix>& u, 
		 const LatticeFermion& psi, 
		 const Real& Kappa,
		 LatticeFermion& chi,
		 int isign)
{
  // NOTE: the loop is not unrolled - it should be all in a single line for
  // optimal performance
  chi = psi;

  // NOTE: temporarily has conversion call of LatticeHalfFermion - will be removed
  for(int mu = 0; mu < Nd; ++mu)
  {
    chi -= Kappa*(spinReconstruct(LatticeHalfFermion(u[mu] * shift(spinProject(psi,mu,-isign), FORWARD, mu)),mu,-isign)
                + spinReconstruct(LatticeHalfFermion(shift(adj(u[mu]) * spinProject(psi,mu,+isign), BACKWARD, mu)),mu,+isign));
  }
}


