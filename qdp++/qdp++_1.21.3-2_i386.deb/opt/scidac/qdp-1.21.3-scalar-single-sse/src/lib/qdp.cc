// $Id: qdp.cc,v 1.8 2003/03/28 05:17:10 edwards Exp $
//
// QDP data parallel interface
//

#include "qdp.h"

QDP_BEGIN_NAMESPACE(QDP);

// Currently empty

QDP_END_NAMESPACE();
