#ifndef ARRAY_TYPE_H
#define ARRAY_TYPE_H

namespace XMLStructWriterAPI {
enum ArrayType { SIMPLE_INT, SIMPLE_FLOAT, SIMPLE_BOOL, SIMPLE_STRING, STRUCT};
};

#endif
