#ifndef LIME_FIXED_TYPES_H
#define LIME_FIXED_TYPES_H

#include <stdint.h>

/* Should be CONFIG'd */
typedef uint64_t  n_uint64_t;
typedef uint32_t  n_uint32_t;
typedef uint16_t  n_uint16_t;

#endif
