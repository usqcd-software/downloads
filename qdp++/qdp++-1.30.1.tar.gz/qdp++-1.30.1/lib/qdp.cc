// $Id: qdp.cc,v 1.11 2008/06/27 13:31:22 bjoo Exp $
//
// QDP data parallel interface
//

#include "qdp.h"

namespace QDP {

// Currently empty

} // namespace QDP;
