// $Id: qdp.cc,v 1.9 2007/06/10 14:32:11 edwards Exp $
//
// QDP data parallel interface
//

#include "qdp.h"

namespace QDP {

// Currently empty

} // namespace QDP;
