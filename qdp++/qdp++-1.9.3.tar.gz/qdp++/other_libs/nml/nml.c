/* $Id: nml.c,v 1.17 2004/05/05 14:37:04 bjoo Exp $ */

/* Support routines for manipulating NML input */

#undef DEBUG

#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include "nml.h"
#include "qcd-nml.h"

#define NML_FILE 1
#define NML_ARG  2

int yyparse(void);

/* the parsed file */
section *abstract;
section *lastgrp;
int secnum;

/* the stack used possibly for sections */
static section *section_stack;

/****************************************************************************
 *                              abort                                       *
 ****************************************************************************/
void parse_abort(char *fmt, ...)
{
  va_list v;

  va_start(v,fmt);
  vfprintf(stderr, fmt, v);
  fprintf(stderr, "\n");
  va_end(v);

  exit(1);
}

/****************************************************************************
 *                     abstract tree management                             *
 ****************************************************************************/

#if 0
static int chkres_eq(const resource *r, int k)
{
  return ((r->type & k) == k) ? 1 : 0;
}
#endif

static int chkres_any(const resource *r, int k)
{
  return ((r->type & k) != 0) ? 1 : 0;
}

char *mk_string(const char *value, int len)
{
  char *s = malloc(len + 1);
  if (s != 0) 
  {
    strncpy(s, value, len);
    s[len] = 0;
  }
  return s;
}

node *mk_node(char *value)
{
  node *r = malloc(sizeof(node));
  if (r != 0) 
  {
    r->type = -1;
    r->num = 0;
    r->val = value;
    r->next = 0;
    r->slist = 0;
  }
  return r;
}

node *mk_complex_node(node *re_value, node *im_value)
{
  node *r = malloc(sizeof(node));
  if (r != 0) 
  {
    r->val = 0;
    r->next = 0;
    r->slist = re_value;
    r->slist->next = im_value;
  }
  return r;
}

resource *mk_resource(node *key, node *value)
{
  resource *r = malloc(sizeof(resource));
  if (r != 0) 
  {
    r->key = key;
    r->type = 0;
    r->dim = 0;
    r->num = 0;
    r->value = value;
    r->next = 0;
  }
  return r;
}

section *mk_section(char *name)
{
  section *s = malloc(sizeof(section));
  if (s != 0) 
  {
    s->secnum = secnum++;
    s->next = 0;
    s->sslist = 0;
    s->up = 0;
    s->rlist = 0;
    s->name = name;
  }
  return s;
}

void rm_string(char *s)
{
  if (s != 0)
    free(s);
}

void rm_node(node *r)
{
  while (r != 0) 
  {
    node *t = r->next;
    rm_node(r->slist);
    rm_string(r->val);
    free(r);
    r = t;
  }
}

static void rm_resource(resource *r)
{
  while (r != 0) 
  {
    resource *t = r->next;
    rm_node(r->key);
    rm_node(r->value);
    free(r);
    r = t;
  }
}

static void rm_section(section *s)
{
  while (s != 0) 
  {
    section *t = s->next;
    rm_section(s->sslist);
    rm_resource(s->rlist);
    rm_string(s->name);
    free(s);
    s = t;
  }
}

void print_node(FILE *f, const node *n)
{
  if (f != 0 && n != 0) 
  {
    if ((n->type & VT_COMPLEX) != 0)
    {
      fprintf(f,"[ %s , %s ]",n->slist->val, n->slist->next->val);
    }
    else if ((n->type & VT_NUMBER) != 0)
    {
      fprintf(f,"%s",n->val);
    }
    else if ((n->type & VT_STRING) != 0)
    {
      fprintf(f,"\"%s\"",n->val);
    }
  }
}

void print_resource(FILE *f, const resource *r)
{
  if (f != 0 && r != 0) 
  {
    /* First print key */
    if (chkres_any(r, VT_SCALAR))
    {
      fprintf(f,"%s",r->key->val);
    }
    else if (chkres_any(r, VT_ARRAY))
    {
      fprintf(f,"%s",r->key->val);
    }
    else if (chkres_any(r, VT_ELEM))
    {
      node *k = r->key->next;

      fprintf(f,"%s( %s",r->key->val, k->val);
      for(k=k->next; k; k=k->next)
	fprintf(f," , %s",k->val);
      fprintf(f," )");
    }

    fprintf(f," = ");

    /* Print value */
    if (chkres_any(r, VT_SCALAR | VT_ELEM))
    {
      print_node(f, r->value);
    }
    else if (chkres_any(r, VT_ARRAY))
    {
      node *v = r->value;

      fprintf(f,"( ");
      print_node(f, v);
      for(v=v->next; v; v=v->next)
      {
	fprintf(f," , ");
	print_node(f, v);
      }
      fprintf(f," )");
    }

    fprintf(f," ,\n");
  }
}

void print_section(FILE *f, const section *ss)
{
  section *s;
  resource *r;

  if (f != 0 && ss != 0) 
  {
    if (ss->name != 0)
      fprintf(f,"&%s\t; secnum = %d\n",ss->name,ss->secnum);

    for(r=ss->rlist; r; r=r->next)
      print_resource(f,r);

    for(s=ss->sslist; s; s=s->next)
      print_section(f,s);

    if (ss->name != 0)
      fprintf(f,"&END\n");
  }
}

/****************************************************************************
 *                             the parser                                   *
 ****************************************************************************/

void add_resource(section *ss, resource *rn)
{
  resource *r, *prev;

  if (ss == 0)
    return;

  if (ss->rlist == 0)
  {
    ss->rlist = rn;
    return;
  }

  if (rn == 0)
    return;

  /* Check for redefinitions. If a redefinition, will eventually unlink. */
  for (r = ss->rlist, prev=r; r; prev=r, r = r->next)
  {
    if (chkres_any(r, VT_SCALAR) && chkres_any(rn, VT_SCALAR))
    {
      /* Both scalar, Only need to check the name */
      /* Eventually unlink if match */
      if (!strcmp(r->key->val, rn->key->val))
      {
	parse_abort("scalar resource %s was defined as a scalar at line %d", 
		    r->key->val, r->line);
	assert(0);
      }
    } 
    else if (chkres_any(r, VT_SCALAR) && chkres_any(rn, VT_ARRAY | VT_ELEM))
    {
      /* Original is scalar and new is some kind of array */
      /* If there is a match then barf */
      if (!strcmp(r->key->val, rn->key->val))
      {
	parse_abort("scalar resource %s was redefined as array at line %d", 
		    rn->key->val, rn->line);
	assert(0);
      }
    } 
    else if (chkres_any(r, VT_ARRAY) && chkres_any(rn, VT_ELEM))
    {
      /* Original is an array and new is an array element */
      /* If there is a match then barf */
      if (!strcmp(r->key->val, rn->key->val))
      {
	parse_abort("array resource %s was redefined as array at line %d", 
		    rn->key->val, rn->line);
	assert(0);
      }
    } 
    else if (chkres_any(r, VT_ARRAY) && chkres_any(rn, VT_ARRAY))
    {
      /* Original is an array and new is an array element */
      /* Eventually unlink if match */
      if (!strcmp(r->key->val, rn->key->val))
      {
	parse_abort("array resource %s was redefined as array at line %d", 
		    rn->key->val, rn->line);
	assert(0);
      }
    } 
    else if (chkres_any(r, VT_ELEM) && chkres_any(rn, VT_ELEM))
    {
      /* Both are array elements, need to walk through */
      /* Eventually unlink if match */
      if (!strcmp(r->key->val, rn->key->val))
      {
	node *kr, *kn;
	int  foundP = 1;

	if (r->dim != rn->dim)
	{
	  parse_abort("array element %s was redefined as different dimension array element line %d", 
		      rn->key->val, rn->line);
	  assert(0);
	}

	for (kr = r->key->next, kn = rn->key->next; kr && kn; kr = kr->next, kn = kn->next)
	{
	  /* Check each index are the same */
	  if (strcmp(kr->val, kn->val))
	  {
	    foundP = 0;
	    break;
	  }
	}

	/* If all elements are the same then a match. For now barf */
	/* Eventually unlink if match */
	if (foundP == 1)
	{
	  parse_abort("resource %s was defined at line %d", (r->key)->val, r->line);
	  assert(0);
	}
      }
    }
  }

  /* Add to the end of the chain */
  prev->next = rn;
}

void add_section(section **ss, section *sn)
{
  section *s, *prev;

  if (*ss == 0)
  {
    *ss = sn;
    return;
  }

  if (sn == 0)
    return;

  /* Check for redefinitions. If a redefinition, will eventually unlink. */
  for (s = *ss, prev=s; s; prev=s, s = s->next)
  {
#ifdef DEBUG
    fprintf(stderr,"add_section: s = %s\n",s->name);
#endif

    if (!strcmp(s->name, sn->name)) 
    {
#if 1
      parse_abort("section %s was defined at line %d", s->name, s->line);
      assert(0);
#else
#ifdef DEBUG
      fprintf(stderr,"Section %s was defined at line %d", s->name, s->line);

      /* Unlink and remove */
      if (s == *ss)
	*ss = s->next;
      else
	prev->next = s->next;

      rm_section(s);
#endif
#endif
    }
  }

  /* Add to the end of the chain */
  sn->up = prev->up;
  prev->next = sn;
}

void add_subsection(section *ss, section *sn)
{
  if (ss == 0)
    return;

  sn->up = ss;
  add_section(&(ss->sslist), sn);
}

void add_node(node **nn, node *n)
{
  node *k, *prev;

  if (*nn == 0)
  {
    *nn = n;
    return;
  }

  for (k = *nn, prev=k; k; prev=k, k = k->next);
  prev->next = n;
}

/****************************************************************************
 *                         global functions                                 *
 ****************************************************************************/

/* Hook for parser to attach */
void add_abstract(section *s)
{
  add_subsection(abstract, s);
  lastgrp = s;
}

/* Initialize the abstract */
section *new_abstract(const char *name)
{
  char *nname;

  if (name != 0)
    nname = strdup(name);
  else
    nname = NULL;

  secnum = 0;
  return mk_section(nname);
}

/* Remove the abstract */
void rm_abstract(section *s)
{
  if (s == 0)
    return;

#ifdef DEBUG
  fprintf(stderr, "rm_abstract\n");
#endif

  rm_section(s);

  return;
}

/* Initialize the lexer and parser */
static int init_nml(nml_obj *nml, section *s)
{
  if (nml == 0)
  {
    fprintf(stderr, "init_nml: uninitialized object\n");
    return 1;
  }

  if (s == 0) 
  {
    fprintf(stderr, "init_nml: unitialized section\n");
    return 1;
  }

  nml->abstract = s;
  nml->lastgrp = 0;

  return 0;
}

/* Wipe out the nml object */
static void fini_nml(nml_obj *nml)
{
  if (nml == 0)
    return;

  /* Only wipe out nml object, not the abstract */
  free(nml);
}

/* Finalize a nml object */
static void fini_param(nml_obj *nml)
{
  fini_nml(nml);
  abstract = 0;
  lastgrp = 0;
  secnum = 0;
}

static int param_read_all(nml_obj *nml)
{
  int err = 0;

#ifdef DEBUG
  fprintf(stderr, "param_read_all\n");
#endif

  if (nml == 0) 
  {
    fprintf(stderr, "param_read_all: uninitialized object\n");
    return 1;
  }

  abstract = nml->abstract;
  secnum = nml->abstract->secnum + 1;
  lastgrp = 0;
  yyparse();

  nml->lastgrp = lastgrp = 0;
  return err;
}

/* Initialize the lexer and parser */
int param_scan_file(section *s, FILE *f)
{
  nml_obj *nml = malloc(sizeof(nml_obj));
  int err;

  if (nml == 0) 
  {
    fprintf(stderr, "param_scan_file: failed to initialize nml\n");
    return 1;
  }

  if (f == 0) 
  {
    fprintf(stderr, "param_scan_file: null file handle\n");
    return 1;
  }

  init_lexer_file(f);

  nml->type = NML_FILE;
  nml->f = f;
  nml->arg = NULL;
  err = init_nml(nml, s);
  err |= param_read_all(nml);
  fini_param(nml);

  return err;
}

/* Initialize the lexer and parser */
int param_scan_arg(section *s, const char *inp)
{
  nml_obj *nml = malloc(sizeof(nml_obj));
  int err;

  if (nml == 0) 
  {
    fprintf(stderr, "param_scan_arg: failed to initialize nml\n");
    return 1;
  }

  if (inp == 0) 
  {
    fprintf(stderr, "param_scan_arg: null arg\n");
    return 1;
  }

  init_lexer_arg((char *)inp);

  nml->type = NML_ARG;
  nml->f = NULL;
  nml->arg = (char *)inp;
  err = init_nml(nml, s);
  err |= param_read_all(nml);
  fini_param(nml);

  return err;
}

int param_open_file(section *s, const char *name)
{
  FILE *f = fopen(name, "r");
  int err;

  if (f == 0) 
  {
    fprintf(stderr, "can not open file %s\n", name);
    return 1;
  }

  err = param_scan_file(s, f);
  fclose(f);

  return err;
}



/* Initialize the section stack. Used only for convenience */
void init_nml_section_stack(section *s)
{
  section_stack = s;

#ifdef DEBUG
  fprintf(stderr,"Debugging dump of abstract\n");
  print_section(stderr, s);
#endif
}

/* Initialize the section stack. Used only for convenience */
section *get_current_nml_section(void)
{
  return section_stack;
}

/* Section stack manipulations */
void push_nml_section_stack(const char *name)
{
#ifdef DEBUG
  fprintf(stderr,"push_nml: name=%s  curstackname=%s\n",
	  name, section_stack->name);
#endif

  section_stack = find_section(section_stack, name, NULL);

#ifdef DEBUG
  fprintf(stderr,"push_nml: newstackname=%s\n",
	  section_stack->name);
#endif

  if (section_stack == 0)
    parse_abort("push_nml_section_stack: subsection %s not found",name);
}

/* Section stack manipulations */
void pop_nml_section_stack()
{
  if (section_stack == 0)
    parse_abort("pop_nml_section_stack: top of stack empty");

#if 0
  if (strcmp(section_stack->name, name))
    parse_abort("pop_nml_section_stack: illegal stack pop of section %s",name);
#endif

#ifdef DEBUG
  fprintf(stderr,"pop_nml: stackname=%s\n",
	  section_stack->name);
  if (section_stack->up != 0)
    fprintf(stderr,"pop_nml: upname=%s\n",
	    section_stack->up->name);
#endif

  section_stack = section_stack->up;
}


/* Find a particular section */
section *find_section(const section *abs, ...)
{
  va_list va;
  section *sp, *spp;
  const char *cname;
  int foundP = 0;

#ifdef DEBUG
  fprintf(stderr, "find_section:\n");
#endif

  if (abs == 0)
    parse_abort("find_section: null pointer to search");

  spp = sp = abs->sslist;

  va_start(va, abs);

  /* Get first subsection name segment */
  cname = va_arg(va, const char *);
#ifdef DEBUG    
  fprintf(stderr, "find_section: sec name = %s\n",cname);
#endif

  while (sp != 0 && cname != 0) 
  {
    foundP = 0;

    while (sp != 0) 
    {
#ifdef DEBUG
      fprintf(stderr, "find_section: this sec name = %s  cname = %s\n",sp->name,cname);
#endif

      /* Found our section */
      if (! strcmp(cname, sp->name)) 
      {
	foundP = 1;
	spp = sp;

	/* get another subsection name segment */
	cname = va_arg(va, const char *);
#ifdef DEBUG    
	fprintf(stderr, "find_section: found sec name = %s\n",cname);
#endif

	/* go down to next subsection list */
	sp = sp->sslist;
	break;
      }

      /* Not our section, go on along the next chain. */
      sp = sp->next;
    }
  }

  va_end(va);

  return ((foundP == 1) ? spp : 0);
}


/* find is used by other files of the library */
const node *param_x_find(const section *sp, const char *key, int rank, va_list va)
{
  resource *rp;
  const node *result = 0;
#define MAXINDEX 20
  char indstr[MAXINDEX][20];
  int ind;

#ifdef DEBUG
  fprintf(stderr, "param_x_find: key = %s  rank = %d\n", key, rank);
#endif

  if (sp == 0)
    return result;

  if (rank >= MAXINDEX)
    parse_abort("param_x_find: rank too large");

  /* Extract indices if they are there */
  if (rank > 0)
  {
    int nn;

    for(nn=0; nn < rank; ++nn)
    {
      ind = va_arg(va, int);

#ifdef DEBUG
      fprintf(stderr, "param_x_find: key = %s  ind[%d] = %d\n", key, nn, ind);
#endif

      if (ind < 0 || ind > 1000000)
      {
	fprintf(stderr, "param_x_find: invalid index %d\n", ind);
	exit(1);
      }
      sprintf(indstr[nn], "%d", ind);
    }
  }


  /* If subsection name found, then lookup */
  /* look for a definition of the resource in the section */
  for (rp = sp->rlist; rp; rp = rp->next) 
  {
#ifdef DEBUG
    fprintf(stderr, "Print: key = %s  target = %s\n", (rp->key)->val, key);
#endif

    if (chkres_any(rp, VT_SCALAR))
    {
      /* Simple scalar */
#ifdef DEBUG
      fprintf(stderr, "checking[scalar]: key = %s\n", (rp->key)->val);
#endif

      if (! strcmp((rp->key)->val, key))
      {
	if (rp->dim != 0)
	  parse_abort("param_x_find: rank and number of indices do not match");

#ifdef DEBUG
	fprintf(stderr, "returning [scalar] result of key = %s\n", key);
#endif

	result = (const node *)rp->value;
	return result;
      }
    }
    else if (chkres_any(rp, VT_ARRAY))
    {
      int i;

      /* Must assume a 1-D array */
#ifdef DEBUG
      fprintf(stderr, "checking[array]: key = %s  rank = %d\n", 
	      (rp->key)->val, rank);
#endif

      if (! strcmp((rp->key)->val, key))
      {
	node *v;

	if (rp->dim != 1)
	  parse_abort("param_x_find: rank and number of indices do not match");

	for(i=0, v=rp->value; i != ind && v; ++i, v=v->next);

#ifdef DEBUG
	fprintf(stderr, "returning [array] result of key = %s\n", key);
#endif

	result = (const node *)v;
	return result;
      }
    }
    else if (chkres_any(rp, VT_ELEM))
    {
      /* Check all array elements */
#ifdef DEBUG
      fprintf(stderr, "checking[elem]: key = %s  ind = %d\n", 
	      (rp->key)->val, ind);
#endif

      if (! strcmp((rp->key)->val, key))
      {
	node *kind;
	int nn;
	int badP = 0;

#ifdef DEBUG
	fprintf(stderr, "found match of key = %s, dim=%d, num=%d\n", 
		(rp->key)->val, rp->dim, rp->num);
#endif

	if (rp->dim != rank)
	  parse_abort("param_x_find: rank and number of indices do not match");

	for(nn=0, kind = rp->key->next; nn < rank && kind; ++nn, kind=kind->next)
	{
	  if (strcmp(kind->val, indstr[nn]))
	  {
	    badP = 1;
	    break;
	  }
	}
	if (badP == 0)
	{
	  result = (const node *)rp->value;
	  return result;
	}
      }
    }
    else
    {
      parse_abort("internal error in param_x_find");
      break;
    }
  }

  return result;
}


void param_abort(const char *v)
{
  fprintf(stderr, "parameter %s not found\n", v);
  fflush(stderr);
  exit(1);
}

int param_bool_array(int *r, const section *sp, const char *key, int rank, ...)
{
  va_list va;
  const node *res;

  va_start(va, rank);
  res = param_x_find(sp, key, rank, va);
  va_end(va);
  if (res == 0) 
  {
    param_abort(key);
    *r = 0;
    return 1;
  } 
  else if ((res->type & VT_COMPLEX) != 0)
  {
    param_abort(key);
    *r = 0;
    return 1;
  }    
  else 
  {
    int foo;
    
    if (!strcasecmp(res->val, "false") ||
        !strcasecmp(res->val, "#f") ||
        !strcasecmp(res->val, "no") ||
        !strcasecmp(res->val, "off") ||
        !strcasecmp(res->val, "0") ||
        !strcasecmp(res->val, "none")) 
    {
      *r = 0;
    }
    else if (!strcasecmp(res->val, "true") ||
	     !strcasecmp(res->val, "#t") ||
	     !strcasecmp(res->val, "yes") ||
	     !strcasecmp(res->val, "1") ||
	     !strcasecmp(res->val, "on"))
    {
      *r = 1;
    }
    else if (sscanf(res->val, "%i", &foo) == 1) 
    {
      /* just to have a uniform true value */
      if (foo) 
      {
	*r = 1;
      } 
      else 
      {
	*r = 0;
      }
    }
  }

  return 0;
}


int param_double_array(double *r, const section *sp, const char *key, int rank, ...)
{
  va_list va;
  const node *res;

  va_start(va, rank);
  res = param_x_find(sp, key, rank, va);
  va_end(va);
  if (res == 0) 
  {
    param_abort(key);
    *r = 0;
    return 1;
  } 
  else if ((res->type & VT_COMPLEX) != 0)
  {
    param_abort(key);
    *r = 0;
    return 1;
  }    
  else 
  {
    if (sscanf(res->val, "%lg", r) < 1) 
    {
      param_abort(key);
      return 1;
    }
  }

  return 0;
}

int param_float_array(float *r, const section *sp, const char *key, int rank, ...)
{
  va_list va;
  const node *res;

  va_start(va, rank);
  res = param_x_find(sp, key, rank, va);
  va_end(va);
  if (res == 0) 
  {
    param_abort(key);
    *r = 0;
    return 1;
  } 
  else if ((res->type & VT_COMPLEX) != 0)
  {
    param_abort(key);
    *r = 0;
    return 1;
  }    
  else 
  {
    if (sscanf(res->val, "%g", r) < 1) 
    {
      param_abort(key);
      *r = 0;
      return 1;
    }
  }

  return 0;
}


int param_complex_double_array(double *re, double *im,
			       const section *sp, const char *key, int rank, ...)
{
  va_list va;
  const node *res;

  va_start(va, rank);
  res = param_x_find(sp, key, rank, va);
  va_end(va);
  if (res == 0) 
  {
    param_abort(key);
    *re = *im = 0;
    return 1;
  } 
  else if ((res->type & VT_COMPLEX) == 0)
  {
    param_abort(key);
    return 1;
  }    
  else 
  {
    if (sscanf(res->slist->val, "%lg", re) < 1) 
    {
      param_abort(key);
      return 1;
    }

    if (sscanf(res->slist->next->val, "%lg", im) < 1)
    {
      param_abort(key);
      return 1;
    }
  }

  return 0;
}


int param_complex_float_array(float *re, float *im,
			      const section *sp, const char *key, int rank, ...)
{
  va_list va;
  const node *res;

  va_start(va, rank);
  res = param_x_find(sp, key, rank, va);
  va_end(va);
  if (res == 0) 
  {
    param_abort(key);
    *re = *im = 0;
    return 1;
  } 
  else if ((res->type & VT_COMPLEX) == 0)
  {
    param_abort(key);
    return 1;
  }    
  else 
  {
    if (sscanf(res->slist->val, "%g", re) < 1) 
    {
      param_abort(key);
      return 1;
    }

    if (sscanf(res->slist->next->val, "%g", im) < 1)
    {
      param_abort(key);
      return 1;
    }
  }

  return 0;
}


int param_complex_int_array(int *re, int *im,
			    const section *sp, const char *key, int rank, ...)
{
  va_list va;
  const node *res;

  va_start(va, rank);
  res = param_x_find(sp, key, rank, va);
  va_end(va);
  if (res == 0) 
  {
    param_abort(key);
    *re = *im = 0;
    return 1;
  } 
  else if ((res->type & VT_COMPLEX) == 0)
  {
    param_abort(key);
    return 1;
  }    
  else 
  {
    if (sscanf(res->slist->val, "%d", re) < 1) 
    {
      param_abort(key);
      return 1;
    }

    if (sscanf(res->slist->next->val, "%d", im) < 1)
    {
      param_abort(key);
      return 1;
    }
  }

  return 0;
}


int param_int_array(int *r, const section *sp, const char *key, int rank, ...)
{
  va_list va;
  const node *res;

  va_start(va, rank);
  res = param_x_find(sp, key, rank, va);
  va_end(va);
  if (res == 0) 
  {
    param_abort(key);
    *r = 0;
    return 1;
  } 
  else if ((res->type & VT_COMPLEX) != 0)
  {
    param_abort(key);
    *r = 0;
    return 1;
  }    
  else 
  {
    if (sscanf(res->val, "%i", r) < 1) 
    {
      param_abort(key);
      return 1;
    }
  }

  return 0;
}


int param_unsigned_array(unsigned *r, const section *sp, const char *key, int rank, ...)
{
  va_list va;
  const node *res;

  va_start(va, rank);
  res = param_x_find(sp, key, rank, va);
  va_end(va);
  if (res == 0) 
  {
    param_abort(key);
    *r = 0;
    return 1;
  } 
  else if ((res->type & VT_COMPLEX) != 0)
  {
    param_abort(key);
    *r = 0;
    return 1;
  }    
  else 
  {
    if (sscanf(res->val, "%u", r) < 1) 
    {
      param_abort(key);
      return 1;
    }

    return 0;
  }
}


int param_intsfx_array(size_t *r, const section *sp, const char *key, int rank, ...)
{
  va_list va;
  const node *res;

  va_start(va, rank);
  res = param_x_find(sp, key, rank, va);
  va_end(va);
  if (res == 0) 
  {
    param_abort(key);
    return 1;
  } 
  else if ((res->type & VT_COMPLEX) != 0)
  {
    param_abort(key);
    *r = 0;
    return 1;
  }    
  else 
  {
    double foo;
    char sx;
    
    switch (sscanf(res->val, "%lg%c", &foo, &sx)) 
    {
    case 1:
      return (int)foo;
    case 2:
      switch (sx) 
      {
      case 'k': case 'K':
        *r = (size_t)(foo * 1024.0);
	return 0;
      case 'm': case 'M':
        *r = (size_t)(foo * 1024.0 * 1024.0);
	return 0;
      case 'g': case 'G':
        *r = (size_t)(foo * 1024.0 * 1024.0 * 1024.0);
	return 0;
      default:
	param_abort(key);
        return 1;
      }
    default:
      param_abort(key);
      return 1;
    }
  }
}

char *param_string_array(const section *sp, const char *key, int rank, ...)
{
  va_list va;
  const node *res;

  va_start(va, rank);
  res = param_x_find(sp, key, rank, va);
  va_end(va);
  if (res == 0)
  {
    param_abort(key);
    return 0;
  }
  else if ((res->type & VT_COMPLEX) != 0)
  {
    param_abort(key);
    return 0;
  }    
  else
  {
    return res->val;
  }
}
