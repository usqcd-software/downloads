#ifndef _qcd_nml_h
#define _qcd_nml_h
/* $Id: qcd-nml.h,v 1.6 2003/06/02 04:22:30 edwards Exp $ */
#include <stddef.h>

#include "nml.h"

#ifdef __cplusplus
extern "C"
{
#endif

typedef struct paramval_s paramval;

struct paramval_s {
  char *name;
  int   val;
};


/* Global functions */
void init_nml_section_stack(section *s);
section *get_current_nml_section(void);
void push_nml_section_stack(const char *name);
void pop_nml_section_stack();

section *new_abstract(const char *inp);
void rm_abstract(section *s);

int param_scan_file(section *s, FILE *f);
int param_scan_arg(section *s, const char *inp);
int param_open_file(section *s, const char *name);
void param_abort(const char *var);

section *find_section(const section *abs, ...);

char * param_string_array(const section *s, const char *key, int rank, ...);
int param_float_array(float *r, const section *s, const char *key, int rank, ...);
int param_double_array(double *r, const section *s, const char *key, int rank, ...);
int param_unsigned_array(unsigned *r, const section *s, const char *key, int rank, ...);
int param_int_array(int *r, const section *s, const char *key, int rank, ...);
int param_intsfx_array(size_t *r, const section *s, const char *key, int rank, ...);
int param_bool_array(int *r, const section *s, const char *key, int rank, ...);

int param_complex_double_array(double *re, double *im, 
			       const section *s, const char *key, int rank, ...);
int param_complex_float_array(float *re, float *im, 
			      const section *s, const char *key, int rank, ...);
int param_complex_int_array(int *re, int *im, 
			    const section *s, const char *key, int rank, ...);

int szin_param_int_val(const paramval *def, 
		       const section *s, const char *key, int rank, const char *grp);
const char *szin_param_int_strng(const paramval *def, int val);

#ifdef __cplusplus
}
#endif

#endif
