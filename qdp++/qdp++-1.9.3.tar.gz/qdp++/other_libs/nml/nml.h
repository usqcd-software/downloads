/* $Id: nml.h,v 1.4 2003/04/20 03:27:07 edwards Exp $
 *
 * nml  header
 */
 
#ifndef _NML_
#define _NML_

#include <stdio.h>
#include <stdarg.h>

/*****************************************************************************
 *         abstract syntax structures for the param file                    *
 *****************************************************************************/

#ifdef __cplusplus
extern "C"
{
#endif

typedef struct section_s  section;
typedef struct resource_s resource;
typedef struct node_s node;

struct section_s {
  int  line;
  int  level;
  int  secnum;
  char *name;
  section *next;
  section *sslist;
  section *up;
  resource *rlist;
};

struct resource_s {
  int  line;
  int  type;
  int  dim;
  int  num;
  node *key;
  node *value;
  resource *next;
};

struct node_s {
  int  type;
  int  num;
  char *val;
  node *next;
  node *slist;
};


typedef struct nml_obj_s {
  int  type;
  FILE *f;
  char *arg;
  section *abstract;
  section *lastgrp;
} nml_obj;


/* Symbol table manipulation */
void init_lexer_file(FILE *f);
void init_lexer_arg(char *inp);

void add_abstract(section *s);

void push_section(char *);
void pop_section();

char *mk_string(const char *value, int len);
void rm_string(char *value);
section *mk_section(char *name);
node *mk_node(char *value);
node *mk_complex_node(node *re_value, node *im_value);
void rm_node(node *r);
resource *mk_resource(node *key, node *value);

void print_section(FILE *f, const section *s);
void print_resource(FILE *f, const resource *r);

section *find_section(const section *abs, ...);

void add_section(section **ss, section *sn);
void add_subsection(section *ss, section *sn);
void add_resource(section *ss, resource *r);
void add_node(node **nn, node *n);
void parse_abort(char *fmt, ...);

/* variable types */
#define VT_SCALAR         1
#define VT_COMPLEX        2
#define VT_ARRAY          4
#define VT_ELEM           8
#define VT_NUMBER         16
#define VT_STRING         32
#define VT_IDENT          64

extern section *abstract;
extern section *current_section;
extern int active_sectionP;

#ifdef __cplusplus
}
#endif

#endif
