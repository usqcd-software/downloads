/* $Id: t_nml.c,v 1.5 2003/04/21 16:31:58 edwards Exp $ */

#include <stdio.h>
#include <stdlib.h>

#include "nml.h"
#include "qcd-nml.h"

#define MAXDATA   2048

int main(int argc, char **argv)
{
  int t;
  double dre, dim;
  float sre, sim;
  int boolP;
  char *str;
  char inp[MAXDATA];
  section *abs;
  section *s;
  FILE *fp;
  FILE *f;
  int nn;
  char *ff = "foo.input";

  if ((fp = fopen(ff,"rt")) == 0)
  {
    fprintf(stderr,"Error opening file %s for reading\n",ff);
    return 1;
  }
  abs = new_abstract("abstract");

#if 1
  param_scan_file(abs, fp);
#else
  nn = fread(inp, sizeof(char), MAXDATA, fp);
  fprintf(stderr,"Input file size %d  bytes\n",nn);
  if (nn >= MAXDATA-1)
  {
    fprintf(stderr,"Input file same size as buffer - probably not big enough\n");
    return 1;
  }
  inp[nn] = '\0';
  param_scan_arg(abs, inp);
#endif
  fclose(fp);

  fprintf(stderr,"Section dump\n");
  print_section(stderr, abs);

  if ((f = fopen("foo.output","wt")) == 0)
  {
    fprintf(stderr,"Error opening file for output\n");
    return 1;
  }
  print_section(f,abs);
  fclose(f);

  s = find_section(abs, "stuff", NULL);
  param_int_array(&t, s, "x", 0);
  fprintf(stderr, "x = %d\n", t);

  param_int_array(&t, s, "eee", 0);
  fprintf(stderr, "eee = %d\n", t);

  param_complex_float_array(&sre, &sim, s, "cde", 0);
  fprintf(stderr, "single: cde = (%g, %g)\n", sre, sim);

  s = find_section(abs, "stuff", "barf", NULL);
  param_int_array(&t, s, "cba", 0);
  fprintf(stderr, "cba[barf] = %d\n", t);

  s = find_section(abs, "stuff", NULL);
  param_int_array(&t, s, "abc", 1, 0);
  fprintf(stderr, "abc(0) = %d\n", t);

  param_int_array(&t, s, "abc", 1, 2);
  fprintf(stderr, "abc(2) = %d\n", t);

  param_int_array(&t, s, "abc", 1, 7);
  fprintf(stderr, "abc(7) = %d\n", t);

  s = find_section(abs, "fred", NULL);
  param_int_array(&t, s, "a", 0);
  fprintf(stderr, "a = %d\n", t);

  s = find_section(abs, "stuff", NULL);
  param_complex_double_array(&dre, &dim, s, "cde", 0);
  fprintf(stderr, "double: cde = (%g, %g)\n", dre, dim);

  param_complex_double_array(&dre, &dim, s, "d", 2, 1, 2);
  fprintf(stderr, "d(1,2) = (%g, %g)\n", dre, dim);

  s = find_section(abs, "fred", NULL);
  param_bool_array(&boolP, s, "bb", 0);
  fprintf(stderr, "bb = %d\n", boolP);

  param_bool_array(&boolP, s, "cc", 0);
  fprintf(stderr, "cc = %d\n", boolP);

  str = param_string_array(s, "str", 0);
  fprintf(stderr, "str = %s\n", str);

  return 0;
}

