typedef union
{
  char *integer;
  char *real;
  char *number;
  char *string;
  char *ident;
  section *section;
  resource *resource;
  node *node;
} YYSTYPE;
#define	BEGINGRP	257
#define	IDENT	258
#define	STRING	259
#define	NUMBER	260
#define	INTEGER	261
#define	REAL	262
#define	ENDGRP	263
#define	LCOMPLEX	264
#define	RCOMPLEX	265
#define	LPAREN	266
#define	RPAREN	267
#define	EOFF	268

