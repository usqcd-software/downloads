#ifndef TYPE32_H
#define TYPE32_H

/* Define to be a 32 bit unsigned integer */
/* NEEDS TO BE CONFIG'ED */
typedef unsigned int u_int32;

#endif

