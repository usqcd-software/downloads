#ifndef LIME_FIXED_TYPES_H
#define LIME_FIXED_TYPES_H

/* Should be CONFIG'd */
typedef unsigned long long  n_uint64_t;
typedef unsigned long       n_uint32_t;
typedef unsigned short      n_uint16_t;

#endif
