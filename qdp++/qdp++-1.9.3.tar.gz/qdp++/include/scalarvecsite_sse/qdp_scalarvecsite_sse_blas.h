// $Id: qdp_scalarvecsite_sse_blas.h,v 1.1 2004/08/09 22:03:10 edwards Exp $
/*! @file
 * @brief Blas optimizations
 * 
 * Generic and maybe SSE optimizations of basic operations
 */


#ifndef QDP_SCALARVECSITE_SSE_BLAS_H
#define QDP_SCALARVECSITE_SSE_BLAS_H

QDP_BEGIN_NAMESPACE(QDP);

// Nuttin here yet, duhhh
  
QDP_END_NAMESPACE();

#endif  // guard
 
