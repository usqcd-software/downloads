// $Id: tutorial.h,v 1.1 2003/02/17 21:41:27 edwards Exp $

//! Return the value of the average plaquette normalized to 1
/*!
 * \param u -- gauge field (Read)
 * \param w_plaq -- plaquette average (Write)
 * \param s_plaq -- space-like plaquette average (Write)
 * \param t_plaq -- time-like plaquette average (Write)
 * \param link   -- space-time average link (Write)
 */
void MesPlq(const multi1d<LatticeColorMatrix>& u, Double& w_plaq, Double& s_plaq, 
	    Double& t_plaq, Double& link);
