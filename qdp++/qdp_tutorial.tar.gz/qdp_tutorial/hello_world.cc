/*
 * $Id: hello_world.cc,v 1.1 2003/02/18 17:21:33 dgr Exp $
 */

#include "qdp.h"

using namespace QDP;

int main(int argc, char *argv[])
{
  // Put the machine into a known state
  // In particular, this might initialise the communication in hardware etc
  QDP_initialize(&argc, &argv);

  /*
   *  We now  have to set up the layout.  Certain parameters are 
   */

  const int foo[] = {4,4,4,8};
  multi1d<int> nrow(Nd);
  nrow = foo;
  Layout::setLattSize(nrow);
  Layout::create();

  cout << "Hello, world" << endl;

  {
    int lattice_volume;
    lattice_volume = Layout::vol();

    cout << "Volume is " << lattice_volume << endl;
  }


  QDP_finalize();

  return 0;
}
  
