#ifndef QDP_SSE_INTRIN_H
#define QDP_SSE_INTRIN_H

// Include the file with the SSE intrinsics  in it
#include <xmmintrin.h>
typedef __m128 v4sf;

#endif 
