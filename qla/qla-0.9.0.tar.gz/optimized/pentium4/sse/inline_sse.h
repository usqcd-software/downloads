#ifndef _INLINE_SSE_H_
#define _INLINE_SSE_H_

/* These assembly inline versions work only with the gnu C compiler on
   P3 or P4 processors */

#include "sse_m_mat_nn.h"
#include "sse_m_mat_na.h"
#include "sse_m_mat_an.h"
#include "sse_m_matvec.h"
#include "sse_m_amatvec.h"
#include "sse_m_mv_s_4dir.h"
#include "sse_m_amv_4dir.h"
#include "sse_m_amv_4vec.h"
#include "sse_su3_proj.h"
#include "sse_m_mat_hwvec.h"
#include "sse_m_amat_hwvec.h"
#include "sse_sub4vecs.h"
#include "sse_addvec.h"
#include "sse_s_m_a_vec.h"
#include "sse_s_m_a_mat.h"

#if defined SSE_INLINE

#define mult_su3_nn               _inline_mult_su3_nn
#define mult_su3_na               _inline_mult_su3_na
#define mult_su3_an               _inline_mult_su3_an
#define mult_su3_mat_vec          _inline_sse_mult_su3_mat_vec
#define mult_adj_su3_mat_vec      _inline_sse_mult_adj_su3_mat_vec
#define mult_su3_mat_vec_sum_4dir _inline_mult_su3_mat_vec_sum_4dir
#define mult_adj_su3_mat_vec_4dir _inline_mult_adj_su3_mat_vec_4dir
#define mult_adj_su3_mat_4vec     _inline_mult_adj_su3_mat_4vec
#define su3_projector             _inline_su3_projector
#define mult_su3_mat_hwvec        _inline_mult_su3_mat_hwvec
#define mult_adj_su3_mat_hwvec    _inline_mult_adj_su3_mat_hwvec
#define sub_four_su3_vecs         _inline_sub_four_su3_vecs
#define add_su3_vector            _inline_add_su3_vector

/* Allow expressions for the scalar arguments here */
/* #define scalar_mult_add_su3_vector(args...) _inline_scalar_mult_add_su3_vector(##args) */
#define scalar_mult_add_su3_vector(a,b,c,d) {float _temp = c; _inline_scalar_mult_add_su3_vector(a,b,_temp,d)}
/* #define scalar_mult_add_su3_matrix(args...) _inline_scalar_mult_add_su3_matrix(##args) */
#define scalar_mult_add_su3_matrix(a,b,c,d) {float _temp = c; _inline_scalar_mult_add_su3_matrix(a,b,_temp,d)}

#endif

/* Corrections by A. Alexandru */
typedef struct
{
   unsigned int c1,c2,c3,c4;
} sse_mask __attribute__ ((__aligned__ (16)));

static sse_mask _sse_sgn13 __attribute__ ((__aligned__ (16), __unused__)) ={0x80000000, 0x00000000, 0x80000000, 0x00000000};
static sse_mask _sse_sgn24 __attribute__ ((__aligned__ (16), __unused__)) ={0x00000000, 0x80000000, 0x00000000, 0x80000000};
static sse_mask _sse_sgn3 __attribute__  ((__aligned__ (16), __unused__)) ={0x00000000, 0x00000000, 0x80000000, 0x00000000};
static sse_mask _sse_sgn4 __attribute__  ((__aligned__ (16), __unused__)) ={0x00000000, 0x00000000, 0x00000000, 0x80000000};


#endif
