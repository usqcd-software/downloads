# LaTeX2HTML 2002 (1.63)
# Associate internals original text with physical files.


$key = q/sec:details/;
$ref_files{$key} = "$dir".q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/sec.datatypes/;
$ref_files{$key} = "$dir".q|node2.html|; 
$noresave{$key} = "$nosave";

1;

