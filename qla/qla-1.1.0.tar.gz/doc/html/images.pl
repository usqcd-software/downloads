# LaTeX2HTML 2002 (1.63)
# Associate images original text with physical files.


$key = q/exp(ia);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="55" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img6.gif"
 ALT="$\exp(ia)$">|; 

$key = q/exp(a);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img3.gif"
 ALT="$\exp(a)$">|; 

$key = q/mathop{{rm{Re}c;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="32" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img7.gif"
 ALT="$\mathop{\rm Re}c$">|; 

$key = q/c=c-mathop{{rm{Re}(a);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="98" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img18.gif"
 ALT="$ c = c - \mathop{\rm Re}(a) $">|; 

$key = q/c=c-abmbox{({a{real)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="136" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img61.gif"
 ALT="$ c = c - ab   \mbox{($a$ real)}$">|; 

$key = q/r={{rm{transpose}(a);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="120" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img74.gif"
 ALT="$r = {\rm transpose}(a)$">|; 

$key = q/c=c+mathop{{rm{Re}(a);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="98" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img16.gif"
 ALT="$ c = c + \mathop{\rm Re}(a) $">|; 

$key = q/r=a^dagger*b^dagger;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="76" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img97.gif"
 ALT="$r = a^\dagger * b^\dagger$">|; 

$key = q/c=-mathop{{rm{Im}(a^*b);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="101" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img44.gif"
 ALT="$ c = -\mathop{\rm Im}(a^*b) $">|; 

$key = q/r={{rm{func}(a);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="83" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img69.gif"
 ALT="$r = {\rm func}(a)$">|; 

$key = q/c=c+abmbox{({a{real)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="136" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img59.gif"
 ALT="$ c = c + ab   \mbox{($a$ real)}$">|; 

$key = q/sqrt{a}arg(a)in(-pi,pi];MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="151" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img4.gif"
 ALT="$\sqrt{a}   \arg(a) \in (-\pi,\pi]$">|; 

$key = q/r_{i_c,i_s}=a_{i_c,i_s,j_c,j_s}mbox{for{i_c=0ldots{}n_c-1,i_s=0ldots{}3{};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="352" HEIGHT="29" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img84.gif"
 ALT="$r_{i_c,i_s} = a_{i_c,i_s,j_c,j_s}   \mbox{for $i_c = 0\ldots{}n_c-1, i_s = 0\ldots{}3$}$">|; 

$key = q/c=c+mathop{{rm{Im}(ab^*);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="113" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img35.gif"
 ALT="$ c = c + \mathop{\rm Im}(ab^*) $">|; 

$key = q/i=0ldots{}n-1;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="100" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img2.gif"
 ALT="$i = 0\ldots{}n-1$">|; 

$key = q/mathop{{rm{Re}r=a;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="63" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img75.gif"
 ALT="$\mathop{\rm Re}r = a$">|; 

$key = q/c=ax-bmbox{({a{real)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="138" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img66.gif"
 ALT="$c = ax - b   \mbox{($a$ real)}$">|; 

$key = q/c=c-mathop{{rm{Im}(a^*b);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="113" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img45.gif"
 ALT="$ c = c - \mathop{\rm Im}(a^*b) $">|; 

$key = q/mathop{{rm{Im}r=0;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="62" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img76.gif"
 ALT="$\mathop{\rm Im}r = 0$">|; 

$key = q/r_i=mathop{{rm{Tr}a^dagger_icdotb_i;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="95" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img95.gif"
 ALT="$r_i = \mathop{\rm Tr}a^\dagger_i \cdot b_i$">|; 

$key = q/c=mathop{{rm{Re}(a^*b);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="86" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img38.gif"
 ALT="$ c = \mathop{\rm Re}(a^*b) $">|; 

$key = q/c=ax-bmbox{({x{real)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="139" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img64.gif"
 ALT="$c = ax - b   \mbox{($x$ real)}$">|; 

$key = q/c=c+mathop{{rm{Im}(a^*b^*);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="120" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img51.gif"
 ALT="$ c = c + \mathop{\rm Im}(a^*b^*) $">|; 

$key = q/r=agamma_d;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="57" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img94.gif"
 ALT="$r = a \gamma_d$">|; 

$key = q/c=ambox{(real)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="89" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img10.gif"
 ALT="$ c = a   \mbox{(real)} $">|; 

$key = q/arg(c);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="46" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img9.gif"
 ALT="$\arg(c)$">|; 

$key = q/r=mathop{{rm{Im}mathop{{rm{Tr}a;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="82" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img88.gif"
 ALT="$r = \mathop{\rm Im}\mathop{\rm Tr}a$">|; 

$key = q/mathop{{rm{Im}r=b;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img77.gif"
 ALT="$\mathop{\rm Im}r = b$">|; 

$key = q/c=-mathop{{rm{Re}(ab^*);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="101" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img32.gif"
 ALT="$ c = -\mathop{\rm Re}(ab^*) $">|; 

$key = q/c=c-mathop{{rm{Im}(a^*b^*);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="120" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img53.gif"
 ALT="$ c = c - \mathop{\rm Im}(a^*b^*) $">|; 

$key = q/r=summathop{{rm{Tr}a^daggercdotb;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="105" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img103.gif"
 ALT="$r = \sum \mathop{\rm Tr}a^\dagger \cdot b$">|; 

$key = q/r_{i_c}=a_{i_c,i_s}mbox{for{i_c=0ldots{}n_c-1{};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="227" HEIGHT="29" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img82.gif"
 ALT="$r_{i_c} = a_{i_c,i_s}   \mbox{for $i_c = 0\ldots{}n_c-1$}$">|; 

$key = q/c=-mathop{{rm{Re}(a);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="87" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img20.gif"
 ALT="$ c =- \mathop{\rm Re}(a) $">|; 

$key = q/r=(a-a^dagger)slash2-imathop{{rm{Im}mathop{{rm{Tr}aslashn_c;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="205" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img89.gif"
 ALT="$r = (a - a^\dagger)/2 - i\mathop{\rm Im}\mathop{\rm Tr}a/n_c$">|; 

$key = q/r=mathop{{rm{Re}mathop{{rm{Tr}a;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="82" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img87.gif"
 ALT="$r = \mathop{\rm Re}\mathop{\rm Tr}a$">|; 

$key = q/c=-abmbox{({a{real)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="122" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img60.gif"
 ALT="$ c = -ab   \mbox{($a$ real)} $">|; 

$key = q/log(a)arg(a)in[0,2pi);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="164" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img5.gif"
 ALT="$\log(a)   \arg(a) \in [0, 2\pi)$">|; 

$key = q/c=mathop{{rm{Re}(a^*b^*);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="93" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img46.gif"
 ALT="$ c = \mathop{\rm Re}(a^*b^*) $">|; 

$key = q/c=c-mathop{{rm{Re}(ab^*);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="112" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img33.gif"
 ALT="$ c = c - \mathop{\rm Re}(ab^*) $">|; 

$key = q/r=mathop{{rm{diag}(a,a,ldots{});MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="127" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img106.gif"
 ALT="$r = \mathop{\rm diag}(a,a,\ldots{})$">|; 

$key = q/c=c+mathop{{rm{Re}(a^*b);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="112" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img39.gif"
 ALT="$ c = c + \mathop{\rm Re}(a^*b) $">|; 

$key = q/r=mathop{{rm{Im}a;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="63" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img79.gif"
 ALT="$r = \mathop{\rm Im}a$">|; 

$key = q/r_i=a_{i,j}mbox{for{i=0ldots{}n_c-1{};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="203" HEIGHT="29" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img80.gif"
 ALT="$r_i = a_{i,j}   \mbox{for $i = 0\ldots{}n_c-1$}$">|; 

$key = q/c=-mathop{{rm{Re}(a^*b^*);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="108" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img48.gif"
 ALT="$ c = -\mathop{\rm Re}(a^*b^*) $">|; 

$key = q/r={{rm{recon,}(p,d,a);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="124" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img92.gif"
 ALT="$r = {\rm recon }(p,d,a)$">|; 

$key = q/r=amathop{{rm{op}b;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="70" HEIGHT="29" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img100.gif"
 ALT="$r = a \mathop{\rm op}b$">|; 

$key = q/c=mathop{{rm{Im}(a^*b);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="86" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img42.gif"
 ALT="$ c = \mathop{\rm Im}(a^*b) $">|; 

$key = q/mathop{{rm{op};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="21" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img72.gif"
 ALT="$\mathop{\rm op}$">|; 

$key = q/c=aslashbmbox{({b{real)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="116" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img62.gif"
 ALT="$ c = a/b   \mbox{($b$ real)} $">|; 

$key = q/r={{rm{func}(a,b);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="97" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img71.gif"
 ALT="$r = {\rm func}(a,b)$">|; 

$key = q/r=mathop{{rm{op}(a,b);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="84" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img99.gif"
 ALT="$r = \mathop{\rm op}(a,b)$">|; 

$key = q/c=mathop{{rm{Im}(a);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="72" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img15.gif"
 ALT="$ c = \mathop{\rm Im}(a) $">|; 

$key = q/mu=-1;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="55" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img67.gif"
 ALT="$\mu = -1$">|; 

$key = q/r=mathop{{rm{Re}summathop{{rm{Tr}a^daggercdotb;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="126" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img104.gif"
 ALT="$r = \mathop{\rm Re}\sum \mathop{\rm Tr}a^\dagger \cdot b$">|; 

$key = q/c=-mathop{{rm{Im}(ab^*);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="101" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img36.gif"
 ALT="$ c = -\mathop{\rm Im}(ab^*) $">|; 

$key = q/r=mathop{{rm{Re}a;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="63" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img78.gif"
 ALT="$r = \mathop{\rm Re}a$">|; 

$key = q/r=mathop{{rm{Tr}a;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="60" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img86.gif"
 ALT="$r = \mathop{\rm Tr}a$">|; 

$key = q/i=1ldots{}n;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="72" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.gif"
 ALT="$i = 1\ldots{}n$">|; 

$key = q/c=c-mathop{{rm{Re}(ab);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="105" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img25.gif"
 ALT="$ c = c - \mathop{\rm Re}(ab) $">|; 

$key = q/c=c-mathop{{rm{Im}(a);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="98" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img19.gif"
 ALT="$ c = c - \mathop{\rm Im}(a) $">|; 

$key = q/c=c+mathop{{rm{Re}(ab);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="105" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img23.gif"
 ALT="$ c = c + \mathop{\rm Re}(ab) $">|; 

$key = q/r_{i,j}=a_imbox{for{i=0ldots{}n_c-1{};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="203" HEIGHT="29" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img81.gif"
 ALT="$r_{i,j} = a_i   \mbox{for $i = 0\ldots{}n_c-1$}$">|; 

$key = q/c=c+mathop{{rm{Im}(a);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="98" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img17.gif"
 ALT="$ c = c + \mathop{\rm Im}(a) $">|; 

$key = q/c=c-mathop{{rm{Im}(ab);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="105" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img29.gif"
 ALT="$ c = c - \mathop{\rm Im}(ab) $">|; 

$key = q/c=c-mathop{{rm{Im}(ab^*);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="113" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img37.gif"
 ALT="$ c = c - \mathop{\rm Im}(ab^*) $">|; 

$key = q/gamma_5;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img68.gif"
 ALT="$\gamma_5$">|; 

$key = q/c=c+mathop{{rm{Im}(a^*b);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="113" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img43.gif"
 ALT="$ c = c + \mathop{\rm Im}(a^*b) $">|; 

$key = q/c=c+mathop{{rm{Im}(ab);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="105" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img27.gif"
 ALT="$ c = c + \mathop{\rm Im}(ab) $">|; 

$key = q/c=-ambox{(real)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="102" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img11.gif"
 ALT="$ c = -a   \mbox{(real)} $">|; 

$key = q/r=(1+pgamma_d)a;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="105" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img91.gif"
 ALT="$r = (1 + p\gamma_d)a$">|; 

$key = q/c=mathop{{rm{Re}(ab);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="79" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img22.gif"
 ALT="$ c = \mathop{\rm Re}(ab) $">|; 

$key = q/c=abmbox{({b{real)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="108" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img54.gif"
 ALT="$ c = ab   \mbox{($b$ real)} $">|; 

$key = q/r_{i_c,i_s,j_c,j_s}=a_{i_c,i_s}mbox{for{i_c=0ldots{}n_c-1,i_s=0ldots{}3{};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="352" HEIGHT="29" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img85.gif"
 ALT="$r_{i_c,i_s,j_c,j_s} = a_{i_c,i_s}    \mbox{for $i_c = 0\ldots{}n_c-1, i_s = 0\ldots{}3$}$">|; 

$key = q/c=mathop{{rm{Re}(ab^*);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="86" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img30.gif"
 ALT="$ c = \mathop{\rm Re}(ab^*) $">|; 

$key = q/c=ax+bmbox{({a{real)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="138" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img65.gif"
 ALT="$c = ax + b   \mbox{($a$ real)}$">|; 

$key = q/c=mathop{{rm{Im}(ab);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="79" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img26.gif"
 ALT="$ c = \mathop{\rm Im}(ab) $">|; 

$key = q/c=c-abmbox{({b{real)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="135" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img57.gif"
 ALT="$ c = c - ab   \mbox{($b$ real)}$">|; 

$key = q/c=c+mathop{{rm{Re}(a^*b^*);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="120" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img47.gif"
 ALT="$ c = c + \mathop{\rm Re}(a^*b^*) $">|; 

$key = q/r_{i_c,i_s}=a_{i_c}mbox{for{i_c=0ldots{}n_c-1{};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="227" HEIGHT="29" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img83.gif"
 ALT="$r_{i_c,i_s} = a_{i_c}   \mbox{for $i_c = 0\ldots{}n_c-1$}$">|; 

$key = q/r=gamma_da;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="57" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img93.gif"
 ALT="$r = \gamma_d a$">|; 

$key = q/c=c+abmbox{({b{real)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="135" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img55.gif"
 ALT="$ c = c + ab   \mbox{($b$ real)}$">|; 

$key = q/r=a*b^dagger;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="70" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img98.gif"
 ALT="$r = a * b^\dagger$">|; 

$key = q/r=a^dagger;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="48" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img73.gif"
 ALT="$r = a^\dagger$">|; 

$key = q/c=ax+bmbox{({x{real)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="139" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img63.gif"
 ALT="$c = ax + b   \mbox{($x$ real)}$">|; 

$key = q/c=c-mathop{{rm{Re}(a^*b^*);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="120" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img49.gif"
 ALT="$ c = c - \mathop{\rm Re}(a^*b^*) $">|; 

$key = q/r=exp(ia);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="84" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img70.gif"
 ALT="$r = \exp(ia)$">|; 

$key = q/r=sum|a|^2;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="77" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img102.gif"
 ALT="$r = \sum \vert a\vert^2$">|; 

$key = q/c=c-ambox{(real)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="116" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img13.gif"
 ALT="$ c = c - a   \mbox{(real)} $">|; 

$key = q/c=-mathop{{rm{Re}(a^*b);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="101" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img40.gif"
 ALT="$ c = -\mathop{\rm Re}(a^*b) $">|; 

$key = q/c=-mathop{{rm{Re}(ab);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="94" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img24.gif"
 ALT="$ c = -\mathop{\rm Re}(ab) $">|; 

$key = q/r_{i_c,j_c}=sum_{i_s}a_{i_c,i_s,j_c,i_s};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="153" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img90.gif"
 ALT="$r_{i_c,j_c} = \sum_{i_s} a_{i_c,i_s,j_c,i_s}$">|; 

$key = q/c=c+mathop{{rm{Re}(ab^*);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="112" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img31.gif"
 ALT="$ c = c + \mathop{\rm Re}(ab^*) $">|; 

$key = q/c=-mathop{{rm{Im}(a);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="87" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img21.gif"
 ALT="$ c =- \mathop{\rm Im}(a) $">|; 

$key = q/c=mathop{{rm{Im}(a^*b^*);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="94" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img50.gif"
 ALT="$ c = \mathop{\rm Im}(a^*b^*) $">|; 

$key = q/c=-mathop{{rm{Im}(ab);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="94" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img28.gif"
 ALT="$ c = -\mathop{\rm Im}(ab) $">|; 

$key = q/mathop{{rm{Im}c;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="33" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img8.gif"
 ALT="$\mathop{\rm Im}c$">|; 

$key = q/c=c-mathop{{rm{Re}(a^*b);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="112" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img41.gif"
 ALT="$ c = c - \mathop{\rm Re}(a^*b) $">|; 

$key = q/c=c+ambox{(real)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="116" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img12.gif"
 ALT="$ c = c + a   \mbox{(real)} $">|; 

$key = q/r=mathop{{rm{not}a;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="67" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img101.gif"
 ALT="$r = \mathop{\rm not}a$">|; 

$key = q/r_i=mathop{{rm{Re}mathop{{rm{Tr}a^dagger_icdotb_i;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="117" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img96.gif"
 ALT="$r_i = \mathop{\rm Re}\mathop{\rm Tr}a^\dagger_i \cdot b_i$">|; 

$key = q/c=-mathop{{rm{Im}(a^*b^*);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="108" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img52.gif"
 ALT="$ c = -\mathop{\rm Im}(a^*b^*) $">|; 

$key = q/c=mathop{{rm{Im}(ab^*);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="86" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img34.gif"
 ALT="$ c = \mathop{\rm Im}(ab^*) $">|; 

$key = q/r=suma;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img105.gif"
 ALT="$r = \sum a$">|; 

$key = q/c=-abmbox{({b{real)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="121" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img56.gif"
 ALT="$ c = -ab   \mbox{($b$ real)} $">|; 

$key = q/c=mathop{{rm{Re}(a);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="72" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img14.gif"
 ALT="$ c = \mathop{\rm Re}(a) $">|; 

$key = q/c=abmbox{({a{real)};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="110" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img58.gif"
 ALT="$ c = ab   \mbox{($a$ real)} $">|; 

1;

