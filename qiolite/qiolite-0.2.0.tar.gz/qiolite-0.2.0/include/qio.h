#ifndef __INCLUDED_QIO_H__
#define __INCLUDED_QIO_H__
#include <stddef.h>
#ifdef __cplusplus
  extern "C" {
#endif

/* Return codes */
#define QIO_SUCCESS 0
#define QIO_EOF -1
#define QIO_ERR_BAD_WRITE_BYTES -2
#define QIO_ERR_OPEN_READ -3
#define QIO_ERR_OPEN_WRITE -4
#define QIO_ERR_BAD_READ_BYTES -5

/* Enumerate in order of increasing verbosity */
#define QIO_VERB_OFF 0
#define QIO_VERB_LOW 1
#define QIO_VERB_MED 2
#define QIO_VERB_REG 3
#define QIO_VERB_HIGH 4
#define QIO_VERB_DEBUG 5
int QIO_verbose(int level);
int QIO_verbosity(void);

typedef struct {
  char *string;
  size_t length;
} QIO_String;
QIO_String *QIO_string_create(void);
void QIO_string_destroy(QIO_String *qs);
size_t QIO_string_length(QIO_String *qs);
void QIO_string_set(QIO_String *qs, char *str);
char *QIO_string_ptr(QIO_String *qs);
void QIO_string_copy(QIO_String *dest, QIO_String src);
void QIO_string_append(QIO_String *qs, char *const str);

/* Support for host file conversion */
/* type */
#define QIO_SINGLE_PATH 0
#define QIO_MULTI_PATH 1
typedef int (*DML_io_node_t)(int rank);
typedef int (*DML_master_io_node_t)(void);
typedef struct {
  int number_io_nodes;
  int type;
  DML_io_node_t my_io_node;
  DML_master_io_node_t master_io_node;
  int *io_node;
  char *(node_path[]);
} QIO_Filesystem;

/* serpar */
#define QIO_SERIAL 0
#define QIO_PARALLEL 1
/* volfmt */
#define QIO_UNKNOWN -1
#define QIO_SINGLEFILE 0
#define QIO_MULTIFILE 1
#define QIO_PARTFILE 2
#define QIO_PARTFILE_DIR 3
/* mode */
#define QIO_CREAT 0
#define QIO_TRUNC 1
#define QIO_APPEND 2
/* ildgstyle: ILDG style file */
#define QIO_ILDGNO 0
#define QIO_ILDGLAT 1
typedef struct {
  int serpar;
  int volfmt;
} QIO_Iflag;
typedef struct {
  int serpar;
  int mode;
  int ildgstyle;
  QIO_String *ildgLFN;
} QIO_Oflag;

/* recordtype */
#define QIO_FIELD 0
#define QIO_GLOBAL 1
#define QIO_HYPER 2
typedef struct {
  char *version;
  char *date;
  int recordtype;
  int spacetime;
  int *hyperlower;
  int *hyperupper;
  char *datatype;
  char *precision;
  int colors;
  int spins;
  int typesize;
  int datacount;
} QIO_RecordInfo;
QIO_RecordInfo *QIO_create_record_info(int recordtype, int *lower, int *upper, int n, char *datatype, char *precision, int colors, int spins, int typesize, int datacount);
void QIO_destroy_record_info(QIO_RecordInfo *record_info);
char *QIO_get_record_date(QIO_RecordInfo *record_info);
char *QIO_get_datatype(QIO_RecordInfo *record_info);
char *QIO_get_precision(QIO_RecordInfo *record_info);
int QIO_get_colors(QIO_RecordInfo *record_info);
int QIO_get_spins(QIO_RecordInfo *record_info);
int QIO_get_typesize(QIO_RecordInfo *record_info);
int QIO_get_datacount(QIO_RecordInfo *record_info);

typedef struct {
  int (*node_number)(int *coords);
  int (*node_index)(int *coords);
  void (*get_coords)(int *coords, int node, int index);
  int (*num_sites)(int node);
  int *latsize;
  int latdim;
  size_t volume;
  size_t sites_on_node;
  int this_node;
  int number_of_nodes;
} QIO_Layout;
typedef struct {
  QIO_Layout *layout;
  void *reader;
  QIO_RecordInfo record_info;
} QIO_Reader;
typedef struct {
  QIO_Layout *layout;
  void *writer;
} QIO_Writer;
void setRecordInfo(QIO_Reader *qr);
QIO_Reader *QIO_open_read(QIO_String *xml_file, char *filename, QIO_Layout *layout, QIO_Filesystem *fs, QIO_Iflag *iflag);
int QIO_close_read(QIO_Reader *qr);
QIO_Writer *QIO_open_write(QIO_String *xml_file, char *filename, int volfmt, QIO_Layout *layout, QIO_Filesystem *fs, QIO_Oflag *oflag);
int QIO_close_write(QIO_Writer *qw);
int QIO_get_reader_latdim(QIO_Reader *qr);
int *QIO_get_reader_latsize(QIO_Reader *qr);
unsigned int QIO_get_reader_last_checksuma(QIO_Reader *qr);
unsigned int QIO_get_reader_last_checksumb(QIO_Reader *qr);
unsigned int QIO_get_writer_last_checksuma(QIO_Writer *qw);
unsigned int QIO_get_writer_last_checksumb(QIO_Writer *qw);
int QIO_read_record_info(QIO_Reader *qr, QIO_RecordInfo *record_info, QIO_String *xml_record);
int QIO_read_record_data(QIO_Reader *qr, void (*put)(char *buf, size_t index, int count, void *arg), size_t datum_size, int word_size, void *arg);
int QIO_next_record(QIO_Reader *qr);
int QIO_read(QIO_Reader *qr, QIO_RecordInfo *record_info, QIO_String *xml_record, void (*put)(char *buf, size_t index, int count, void *arg), size_t datum_size, int word_size, void *arg);
int QIO_write(QIO_Writer *qw, QIO_RecordInfo *record_info, QIO_String *xml_record, void (*get)(char *buf, size_t index, int count, void *arg), size_t datum_size, int word_size, void *arg);

#ifdef __cplusplus
}
#endif
#endif /* __INCLUDED_QIO_H__*/
