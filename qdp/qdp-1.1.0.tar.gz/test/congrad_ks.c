#include <stdio.h>
#include <qdp.h>
#include "congrad_ks.h"

#define dclock QDP_time

int
congrad(QDP_ColorVector  *result,
	QDP_ColorMatrix  **gauge,
	QDP_ColorVector  *rhs,
	QLA_Real         mass,
	int              max_iter,
	double           epsilon)
{
  QLA_Real eps, a, b, c, d;
  QLA_Real rhs_norm, mass2;
  QDP_ColorVector *r, *p, *Mp, *MMp;
  int i, dscount=0, cgcount=0;
  double dstime=0, cgtime=0;

  prepare_dslash();

  r = QDP_create_V();
  p = QDP_create_V();
  Mp = QDP_create_V();
  MMp = QDP_create_V();

  mass2 = 4*mass*mass;

  QDP_r_eq_norm2_V(&rhs_norm, rhs, QDP_all);
  eps = rhs_norm * epsilon;

  if(QDP_this_node==0) printf("norm=%g  eps=%g\n",rhs_norm,eps);

  do {
    QDP_r_eq_norm2_V(&a,result,QDP_all);
    if(QDP_this_node==0) printf("result norm=%g\n",a);
    //dstime -= dclock();
    dslash(p, gauge, result);
    dslash(r, gauge, p);
    //dstime += dclock();
    //dscount += 2;
    QDP_V_meq_r_times_V(r, &mass2, result, QDP_all);
    QDP_V_peq_V(r, rhs, QDP_all); /* r += rhs */
    QDP_V_eq_V(p, r, QDP_all);
    QDP_r_eq_norm2_V(&c, r, QDP_all);

    cgtime -= dclock();
    for (i = 0; i < max_iter; i++) {
      if(QDP_this_node==0) printf("%6i c=%g\n",i,c);
      if (c < eps) break;

      dstime -= dclock();
      dslash(Mp, gauge, p);
      dslash(MMp, gauge, Mp);
      dstime += dclock();
      dscount += 2;
      QDP_V_meq_r_times_V(MMp, &mass2, p, QDP_all);

      QDP_r_eq_re_V_dot_V(&d, p, MMp, QDP_all);
      a = - c / d;
      QDP_V_peq_r_times_V(result, &a, p, QDP_all);  /* result += a*p */
      QDP_V_peq_r_times_V(r, &a, MMp, QDP_all);  /* r += a*MMp */
      QDP_r_eq_norm2_V(&d, r, QDP_all);
      b = d / c;
      c = d;
      QDP_V_eq_r_times_V_plus_V(p, &b, p, r, QDP_all);  /* p = b*p + r */
      cgcount++;
    }
    cgtime += dclock();
  } while(c>eps);

  QDP_destroy_V(r);
  QDP_destroy_V(p);
  QDP_destroy_V(Mp);
  QDP_destroy_V(MMp);

  //fprintf(stderr,"done free\n");

  cleanup_dslash();

  //fprintf(stderr,"done cleanup\n");
  if(QDP_this_node==0) {
    double dsmflop, cgmflop;
    dsmflop = 0.000570*QDP_sites_on_node;
    cgmflop = 2*dsmflop + 0.000072*QDP_sites_on_node;
    printf("dslash  time = %g  count = %i  mflops = %g\n", dstime, dscount,
           (dsmflop*dscount)/(dstime));
    printf("congrad time = %g  count = %i  mflops = %g\n", cgtime, cgcount,
           (cgmflop*cgcount)/(cgtime));
  }
  return i;
}
