#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <sys/times.h>
#include <unistd.h>
#include "qdp_common_internal.h"
#include "qdp_layout.h"
#include "com_common.h"
#include "com_specific.h"

/*  Exported Globals  */

int QDP_suspended = 0;
int QDP_block_size = 256;

/* Private Globals */

static int qdp_initialized=0;
static QDP_prof *prof_list=NULL, **prof_last;

void
QDP_register_prof(QDP_prof *qp)
{
  *prof_last = qp;
  prof_last = &qp->next;
}

double
QDP_time(void)
{
  struct timeval tp;
  gettimeofday(&tp,NULL);
  return ( (double) tp.tv_sec + (double) tp.tv_usec * 1.e-6 );
  //struct tms buf;
  //times(&buf);
  //return buf.tms_utime + buf.tms_stime;
  //  return (double)clock()/CLOCKS_PER_SEC;
}

int
QDP_initialize(int argc, char *argv[])
{
  if(qdp_initialized) {
    fprintf(stderr,
    	    "error: QDP_initialize() called but QDP already initialized!\n");
    QDP_abort();
  }
  qdp_initialized = 1;
  if(!QDP_comm_initialized()) {
    QDP_initialize_comm(argc, argv);
    qdp_initialized = 2;
  }
  prof_last = &prof_list;
  return 0;
}

void
QDP_finalize(void)
{
  if(!qdp_initialized) {
    fprintf(stderr,"error: QDP_finalize() called but QDP not initialized!\n");
    QDP_abort();
  }
  if((prof_list)&&(QDP_this_node==0)) {
    double s;
    QDP_prof *qp;
    s = 1000.0;
    //s = 1000.0/sysconf(_SC_CLK_TCK);
    *prof_last = NULL;
    qp = prof_list;
    printf("%-29s          time us per ns per\n","");
    printf("%-29s  count   (ms)  call   site  caller:line\n","QDP function");
    printf("----------------------------------------");
    printf("---------------------------------------\n");
    while(qp) {
      if(qp->count) {
	printf("%-29s %6i %6i %6i %6i %s:%i\n", qp->func, qp->count,
	       (int)(s*qp->time+0.5), (int)((1000*s*qp->time/qp->count)+0.5),
	       (int)((1000000*s*qp->time/(qp->nsites))+0.5),
	       qp->caller, qp->line);
	if(0*qp->math_time) {
	  printf("%-29s %6i %6i %6i %6i %s:%i\n", "  -math", qp->count,
		 (int)(s*qp->math_time+0.5),
	       (int)((1000*s*qp->math_time/qp->count)+0.5),
		 (int)((1000000*s*qp->math_time/(qp->nsites))+0.5),
		 qp->caller, qp->line);
	}
	if(qp->comm_time) {
	  printf("%-29s %6i %6i %6i %6i %s:%i\n", "  -comm", qp->count,
		 (int)(s*qp->comm_time+0.5),
		 (int)((1000*s*qp->comm_time/qp->count)+0.5),
		 (int)((1000000*s*qp->comm_time/(qp->nsites))+0.5),
		 qp->caller, qp->line);
	}
      }
      qp = qp->next;
    }
  }
  if(qdp_initialized==2) QDP_finalize_comm();
}

void
QDP_abort(void)
{
  QDP_abort_comm();
  exit(1);
}

void
QDP_suspend_comm(void)
{
  QDP_suspended = 1;
  QDP_clear_shift_list();
}

void
QDP_resume_comm(void)
{
  QDP_suspended = 0;
}

int
QDP_get_block_size(void)
{
  return QDP_block_size;
}

void
QDP_set_block_size(int bs)
{
  if(bs>0) QDP_block_size = bs;
}

/* IO routines */

void
QDP_IO_get_site(char *buf, const int coords[], void *field)
{
  if( QDP_node_number(coords) != QDP_this_node ) {
    buf[0] = '\0';
  } else {
    struct QDP_IO_field *qf = field;
    int i;
    i = QDP_index(coords);
    memcpy(buf, qf->data+i*qf->size, qf->size);
  }
}

void
QDP_IO_put_site(char *buf, const int coords[], void *field)
{
  if( QDP_node_number(coords) == QDP_this_node ) {
    struct QDP_IO_field *qf = field;
    int i;
    i = QDP_index(coords);
    memcpy(qf->data+i*qf->size, buf, qf->size);
  }
}

QDP_Reader *
QDP_open_read(XML_MetaData *md, char *filename, int volfmt, int serpar)
{
  QDP_Reader *qdpr;
  QIO_Layout *layout;

  qdpr = (QDP_Reader *)malloc(sizeof(struct QDP_Reader_struct));
  if(qdpr == NULL) return NULL;

  layout = (QIO_Layout *)malloc(sizeof(QIO_Layout));
  if(layout == NULL) {
    free(qdpr);
    return NULL;
  }

  layout->node_number = QDP_node_number;
  layout->latdim = QDP_ndim();
  layout->latsize = (int *)malloc(layout->latdim*sizeof(int));
  QDP_latsize(layout->latsize);
  layout->volume = QDP_volume();
  layout->this_node = QDP_this_node;

  qdpr->qior = QIO_open_read(md, filename, serpar, layout);

  free(layout->latsize);
  free(layout);

  if(!qdpr->qior) {
    free(qdpr);
    return NULL;
  }

  return qdpr;
}

QDP_Writer *
QDP_open_write(XML_MetaData *md, char *filename, int volfmt, int serpar, 
	       int siteorder, int mode)
{
  QDP_Writer *qdpw;
  QIO_Layout *layout;

  qdpw = (QDP_Writer *)malloc(sizeof(struct QDP_Writer_struct));
  if(qdpw == NULL) return NULL;

  layout = (QIO_Layout *)malloc(sizeof(QIO_Layout));
  if(layout == NULL) {
    free(qdpw);
    return NULL;
  }

  layout->node_number = QDP_node_number;
  layout->latdim = QDP_ndim();
  layout->latsize = (int *)malloc(layout->latdim*sizeof(int));
  QDP_latsize(layout->latsize);
  layout->volume = QDP_volume();
  layout->this_node = QDP_this_node;

  qdpw->qiow = QIO_open_write(md, filename, serpar, siteorder, mode, layout);

  free(layout->latsize);
  free(layout);

  if(!qdpw->qiow) {
    free(qdpw);
    return NULL;
  }

  return qdpw;
}

int
QDP_close_read(QDP_Reader *qdpr)
{
  int status;
  status = QIO_close_read(qdpr->qior);
  free(qdpr);
  return status;
}

int
QDP_close_write(QDP_Writer *qdpw)
{
  int status;
  status = QIO_close_write(qdpw->qiow);
  free(qdpw);
  return status;
}
