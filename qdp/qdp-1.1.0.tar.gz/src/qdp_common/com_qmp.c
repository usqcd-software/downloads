/****************** com_mpi.c ************************************************/
/* Communications routines for QDP/C and MILC modified from MILC version 6.
   This file is communications-scheme dependent.
   QMP version - allegedly machine independent
*/
/*
 Exported Functions:

  QDP_initialize_comm_specific()  does any communications dependent setup
  QDP_finalize_comm_specific()    closes communications
  QDP_abort_comm_specific()       abruptly closes communications

  QDP_comm_type()        returns string describing communications architecture
  QDP_mynode()           returns node number of this node.
  QDP_numnodes()         returns number of nodes

  QDP_barrier()          provides a synchronization point for all nodes.
  QDP_sum_float()        sums a floating point number over all nodes.
  QDP_sum_float_array()  sums an array of floats over all nodes 
  QDP_sum_double()       sums a double over all nodes.
  QDP_sum_double_array() sums an array of doubles over all nodes.
  QDP_global_xor()       finds global exclusive or of long
  QDP_max_float()        finds maximum floating point number over all nodes.
  QDP_max_double()       finds maximum double over all nodes.
  QDP_binary_reduction() binary reduction
  QDP_broadcast()        broadcasts a number of bytes
  QDP_send_bytes()       sends some bytes to one other node.
  QDP_recv_bytes()       receives some bytes from some other node.

  QDP_alloc_mh()         allocate space for message handles
  QDP_free_mh()          free space for message handles
  QDP_alloc_msgmem()     allocate communications buffer
  QDP_free_msgmem()      free communications buffer
  QDP_prepare_send()     prepare to send message
  QDP_prepare_recv()     prepare to receive message
  QDP_prepare_msgs()     prepare message group (multi, if possible)
  QDP_start_send()       start sending messages
  QDP_start_recv()       start receiving messages
  QDP_wait_send()        wait for sent messages
  QDP_wait_recv()        wait for received messages
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "com_specific.h"
#include <qmp.h>


/**********************************************************************
 *                      INTERNAL DATA TYPES                           *
 **********************************************************************/

/* Structure to keep track of outstanding sends and receives */
struct QDP_mh_struct {
  int n;
  QMP_msgmem_t *mmv;
  QMP_msghandle_t *mhv;
  QMP_msghandle_t mh;
};


/**********************************************************************
 *                BASIC COMMUNICATIONS FUNCTIONS                      *
 **********************************************************************/
int QDP_get_msg_passing_type(void)
{
  if(QMP_get_msg_passing_type()==QMP_SWITCH) return QDP_SWITCH;
  return QDP_GRID;
}

int QDP_get_allocated_number_of_dimensions(void) { return (int)QMP_get_allocated_number_of_dimensions(); }
const int* QDP_get_allocated_dimensions(void) { return (int *)QMP_get_allocated_dimensions(); }

/*
**  Communications initialization
*/
void
QDP_initialize_comm_specific(int argc, char **argv)
{
  int err;

  err = QMP_init_msg_passing(&argc, &argv, QMP_SMP_MULTIPLE_ADDRESS);
  if(err!=0) {
    printf("%s\n", QMP_error_string(err));
    printf("com_qmp: Initialize QMP failed.\n");
    fflush(stdout);
    exit(err);
  }
}

/*
**  Communications shutdownw
*/
void
QDP_finalize_comm_specific(void)
{
  QMP_finalize_msg_passing();
}

/*
**  Communications abrupt halt
*/
void
QDP_abort_comm_specific(void)
{
  QMP_finalize_msg_passing();
}

/*
**  Tell what kind of communications we are using
*/
static char name[]="QMP";
char *
QDP_comm_type(void)
{
  return(name);
}

/*
**  Return my node number
*/
int
QDP_mynode(void)
{
  return QMP_get_node_number();
}

/*
**  Return number of nodes
*/
int
QDP_numnodes(void)
{
  return QMP_get_number_of_nodes();
}

/*
**  Synchronize all nodes
*/
void
QDP_barrier(void)
{
  while(QMP_wait_for_barrier(1000)==QMP_TIMEOUT);
}

/*
**  Sum float over all nodes
*/
void
QDP_sum_float(float *fpt)
{
  QMP_sum_float(fpt);
}

/*
**  Sum a array of floats over all nodes
*/
void
QDP_sum_float_array(float *fpt, int nfloats)
{
  QMP_sum_float_array(fpt, nfloats);
}

/*
**  Sum double over all nodes
*/
void
QDP_sum_double(double *dpt)
{
  QMP_sum_double(dpt);
}

/*
**  Sum a array of doubles over all nodes
*/
void
QDP_sum_double_array(double *dpt, int ndoubles)
{
  QMP_sum_double_array(dpt, ndoubles);
}

/*
**  Global exclusive or acting on long
*/
void
QDP_global_xor(long *pt)
{
  long work;
  work = (long)*pt;
  QMP_global_xor(&work);
  *pt = (long)work;
}

/*
**  Find maximum of float over all nodes
*/
void
QDP_max_float(float *fpt)
{
  QMP_max_float(fpt);
}

/*
**  Find maximum of double over all nodes
*/
void
QDP_max_double(double *dpt)
{
  QMP_max_double(dpt);
}

/*
**  Binary reduction
*/
void
QDP_binary_reduction(void *data, int size, void func(void *, void *))
{
  QMP_binary_reduction(data, size, func);
}

/*
**  Broadcast bytes from node 0 to all others
*/
void
QDP_broadcast(char *buf, int size)
{
  QMP_broadcast(buf, size);
}


/********************************************************************
 *                   SEND AND RECEIVE BYTES                         *
 ********************************************************************/

/*
**  send_sytes is to be called only by the node doing the sending
*/
void
QDP_send_bytes(char *buf, int size, int tonode)
{
  void *mbuf;
  QMP_msgmem_t mm;
  QMP_msghandle_t mh;

  mbuf = QMP_allocate_aligned_memory(size);
  memcpy(mbuf, buf, size);
  mm = QMP_declare_msgmem(mbuf, size);
  mh = QMP_declare_send_to(mm, tonode, 0);
  QMP_start(mh);
  QMP_wait(mh);
  QMP_free_msghandle(mh);
  QMP_free_msgmem(mm);
  QMP_free_aligned_memory(mbuf);
}

/*
**  recv_bytes is to be called only by the node to which the bytes were sent
*/
void
QDP_recv_bytes(char *buf, int size, int fromnode)
{
  void *mbuf;
  QMP_msgmem_t mm;
  QMP_msghandle_t mh;

  mbuf = QMP_allocate_aligned_memory(size);
  mm = QMP_declare_msgmem(mbuf, size);
  mh = QMP_declare_receive_from(mm, fromnode, 0);
  QMP_start(mh);
  QMP_wait(mh);
  memcpy(buf, mbuf, size);
  QMP_free_msghandle(mh);
  QMP_free_msgmem(mm);
  QMP_free_aligned_memory(mbuf);
}


/**********************************************************************
 *                         GATHER ROUTINES                            *
 **********************************************************************/

/*
**  allocate space for message handles
*/
QDP_mh *
QDP_alloc_mh(int n)
{
  QDP_mh *mh;

  mh = (QDP_mh *) malloc(sizeof(struct QDP_mh_struct));
  mh->n = n;
  if(n) {
    mh->mmv = (QMP_msgmem_t *) malloc(n*sizeof(QMP_msgmem_t));
    mh->mhv = (QMP_msghandle_t *) malloc(n*sizeof(QMP_msghandle_t));
  } else {
    mh->mmv = NULL;
    mh->mhv = NULL;
  }
  return mh;
}

/*
**  free space for message handles
*/
void
QDP_free_mh(QDP_mh *mh)
{
  int i;

  QMP_free_msghandle(mh->mh);
  for(i=0; i<mh->n; ++i) {
    QMP_free_msghandle(mh->mhv[i]);
    QMP_free_msgmem(mh->mmv[i]);
  }
  free(mh->mhv);
  free(mh->mmv);
  free(mh);
}

/*
**  allocate communications buffer
*/
char *
QDP_alloc_msgmem(int n)
{
  return (char *) QMP_allocate_aligned_memory(n);
}

/*
**  free communications buffer
*/
void
QDP_free_msgmem(char *buf)
{
  QMP_free_aligned_memory(buf);
}

/*
**  prepare to send message
*/
void
QDP_prepare_send(QDP_mh *mh, send_msg_t *sm, int i)
{
  mh->mmv[i] = QMP_declare_msgmem(sm->buf, sm->size);
  mh->mhv[i] = QMP_declare_send_to(mh->mmv[i], sm->node, 0);
}

/*
**  prepare to receive message
*/
void
QDP_prepare_recv(QDP_mh *mh, recv_msg_t *rm, int i)
{
  mh->mmv[i] = QMP_declare_msgmem(rm->buf, rm->size);
  mh->mhv[i] = QMP_declare_receive_from(mh->mmv[i], rm->node, 0);
}

/*
**  prepare message group (multi, if possible)
*/
void
QDP_prepare_msgs(QDP_mh *mh)
{
  mh->mh = QMP_declare_multiple( mh->mhv, mh->n );
}

/*
**  start sending messages
*/
void
QDP_start_send(QDP_msg_tag *mtag, int gather_number)
{
  QMP_start(mtag->mhsend->mh);
}

/*
**  start receiving messages
*/
void
QDP_start_recv(QDP_msg_tag *mtag, int gather_number)
{
  QMP_start(mtag->mhrecv->mh);
}

/*
**  wait for sent messages
*/
void
QDP_wait_send(QDP_msg_tag *mtag)
{
  QMP_wait(mtag->mhsend->mh);
}

/*
**  wait for received messages
*/
void
QDP_wait_recv(QDP_msg_tag *mtag)
{
  QMP_wait(mtag->mhrecv->mh);
}
