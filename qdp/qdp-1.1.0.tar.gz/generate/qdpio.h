#ifndef _QDPIO_H
#define _QDPIO_H

#include <qio.h>

/* volume formats */
#define QDP_SINGLEFILE QIO_SINGLEFILE 
#define QDP_MULTIFILE  QIO_MULTIFILE  

/* serial or parallel */
#define QDP_SERIAL     QIO_SERIAL     
#define QDP_PARALLEL   QIO_PARALLEL   

/* site order */
#define QDP_LEX_ORDER  QIO_LEX_ORDER  
#define QDP_NAT_ORDER  QIO_NAT_ORDER  

/* write mode */
#define QDP_CREATE     QIO_CREATE
#define QDP_TRUNCATE   QIO_TRUNCATE
#define QDP_APPEND     QIO_APPEND

#ifdef __cplusplus
extern "C" {
#endif

typedef struct QDP_Reader_struct QDP_Reader;
typedef struct QDP_Writer_struct QDP_Writer;

QDP_Writer *QDP_open_write(XML_MetaData *xml_file, char *filename, int volfmt,
			   int serpar, int siteorder, int mode);
int QDP_close_write(QDP_Writer *out);

QDP_Reader *QDP_open_read(XML_MetaData *xml_file, char *filename, int volfmt,
                          int serpar);
int QDP_close_read(QDP_Reader *out);

!ALLTYPES
int QDP$PC_read_$ABBR($NC QDP_Reader *out, XML_MetaData *md, $QDPPCTYPE *field);
int QDP$PC_write_$ABBR($NC QDP_Writer *out, XML_MetaData *md, $QDPPCTYPE *field);
!END

#ifdef __cplusplus
}
#endif

#endif /* _QDPIO_H */
