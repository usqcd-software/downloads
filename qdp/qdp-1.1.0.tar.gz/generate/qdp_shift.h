#ifndef _QDP_SHIFT_H
#define _QDP_SHIFT_H

typedef struct QDP_Shift_struct * QDP_Shift;

typedef enum {QDP_forward=0, QDP_backward=1} QDP_ShiftDir;

extern int QDP_this_node;
extern QDP_Shift *QDP_neighbor;

extern QDP_Shift QDP_create_shift(int disp[]);
extern QDP_Shift QDP_create_map(void (*func)(int sx[], int rx[], QDP_ShiftDir fb, void *args), void *args, int argsize);
extern void QDP_destroy_shift(QDP_Shift s);

#endif
