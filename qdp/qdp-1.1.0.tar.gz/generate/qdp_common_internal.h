#ifndef _QDP_COMMON_INTERNAL
#define _QDP_COMMON_INTERNAL

#include "qla_types.h"
#include "qla_complex.h"
#include "qla_random.h"
#include "qdp_types.h"
#include "qdp_common.h"
#include "qdpio.h"
#include "com_common.h"
#include "com_specific.h"

#ifdef __cplusplus
extern "C" {
#endif

struct QDP_Reader_struct {
  QIO_Reader *qior;
};

struct QDP_Writer_struct {
  QIO_Writer *qiow;
};

struct QDP_IO_field {
  char *data;
  int size;
  int nc;
};

typedef struct QDP_shift_list_t {
  struct QDP_shift_src_t *ss;
  struct QDP_shift_list_t *next;
  struct QDP_shift_list_t *prev;
} QDP_shift_list_t;

typedef struct QDP_shift_tag_t {
  int shift_pending;
  int nref;
  int nv;
  QDP_msg_tag *msgtag;
} QDP_shift_tag_t;

typedef struct QDP_shift_src_t {
  QDP_Shift shift;
  int fb;
  QDP_Subset subset;
  char **ptr;
  QDP_shift_tag_t *st;
  QDP_shift_list_t *sl;
  struct QDP_data_common_t *dc;
  struct QDP_shift_src_t *next;
} QDP_shift_src_t;

typedef struct QDP_shift_dest_t {
  struct QDP_data_common_t *dc;
  struct QDP_shift_dest_t *next;
} QDP_shift_dest_t;

typedef struct QDP_data_common_t {
  char **data;
  char ***ptr;
  int size;
  int discarded;
  int exposed;
  QDP_shift_src_t *shift_src;
  QDP_shift_dest_t *shift_dest;
} QDP_data_common_t;

!ALLTYPES
struct $QDPPCTYPE_struct {
  $QLAPCTYPE *data;
  $QLAPCTYPE **ptr;
  QDP_data_common_t dc;
};

!END
extern QDP_msg_tag *QDP_declare_shift(char **dest, char *src, int size, QDP_Shift shift, QDP_ShiftDir fb, QDP_Subset subset);
extern void QDP_declare_accumulate_shift(QDP_msg_tag **mt, char **dest, char *src, int size, QDP_Shift shift, QDP_ShiftDir fb, QDP_Subset subset);
extern void QDP_binary_reduce(void func(), int size, void *data);
extern void QDP_binary_reduce_multi(void func(), int size, void *data, int ns);
extern void QDP_N_binary_reduce(int nc, void func(), int size, void *data);
extern void QDP_N_binary_reduce_multi(int nc, void func(), int size, void *data, int ns);

extern struct QDP_shift_tag_t *QDP_alloc_shift_tag(int nv);
extern void QDP_remove_shift_tag_reference(struct QDP_shift_tag_t *st);
extern void QDP_clear_shift_list(void);
extern void QDP_prepare_destroy(QDP_data_common_t *dc);
extern void QDP_prepare_dest(QDP_data_common_t *dc);
extern void QDP_prepare_src(QDP_data_common_t *dc);
extern int QDP_prepare_shift(QDP_data_common_t *dest_dc, QDP_data_common_t *src_dc, QDP_Shift shift, QDP_ShiftDir fb, QDP_Subset subset);
extern void QDP_switch_ptr_to_data(QDP_data_common_t *dc);

extern int QDP_suspended;

extern int QDP_block_size;

extern void QDP_IO_get_site(char *buf, const int coords[], void *field);
extern void QDP_IO_put_site(char *buf, const int coords[], void *field);

#define QDPIO_size_S(p, nc, ns) sizeof(QLA_RandomState)
#define QDPIO_get_S(NC, p, pc, buf, s, nc, ns) \
  memcpy(buf, s, sizeof(QLA_RandomState))
#define QDPIO_put_S(NC, p, pc, s, buf, nc, ns) \
  memcpy(s, buf, sizeof(QLA_RandomState))

#define QDPIO_size_I(p, nc, ns) sizeof(QLA_Int)
#define QDPIO_get_I(NC, p, pc, buf, s, nc, ns) *((QLA_Int*)buf) = *s
#define QDPIO_put_I(NC, p, pc, s, buf, nc, ns) *s = *((QLA_Int*)buf)

#define QDPIO_size_R(p, nc, ns) sizeof(QLA_##p##_Real)
#define QDPIO_get_R(NC, p, pc, buf, s, nc, ns) *((QLA_##p##_Real*)buf) = *s
#define QDPIO_put_R(NC, p, pc, s, buf, nc, ns) *s = *((QLA_##p##_Real*)buf)

#define QDPIO_size_C(p, nc, ns) sizeof(QLA_##p##_Complex)
#define QDPIO_get_C(NC, p, pc, buf, s, nc, ns) *((QLA_##p##_Complex*)buf) = *s
#define QDPIO_put_C(NC, p, pc, s, buf, nc, ns) *s = *((QLA_##p##_Complex*)buf)

#define QDPIO_size_V(p, nc, ns) (nc*sizeof(QLA_##p##_Complex))
#define QDPIO_get_V(NC, p, pc, buf, s, nc, ns) { \
  int _ic; \
  for(_ic=0; _ic<(nc); ++_ic) { \
    QLA##pc##_C_eq_elem_V(NC ((QLA_##p##_Complex *)buf)+_ic, s, _ic); \
  } \
}
#define QDPIO_put_V(NC, p, pc, s, buf, nc, ns) { \
  int _ic; \
  for(_ic=0; _ic<(nc); ++_ic) { \
    QLA##pc##_V_eq_elem_C(NC s, ((QLA_##p##_Complex *)buf)+_ic, _ic); \
  } \
}

#define QDPIO_size_H(p, nc, ns) ((ns/2)*nc*sizeof(QLA_##p##_Complex))
#define QDPIO_get_H(NC, p, pc, buf, s, nc, ns) { \
  int _ic, _is; \
  for(_ic=0; _ic<(nc); ++_ic) { \
    for(_is=0; _is<(ns); ++_is) { \
      QLA##pc##_C_eq_elem_H(NC ((QLA_##p##_Complex *)buf)+(nc)*_is+_ic, s, _ic, _is); \
    } \
  } \
}
#define QDPIO_put_H(NC, p, pc, s, buf, nc, ns) { \
  int _ic, _is; \
  for(_ic=0; _ic<(nc); ++_ic) { \
    for(_is=0; _is<(ns); ++_is) { \
      QLA##pc##_H_eq_elem_C(NC s, ((QLA_##p##_Complex *)buf)+(nc)*_is+_ic, _ic, _is); \
    } \
  } \
}

#define QDPIO_size_D(p, nc, ns) ((ns)*(nc)*sizeof(QLA_##p##_Complex))
#define QDPIO_get_D(NC, p, pc, buf, s, nc, ns) { \
  int _ic, _is; \
  for(_ic=0; _ic<(nc); ++_ic) { \
    for(_is=0; _is<(ns); ++_is) { \
      QLA##pc##_C_eq_elem_D(NC ((QLA_##p##_Complex *)buf)+_is*(nc)+_ic, s, _ic, _is); \
    } \
  } \
}
#define QDPIO_put_D(NC, p, pc, s, buf, nc, ns) { \
  int _ic, _is; \
  for(_ic=0; _ic<(nc); ++_ic) { \
    for(_is=0; _is<(ns); ++_is) { \
      QLA##pc##_D_eq_elem_C(NC s, ((QLA_##p##_Complex *)buf)+_is*(nc)+_ic, _ic, _is); \
    } \
  } \
}


#define QDPIO_size_M(p, nc, ns) ((nc)*(nc)*sizeof(QLA_##p##_Complex))
#define QDPIO_get_M(NC, p, pc, buf, s, nc, ns) { \
  int _ic, _jc; \
  for(_ic=0; _ic<(nc); ++_ic) { \
    for(_jc=0; _jc<(nc); ++_jc) { \
      QLA##pc##_C_eq_elem_M(NC ((QLA_##p##_Complex *)buf)+_ic*(nc)+_jc, s, _ic, _jc); \
    } \
  } \
}
#define QDPIO_put_M(NC, p, pc, s, buf, nc, ns) { \
  int _ic, _jc; \
  for(_ic=0; _ic<(nc); ++_ic) { \
    for(_jc=0; _jc<(nc); ++_jc) { \
      QLA##pc##_M_eq_elem_C(NC s, ((QLA_##p##_Complex *)buf)+_ic*(nc)+_jc, _ic, _jc); \
    } \
  } \
}

#define QDPIO_size_P(p, nc, ns) ((ns)*(ns)*(nc)*(nc)*sizeof(QLA_##p##_Complex))
#define QDPIO_get_P(NC, p, pc, buf, s, nc, ns) { \
  int _ic, _jc, _is, _js; \
  for(_ic=0; _ic<(nc); ++_ic) { \
    for(_jc=0; _jc<(nc); ++_jc) { \
      for(_is=0; _is<(ns); ++_ic) { \
        for(_js=0; _js<(ns); ++_jc) { \
          QLA##pc##_C_eq_elem_P(NC ((QLA_##p##_Complex *)buf)+((_ic*(ns)+_is)*(nc)+_jc)*(ns)+_js, s, _ic, _is, _jc, _js); \
        } \
      } \
    } \
  } \
}
#define QDPIO_put_P(NC, p, pc, s, buf, nc, ns) { \
  int _ic, _jc, _is, _js; \
  for(_ic=0; _ic<(nc); ++_ic) { \
    for(_jc=0; _jc<(nc); ++_jc) { \
      for(_is=0; _is<(ns); ++_ic) { \
        for(_js=0; _js<(ns); ++_jc) { \
          QLA##pc##_P_eq_elem_C(NC s, ((QLA_##p##_Complex *)buf)+((_ic*(ns)+_is)*(nc)+_jc)*(ns)+_js, _ic, _is, _jc, _js); \
        } \
      } \
    } \
  } \
}

#ifdef __cplusplus
}
#endif

#endif
