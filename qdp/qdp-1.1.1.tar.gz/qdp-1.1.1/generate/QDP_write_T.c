#include <stdlib.h>
#include "qdp_$lib_internal.h"

#undef N
#define N -1
#if ($C+0) == -1
#define NC qf->nc,
#else
#define NC
#endif

static void
QDP$PC_get_$ABBR(char *buf, const int coords[], void *field)
{
  if( QDP_node_number(coords) == QDP_this_node ) {
    struct QDP_IO_field *qf = field;
    $QLAPCTYPE *s;
    s = (($QLAPCTYPE *)(qf->data)) + QDP_index(coords);
    QDPIO_get_$ABBR(NC, $P, $PC, buf, s, qf->nc, QLA_Ns);
  }
}

int
QDP$PC_write_$ABBR($NC QDP_Writer *qdpw, XML_MetaData *md, $QDPPCTYPE *field)
{
  struct QDP_IO_field qf;
  int status;

  QDP_prepare_dest( &field->dc );

  qf.data = (char *) QDP$PC_expose_$ABBR($NCVAR field);
  qf.size = QDPIO_size_$ABBR($P, $QDP_NC, QLA_Ns);
  qf.nc = $QDP_NC;

  status = QIO_write( qdpw->qiow, md, QDP$PC_get_$ABBR, qf.size, (void *)&qf );

  QDP$PC_reset_$ABBR( $NCVAR field );

  return status;
}
