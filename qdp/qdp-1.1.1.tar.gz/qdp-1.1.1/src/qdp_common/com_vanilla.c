/****************** com_vanilla.c ********************************************/
/* Communications routines for QDP/C and MILC modified from MILC version 6.
   This file is communications-scheme dependent.
   Version for single processor machines.
*/
/*
 Exported Functions:

  QDP_initialize_comm_specific()  does any communications dependent setup
  QDP_finalize_comm_specific()    closes communications
  QDP_abort_comm_specific()       abruptly closes communications

  QDP_comm_type()        returns string describing communications architecture
  QDP_mynode()           returns node number of this node.
  QDP_numnodes()         returns number of nodes

  QDP_barrier()          provides a synchronization point for all nodes.
  QDP_sum_float()        sums a floating point number over all nodes.
  QDP_sum_float_array()  sums an array of floats over all nodes 
  QDP_sum_double()       sums a double over all nodes.
  QDP_sum_double_array() sums an array of doubles over all nodes.
  QDP_global_xor()       finds global exclusive or of long
  QDP_max_float()        finds maximum floating point number over all nodes.
  QDP_max_double()       finds maximum double over all nodes.
  QDP_binary_reduction() binary reduction
  QDP_broadcast()        broadcasts a number of bytes
  QDP_send_bytes()       sends some bytes to one other node.
  QDP_recv_bytes()       receives some bytes from some other node.

  QDP_alloc_mh()         allocate space for message handles
  QDP_free_mh()          free space for message handles
  QDP_alloc_msgmem()     allocate communications buffer
  QDP_free_msgmem()      free communications buffer
  QDP_prepare_send()     prepare to send message
  QDP_prepare_recv()     prepare to receive message
  QDP_prepare_msgs()     prepare message group (multi, if possible)
  QDP_start_send()       start sending messages
  QDP_start_recv()       start receiving messages
  QDP_wait_send()        wait for sent messages
  QDP_wait_recv()        wait for received messages
*/

#include <stdlib.h>
#include <stdio.h>
#include "com_specific.h"


/**********************************************************************
 *                      INTERNAL DATA TYPES                           *
 **********************************************************************/

/* Structure to keep track of outstanding sends and receives */
struct QDP_mh_struct {
  int dummy;
};  /* don't need anything */


/**********************************************************************
 *                BASIC COMMUNICATIONS FUNCTIONS                      *
 **********************************************************************/

/*
**  Communications initialization
*/
void
QDP_initialize_comm_specific(int argc, char **argv)
{
}

/*
**  Communications shutdown
*/
void
QDP_finalize_comm_specific(void)
{
}

/*
**  Communications abrupt halt
*/
void
QDP_abort_comm_specific(void)
{
}

/*
**  Tell what kind of communications we are using
*/
static char name[]="Scalar processor";
char *
QDP_comm_type(void)
{
  return(name);
}

/*
**  Return my node number
*/
int
QDP_mynode(void)
{
  return(0);
}

/*
**  Return number of nodes
*/
int
QDP_numnodes(void)
{
  return(1);
}

/*
**  Synchronize all nodes
*/
void
QDP_barrier(void)
{
}

/*
**  Sum float over all nodes
*/
void
QDP_sum_float(float *fpt)
{
}

/*
**  Sum a array of floats over all nodes
*/
void
QDP_sum_float_array(float *fpt, int nfloats)
{
}

/*
**  Sum double over all nodes
*/
void
QDP_sum_double(double *dpt)
{
}

/*
**  Sum a array of doubles over all nodes
*/
void
QDP_sum_double_array(double *dpt, int ndoubles)
{
}

/*
**  Global exclusive or acting on long
*/
void
QDP_global_xor(long *pt)
{
}

/*
**  Find maximum of float over all nodes
*/
void
QDP_max_float(float *fpt)
{
}

/*
**  Find maximum of double over all nodes
*/
void
QDP_max_double(double *dpt)
{
}

/*
**  Binary reduction
*/
void
QDP_binary_reduction(void *data, int size, void func())
{
}

/*
**  Broadcast bytes from node 0 to all others
*/
void
QDP_broadcast(char *buf, int size)
{
}


/********************************************************************
 *                   SEND AND RECEIVE BYTES                         *
 ********************************************************************/

/*
**  send_sytes is to be called only by the node doing the sending
*/
void
QDP_send_bytes(char *buf, int size, int tonode)
{
  printf("ERROR: called send_bytes() in com_vanilla.c\n");
  exit(1);
}

/*
**  recv_bytes is to be called only by the node to which the bytes were sent
*/
void
QDP_recv_bytes(char *buf, int size, int fromnode)
{
  printf("ERROR: called recv_bytes() in com_vanilla.c\n");
  exit(1);
}


/**********************************************************************
 *                         GATHER ROUTINES                            *
 **********************************************************************/

/*
**  allocate space for message handles
*/
QDP_mh *
QDP_alloc_mh(int n)
{
  return (QDP_mh *) NULL;
}

/*
**  free space for message handles
*/
void
QDP_free_mh(QDP_mh *mh)
{
}

/*
**  allocate communications buffer
*/
char *
QDP_alloc_msgmem(int n)
{
  return (char *) NULL;
}

/*
**  free communications buffer
*/
void
QDP_free_msgmem(char *buf)
{
}

/*
**  prepare to send message
*/
void
QDP_prepare_send(QDP_mh *mh, send_msg_t *sm, int i)
{
}

/*
**  prepare to receive message
*/
void
QDP_prepare_recv(QDP_mh *mh, recv_msg_t *rm, int i)
{
}

/*
**  prepare message group (multi, if possible)
*/
void
QDP_prepare_msgs(QDP_mh *mh)
{
}

/*
**  start sending messages
*/
void
QDP_start_send(QDP_msg_tag *mtag, int gather_number)
{
}

/*
**  start receiving messages
*/
void
QDP_start_recv(QDP_msg_tag *mtag, int gather_number)
{
}

/*
**  wait for sent messages
*/
void
QDP_wait_send(QDP_msg_tag *mtag)
{
}

/*
**  wait for received messages
*/
void
QDP_wait_recv(QDP_msg_tag *mtag)
{
}
