/******** layout_hyper.c *********/
/* SciDAC QDP Data Parallel API */
/* adapted from MIMD version 6 */

/* ROUTINES WHICH DETERMINE THE DISTRIBUTION OF SITES ON NODES */

/* This version divides the lattice by factors of prime numbers in any of the
   four directions.  It prefers to divide the longest dimensions,
   which mimimizes the area of the surfaces.  Similarly, it prefers
   to divide dimensions which have already been divided, thus not
   introducing more off-node directions.

        S. Gottlieb, May 18, 1999
        The code will start trying to divide with the largest prime factor
        and then work its way down to 2.  The current maximum prime is 53.
        The array of primes on line 46 may be extended if necessary.

   This requires that the lattice volume be divisible by the number
   of nodes.  Each dimension must be divisible by a suitable factor
   such that the product of the four factors is the number of nodes.

   3/29/00 EVENFIRST is the rule now. CD.
   12/10/00 Fixed so k = MAXPRIMES-1 DT
*/

/*
   QDP_setup_layout()  sets up layout
   QDP_node_number()   returns the node number on which a site lives
   QDP_index()         returns the index of the site on the node
   QDP_get_coords()    gives lattice coords from node & index
*/

#include <stdlib.h>
#include <stdio.h>
#include "qdp_layout.h"
#include "com_specific.h"

static int *squaresize;   /* dimensions of hypercubes */
static int *nsquares;	  /* number of hypercubes in each direction */
static int ndim;
static int prime[] = {2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53};
#define MAXPRIMES (sizeof(prime)/sizeof(int))

void
QDP_setup_layout(int len[], int nd)
{
  int i, j, k, n;

  ndim = nd;
  squaresize = (int *) malloc(ndim*sizeof(int));
  nsquares = (int *) malloc(ndim*sizeof(int));

  /* Figure out dimensions of rectangle */
  for(i=0; i<ndim; ++i) {
    squaresize[i] = len[i];
    nsquares[i] = 1;
  }

  n = QDP_numnodes();   /* remaining number of nodes to be factored */
  k = MAXPRIMES-1;
  while(n>1) {
    /* figure out which prime to divide by starting with largest */
    while( (n%prime[k]!=0) && (k>0) ) --k;

    /* figure out which direction to divide */
    /* find largest divisible dimension of h-cubes */
    /* if one direction with largest dimension has already been
       divided, divide it again.  Otherwise divide first direction
       with largest dimension. */
    j = -1;
    for(i=0; i<ndim; i++) {
      if(squaresize[i]%prime[k]==0) {
	if( (j<0) || (squaresize[i]>squaresize[j]) ) {
	  j = i;
	} else if(squaresize[i]==squaresize[j]) {
	  if(nsquares[j]==1) j = i;
	}
      }
    }

    /* This can fail if we run out of prime factors in the dimensions */
    if(j<0) {
      if(QDP_mynode()==0) {
	fprintf(stderr, "LAYOUT: Not enough prime factors in lattice dimensions\n");
      }
      QDP_abort_comm();
      exit(1);
    }

    /* do the surgery */
    n /= prime[k];
    squaresize[j] /= prime[k];
    nsquares[j] *= prime[k];
  }

  QDP_sites_on_node = 1;
  for(i=0; i<ndim; ++i) {
    QDP_sites_on_node *= squaresize[i];
  }
}

int
QDP_node_number(const int x[])
{
  int i, r=0;

  for(i=ndim-1; i>=0; --i) {
    r = r*nsquares[i] + (x[i]/squaresize[i]);
  }
  return r;
}

int
QDP_index(const int x[])
{
  int i, r=0, p=0;

  for(i=ndim-1; i>=0; --i) {
    r = r*squaresize[i] + (x[i]%squaresize[i]);
    p += x[i];
  }

  if( p%2==0 ) { /* even site */
    r /= 2;
  } else {
    r = (r+QDP_sites_on_node)/2;
  }
  return r;
}

void
QDP_get_coords(int x[], int node, int index)
{
  int i, p, r;

  p = 0;
  index *= 2;
  if( index>=QDP_sites_on_node ) {
    index -= QDP_sites_on_node - 1;
    p = 1;
  }

  r = 0;
  for(i=0; i<ndim; ++i) {
    x[i] = (node%nsquares[i])*squaresize[i] + (index%squaresize[i]);
    r += x[i];
    node /= nsquares[i];
    index /= squaresize[i];
  }

  x[0] += (r&1) - p;
}
