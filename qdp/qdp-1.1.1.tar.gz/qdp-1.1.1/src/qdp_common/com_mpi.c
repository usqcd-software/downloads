/****************** com_mpi.c ************************************************/
/* Communications routines for QDP/C and MILC modified from MILC version 6.
   This file is communications-scheme dependent.
   MPI version - allegedly machine independent
*/
/*
 Exported Functions:

  QDP_initialize_comm_specific()  does any communications dependent setup
  QDP_finalize_comm_specific()    closes communications
  QDP_abort_comm_specific()       abruptly closes communications

  QDP_comm_type()        returns string describing communications architecture
  QDP_mynode()           returns node number of this node.
  QDP_numnodes()         returns number of nodes

  QDP_barrier()          provides a synchronization point for all nodes.
  QDP_sum_float()        sums a floating point number over all nodes.
  QDP_sum_float_array()  sums an array of floats over all nodes 
  QDP_sum_double()       sums a double over all nodes.
  QDP_sum_double_array() sums an array of doubles over all nodes.
  QDP_global_xor()       finds global exclusive or of long
  QDP_max_float()        finds maximum floating point number over all nodes.
  QDP_max_double()       finds maximum double over all nodes.
  QDP_binary_reduction() binary reduction
  QDP_broadcast()        broadcasts a number of bytes
  QDP_send_bytes()       sends some bytes to one other node.
  QDP_recv_bytes()       receives some bytes from some other node.

  QDP_alloc_mh()         allocate space for message handles
  QDP_free_mh()          free space for message handles
  QDP_alloc_msgmem()     allocate communications buffer
  QDP_free_msgmem()      free communications buffer
  QDP_prepare_send()     prepare to send message
  QDP_prepare_recv()     prepare to receive message
  QDP_prepare_msgs()     prepare message group (multi, if possible)
  QDP_start_send()       start sending messages
  QDP_start_recv()       start receiving messages
  QDP_wait_send()        wait for sent messages
  QDP_wait_recv()        wait for received messages
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "com_specific.h"
#include <mpi.h>


/**********************************************************************
 *                      INTERNAL DATA TYPES                           *
 **********************************************************************/

/* Structure to keep track of outstanding sends and receives */
struct QDP_mh_struct {
  MPI_Datatype dt;
  MPI_Request *mreq;     /* message handle returned by system call */
};


/**********************************************************************
 *                BASIC COMMUNICATIONS FUNCTIONS                      *
 **********************************************************************/

void
err_func(MPI_Comm *comm, int *stat, ...)
{
  int len;
  char err_string[MPI_MAX_ERROR_STRING];

  printf("MPI error number: %i\n", *stat);
  MPI_Error_string(*stat, err_string, &len);
  printf("%s\n", err_string);
  QDP_abort_comm_specific();
  exit(1);
}

/*
**  Communications initialization
*/
void
QDP_initialize_comm_specific(int argc, char **argv)
{
  int flag;
  MPI_Comm comm;
  MPI_Errhandler errhandler;

  flag = MPI_Init(&argc, &argv);
  comm = MPI_COMM_WORLD;
  if(flag) err_func(&comm, &flag);
  flag = MPI_Errhandler_create((MPI_Handler_function *)err_func, &errhandler);
  if(flag) err_func(&comm, &flag);
  flag = MPI_Errhandler_set(MPI_COMM_WORLD, errhandler);
  if(flag) err_func(&comm, &flag);
}

/*
**  Communications shutdownw
*/
void
QDP_finalize_comm_specific(void)
{
  MPI_Finalize();
}

/*
**  Communications abrupt halt
*/
void
QDP_abort_comm_specific(void)
{
  MPI_Abort(MPI_COMM_WORLD, 0);
}

/*
**  Tell what kind of communications we are using
*/
static char name[]="MPI (portable)";
char *
QDP_comm_type(void)
{
  return(name);
}

/*
**  Return my node number
*/
int
QDP_mynode(void)
{
  int node;
  MPI_Comm_rank( MPI_COMM_WORLD, &node );
  return(node);
}

/*
**  Return number of nodes
*/
int
QDP_numnodes(void)
{
  int nodes;
  MPI_Comm_size( MPI_COMM_WORLD, &nodes );
  return(nodes);
}

/*
**  Synchronize all nodes
*/
void
QDP_barrier(void)
{
  MPI_Barrier( MPI_COMM_WORLD );
}

/*
**  Sum float over all nodes
*/
void
QDP_sum_float(float *fpt)
{
  float work;
  MPI_Allreduce( fpt, &work, 1, MPI_FLOAT, MPI_SUM, MPI_COMM_WORLD );
  *fpt = work;
}

/*
**  Sum a array of floats over all nodes
*/
void
QDP_sum_float_array(float *fpt, int nfloats)
{
  float *work;
  int i;
  work = (float *)malloc(nfloats*sizeof(float));
  MPI_Allreduce( fpt, work, nfloats, MPI_FLOAT, MPI_SUM, MPI_COMM_WORLD );
  for(i=0; i<nfloats; i++) fpt[i] = work[i];
  free(work);
}

/*
**  Sum double over all nodes
*/
void
QDP_sum_double(double *dpt)
{
  double work;
  MPI_Allreduce( dpt, &work, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD );
  *dpt = work;
}

/*
**  Sum a array of doubles over all nodes
*/
void
QDP_sum_double_array(double *dpt, int ndoubles)
{
  double *work;
  int i;
  work = (double *)malloc(ndoubles*sizeof(double));
  MPI_Allreduce( dpt, work, ndoubles, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD );
  for(i=0; i<ndoubles; i++) dpt[i] = work[i];
  free(work);
}

/*
**  Global exclusive or acting on long
*/
void
QDP_global_xor(long *pt)
{
  long work;
  MPI_Allreduce( pt, &work, 1, MPI_LONG, MPI_BXOR, MPI_COMM_WORLD );
  *pt = work;
}

/*
**  Find maximum of float over all nodes
*/
void
QDP_max_float(float *fpt)
{
  float work;
  MPI_Allreduce( fpt, &work, 1, MPI_FLOAT, MPI_MAX, MPI_COMM_WORLD );
  *fpt = work;
}

/*
**  Find maximum of double over all nodes
*/
void
QDP_max_double(double *dpt)
{
  double work;
  MPI_Allreduce( dpt, &work, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD );
  *dpt = work;
}

static void (*gfunc)();

static void
bfunc(void *invec, void *inoutvec, int *len, MPI_Datatype *datatype)
{
  gfunc(inoutvec, invec);
}

/*
**  Binary reduction
*/
void
QDP_binary_reduction(void *data, int size, void func())
{
  MPI_Op newop;
  void *buf;

  MPI_Op_create(bfunc, 1, &newop);

  buf = (void *) malloc(size);
  memcpy(buf, data, size);

  gfunc = func;
  MPI_Allreduce(buf, data, size, MPI_CHAR, newop, MPI_COMM_WORLD);

  free(buf);
  MPI_Op_free(&newop);
}

/*
**  Broadcast bytes from node 0 to all others
*/
void
QDP_broadcast(char *buf, int size)
{
  MPI_Bcast( buf, size, MPI_BYTE, 0, MPI_COMM_WORLD );
}


/********************************************************************
 *                   SEND AND RECEIVE BYTES                         *
 ********************************************************************/

/*
**  send_sytes is to be called only by the node doing the sending
*/
void
QDP_send_bytes(char *buf, int size, int tonode)
{
  MPI_Send( buf, size, MPI_BYTE, tonode, 0, MPI_COMM_WORLD );
}

/*
**  recv_bytes is to be called only by the node to which the bytes were sent
*/
void
QDP_recv_bytes(char *buf, int size, int fromnode)
{
  MPI_Status status;
  MPI_Recv( buf, size, MPI_BYTE, fromnode, 0, MPI_COMM_WORLD, &status );
}


/**********************************************************************
 *                         GATHER ROUTINES                            *
 **********************************************************************/

/*
**  allocate space for message handles
*/
QDP_mh *
QDP_alloc_mh(int n)
{
  QDP_mh *mh;

  mh = (QDP_mh *) malloc(sizeof(struct QDP_mh_struct));
  if(n) mh->mreq = (MPI_Request *) malloc(n*sizeof(MPI_Request));
  else mh->mreq = NULL;
  return mh;
}

/*
**  free space for message handles
*/
void
QDP_free_mh(QDP_mh *mh)
{
  free(mh->mreq);
  free(mh);
}

/*
**  allocate communications buffer
*/
char *
QDP_alloc_msgmem(int n)
{
  return (char *) malloc(n);
}

/*
**  free communications buffer
*/
void
QDP_free_msgmem(char *buf)
{
  free(buf);
}

/*
**  prepare to send message
*/
void
QDP_prepare_send(QDP_mh *mh, send_msg_t *sm, int i)
{
  if((sm->gmem->next==NULL)&&(sm->gmem->size==sm->gmem->stride)) {
    int i, kb, ke, sb, se, sn, ss, nn=0;
    //printf("%i: %i\n", QDP_this_node, sm->node);
    kb = -1;
    sb = -1;
    for(i=sm->gmem->begin; i<sm->gmem->end; i++) {
      if(kb<0) {
	kb = sm->gmem->sitelist[i];
	ke = kb;
      } else {
	if(sm->gmem->sitelist[i]==(ke+1)) {
	  ke = sm->gmem->sitelist[i];
	} else {
	  //printf("  %i %i\n", kb, ke);
	  if(sb<0) {
	    sb = kb;
	    se = ke;
	    ss = 0;
	    sn = 1;
	    nn++;
	  } else {
	    if( ((se-sb)==(ke-kb)) && (kb>sb) && ( (sn==1)||(sn*ss==kb-sb) ) ) {
	      if(sn==1) ss = kb - sb;
	      sn++;
	    } else {
	      //printf(" %i - %i : %i x %i\n", sb, se, ss, sn);
	      sb = kb;
	      se = ke;
	      ss = 0;
	      sn = 1;
	      nn++;
	    }
	  }
	  kb = sm->gmem->sitelist[i];
	  ke = kb;
	}
      }
    }
    //printf("  %i %i\n", kb, ke);
    if(sb<0) {
      sb = kb;
      se = ke;
      ss = 0;
      sn = 1;
      nn++;
      //printf(" %i - %i : %i x %i\n", sb, se, ss, sn);
    } else {
      if( ((se-sb)==(ke-kb)) && (kb>sb) && ( (sn==1)||(sn*ss==kb-sb) ) ) {
	if(sn==1) ss = kb - sb;
	sn++;
	//printf(" %i - %i : %i x %i\n", sb, se, ss, sn);
      } else {
	//printf(" %i - %i : %i x %i\n", sb, se, ss, sn);
	sb = kb;
	se = ke;
	ss = 0;
	sn = 1;
	nn++;
	//printf(" %i - %i : %i x %i\n", sb, se, ss, sn);
      }
    }
    if(nn==1) {
      //printf(" %i - %i : %i x %i\n", sb, se, ss, sn);
      sm->gmem->sb = sb;
      sm->gmem->se = se;
      sm->gmem->ss = ss;
      sm->gmem->sn = sn;
    } else {
      sm->gmem->sn = 0;
    }
  } else {
    sm->gmem->sn = 0;
  }
  sm->gmem->sn = 0;
  if(sm->gmem->sn!=0) {
    int len, stride;
    len = sm->gmem->size * (sm->gmem->se-sm->gmem->sb+1);
    stride = sm->gmem->size * sm->gmem->ss;
    MPI_Type_vector( sm->gmem->sn, len, stride,
		     MPI_BYTE, &mh->dt );
    MPI_Type_commit( &mh->dt );
  }
}

/*
**  prepare to receive message
*/
void
QDP_prepare_recv(QDP_mh *mh, recv_msg_t *rm, int i)
{
}

/*
**  prepare message group (multi, if possible)
*/
void
QDP_prepare_msgs(QDP_mh *mh)
{
}

/*
**  start sending messages
*/
void
QDP_start_send(QDP_msg_tag *mtag, int gather_number)
{
  int i=0, gid;
  send_msg_t *sm;

  gid = ((gather_number-1) % 255) + 1;

  sm = mtag->send_msgs;
  while(sm!=NULL) {
    if(sm->gmem->sn==0) {
      MPI_Isend( sm->buf, sm->size, MPI_BYTE, sm->node,
		 gid, MPI_COMM_WORLD, &mtag->mhsend->mreq[i] );
    } else {
      char *mb;
      mb = sm->gmem->mem + (sm->gmem->size*sm->gmem->sb);
      MPI_Isend( mb, 1, mtag->mhsend->dt, sm->node,
		 gid, MPI_COMM_WORLD, &mtag->mhsend->mreq[i] );
    }
    ++i;
    sm = sm->next;
  }
}

/*
**  start receiving messages
*/
void
QDP_start_recv(QDP_msg_tag *mtag, int gather_number)
{
  int i=0, gid;
  recv_msg_t *rm;

  gid = ((gather_number-1) % 255) + 1;

  rm = mtag->recv_msgs;
  while(rm!=NULL) {
    MPI_Irecv( rm->buf, rm->size, MPI_BYTE, rm->node,
	       gid, MPI_COMM_WORLD, &mtag->mhrecv->mreq[i] );
    ++i;
    rm = rm->next;
  }
}

/*
**  wait for sent messages
*/
void
QDP_wait_send(QDP_msg_tag *mtag)
{
  MPI_Status status;
  int i;

  for(i=0; i<mtag->nsends; i++) {
    MPI_Wait( &mtag->mhsend->mreq[i], &status );
  }
}

/*
**  wait for received messages
*/
void
QDP_wait_recv(QDP_msg_tag *mtag)
{
  MPI_Status status;
  int i;

  for(i=0; i<mtag->nrecvs; i++) {
    MPI_Wait( &mtag->mhrecv->mreq[i], &status );
  }
}
