/****************** com_common.c *********************************************/
/* Communications routines for QDP/C and MILC modified from MILC version 6.
   This file is communications-scheme independent.
*/
/*
  Exported Functions:

   QDP_initialize_comm()   initializes communications
   QDP_finalize_comm()     closes communications
   QDP_abort_comm()        halts communications

   QDP_make_gather_map()    calculates and stores necessary communications
                             lists for a given gather map function
   QDP_make_gather_shift()  calculates and stores necessary communications
                             lists for a given gather shift displacement
   QDP_free_gather()        destroys a made gather

   QDP_declare_strided_gather()  creates a message tag that defines specific
                                  details of a gather to be used later
   QDP_do_gather()               executes a previously declared gather
   QDP_wait_gather()             waits for gather to finish, insuring that the
                                  data has actually arrived.
   QDP_cleanup_gather()          frees all the buffers that were allocated,
                                  WHICH FREES THE GATHERED DATA.

   QDP_accumulate_gather()       combines gathers into single message tag
   QDP_declare_accumulate_strided_gather()
                                 does declare_gather() and accumulate_gather()
                                  in single step.
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "qdp_layout.h"
#include "com_common.h"
#include "com_common_internal.h"
#include "com_specific.h"

#define NOWHERE -1	/* Not an index in array of fields */


/***************************************************
 *  Global variables for the communications stuff  *
 ***************************************************/

int QDP_this_node = -1;

static int comm_initialized=0;

/* array storing gather setup info */
static QDP_gather *gather_list=NULL, *free_gather_list=NULL;
static int gather_number=1;


/**********************************************************************
 *                BASIC COMMUNICATIONS FUNCTIONS                      *
 **********************************************************************/

/*
**  Communications initialization
*/
void
QDP_initialize_comm(int argc, char **argv)
{
  QDP_initialize_comm_specific(argc, argv);
  QDP_this_node = QDP_mynode();
  comm_initialized = 1;
}

/*
**  normal exit
*/
void
QDP_finalize_comm(void)
{
  QDP_finalize_comm_specific();
}

/*
**  abrupt halt
*/
void
QDP_abort_comm(void)
{
  QDP_abort_comm_specific();
}

/*
**  error exit
*/
static void
QDP_comm_error(void)
{
  QDP_abort_comm();
  exit(1);
}

/*
**  check if communications have been initialized
*/
int
QDP_comm_initialized(void)
{
  return comm_initialized;
}


/**********************************************************************
 *                  FUNCTIONS USED TO MAKE GATHERS                    *
 **********************************************************************/

static QDP_gather *
new_gather()
{
  QDP_gather *g;

  if(free_gather_list==NULL) {
    g = (QDP_gather *) malloc(sizeof(struct QDP_gather_struct));
  } else {
    g = free_gather_list;
    free_gather_list = g->next;
  }
  if((g->next=gather_list)!=NULL) gather_list->prev = g;
  g->prev = NULL;
  gather_list = g;

  return g;
}

static void
free_gather_t(gather_t *gt)
{
  int i;

  for(i=0; i<gt->nrecvs; ++i) {
    free(gt->recvlist[i].sitelist);
  }
  free(gt->recvlist);

  for(i=0; i<gt->nsends; ++i) {
    free(gt->sendlist[i].sitelist);
    free(gt->sendlist[i].destlist);
  }
  free(gt->sendlist);

  free(gt->fromlist);
}

void
QDP_free_gather(QDP_gather *g)
{
  free_gather_t(&g->g[0]);
  if(g->g[1].fromlist) free_gather_t(&g->g[1]);
  if(g->next) g->next->prev = g->prev;
  if(g->prev) g->prev->next = g->next;
  if(gather_list==g) gather_list = g->next;
  g->next = free_gather_list;
  free_gather_list = g;
}

static void
sort_sendlist(int *list, int *key, int n)
{
  int j, k, in1, in2, flag;

  /* bubble sort, if this takes too long fix it later */
  for(j=n-1; j>0; j--) {
    flag=0;
    for(k=0; k<j; k++) {
      in1 = key[k];
      in2 = key[k+1];
      if(in1>in2) {
	flag = 1;
	key[k]   = in2;
	key[k+1] = in1;
	in1 = list[k];
	list[k] = list[k+1];
	list[k+1] = in1;
      }
    }
    if(flag==0) break;
  }
}

static void
make_gather_map_dir(gather_t *gt,
		    void (*func)(int[], int[], QDP_ShiftDir, void *),
		    void *args, QDP_ShiftDir dir)
{
  int i, j;
  int *xr,*xs;		/* coordinates */
  int *ls, *ns, **sl, **dl;

  xs = (int *) malloc(QDP_ndim()*sizeof(int));
  xr = (int *) malloc(QDP_ndim()*sizeof(int));

  ls = (int *) malloc(QDP_numnodes()*sizeof(int));
  ns = (int *) malloc(QDP_numnodes()*sizeof(int));
  sl = (int **) malloc(QDP_numnodes()*sizeof(int *));
  dl = (int **) malloc(QDP_numnodes()*sizeof(int *));
  for(i=0; i<QDP_numnodes(); ++i) {
    ls[i] = 0;
    ns[i] = 0;
    sl[i] = NULL;
  }

  gt->fromlist = (int *)malloc( QDP_sites_on_node*sizeof(int) );
  if( gt->fromlist==NULL ) {
    printf("make_gather: NODE %d: no room for fromlist array\n",QDP_this_node);
    QDP_comm_error();
  }

  /* RECEIVE LISTS */
  gt->nrecvs = 0;
  for(i=0; i<QDP_sites_on_node; ++i) {
    QDP_get_coords(xr, QDP_this_node, i);
    func(xr, xs, dir, args);
    j = QDP_node_number(xs);
    if( j==QDP_mynode() ) {
      gt->fromlist[i] = QDP_index(xs);
    } else {
      gt->fromlist[i] = NOWHERE;
      if(ns[j]==0) ++gt->nrecvs;
      if(ns[j]>=ls[j]) {
	ls[j] += 16;
	sl[j] = (int *) realloc(sl[j], ls[j]*sizeof(int));
      }
      sl[j][ns[j]] = i;
      ++ns[j];
    }
  }

  if(gt->nrecvs) {
    gt->recvlist = (recvlist_t *) malloc(gt->nrecvs*sizeof(recvlist_t));
    j = 0;
    for(i=0; i<QDP_numnodes(); ++i) {
      if(ns[i]) {
	gt->recvlist[j].node = i;
	gt->recvlist[j].nsites = ns[i];
	gt->recvlist[j].sitelist = sl[i];
	++j;
      }
    }
  } else {
    gt->recvlist = NULL;
  }

  /* SEND LISTS: */
  for(i=0; i<QDP_numnodes(); ++i) {
    ls[i] = 0;
    ns[i] = 0;
    sl[i] = NULL;
    dl[i] = NULL;
  }
  dir = (QDP_forward+QDP_backward) - dir;
  gt->nsends = 0;
  for(i=0; i<QDP_sites_on_node; ++i) {
    QDP_get_coords(xs, QDP_this_node, i);
    func(xs, xr, dir, args);
    j = QDP_node_number(xr);
    if( j!=QDP_mynode() ) {
      if(ns[j]==0) ++gt->nsends;
      if(ns[j]>=ls[j]) {
	ls[j] += 16;
	sl[j] = (int *) realloc(sl[j], ls[j]*sizeof(int));
	dl[j] = (int *) realloc(dl[j], ls[j]*sizeof(int));
      }
      sl[j][ns[j]] = i;
      dl[j][ns[j]] = QDP_index(xr);
      ++ns[j];
    }
  }

  if(gt->nsends) {
    gt->sendlist = (sendlist_t *) malloc(gt->nsends*sizeof(sendlist_t));
    j = 0;
    for(i=0; i<QDP_numnodes(); ++i) {
      if(ns[i]) {
	sort_sendlist(sl[i], dl[i], ns[i]);
	gt->sendlist[j].node = i;
	gt->sendlist[j].nsites = ns[i];
	gt->sendlist[j].sitelist = sl[i];
	gt->sendlist[j].destlist = dl[i];
	++j;
      }
    }
  } else {
    gt->sendlist = NULL;
  }

  free(dl);
  free(sl);
  free(ns);
  free(ls);
  free(xr);
  free(xs);
}

/*
**  add another gather to the list of tables
*/
QDP_gather *
QDP_make_gather_map(
  void (*func)(int[], int[], QDP_ShiftDir, void *),
                        /* function which defines sites to gather from */
  void *args,		/* list of arguments, to be passed to function */
  int argsize,
  int inverse)		/* OWN_INVERSE, WANT_INVERSE, or NO_INVERSE */
{
  QDP_gather *g;        /* gather being created */

  g = new_gather();

  make_gather_map_dir(&g->g[0], func, args, QDP_forward);

  if( inverse == QDP_NO_INVERSE ) {
    g->g[1].fromlist = NULL;
    g->g[1].recvlist = NULL;
    g->g[1].sendlist = NULL;
  } else {
    make_gather_map_dir(&g->g[1], func, args, QDP_backward);
  }

  return(g);
}

static void
disp_func(int x[], int t[], QDP_ShiftDir fb, void *args)
{
  int i;

  if(fb==QDP_forward) {
    for(i=0; i<QDP_ndim(); ++i) {
      t[i] = (QDP_coord_size(i)*abs(((int*)args)[i])+x[i]+((int*)args)[i])%QDP_coord_size(i);
    }
  } else {
    for(i=0; i<QDP_ndim(); ++i) {
      t[i] = (QDP_coord_size(i)*abs(((int*)args)[i])+x[i]-((int*)args)[i])%QDP_coord_size(i);
    }
  }
}

/*
**  add another gather to the list of tables from displacement
*/
QDP_gather *
QDP_make_gather_shift(
  int disp[],		/* displacement */
  int inverse)		/* OWN_INVERSE, WANT_INVERSE, or NO_INVERSE */
{
  return QDP_make_gather_map(disp_func, (void *)disp, QDP_ndim()*sizeof(int),
			     inverse);
}


/**********************************************************************
 *                         GATHER ROUTINES                            *
 **********************************************************************

 QDP_declare_strided_gather() returns a pointer to msg_tag which will
   be used as input to subsequent prepare_gather() (optional), do_gather(),
   wait_gather() and cleanup_gather() calls.

 QDP_prepare_gather() allocates buffers needed for the gather.  This call is
   optional since it will automatically be called from do_gather() if
   not explicitly called before.

 QDP_do_gather() starts the actual gather.  This may be repeated after a
    QDP_wait_gather() to repeat the exact same gather.

 QDP_wait_gather() waits for the gather to finish.

 QDP_cleanup_gather() frees memory associated with the QDP_msg_tag.

*/

recv_msg_t *
alloc_rm(void)
{
  return (recv_msg_t *) malloc(sizeof(recv_msg_t));
}

send_msg_t *
alloc_sm(void)
{
  return (send_msg_t *) malloc(sizeof(send_msg_t));
}

gmem_t *
alloc_gmem(void)
{
  return (gmem_t *) malloc(sizeof(gmem_t));
}

int
make_recv_msg(recv_msg_t ***pprm, recvlist_t *rl, QDP_Subset subset,
	      char **mem, int size, char *src)
{
  int n=0;

  if(subset->indexed) {
    int i, j=0, len=0;

    for(i=0; i<subset->len; ++i) {
      while((j<rl->nsites)&&(rl->sitelist[j]<subset->index[i])) ++j;
      if(j>=rl->nsites) break;
      if(rl->sitelist[j]==subset->index[i]) ++len;
    }

    if(len!=0) {
      recv_msg_t *rm;
      rm = alloc_rm();
      rm->node = rl->node;
      rm->size = len*size;
      rm->buf = NULL;
      rm->gmem = alloc_gmem();
      rm->gmem->next = NULL;
      rm->gmem->src = src;
      rm->gmem->offset = 0;
      rm->gmem->mem = (char *)mem;
      rm->gmem->stride = sizeof(char *);
      rm->gmem->size = size;
      rm->gmem->begin = 0;
      rm->gmem->end = len;
      rm->gmem->sitelist = (int *) malloc(len*sizeof(int));
      rm->gmem->sitelist_allocated = 1;
      **pprm = rm;
      *pprm = &rm->next;
      n = 1;
      j = 0;
      len = 0;
      for(i=0; i<subset->len; ++i) {
	while((j<rl->nsites)&&(rl->sitelist[j]<subset->index[i])) ++j;
	if(j>=rl->nsites) break;
	if(rl->sitelist[j]==subset->index[i]) {
	  rm->gmem->sitelist[len] = rl->sitelist[j];
	  ++len;
	}
      }
    }

  } else {
    int i, j;

    i = 0;
    while( ( i < rl->nsites ) &&
	   ( rl->sitelist[i] < subset->offset ) ) i++;
    j = i;
    while( ( j < rl->nsites ) &&
	   ( rl->sitelist[j] < subset->offset+subset->len ) ) j++;

    if(j!=i) {
      recv_msg_t *rm;
      rm = alloc_rm();
      rm->node = rl->node;
      rm->size = (j-i)*size;
      rm->buf = NULL;
      rm->gmem = alloc_gmem();
      rm->gmem->next = NULL;
      rm->gmem->src = src;
      rm->gmem->offset = 0;
      rm->gmem->mem = (char *)mem;
      rm->gmem->stride = sizeof(char *);
      rm->gmem->size = size;
      rm->gmem->begin = i;
      rm->gmem->end = j;
      rm->gmem->sitelist = rl->sitelist;
      rm->gmem->sitelist_allocated = 0;
      **pprm = rm;
      *pprm = &rm->next;
      n = 1;
    }
  }
  return n;
}

int
make_send_msg(send_msg_t ***ppsm, sendlist_t *sl, QDP_Subset subset,
	      char *mem, int stride, int size)
{
  int n=0;

  if(subset->indexed) {
    int i, j=0, len=0;

    for(i=0; i<subset->len; ++i) {
      while((j<sl->nsites)&&(sl->destlist[j]<subset->index[i])) ++j;
      if(j>=sl->nsites) break;
      if(sl->destlist[j]==subset->index[i]) ++len;
    }

    if(len!=0) {
      send_msg_t *sm;
      sm = alloc_sm();
      sm->node = sl->node;
      sm->size = len*size;
      sm->buf = NULL;
      sm->gmem = alloc_gmem();
      sm->gmem->next = NULL;
      sm->gmem->mem = mem;
      sm->gmem->stride = stride;
      sm->gmem->size = size;
      sm->gmem->begin = 0;
      sm->gmem->end = len;
      sm->gmem->sitelist = (int *) malloc(len*sizeof(int));
      sm->gmem->sitelist_allocated = 1;
      **ppsm = sm;
      *ppsm = &sm->next;
      n = 1;
      j = 0;
      len = 0;
      for(i=0; i<subset->len; ++i) {
	while((j<sl->nsites)&&(sl->destlist[j]<subset->index[i])) ++j;
	if(j>=sl->nsites) break;
	if(sl->destlist[j]==subset->index[i]) {
	  sm->gmem->sitelist[len] = sl->sitelist[j];
	  ++len;
	}
      }
    }

  } else {
    int i, j;

    i = 0;
    while( ( i < sl->nsites ) &&
	   ( sl->destlist[i] < subset->offset ) ) i++;
    j = i;
    while( ( j < sl->nsites ) &&
	   ( sl->destlist[j] < subset->offset+subset->len ) ) j++;

    if(j!=i) {
      send_msg_t *sm;
      sm = alloc_sm();
      sm->node = sl->node;
      sm->size = (j-i)*size;
      sm->buf = NULL;
      sm->gmem = alloc_gmem();
      sm->gmem->next = NULL;
      sm->gmem->mem = mem;
      sm->gmem->stride = stride;
      sm->gmem->size = size;
      sm->gmem->begin = i;
      sm->gmem->end = j;
      sm->gmem->sitelist = sl->sitelist;
      sm->gmem->sitelist_allocated = 0;
      **ppsm = sm;
      *ppsm = &sm->next;
      n = 1;
    }
  }
  return n;
}

/*
**  returns msg_tag containing details for specific gather
**  handles gathers from both field offset and temp
*/
QDP_msg_tag *
QDP_declare_strided_gather(
  char *src,	        /* source buffer aligned to desired field */
  int stride,           /* bytes between source fields in source buffer */
  int size,		/* size in bytes of the source field */
  QDP_gather *g,        /* gather to do */
  QDP_ShiftDir fb,      /* forwards or backwards */
  QDP_Subset subset,	/* subset of sites to gather to */
  char **dest)		/* array of pointers for result */
{
  int i, j;	        /* scratch */
  QDP_msg_tag *mtag;	/* message tag structure we will return a pointer to */
  recv_msg_t **rm;
  send_msg_t **sm;
  gather_t *gt;         /* pointer to current gather */

  gt = &g->g[fb];

  /* set pointers in sites whose neighbors are on this node */
  if(subset->indexed) {
    for(i=0; i<subset->len; ++i) {
      j = subset->index[i];
      if(gt->fromlist[j] != NOWHERE) {
	dest[j] = src + gt->fromlist[j]*stride;
      }
    }
  } else {
    i = subset->offset + subset->len;
    for(j=subset->offset; j<i; ++j) {
      if(gt->fromlist[j] != NOWHERE) {
	dest[j] = src + gt->fromlist[j]*stride;
      }
    }
  }

  /*  allocate the message tag */
  mtag = (QDP_msg_tag *)malloc(sizeof(QDP_msg_tag));
  mtag->prepared = 0;

  mtag->nrecvs = 0;
  rm = &mtag->recv_msgs;
  for(i=0; i<gt->nrecvs; ++i) {
    mtag->nrecvs += make_recv_msg(&rm, &gt->recvlist[i], subset, dest, size,
				  src);
  }
  *rm = NULL;

  mtag->nsends = 0;
  sm = &mtag->send_msgs;
  for(i=0; i<gt->nsends; ++i) {
    mtag->nsends += make_send_msg(&sm, &gt->sendlist[i], subset,
				  src, stride, size);
  }
  *sm = NULL;

  return mtag;
}

/*
**  allocate buffers for gather
*/
static void
prepare_gather(QDP_msg_tag *mtag)
{
  int i, j;
  recv_msg_t *rm;
  send_msg_t *sm;
  gmem_t *gmem;
  char *tpt;

  mtag->prepared = 1;

  mtag->mhrecv = QDP_alloc_mh(mtag->nrecvs);
  rm = mtag->recv_msgs;
  j = 0;
  /* for each node which has neighbors of my sites */
  while(rm!=NULL) {
    rm->buf = QDP_alloc_msgmem( rm->size );
    QDP_prepare_recv(mtag->mhrecv, rm, j);
    /* set pointers in sites to correct location */
    gmem = rm->gmem;
    tpt = rm->buf;
    do {
      for(i=gmem->begin; i<gmem->end; ++i, tpt+=gmem->size) {
	((char **)gmem->mem)[gmem->sitelist[i]] = tpt;
      }
    } while((gmem=gmem->next)!=NULL);
    rm = rm->next;
    ++j;
  }
  QDP_prepare_msgs(mtag->mhrecv);

  mtag->mhsend = QDP_alloc_mh(mtag->nsends);
  sm = mtag->send_msgs;
  j = 0;
  /* for each node whose neighbors I have */
  while(sm!=NULL) {
    sm->buf = (char *)QDP_alloc_msgmem( sm->size );
    QDP_prepare_send(mtag->mhsend, sm, j);
    sm = sm->next;
    ++j;
  }
  QDP_prepare_msgs(mtag->mhsend);
}

/*
**  actually execute the gather
*/
void
QDP_do_gather(QDP_msg_tag *mtag)  /* previously returned by start_gather */
{
  int i;	/* scratch */
  char *tpt;	/* scratch pointer in buffers */
  send_msg_t *sm;
  gmem_t *gmem;

  if(!mtag->prepared) prepare_gather(mtag);

  if(mtag->nrecvs>0) QDP_start_recv(mtag, gather_number);

  sm = mtag->send_msgs;
  /* for each node whose neighbors I have */
  while(sm!=NULL) {
    /* gather data into the buffer */
    tpt = sm->buf;
    gmem = sm->gmem;
    do {
      for(i=gmem->begin; i<gmem->end; ++i,tpt+=gmem->size) {
	memcpy( tpt, gmem->mem + gmem->sitelist[i]*gmem->stride, gmem->size );
      }
    } while((gmem=gmem->next)!=NULL);
    /* start the send */
    sm = sm->next;
  }
  if(mtag->nsends>0) QDP_start_send(mtag, gather_number);
  ++gather_number;
}

/*
**  wait for gather to finish
*/
void
QDP_wait_gather(QDP_msg_tag *mtag)
{
  /* wait for all receive messages */
  if(mtag->nrecvs>0) QDP_wait_recv( mtag );

  /* wait for all send messages */
  if(mtag->nsends>0) QDP_wait_send( mtag );
}

/*
**  free buffers associated with message tag
*/
void
QDP_cleanup_gather(QDP_msg_tag *mtag)
{
  gmem_t *gmem, *next;
  recv_msg_t *rm, *rml;
  send_msg_t *sm, *sml;

  /* free all receive buffers */
  if(mtag->prepared) QDP_free_mh( mtag->mhrecv );
  rm = mtag->recv_msgs;
  while(rm!=NULL) {
    if(mtag->prepared) QDP_free_msgmem( rm->buf );
    gmem = rm->gmem;
    do {
      if(gmem->sitelist_allocated) free(gmem->sitelist);
      next = gmem->next;
      free(gmem);
      gmem = next;
    } while(gmem!=NULL);
    rml = rm;
    rm = rm->next;
    free(rml);
  }

  /*  free all send buffers */
  if(mtag->prepared) QDP_free_mh( mtag->mhsend );
  sm = mtag->send_msgs;
  while(sm!=NULL) {
    if(mtag->prepared) QDP_free_msgmem( sm->buf );
    gmem = sm->gmem;
    do {
      if(gmem->sitelist_allocated) free(gmem->sitelist);
      next = gmem->next;
      free(gmem);
      gmem = next;
    } while(gmem!=NULL);
    sml = sm;
    sm = sm->next;
    free(sml);
  }

  free(mtag);
}


/**********************************************************************
 *                      MULTI-GATHER ROUTINES                         *
 **********************************************************************

 QDP_accumulate_gather(QDP_msg_tag **mtag, QDP_msg_tag *tag)
   Joins declared gathers together under a single msg_tag.
   The second argument (tag) would be merged with the first (mtag).
   If mtag is NULL then this just copies tag into mtag.

 QDP_declare_accumulate_strided_gather() declares and joins gathers.

*/

/*
**  helper function to copy the QDP_gmem_t structure
*/
static void
add_recv_gmem(gmem_t **dest, gmem_t *src)
{
  gmem_t **dgm, *gm;

  do {
    dgm = dest;
    if(*dgm!=NULL) {
      do {
	if((*dgm)->src==src->src) {
	  while( (*dgm!=NULL) && ((*dgm)->src==src->src) &&
		 ((*dgm)->end-(*dgm)->begin>=src->end-src->begin) )
	    dgm = &(*dgm)->next;
	  break;
	}
	dgm = &(*dgm)->next;
      } while(*dgm!=NULL);
    }
    gm = (gmem_t *)malloc(sizeof(gmem_t));
    if(gm==NULL) {
      printf("error copy_gmem malloc node:%i\n", QDP_mynode());
      QDP_comm_error();
    }
    memcpy(gm, src, sizeof(gmem_t));
    gm->next = *dgm;
    *dgm = gm;
    src = src->next;
  } while(src!=NULL);
}

/*
**  helper function that merges a source recv_msg_t structure into the dest
*/
static void
add_recv_msg(QDP_msg_tag *amtag, QDP_msg_tag *mtag)
{
  recv_msg_t *arm, *rm;

  rm = mtag->recv_msgs;
  while(rm!=NULL) {
    arm = amtag->recv_msgs;
    while(1) {
      if(arm==NULL) {
	arm = (recv_msg_t *) malloc(sizeof(recv_msg_t));
	arm->next = amtag->recv_msgs;
	amtag->recv_msgs = arm;
	arm->node = rm->node;
	arm->size = rm->size;
	arm->gmem = NULL;
	amtag->nrecvs++;
	break;
      }
      if(arm->node==rm->node) {
	arm->size += rm->size;
	break;
      }
      arm = arm->next;
    }
    add_recv_gmem( &arm->gmem, rm->gmem );
    rm = rm->next;
  }
}

/*
**  helper function to copy the QDP_gmem_t structure
*/
static void
add_send_gmem(gmem_t **dest, gmem_t *src)
{
  gmem_t **dgm, *gm;

  do {
    dgm = dest;
    if(*dgm!=NULL) {
      do {
	if((*dgm)->mem==src->mem) {
	  while( (*dgm!=NULL) && ((*dgm)->mem==src->mem) &&
		 ((*dgm)->end-(*dgm)->begin>=src->end-src->begin) )
	    dgm = &(*dgm)->next;
	  break;
	}
	dgm = &(*dgm)->next;
      } while(*dgm!=NULL);
    }
    gm = (gmem_t *)malloc(sizeof(gmem_t));
    if(gm==NULL) {
      printf("error copy_gmem malloc node:%i\n", QDP_mynode());
      QDP_comm_error();
    }
    memcpy(gm, src, sizeof(gmem_t));
    gm->next = *dgm;
    *dgm = gm;
    src = src->next;
  } while(src!=NULL);
}

/*
**  helper function that merges a source send_msg_t structure into the dest
*/
static void
add_send_msg(QDP_msg_tag *amtag, QDP_msg_tag *mtag)
{
  send_msg_t *sma, *sm;

  sm = mtag->send_msgs;
  while(sm!=NULL) {
    sma = amtag->send_msgs;
    while(1) {
      if(sma==NULL) {
	sma = (send_msg_t *) malloc(sizeof(send_msg_t));
	sma->next = amtag->send_msgs;
	amtag->send_msgs = sma;
	sma->node = sm->node;
	sma->size = sm->size;
	sma->gmem = NULL;
	amtag->nsends++;
	break;
      }
      if(sma->node==sm->node) {
	sma->size += sm->size;
	break;
      }
      sma = sma->next;
    }
    add_send_gmem( &sma->gmem, sm->gmem );
    sm = sm->next;
  }
}

/*
**  merges already declared gather
*/
void
QDP_accumulate_gather(QDP_msg_tag **mmtag, QDP_msg_tag *mtag)
{
  QDP_msg_tag *amtag;

  if(*mmtag==NULL) {
    amtag = (QDP_msg_tag *)malloc(sizeof(QDP_msg_tag));
    if(amtag==NULL) {
      printf("error accumulate_gather malloc node:%i\n", QDP_mynode());
      QDP_comm_error();
    }
    amtag->nrecvs = 0;
    amtag->recv_msgs = NULL;
    amtag->nsends = 0;
    amtag->send_msgs = NULL;
    *mmtag = amtag;
  } else {
    amtag = *mmtag;
  }

  add_recv_msg( amtag, mtag );
  add_send_msg( amtag, mtag );
}

/*
**  declares and merges gather
**  handles both field offset and temp
*/
void
QDP_declare_accumulate_strided_gather(
  QDP_msg_tag **mmtag,      /* tag to accumulate gather into */
  char *field,	        /* which field? Some member of structure "site" */
  int stride,           /* bytes between fields in source buffer */
  int size,		/* size in bytes of the field (eg sizeof(su3_vector))*/
  QDP_gather *g,        /* gather to do */
  QDP_ShiftDir fb,      /* forwards or backwards */
  QDP_Subset subset,	/* parity of sites whose neighbors we gather.
			   one of EVEN, ODD or EVENANDODD. */
  char **dest)		/* one of the vectors of pointers */
{
  QDP_msg_tag *mtag;

  mtag = QDP_declare_strided_gather(field, stride, size, g, fb, subset, dest);
  if(*mmtag==NULL) {
    *mmtag = mtag;
  } else {
    QDP_accumulate_gather( mmtag, mtag );
    QDP_cleanup_gather( mtag );
  }
}
