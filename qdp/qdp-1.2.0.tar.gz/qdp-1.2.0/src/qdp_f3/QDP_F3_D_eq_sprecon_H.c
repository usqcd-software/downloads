/*
 *  Type conversion and component extraction and insertion
 *
 *  Dirac spin reconstruction
 */

#include "qdp_f3_internal.h"

void
QDP_F3_D_eq_sprecon_H( QDP_F3_DiracFermion *__restrict__ dest, QDP_F3_HalfFermion *src, int dir, int sign, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src->dc);

  if( subset->indexed ) {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F3_D_xeq_sprecon_pH( dest->data, src->ptr, dir, sign, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F3_D_xeq_sprecon_H( dest->data, src->data, dir, sign, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    }
  } else {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F3_D_veq_sprecon_pH( dest->data+subset->offset, src->ptr+subset->offset, dir, sign, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F3_D_veq_sprecon_H( dest->data+subset->offset, src->data+subset->offset, dir, sign, subset->len );
      //QDP_math_time += QDP_time();
    }
  }
}
