/*
 *  Unary Operations
 *
 *  Complex conjugate
 */

#include "qdp_f3_internal.h"

void
QDP_F3_D_meq_conj_D( QDP_F3_DiracFermion *__restrict__ dest, QDP_F3_DiracFermion *src, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src->dc);

  if( subset->indexed ) {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F3_D_xmeq_conj_pD( dest->data, src->ptr, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F3_D_xmeq_conj_D( dest->data, src->data, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    }
  } else {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F3_D_vmeq_conj_pD( dest->data+subset->offset, src->ptr+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F3_D_vmeq_conj_D( dest->data+subset->offset, src->data+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    }
  }
}
