/*
 *  Fills and random numbers
 *
 *  Zero fills
 */

#include "qdp_f3_internal.h"

void
QDP_F3_D_eq_zero( QDP_F3_DiracFermion *__restrict__ dest, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);

  if( subset->indexed ) {
    QLA_F3_D_xeq_zero( dest->data, subset->index, subset->len );
  } else {
    QLA_F3_D_veq_zero( dest->data+subset->offset, subset->len );
  }
}
