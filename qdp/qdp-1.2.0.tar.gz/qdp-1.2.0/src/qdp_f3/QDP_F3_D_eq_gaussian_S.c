/*
 *  Fills and random numbers
 *
 *  Gaussian random number fills
 */

#include "qdp_f3_internal.h"

void
QDP_F3_D_eq_gaussian_S( QDP_F3_DiracFermion *__restrict__ dest, QDP_RandomState *src, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src->dc);

  if( subset->indexed ) {
    QLA_F3_D_xeq_gaussian_S( dest->data, src->data, subset->index, subset->len );
  } else {
    QLA_F3_D_veq_gaussian_S( dest->data+subset->offset, src->data+subset->offset, subset->len );
  }
}
