/*
 *  Fills and random numbers
 *
 *  Constant fills
 */

#include "qdp_f3_internal.h"

void
QDP_F3_H_eq_h( QDP_F3_HalfFermion *__restrict__ dest, QLA_F3_HalfFermion *src, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);

  if( subset->indexed ) {
    QLA_F3_H_xeq_h( dest->data, src, subset->index, subset->len );
  } else {
    QLA_F3_H_veq_h( dest->data+subset->offset, src, subset->len );
  }
}
