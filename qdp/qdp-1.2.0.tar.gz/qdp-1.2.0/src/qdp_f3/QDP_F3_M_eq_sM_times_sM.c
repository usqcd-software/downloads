#include "qdp_f3.h"
#include "qdp_f3_internal.h"
#include "com_common.h"
#include "com_common_internal.h"

#define fvpp QLA_F3_M_veq_pM_times_pM
#define fxpp QLA_F3_M_xeq_pM_times_pM

void
QDP_F3_M_eq_sM_times_sM(QDP_F3_ColorMatrix *__restrict__ dest, QDP_F3_ColorMatrix *src1, QDP_F3_ColorMatrix *src2, QDP_Shift shift, int fb, QDP_Subset subset)
{
  char **temp1, **temp2;
  QDP_msg_tag *mtag1, *mtag2;

  temp1 = (char **)malloc(QDP_sites_on_node*sizeof(char *));
  temp2 = (char **)malloc(QDP_sites_on_node*sizeof(char *));

  if((fb!=QDP_forward)&&(fb!=QDP_backward)) {
    fprintf(stderr,"QDP: error: bad fb in QDP_F3_$ABBR_eq_s$ABBR\n");
    QDP_abort();
  }

  /* prepare shift source 1 */
  if(src1->ptr==NULL) {
    if(src1->data==NULL) {
      fprintf(stderr,"error: shifting from uninitialized source\n");
      QDP_abort();
    }
  } else {
    QDP_switch_ptr_to_data(&src1->dc);
  }
  mtag1 = QDP_declare_shift( temp1, (char *)src1->data, sizeof(QLA_F3_ColorMatrix),
			     shift, fb, subset );
  QDP_do_gather(mtag1);

  /* prepare shift source 2 */
  if(src2->ptr==NULL) {
    if(src2->data==NULL) {
      fprintf(stderr,"error: shifting from uninitialized source\n");
      QDP_abort();
    }
  } else {
    QDP_switch_ptr_to_data(&src2->dc);
  }
  mtag2 = QDP_declare_shift( temp2, (char *)src2->data, sizeof(QLA_F3_ColorMatrix),
			     shift, fb, subset );
  QDP_do_gather(mtag2);

  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src2->dc);
  QDP_wait_gather(mtag1);
  QDP_wait_gather(mtag2);

#define SRC1 ((QLA_F3_ColorMatrix **)temp1)
#define SRC2 ((QLA_F3_ColorMatrix **)temp2)
  if(subset->indexed==0) {
    fvpp( dest->data+subset->offset, SRC1+subset->offset, SRC2+subset->offset, subset->len );
  } else {
    fxpp( dest->data, SRC1, SRC2, subset->index, subset->len );
  }

  QDP_cleanup_gather(mtag1);
  QDP_cleanup_gather(mtag2);
  free(temp1);
  free(temp2);
}
