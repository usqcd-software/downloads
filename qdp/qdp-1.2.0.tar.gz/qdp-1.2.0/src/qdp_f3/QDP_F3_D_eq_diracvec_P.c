/*
 *  Type conversion and component extraction and insertion
 *
 *  Extracting a Dirac vector from a Dirac propagator matrix column
 */

#include "qdp_f3_internal.h"

void
QDP_F3_D_eq_diracvec_P( QDP_F3_DiracFermion *__restrict__ dest, QDP_F3_DiracPropagator *src, int jc, int js, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src->dc);

  if( subset->indexed ) {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F3_D_xeq_diracvec_pP( dest->data, src->ptr, jc, js, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F3_D_xeq_diracvec_P( dest->data, src->data, jc, js, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    }
  } else {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F3_D_veq_diracvec_pP( dest->data+subset->offset, src->ptr+subset->offset, jc, js, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F3_D_veq_diracvec_P( dest->data+subset->offset, src->data+subset->offset, jc, js, subset->len );
      //QDP_math_time += QDP_time();
    }
  }
}
