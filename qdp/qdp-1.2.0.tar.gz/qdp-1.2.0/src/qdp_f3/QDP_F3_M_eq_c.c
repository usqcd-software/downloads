/*
 *  Fills and random numbers
 *
 *  Fill color matrix with constant times identity
 */

#include "qdp_f3_internal.h"

void
QDP_F3_M_eq_c( QDP_F3_ColorMatrix *__restrict__ dest, QLA_F_Complex *src, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);

  if( subset->indexed ) {
    QLA_F3_M_xeq_c( dest->data, src, subset->index, subset->len );
  } else {
    QLA_F3_M_veq_c( dest->data+subset->offset, src, subset->len );
  }
}
