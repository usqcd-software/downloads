/*
 *  Type conversion and component extraction and insertion
 *
 *  Accessing a Dirac propagator matrix element
 */

#include "qdp_f3_internal.h"

void
QDP_F3_C_eq_elem_P( QDP_F_Complex *__restrict__ dest, QDP_F3_DiracPropagator *src, int ic, int is, int jc, int js, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src->dc);

  if( subset->indexed ) {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F3_C_xeq_elem_pP( dest->data, src->ptr, ic, is, jc, js, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F3_C_xeq_elem_P( dest->data, src->data, ic, is, jc, js, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    }
  } else {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F3_C_veq_elem_pP( dest->data+subset->offset, src->ptr+subset->offset, ic, is, jc, js, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F3_C_veq_elem_P( dest->data+subset->offset, src->data+subset->offset, ic, is, jc, js, subset->len );
      //QDP_math_time += QDP_time();
    }
  }
}
