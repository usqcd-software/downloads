/*
 *  Type conversion and component extraction and insertion
 *
 *  Dirac spin projection
 */

#include "qdp_f3_internal.h"

void
QDP_F3_H_eq_spproj_D( QDP_F3_HalfFermion *__restrict__ dest, QDP_F3_DiracFermion *src, int dir, int sign, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src->dc);

  if( subset->indexed ) {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F3_H_xeq_spproj_pD( dest->data, src->ptr, dir, sign, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F3_H_xeq_spproj_D( dest->data, src->data, dir, sign, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    }
  } else {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F3_H_veq_spproj_pD( dest->data+subset->offset, src->ptr+subset->offset, dir, sign, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F3_H_veq_spproj_D( dest->data+subset->offset, src->data+subset->offset, dir, sign, subset->len );
      //QDP_math_time += QDP_time();
    }
  }
}
