/*
 *  Type conversion and component extraction and insertion
 *
 *  Inserting a color vector into a color matrix column
 */

#include "qdp_f3_internal.h"

void
QDP_F3_M_eq_colorvec_V( QDP_F3_ColorMatrix *__restrict__ dest, QDP_F3_ColorVector *src, int j, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src->dc);

  if( subset->indexed ) {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F3_M_xeq_colorvec_pV( dest->data, src->ptr, j, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F3_M_xeq_colorvec_V( dest->data, src->data, j, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    }
  } else {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F3_M_veq_colorvec_pV( dest->data+subset->offset, src->ptr+subset->offset, j, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F3_M_veq_colorvec_V( dest->data+subset->offset, src->data+subset->offset, j, subset->len );
      //QDP_math_time += QDP_time();
    }
  }
}
