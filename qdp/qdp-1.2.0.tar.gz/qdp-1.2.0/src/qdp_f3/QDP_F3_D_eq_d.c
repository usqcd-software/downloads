/*
 *  Fills and random numbers
 *
 *  Constant fills
 */

#include "qdp_f3_internal.h"

void
QDP_F3_D_eq_d( QDP_F3_DiracFermion *__restrict__ dest, QLA_F3_DiracFermion *src, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);

  if( subset->indexed ) {
    QLA_F3_D_xeq_d( dest->data, src, subset->index, subset->len );
  } else {
    QLA_F3_D_veq_d( dest->data+subset->offset, src, subset->len );
  }
}
