/*
 *  Type conversion and component extraction and insertion
 *
 *  Inserting a half fermion or Dirac fermion spinor element
 */

#include "qdp_f3_internal.h"

void
QDP_F3_D_eq_elem_C( QDP_F3_DiracFermion *__restrict__ dest, QDP_F_Complex *src, int color, int spin, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src->dc);

  if( subset->indexed ) {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F3_D_xeq_elem_pC( dest->data, src->ptr, color, spin, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F3_D_xeq_elem_C( dest->data, src->data, color, spin, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    }
  } else {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F3_D_veq_elem_pC( dest->data+subset->offset, src->ptr+subset->offset, color, spin, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F3_D_veq_elem_C( dest->data+subset->offset, src->data+subset->offset, color, spin, subset->len );
      //QDP_math_time += QDP_time();
    }
  }
}
