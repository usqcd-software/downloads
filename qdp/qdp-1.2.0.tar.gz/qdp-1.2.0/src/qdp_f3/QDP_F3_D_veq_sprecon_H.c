/*
 *  Type conversion and component extraction and insertion
 *
 *  Dirac spin reconstruction
 */

#include "qdp_f3_internal.h"

void
QDP_F3_D_veq_sprecon_H( QDP_F3_DiracFermion *__restrict__ dest[], QDP_F3_HalfFermion *src[], int dir[], int sign[], QDP_Subset subset, int nv )
{
  int i, offset, blen;
  for(i=0; i<nv; ++i) {
    QDP_prepare_dest(&dest[i]->dc);
    QDP_prepare_src(&src[i]->dc);
  }

  offset = 0;
  blen = QDP_block_size;
  while(1) {
    if( blen > subset->len - offset ) blen = subset->len - offset;
    if( blen <= 0) break;
    for(i=0; i<nv; ++i) {
    if( subset->indexed ) {
      if( src[i]->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_xeq_sprecon_pH( dest[i]->data, src[i]->ptr, dir[i], sign[i], subset->index+offset, blen );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_xeq_sprecon_H( dest[i]->data, src[i]->data, dir[i], sign[i], subset->index+offset, blen );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src[i]->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_veq_sprecon_pH( dest[i]->data+subset->offset+offset, src[i]->ptr+subset->offset+offset, dir[i], sign[i], blen );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_veq_sprecon_H( dest[i]->data+subset->offset+offset, src[i]->data+subset->offset+offset, dir[i], sign[i], blen );
        //QDP_math_time += QDP_time();
      }
    }
    }
    offset += blen;
  }
}
