/*
 *  Fills and random numbers
 *
 *  Constant fills
 */

#include "qdp_f3_internal.h"

void
QDP_F3_M_eq_m( QDP_F3_ColorMatrix *__restrict__ dest, QLA_F3_ColorMatrix *src, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);

  if( subset->indexed ) {
    QLA_F3_M_xeq_m( dest->data, src, subset->index, subset->len );
  } else {
    QLA_F3_M_veq_m( dest->data+subset->offset, src, subset->len );
  }
}
