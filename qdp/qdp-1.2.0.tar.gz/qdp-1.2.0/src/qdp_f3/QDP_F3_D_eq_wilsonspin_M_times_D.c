/*
 *  Type conversion and component extraction and insertion
 *
 *  Matrix multiply and Wilson spin multiplication
 */

#include "qdp_f3_internal.h"

void
QDP_F3_D_eq_wilsonspin_M_times_D( QDP_F3_DiracFermion *__restrict__ dest, QDP_F3_ColorMatrix *src1, QDP_F3_DiracFermion *src2, int dir, int sign, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src1->dc);
  QDP_prepare_src(&src2->dc);

  if( subset->indexed ) {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_xeq_wilsonspin_pM_times_pD( dest->data, src1->ptr, src2->ptr, dir, sign, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_xeq_wilsonspin_pM_times_D( dest->data, src1->ptr, src2->data, dir, sign, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_xeq_wilsonspin_M_times_pD( dest->data, src1->data, src2->ptr, dir, sign, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_xeq_wilsonspin_M_times_D( dest->data, src1->data, src2->data, dir, sign, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      }
    }
  } else {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_veq_wilsonspin_pM_times_pD( dest->data+subset->offset, src1->ptr+subset->offset, src2->ptr+subset->offset, dir, sign, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_veq_wilsonspin_pM_times_D( dest->data+subset->offset, src1->ptr+subset->offset, src2->data+subset->offset, dir, sign, subset->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_veq_wilsonspin_M_times_pD( dest->data+subset->offset, src1->data+subset->offset, src2->ptr+subset->offset, dir, sign, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_veq_wilsonspin_M_times_D( dest->data+subset->offset, src1->data+subset->offset, src2->data+subset->offset, dir, sign, subset->len );
        //QDP_math_time += QDP_time();
      }
    }
  }
}
