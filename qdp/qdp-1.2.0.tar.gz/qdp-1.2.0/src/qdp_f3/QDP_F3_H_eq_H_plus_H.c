/*
 *  Binary operations with fields
 *
 *  Addition
 */

#include "qdp_f3_internal.h"

void
QDP_F3_H_eq_H_plus_H( QDP_F3_HalfFermion *__restrict__ dest, QDP_F3_HalfFermion *src1, QDP_F3_HalfFermion *src2, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src1->dc);
  QDP_prepare_src(&src2->dc);

  if( subset->indexed ) {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F3_H_xeq_pH_plus_pH( dest->data, src1->ptr, src2->ptr, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F3_H_xeq_pH_plus_H( dest->data, src1->ptr, src2->data, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F3_H_xeq_H_plus_pH( dest->data, src1->data, src2->ptr, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F3_H_xeq_H_plus_H( dest->data, src1->data, src2->data, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      }
    }
  } else {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F3_H_veq_pH_plus_pH( dest->data+subset->offset, src1->ptr+subset->offset, src2->ptr+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F3_H_veq_pH_plus_H( dest->data+subset->offset, src1->ptr+subset->offset, src2->data+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F3_H_veq_H_plus_pH( dest->data+subset->offset, src1->data+subset->offset, src2->ptr+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F3_H_veq_H_plus_H( dest->data+subset->offset, src1->data+subset->offset, src2->data+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      }
    }
  }
}
