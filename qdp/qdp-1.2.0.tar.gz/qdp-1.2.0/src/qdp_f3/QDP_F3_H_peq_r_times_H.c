/*
 *  Binary operations with constants
 *
 *  Multiplication by real constant
 */

#include "qdp_f3_internal.h"

void
QDP_F3_H_peq_r_times_H( QDP_F3_HalfFermion *__restrict__ dest, QLA_F_Real *src1, QDP_F3_HalfFermion *src2, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src2->dc);

  if( subset->indexed ) {
    if( src2->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F3_H_xpeq_r_times_pH( dest->data, src1, src2->ptr, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F3_H_xpeq_r_times_H( dest->data, src1, src2->data, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    }
  } else {
    if( src2->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F3_H_vpeq_r_times_pH( dest->data+subset->offset, src1, src2->ptr+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F3_H_vpeq_r_times_H( dest->data+subset->offset, src1, src2->data+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    }
  }
}
