#include "qdp_f3.h"
#include "qdp_f3_internal.h"
#include "com_common.h"
#include "com_common_internal.h"

#define fvpd QLA_F3_D_veq_pMa_times_D
#define fxpd QLA_F3_D_xeq_pMa_times_D
#define fvpp QLA_F3_D_veq_pMa_times_pD
#define fxpp QLA_F3_D_xeq_pMa_times_pD

void
QDP_F3_D_peq_sMa_times_D(QDP_F3_DiracFermion *__restrict__ dest, QDP_F3_ColorMatrix *src1, QDP_F3_DiracFermion *src2, QDP_Shift shift, int fb, QDP_Subset subset)
{
  char **temp1;
  QDP_msg_tag *mtag;

  temp1 = (char **)malloc(QDP_sites_on_node*sizeof(char *));

  if((fb!=QDP_forward)&&(fb!=QDP_backward)) {
    fprintf(stderr,"QDP: error: bad fb in QDP_F3_$ABBR_eq_s$ABBR\n");
    QDP_abort();
  }

  /* prepare shift source */
  if(src1->ptr==NULL) {
    if(src1->data==NULL) {
      fprintf(stderr,"error: shifting from uninitialized source\n");
      QDP_abort();
    }
  } else {
    QDP_switch_ptr_to_data(&src1->dc);
  }

  mtag = QDP_declare_shift( temp1, (char *)src1->data, sizeof(QLA_F3_ColorMatrix),
			    shift, fb, subset );
  QDP_do_gather(mtag);
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src2->dc);
  QDP_wait_gather(mtag);

#define SRC1 ((QLA_F3_ColorMatrix **)temp1)
#define SRC2D src2->data
#define SRC2P src2->ptr
  if(src2->ptr==NULL) {
    if(subset->indexed==0) {
      fvpd( dest->data+subset->offset, SRC1+subset->offset, SRC2D+subset->offset, subset->len );
    } else {
      fxpd( dest->data, SRC1, SRC2D, subset->index, subset->len );
    }
  } else {
    if(subset->indexed==0) {
      fvpp( dest->data+subset->offset, SRC1+subset->offset, SRC2P+subset->offset, subset->len );
    } else {
      fxpp( dest->data, SRC1, SRC2P, subset->index, subset->len );
    }
  }

  QDP_cleanup_gather(mtag);
  free(temp1);
}
