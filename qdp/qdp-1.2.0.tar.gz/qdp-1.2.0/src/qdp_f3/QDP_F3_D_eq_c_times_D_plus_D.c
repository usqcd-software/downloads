/*
 *  Ternary operations with fields
 *
 *  Addition or subtraction with complex scalar multiplication
 */

#include "qdp_f3_internal.h"

void
QDP_F3_D_eq_c_times_D_plus_D( QDP_F3_DiracFermion *__restrict__ dest, QLA_F_Complex *c, QDP_F3_DiracFermion *src1, QDP_F3_DiracFermion *src2, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src1->dc);
  QDP_prepare_src(&src2->dc);

  if( subset->indexed ) {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_xeq_c_times_pD_plus_pD( dest->data, c, src1->ptr, src2->ptr, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_xeq_c_times_pD_plus_D( dest->data, c, src1->ptr, src2->data, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_xeq_c_times_D_plus_pD( dest->data, c, src1->data, src2->ptr, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_xeq_c_times_D_plus_D( dest->data, c, src1->data, src2->data, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      }
    }
  } else {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_veq_c_times_pD_plus_pD( dest->data+subset->offset, c, src1->ptr+subset->offset, src2->ptr+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_veq_c_times_pD_plus_D( dest->data+subset->offset, c, src1->ptr+subset->offset, src2->data+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_veq_c_times_D_plus_pD( dest->data+subset->offset, c, src1->data+subset->offset, src2->ptr+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F3_D_veq_c_times_D_plus_D( dest->data+subset->offset, c, src1->data+subset->offset, src2->data+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      }
    }
  }
}
