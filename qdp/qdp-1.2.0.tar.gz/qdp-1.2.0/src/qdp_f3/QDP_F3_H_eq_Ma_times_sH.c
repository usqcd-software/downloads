#include "qdp_f3.h"
#include "qdp_f3_internal.h"
#include "com_common.h"
#include "com_common_internal.h"

#define fvdp QLA_F3_H_veq_Ma_times_pH
#define fxdp QLA_F3_H_xeq_Ma_times_pH
#define fvpp QLA_F3_H_veq_pMa_times_pH
#define fxpp QLA_F3_H_xeq_pMa_times_pH

void
QDP_F3_H_eq_Ma_times_sH(QDP_F3_HalfFermion *__restrict__ dest, QDP_F3_ColorMatrix *src1, QDP_F3_HalfFermion *src2, QDP_Shift shift, int fb, QDP_Subset subset)
{
  char **temp2;
  QDP_msg_tag *mtag;

  temp2 = (char **)malloc(QDP_sites_on_node*sizeof(char *));

  if((fb!=QDP_forward)&&(fb!=QDP_backward)) {
    fprintf(stderr,"QDP: error: bad fb in QDP_F3_$ABBR_eq_s$ABBR\n");
    QDP_abort();
  }

  /* prepare shift source */
  if(src2->ptr==NULL) {
    if(src2->data==NULL) {
      fprintf(stderr,"error: shifting from uninitialized source\n");
      QDP_abort();
    }
  } else {
    QDP_switch_ptr_to_data(&src2->dc);
  }

  mtag = QDP_declare_shift( temp2, (char *)src2->data, sizeof(QLA_F3_HalfFermion),
			    shift, fb, subset );
  QDP_do_gather(mtag);
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src1->dc);
  QDP_wait_gather(mtag);

#define SRC2 ((QLA_F3_HalfFermion **)temp2)
#define SRC1D src1->data
#define SRC1P src1->ptr
  if(src1->ptr==NULL) {
    if(subset->indexed==0) {
      fvdp( dest->data+subset->offset, SRC1D+subset->offset, SRC2+subset->offset, subset->len );
    } else {
      fxdp( dest->data, SRC1D, SRC2, subset->index, subset->len );
    }
  } else {
    if(subset->indexed==0) {
      fvpp( dest->data+subset->offset, SRC1P+subset->offset, SRC2+subset->offset, subset->len );
    } else {
      fxpp( dest->data, SRC1P, SRC2, subset->index, subset->len );
    }
  }

  QDP_cleanup_gather(mtag);
  free(temp2);
}
