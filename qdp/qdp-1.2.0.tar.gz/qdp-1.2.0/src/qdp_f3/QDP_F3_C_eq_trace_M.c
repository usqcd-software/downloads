/*
 *  Type conversion and component extraction and insertion
 *
 *  Trace of color matrix
 */

#include "qdp_f3_internal.h"

void
QDP_F3_C_eq_trace_M( QDP_F_Complex *__restrict__ dest, QDP_F3_ColorMatrix *src, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src->dc);

  if( subset->indexed ) {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F3_C_xeq_trace_pM( dest->data, src->ptr, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F3_C_xeq_trace_M( dest->data, src->data, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    }
  } else {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F3_C_veq_trace_pM( dest->data+subset->offset, src->ptr+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F3_C_veq_trace_M( dest->data+subset->offset, src->data+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    }
  }
}
