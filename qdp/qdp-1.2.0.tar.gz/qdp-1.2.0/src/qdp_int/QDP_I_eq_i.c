/*
 *  Fills and random numbers
 *
 *  Constant fills
 */

#include "qdp_int_internal.h"

void
QDP_I_eq_i( QDP_Int *__restrict__ dest, QLA_Int *src, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);

  if( subset->indexed ) {
    QLA_I_xeq_i( dest->data, src, subset->index, subset->len );
  } else {
    QLA_I_veq_i( dest->data+subset->offset, src, subset->len );
  }
}
