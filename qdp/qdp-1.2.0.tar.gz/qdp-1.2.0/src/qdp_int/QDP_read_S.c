#include <stdlib.h>
#include "qdp_int_internal.h"
#include <qdp_string.h>

#undef N
#define N -1
#if (+0) == -1
#define NC qf->nc,
#else
#define NC
#endif
#undef N

#undef F
#undef D
#define F -1
#define D -1
#if (+0) == -1
#define WS QDPIO_word_S()
#else
#define WS QDPIO_word_S(dummy)
#endif
#undef F
#undef D

/* Internal factory function for array of field data */
static void
QDP_vput_S(char *buf, size_t index, int count, void *qfin)
{
  struct QDP_IO_field *qf = qfin;
  QDP_RandomState **field = (QDP_RandomState **)(qf->data);
  QLA_RandomState *dest;
  QLA_RandomState *src = (QLA_RandomState *)buf;
  int i;

/* For the site specified by "index", move an array of "count" data
   from the read buffer to an array of fields */

  for(i=0; i<count; i++) {
    dest = QDP_expose_S( field[i] ) + index;
    QDPIO_put_S(NC, , , dest, src+i, qf->nc, QLA_Ns);
    QDP_reset_S( field[i] );
  }
}

/* Internal factory function for global data */
static void
QDP_vput_s(char *buf, size_t index, int count, void *qfin)
{
  struct QDP_IO_field *qf = qfin;
  QLA_RandomState *dest = (QLA_RandomState *)(qf->data);
  QLA_RandomState *src = (QLA_RandomState *)buf;
  int i;

  for(i=0; i<count; i++) {
    QDPIO_put_S(NC, , , (dest+i), (src+i), qf->nc, QLA_Ns);
  }
}

/* read an array of QDP fields */
int
QDP_vread_S( QDP_Reader *qdpr, QDP_String *md, QDP_RandomState *field[],
		   int nv)
{
  struct QDP_IO_field qf;
  int i, status;
  QIO_RecordInfo *cmp_info;

  qf.data = (char *) field;
  qf.size = QDPIO_size_S(, 0, QLA_Ns);
  qf.nc = 0;
  qf.word_size = WS;

  cmp_info = QIO_create_record_info(QIO_FIELD, "QDP_RandomState", "", 0,
				    QLA_Ns, qf.size, nv);

  for(i=0; i<nv; i++) QDP_prepare_dest( &field[i]->dc );

  status = QDP_read_check(qdpr, md, QIO_FIELD, QDP_vput_S, &qf,
			  nv, cmp_info);

  QIO_destroy_record_info(cmp_info);

  return status;
}

/* read a single QDP field */
int
QDP_read_S( QDP_Reader *qdpr, QDP_String *md, QDP_RandomState *field)
{
  QDP_RandomState *temp[1];
  temp[0] = field;
  return QDP_vread_S(qdpr, md, temp, 1);
}

/* read a global array of QLA data */
int
QDP_vread_s( QDP_Reader *qdpr, QDP_String *md, QLA_RandomState *array,
		      int n)
{
  struct QDP_IO_field qf;
  int status;
  QIO_RecordInfo *cmp_info;

  qf.data = (char *) array;
  qf.size = QDPIO_size_S(, 0, QLA_Ns);
  qf.nc   = 0;
  qf.word_size = WS;

  cmp_info = QIO_create_record_info(QIO_GLOBAL, "QDP_RandomState", "", 0,
				    QLA_Ns, qf.size, n);

  status = QDP_read_check(qdpr, md, QIO_GLOBAL, QDP_vput_s, &qf,
			  n, cmp_info);

  QIO_destroy_record_info(cmp_info);

  return status;
}
