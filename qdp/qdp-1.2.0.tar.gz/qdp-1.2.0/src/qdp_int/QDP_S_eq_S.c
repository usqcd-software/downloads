/*
 *  Unary Operations
 *
 *  Copying
 */

#include "qdp_int_internal.h"

void
QDP_S_eq_S( QDP_RandomState *__restrict__ dest, QDP_RandomState *src, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src->dc);

  if( subset->indexed ) {
    QLA_S_xeq_S( dest->data, src->data, subset->index, subset->len );
  } else {
    QLA_S_veq_S( dest->data+subset->offset, src->data+subset->offset, subset->len );
  }
}
