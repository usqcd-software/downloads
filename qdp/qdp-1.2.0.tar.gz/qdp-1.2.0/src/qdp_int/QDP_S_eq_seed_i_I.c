/*
 *  Fills and random numbers
 *
 *  Seeding the random number generator field from an integer field
 */

#include "qdp_int_internal.h"

void
QDP_S_eq_seed_i_I( QDP_RandomState *__restrict__ dest, QLA_Int c, QDP_Int *src, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src->dc);

  if( subset->indexed ) {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_S_xeq_seed_i_pI( dest->data, c, src->ptr, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_S_xeq_seed_i_I( dest->data, c, src->data, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    }
  } else {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_S_veq_seed_i_pI( dest->data+subset->offset, c, src->ptr+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_S_veq_seed_i_I( dest->data+subset->offset, c, src->data+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    }
  }
}
