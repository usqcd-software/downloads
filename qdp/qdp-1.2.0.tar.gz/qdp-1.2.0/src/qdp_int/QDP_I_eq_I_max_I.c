/*
 *  Binary operations with fields
 *
 *  Elementary binary functions on integers
 */

#include "qdp_int_internal.h"

void
QDP_I_eq_I_max_I( QDP_Int *__restrict__ dest, QDP_Int *src1, QDP_Int *src2, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src1->dc);
  QDP_prepare_src(&src2->dc);

  if( subset->indexed ) {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_I_xeq_pI_max_pI( dest->data, src1->ptr, src2->ptr, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_I_xeq_pI_max_I( dest->data, src1->ptr, src2->data, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_I_xeq_I_max_pI( dest->data, src1->data, src2->ptr, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_I_xeq_I_max_I( dest->data, src1->data, src2->data, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      }
    }
  } else {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_I_veq_pI_max_pI( dest->data+subset->offset, src1->ptr+subset->offset, src2->ptr+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_I_veq_pI_max_I( dest->data+subset->offset, src1->ptr+subset->offset, src2->data+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_I_veq_I_max_pI( dest->data+subset->offset, src1->data+subset->offset, src2->ptr+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_I_veq_I_max_I( dest->data+subset->offset, src1->data+subset->offset, src2->data+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      }
    }
  }
}
