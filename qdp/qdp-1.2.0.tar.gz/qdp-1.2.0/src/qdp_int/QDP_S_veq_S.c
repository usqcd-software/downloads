/*
 *  Unary Operations
 *
 *  Copying
 */

#include "qdp_int_internal.h"

void
QDP_S_veq_S( QDP_RandomState *__restrict__ dest[], QDP_RandomState *src[], QDP_Subset subset, int nv )
{
  int i, offset, blen;
  for(i=0; i<nv; ++i) {
    QDP_prepare_dest(&dest[i]->dc);
    QDP_prepare_src(&src[i]->dc);
  }

  offset = 0;
  blen = QDP_block_size;
  while(1) {
    if( blen > subset->len - offset ) blen = subset->len - offset;
    if( blen <= 0) break;
    for(i=0; i<nv; ++i) {
    if( subset->indexed ) {
      QLA_S_xeq_S( dest[i]->data, src[i]->data, subset->index+offset, blen );
    } else {
      QLA_S_veq_S( dest[i]->data+subset->offset+offset, src[i]->data+subset->offset+offset, blen );
    }
    }
    offset += blen;
  }
}
