#include <stdlib.h>
#include "qdp_int.h"
#include "qdp_int_internal.h"

QDP_Int *
QDP_create_I(void)
{
  QDP_Int *m;

  m = (QDP_Int *) malloc(sizeof(QDP_Int));
  if(m!=NULL) {
    m->data = NULL;
    m->ptr = NULL;
    m->dc.data = (char **) &(m->data);
    m->dc.ptr = (char ***) &(m->ptr);
    m->dc.size = sizeof(QLA_Int);
    m->dc.discarded = 1;
    m->dc.exposed = 0;
    m->dc.shift_src = NULL;
    m->dc.shift_dest = NULL;
  }

  return m;
}

void
QDP_destroy_I(QDP_Int *field)
{
  QDP_prepare_destroy(&field->dc);
  free(field->data);
  free(field->ptr);
  free(field);
}
