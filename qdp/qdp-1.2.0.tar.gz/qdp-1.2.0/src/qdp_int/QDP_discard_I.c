#include "qdp_int_internal.h"

void
QDP_discard_I(QDP_Int *dest)
{
  dest->dc.discarded = 1;
}
