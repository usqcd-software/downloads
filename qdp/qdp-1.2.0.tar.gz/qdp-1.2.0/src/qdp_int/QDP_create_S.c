#include <stdlib.h>
#include "qdp_int.h"
#include "qdp_int_internal.h"

QDP_RandomState *
QDP_create_S(void)
{
  QDP_RandomState *m;

  m = (QDP_RandomState *) malloc(sizeof(QDP_RandomState));
  if(m!=NULL) {
    m->data = NULL;
    m->ptr = NULL;
    m->dc.data = (char **) &(m->data);
    m->dc.ptr = (char ***) &(m->ptr);
    m->dc.size = sizeof(QLA_RandomState);
    m->dc.discarded = 1;
    m->dc.exposed = 0;
    m->dc.shift_src = NULL;
    m->dc.shift_dest = NULL;
  }

  return m;
}

void
QDP_destroy_S(QDP_RandomState *field)
{
  QDP_prepare_destroy(&field->dc);
  free(field->data);
  free(field->ptr);
  free(field);
}
