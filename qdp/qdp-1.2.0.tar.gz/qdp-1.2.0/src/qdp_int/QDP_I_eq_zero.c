/*
 *  Fills and random numbers
 *
 *  Zero fills
 */

#include "qdp_int_internal.h"

void
QDP_I_eq_zero( QDP_Int *__restrict__ dest, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);

  if( subset->indexed ) {
    QLA_I_xeq_zero( dest->data, subset->index, subset->len );
  } else {
    QLA_I_veq_zero( dest->data+subset->offset, subset->len );
  }
}
