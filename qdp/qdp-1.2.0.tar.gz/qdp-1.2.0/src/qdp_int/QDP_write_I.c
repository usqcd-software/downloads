#include <stdlib.h>
#include "qdp_int_internal.h"
#include <qdp_string.h>

#undef N
#define N -1
#if (+0) == -1
#define NC qf->nc,
#else
#define NC
#endif

#undef F
#undef D
#define F -1
#define D -1
#if (+0) == -1
#define WS QDPIO_word_I()
#else
#define WS QDPIO_word_I(dummy)
#endif
#undef F
#undef D

/* Internal factory function for array of field data */
static void
QDP_vget_I(char *buf, size_t index, int count, void *qfin)
{
  struct QDP_IO_field *qf = qfin;
  QDP_Int **field = (QDP_Int **)(qf->data);
  QLA_Int *src;
  QLA_Int *dest = (QLA_Int *)buf;
  int i;

/* For the site specified by "index", move an array of "count" data
   from the array of fields to the write buffer */
  for(i = 0; i < count; i++, dest++) {
    src = QDP_expose_I( field[i] ) + index;
    QDPIO_get_I(NC, , , dest, src, qf->nc, QLA_Ns);
    QDP_reset_I( field[i] );
  }
}

/* Internal factory function for global data */
static void
QDP_vget_i(char *buf, size_t index, int count, void *qfin)
{
  struct QDP_IO_field *qf = qfin;
  QLA_Int *src = (QLA_Int *)(qf->data);
  QLA_Int *dest = (QLA_Int *)buf;
  int i;

  for(i = 0; i < count; i++, src++, dest++)
    QDPIO_get_I(NC, , , dest, src, qf->nc, QLA_Ns);
}

/* Write an array of QDP fields */
int
QDP_vwrite_I(QDP_Writer *qdpw, QDP_String *md, QDP_Int *field[],
		    int nv)
{
  struct QDP_IO_field qf;
  int i, status;
  QIO_RecordInfo *rec_info;

  qf.data = (char *) field;
  qf.size = QDPIO_size_I(, 0, QLA_Ns);
  qf.nc = 0;
  qf.word_size = WS;

  rec_info = QIO_create_record_info(QIO_FIELD, "QDP_Int", "", 0,
				    QLA_Ns, qf.size, nv);

  for(i=0; i<nv; i++)
    QDP_prepare_dest( &field[i]->dc );

  status = QDP_write_check(qdpw, md, QIO_FIELD, QDP_vget_I, &qf, nv,
			   rec_info);
  return status;
}

/* Write a single QDP field */
int
QDP_write_I( QDP_Writer *qdpw, QDP_String *md, QDP_Int *f)
{
  QDP_Int *field[1];
  field[0] = f;
  return QDP_vwrite_I(qdpw, md, field, 1);
}

/* Write a global array of QLA data */
int
QDP_vwrite_i(QDP_Writer *qdpw, QDP_String *md, QLA_Int *array,
		       int count)
{
  struct QDP_IO_field qf;
  QIO_RecordInfo *rec_info;

  qf.data = (char *) array;
  qf.size = QDPIO_size_I(, 0, QLA_Ns);
  qf.nc = 0;
  qf.word_size = WS;

  rec_info = QIO_create_record_info(QIO_GLOBAL, "QDP_Int", "", 0,
				    QLA_Ns, qf.size, count);

  return QDP_write_check(qdpw, md, QIO_GLOBAL, QDP_vget_i,
			 &qf, count, rec_info);
}
