#include "qdp_int.h"
#include "qdp_int_internal.h"

QLA_RandomState *
QDP_expose_S(QDP_RandomState *dest)
{
  QDP_prepare_dest(&dest->dc);
  dest->dc.exposed = 1;
  return dest->data;
}

void
QDP_reset_S(QDP_RandomState *dest)
{
  if(!dest->dc.exposed) {
    fprintf(stderr,"error: trying to restore non-exposed data\n");
    QDP_abort();
  }
  dest->dc.exposed = 0;
}
