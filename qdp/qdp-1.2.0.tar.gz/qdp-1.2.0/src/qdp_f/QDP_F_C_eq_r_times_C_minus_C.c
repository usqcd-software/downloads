/*
 *  Ternary operations with fields
 *
 *  Addition or subtraction with real scalar multiplication
 */

#include "qdp_f_internal.h"

void
QDP_F_C_eq_r_times_C_minus_C( QDP_F_Complex *__restrict__ dest, QLA_F_Real *c, QDP_F_Complex *src1, QDP_F_Complex *src2, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src1->dc);
  QDP_prepare_src(&src2->dc);

  if( subset->indexed ) {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F_C_xeq_r_times_pC_minus_pC( dest->data, c, src1->ptr, src2->ptr, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F_C_xeq_r_times_pC_minus_C( dest->data, c, src1->ptr, src2->data, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F_C_xeq_r_times_C_minus_pC( dest->data, c, src1->data, src2->ptr, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F_C_xeq_r_times_C_minus_C( dest->data, c, src1->data, src2->data, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      }
    }
  } else {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F_C_veq_r_times_pC_minus_pC( dest->data+subset->offset, c, src1->ptr+subset->offset, src2->ptr+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F_C_veq_r_times_pC_minus_C( dest->data+subset->offset, c, src1->ptr+subset->offset, src2->data+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F_C_veq_r_times_C_minus_pC( dest->data+subset->offset, c, src1->data+subset->offset, src2->ptr+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F_C_veq_r_times_C_minus_C( dest->data+subset->offset, c, src1->data+subset->offset, src2->data+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      }
    }
  }
}
