/*
 *  Reductions
 *
 *  Multisubset global sums
 */

#include "qdp_f_internal.h"

void
QDP_F_r_eq_sum_R_multi( QLA_F_Real dest[], QDP_F_Real *src, QDP_Subset subset[], int ns )
{
  int i;
  QLA_D_Real *dtemp;
  dtemp = (QLA_D_Real *) malloc(ns*sizeof(QLA_D_Real));
  QDP_prepare_src(&src->dc);

  for(i=0; i<ns; i++) {
  if( subset[i]->indexed ) {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_DF_r_xeq_sum_pR( &dtemp[i], src->ptr, subset[i]->index, subset[i]->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_DF_r_xeq_sum_R( &dtemp[i], src->data, subset[i]->index, subset[i]->len );
      //QDP_math_time += QDP_time();
    }
  } else {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_DF_r_veq_sum_pR( &dtemp[i], src->ptr+subset[i]->offset, subset[i]->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_DF_r_veq_sum_R( &dtemp[i], src->data+subset[i]->offset, subset[i]->len );
      //QDP_math_time += QDP_time();
    }
  }
  }
  QDP_binary_reduce_multi(QLA_D_R_vpeq_R, sizeof(QLA_D_Real), dtemp, ns);
  QLA_FD_R_veq_R(dest, dtemp, ns);
  free(dtemp);
}
