/*
 *  Reductions
 *
 *  Global inner product
 */

#include "qdp_f_internal.h"

void
QDP_F_c_veq_C_dot_C( QLA_F_Complex dest[], QDP_F_Complex *src1[], QDP_F_Complex *src2[], QDP_Subset subset, int nv )
{
  int i, offset, blen;
  QLA_D_Complex *dtemp;
  dtemp = (QLA_D_Complex *) malloc(nv*sizeof(QLA_D_Complex));
  QLA_D_C_veq_zero(dtemp, nv);
  for(i=0; i<nv; ++i) {
    QDP_prepare_src(&src1[i]->dc);
    QDP_prepare_src(&src2[i]->dc);
  }

  offset = 0;
  blen = QDP_block_size;
  while(1) {
    if( blen > subset->len - offset ) blen = subset->len - offset;
    if( blen <= 0) break;
    for(i=0; i<nv; ++i) {
    if( subset->indexed ) {
      if( src1[i]->ptr ) {
        if( src2[i]->ptr ) {
          //QDP_math_time -= QDP_time();
          QLA_DF_c_xpeq_pC_dot_pC( &dtemp[i], src1[i]->ptr, src2[i]->ptr, subset->index+offset, blen );
          //QDP_math_time += QDP_time();
        } else {
          //QDP_math_time -= QDP_time();
          QLA_DF_c_xpeq_pC_dot_C( &dtemp[i], src1[i]->ptr, src2[i]->data, subset->index+offset, blen );
          //QDP_math_time += QDP_time();
        }
      } else {
        if( src2[i]->ptr ) {
          //QDP_math_time -= QDP_time();
          QLA_DF_c_xpeq_C_dot_pC( &dtemp[i], src1[i]->data, src2[i]->ptr, subset->index+offset, blen );
          //QDP_math_time += QDP_time();
        } else {
          //QDP_math_time -= QDP_time();
          QLA_DF_c_xpeq_C_dot_C( &dtemp[i], src1[i]->data, src2[i]->data, subset->index+offset, blen );
          //QDP_math_time += QDP_time();
        }
      }
    } else {
      if( src1[i]->ptr ) {
        if( src2[i]->ptr ) {
          //QDP_math_time -= QDP_time();
          QLA_DF_c_vpeq_pC_dot_pC( &dtemp[i], src1[i]->ptr+subset->offset+offset, src2[i]->ptr+subset->offset+offset, blen );
          //QDP_math_time += QDP_time();
        } else {
          //QDP_math_time -= QDP_time();
          QLA_DF_c_vpeq_pC_dot_C( &dtemp[i], src1[i]->ptr+subset->offset+offset, src2[i]->data+subset->offset+offset, blen );
          //QDP_math_time += QDP_time();
        }
      } else {
        if( src2[i]->ptr ) {
          //QDP_math_time -= QDP_time();
          QLA_DF_c_vpeq_C_dot_pC( &dtemp[i], src1[i]->data+subset->offset+offset, src2[i]->ptr+subset->offset+offset, blen );
          //QDP_math_time += QDP_time();
        } else {
          //QDP_math_time -= QDP_time();
          QLA_DF_c_vpeq_C_dot_C( &dtemp[i], src1[i]->data+subset->offset+offset, src2[i]->data+subset->offset+offset, blen );
          //QDP_math_time += QDP_time();
        }
      }
    }
    }
    offset += blen;
  }
  QDP_binary_reduce_multi(QLA_D_C_vpeq_C, sizeof(QLA_D_Complex), dtemp, nv);
  QLA_FD_C_veq_C(dest, dtemp, nv);
  free(dtemp);
}
