#ifndef _QDP_F_INTERNAL_H
#define _QDP_F_INTERNAL_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "qla_types.h"
#include "qla_complex.h"
#include "qla_random.h"
#include "qla_f.h"
#include "qla_d.h"
#include "qla_df.h"
#include "qdp_f.h"
#include "qdp_common_internal.h"
#include "com_common.h"
#include "com_common_internal.h"

#endif
