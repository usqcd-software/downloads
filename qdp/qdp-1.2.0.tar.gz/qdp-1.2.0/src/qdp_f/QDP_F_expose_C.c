#include "qdp_f.h"
#include "qdp_f_internal.h"

QLA_F_Complex *
QDP_F_expose_C(QDP_F_Complex *dest)
{
  QDP_prepare_dest(&dest->dc);
  dest->dc.exposed = 1;
  return dest->data;
}

void
QDP_F_reset_C(QDP_F_Complex *dest)
{
  if(!dest->dc.exposed) {
    fprintf(stderr,"error: trying to restore non-exposed data\n");
    QDP_abort();
  }
  dest->dc.exposed = 0;
}
