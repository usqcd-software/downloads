/*
 *  Unary Operations
 *
 *  Incrementing
 */

#include "qdp_f_internal.h"

void
QDP_F_R_veqm_R( QDP_F_Real *__restrict__ dest[], QDP_F_Real *src[], QDP_Subset subset, int nv )
{
  int i, offset, blen;
  for(i=0; i<nv; ++i) {
    QDP_prepare_dest(&dest[i]->dc);
    QDP_prepare_src(&src[i]->dc);
  }

  offset = 0;
  blen = QDP_block_size;
  while(1) {
    if( blen > subset->len - offset ) blen = subset->len - offset;
    if( blen <= 0) break;
    for(i=0; i<nv; ++i) {
    if( subset->indexed ) {
      if( src[i]->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F_R_xeqm_pR( dest[i]->data, src[i]->ptr, subset->index+offset, blen );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F_R_xeqm_R( dest[i]->data, src[i]->data, subset->index+offset, blen );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src[i]->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F_R_veqm_pR( dest[i]->data+subset->offset+offset, src[i]->ptr+subset->offset+offset, blen );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F_R_veqm_R( dest[i]->data+subset->offset+offset, src[i]->data+subset->offset+offset, blen );
        //QDP_math_time += QDP_time();
      }
    }
    }
    offset += blen;
  }
}
