/*
 *  Fills and random numbers
 *
 *  Constant fills
 */

#include "qdp_f_internal.h"

void
QDP_F_R_eq_r( QDP_F_Real *__restrict__ dest, QLA_F_Real *src, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);

  if( subset->indexed ) {
    QLA_F_R_xeq_r( dest->data, src, subset->index, subset->len );
  } else {
    QLA_F_R_veq_r( dest->data+subset->offset, src, subset->len );
  }
}
