/*
 *  Reductions
 *
 *  Global sums
 */

#include "qdp_f_internal.h"

void
QDP_F_c_eq_sum_C( QLA_F_Complex *__restrict__ dest, QDP_F_Complex *src, QDP_Subset subset )
{
  QLA_D_Complex dtemp;
  QDP_prepare_src(&src->dc);

  if( subset->indexed ) {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_DF_c_xeq_sum_pC( &dtemp, src->ptr, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_DF_c_xeq_sum_C( &dtemp, src->data, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    }
  } else {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_DF_c_veq_sum_pC( &dtemp, src->ptr+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_DF_c_veq_sum_C( &dtemp, src->data+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    }
  }
  QDP_binary_reduce(QLA_D_C_peq_C, sizeof(QLA_D_Complex), &dtemp);
  QLA_FD_C_eq_C(dest, &dtemp);
}
