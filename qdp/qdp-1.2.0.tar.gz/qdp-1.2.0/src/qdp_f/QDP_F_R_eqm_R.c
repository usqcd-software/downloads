/*
 *  Unary Operations
 *
 *  Incrementing
 */

#include "qdp_f_internal.h"

void
QDP_F_R_eqm_R( QDP_F_Real *__restrict__ dest, QDP_F_Real *src, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src->dc);

  if( subset->indexed ) {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F_R_xeqm_pR( dest->data, src->ptr, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F_R_xeqm_R( dest->data, src->data, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    }
  } else {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F_R_veqm_pR( dest->data+subset->offset, src->ptr+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F_R_veqm_R( dest->data+subset->offset, src->data+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    }
  }
}
