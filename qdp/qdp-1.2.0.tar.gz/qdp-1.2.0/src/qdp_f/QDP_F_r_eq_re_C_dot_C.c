/*
 *  Reductions
 *
 *  Real part of global inner product
 */

#include "qdp_f_internal.h"

void
QDP_F_r_eq_re_C_dot_C( QLA_F_Real *__restrict__ dest, QDP_F_Complex *src1, QDP_F_Complex *src2, QDP_Subset subset )
{
  QLA_D_Real dtemp;
  QDP_prepare_src(&src1->dc);
  QDP_prepare_src(&src2->dc);

  if( subset->indexed ) {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_DF_r_xeq_re_pC_dot_pC( &dtemp, src1->ptr, src2->ptr, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_DF_r_xeq_re_pC_dot_C( &dtemp, src1->ptr, src2->data, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_DF_r_xeq_re_C_dot_pC( &dtemp, src1->data, src2->ptr, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_DF_r_xeq_re_C_dot_C( &dtemp, src1->data, src2->data, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      }
    }
  } else {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_DF_r_veq_re_pC_dot_pC( &dtemp, src1->ptr+subset->offset, src2->ptr+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_DF_r_veq_re_pC_dot_C( &dtemp, src1->ptr+subset->offset, src2->data+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_DF_r_veq_re_C_dot_pC( &dtemp, src1->data+subset->offset, src2->ptr+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_DF_r_veq_re_C_dot_C( &dtemp, src1->data+subset->offset, src2->data+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      }
    }
  }
  QDP_binary_reduce(QLA_D_R_peq_R, sizeof(QLA_D_Real), &dtemp);
  QLA_FD_R_eq_R(dest, &dtemp);
}
