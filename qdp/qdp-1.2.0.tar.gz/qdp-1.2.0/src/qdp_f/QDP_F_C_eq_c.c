/*
 *  Fills and random numbers
 *
 *  Constant fills
 */

#include "qdp_f_internal.h"

void
QDP_F_C_eq_c( QDP_F_Complex *__restrict__ dest, QLA_F_Complex *src, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);

  if( subset->indexed ) {
    QLA_F_C_xeq_c( dest->data, src, subset->index, subset->len );
  } else {
    QLA_F_C_veq_c( dest->data+subset->offset, src, subset->len );
  }
}
