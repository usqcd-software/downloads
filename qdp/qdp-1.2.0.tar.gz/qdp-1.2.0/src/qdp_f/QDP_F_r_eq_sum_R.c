/*
 *  Reductions
 *
 *  Global sums
 */

#include "qdp_f_internal.h"

void
QDP_F_r_eq_sum_R( QLA_F_Real *__restrict__ dest, QDP_F_Real *src, QDP_Subset subset )
{
  QLA_D_Real dtemp;
  QDP_prepare_src(&src->dc);

  if( subset->indexed ) {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_DF_r_xeq_sum_pR( &dtemp, src->ptr, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_DF_r_xeq_sum_R( &dtemp, src->data, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    }
  } else {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_DF_r_veq_sum_pR( &dtemp, src->ptr+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_DF_r_veq_sum_R( &dtemp, src->data+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    }
  }
  QDP_binary_reduce(QLA_D_R_peq_R, sizeof(QLA_D_Real), &dtemp);
  QLA_FD_R_eq_R(dest, &dtemp);
}
