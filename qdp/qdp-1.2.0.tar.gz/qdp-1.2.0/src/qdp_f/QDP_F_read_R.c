#include <stdlib.h>
#include "qdp_f_internal.h"
#include <qdp_string.h>

#undef N
#define N -1
#if (+0) == -1
#define NC qf->nc,
#else
#define NC
#endif
#undef N

#undef F
#undef D
#define F -1
#define D -1
#if (F+0) == -1
#define WS QDPIO_word_R(F)
#else
#define WS QDPIO_word_R(dummy)
#endif
#undef F
#undef D

/* Internal factory function for array of field data */
static void
QDP_F_vput_R(char *buf, size_t index, int count, void *qfin)
{
  struct QDP_IO_field *qf = qfin;
  QDP_F_Real **field = (QDP_F_Real **)(qf->data);
  QLA_F_Real *dest;
  QLA_F_Real *src = (QLA_F_Real *)buf;
  int i;

/* For the site specified by "index", move an array of "count" data
   from the read buffer to an array of fields */

  for(i=0; i<count; i++) {
    dest = QDP_F_expose_R( field[i] ) + index;
    QDPIO_put_R(NC, F, _F, dest, src+i, qf->nc, QLA_Ns);
    QDP_F_reset_R( field[i] );
  }
}

/* Internal factory function for global data */
static void
QDP_F_vput_r(char *buf, size_t index, int count, void *qfin)
{
  struct QDP_IO_field *qf = qfin;
  QLA_F_Real *dest = (QLA_F_Real *)(qf->data);
  QLA_F_Real *src = (QLA_F_Real *)buf;
  int i;

  for(i=0; i<count; i++) {
    QDPIO_put_R(NC, F, _F, (dest+i), (src+i), qf->nc, QLA_Ns);
  }
}

/* read an array of QDP fields */
int
QDP_F_vread_R( QDP_Reader *qdpr, QDP_String *md, QDP_F_Real *field[],
		   int nv)
{
  struct QDP_IO_field qf;
  int i, status;
  QIO_RecordInfo *cmp_info;

  qf.data = (char *) field;
  qf.size = QDPIO_size_R(F, 0, QLA_Ns);
  qf.nc = 0;
  qf.word_size = WS;

  cmp_info = QIO_create_record_info(QIO_FIELD, "QDP_F_Real", "F", 0,
				    QLA_Ns, qf.size, nv);

  for(i=0; i<nv; i++) QDP_prepare_dest( &field[i]->dc );

  status = QDP_read_check(qdpr, md, QIO_FIELD, QDP_F_vput_R, &qf,
			  nv, cmp_info);

  QIO_destroy_record_info(cmp_info);

  return status;
}

/* read a single QDP field */
int
QDP_F_read_R( QDP_Reader *qdpr, QDP_String *md, QDP_F_Real *field)
{
  QDP_F_Real *temp[1];
  temp[0] = field;
  return QDP_F_vread_R(qdpr, md, temp, 1);
}

/* read a global array of QLA data */
int
QDP_F_vread_r( QDP_Reader *qdpr, QDP_String *md, QLA_F_Real *array,
		      int n)
{
  struct QDP_IO_field qf;
  int status;
  QIO_RecordInfo *cmp_info;

  qf.data = (char *) array;
  qf.size = QDPIO_size_R(F, 0, QLA_Ns);
  qf.nc   = 0;
  qf.word_size = WS;

  cmp_info = QIO_create_record_info(QIO_GLOBAL, "QDP_F_Real", "F", 0,
				    QLA_Ns, qf.size, n);

  status = QDP_read_check(qdpr, md, QIO_GLOBAL, QDP_F_vput_r, &qf,
			  n, cmp_info);

  QIO_destroy_record_info(cmp_info);

  return status;
}
