/*
 *  Reductions
 *
 *  Global squared norm: uniform precision
 */

#include "qdp_f_internal.h"

void
QDP_F_r_eq_norm2_I( QLA_F_Real *__restrict__ dest, QDP_Int *src, QDP_Subset subset )
{
  QDP_prepare_src(&src->dc);

  if( subset->indexed ) {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F_r_xeq_norm2_pI( dest, src->ptr, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F_r_xeq_norm2_I( dest, src->data, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    }
  } else {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F_r_veq_norm2_pI( dest, src->ptr+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F_r_veq_norm2_I( dest, src->data+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    }
  }
  QDP_binary_reduce(QLA_F_R_peq_R, sizeof(QLA_F_Real), dest);
}
