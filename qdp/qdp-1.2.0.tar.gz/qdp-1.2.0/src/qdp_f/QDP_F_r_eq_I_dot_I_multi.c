/*
 *  Reductions
 *
 *  Multisubset inner products
 */

#include "qdp_f_internal.h"

void
QDP_F_r_eq_I_dot_I_multi( QLA_F_Real dest[], QDP_Int *src1, QDP_Int *src2, QDP_Subset subset[], int ns )
{
  int i;
  QDP_prepare_src(&src1->dc);
  QDP_prepare_src(&src2->dc);

  for(i=0; i<ns; i++) {
  if( subset[i]->indexed ) {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F_r_xeq_pI_dot_pI( dest, src1->ptr, src2->ptr, subset[i]->index, subset[i]->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F_r_xeq_pI_dot_I( dest, src1->ptr, src2->data, subset[i]->index, subset[i]->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F_r_xeq_I_dot_pI( dest, src1->data, src2->ptr, subset[i]->index, subset[i]->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F_r_xeq_I_dot_I( dest, src1->data, src2->data, subset[i]->index, subset[i]->len );
        //QDP_math_time += QDP_time();
      }
    }
  } else {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F_r_veq_pI_dot_pI( dest, src1->ptr+subset[i]->offset, src2->ptr+subset[i]->offset, subset[i]->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F_r_veq_pI_dot_I( dest, src1->ptr+subset[i]->offset, src2->data+subset[i]->offset, subset[i]->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F_r_veq_I_dot_pI( dest, src1->data+subset[i]->offset, src2->ptr+subset[i]->offset, subset[i]->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F_r_veq_I_dot_I( dest, src1->data+subset[i]->offset, src2->data+subset[i]->offset, subset[i]->len );
        //QDP_math_time += QDP_time();
      }
    }
  }
  }
  QDP_binary_reduce_multi(QLA_F_R_vpeq_R, sizeof(QLA_F_Real), dest, ns);
}
