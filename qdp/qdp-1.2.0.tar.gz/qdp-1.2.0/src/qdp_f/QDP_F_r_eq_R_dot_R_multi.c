/*
 *  Reductions
 *
 *  Multisubset inner products
 */

#include "qdp_f_internal.h"

void
QDP_F_r_eq_R_dot_R_multi( QLA_F_Real dest[], QDP_F_Real *src1, QDP_F_Real *src2, QDP_Subset subset[], int ns )
{
  int i;
  QLA_D_Real *dtemp;
  dtemp = (QLA_D_Real *) malloc(ns*sizeof(QLA_D_Real));
  QDP_prepare_src(&src1->dc);
  QDP_prepare_src(&src2->dc);

  for(i=0; i<ns; i++) {
  if( subset[i]->indexed ) {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_DF_r_xeq_pR_dot_pR( &dtemp[i], src1->ptr, src2->ptr, subset[i]->index, subset[i]->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_DF_r_xeq_pR_dot_R( &dtemp[i], src1->ptr, src2->data, subset[i]->index, subset[i]->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_DF_r_xeq_R_dot_pR( &dtemp[i], src1->data, src2->ptr, subset[i]->index, subset[i]->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_DF_r_xeq_R_dot_R( &dtemp[i], src1->data, src2->data, subset[i]->index, subset[i]->len );
        //QDP_math_time += QDP_time();
      }
    }
  } else {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_DF_r_veq_pR_dot_pR( &dtemp[i], src1->ptr+subset[i]->offset, src2->ptr+subset[i]->offset, subset[i]->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_DF_r_veq_pR_dot_R( &dtemp[i], src1->ptr+subset[i]->offset, src2->data+subset[i]->offset, subset[i]->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_DF_r_veq_R_dot_pR( &dtemp[i], src1->data+subset[i]->offset, src2->ptr+subset[i]->offset, subset[i]->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_DF_r_veq_R_dot_R( &dtemp[i], src1->data+subset[i]->offset, src2->data+subset[i]->offset, subset[i]->len );
        //QDP_math_time += QDP_time();
      }
    }
  }
  }
  QDP_binary_reduce_multi(QLA_D_R_vpeq_R, sizeof(QLA_D_Real), dtemp, ns);
  QLA_FD_R_veq_R(dest, dtemp, ns);
  free(dtemp);
}
