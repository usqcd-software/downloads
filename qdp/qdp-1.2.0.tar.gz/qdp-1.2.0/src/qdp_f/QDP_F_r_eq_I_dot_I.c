/*
 *  Reductions
 *
 *  Global inner product
 */

#include "qdp_f_internal.h"

void
QDP_F_r_eq_I_dot_I( QLA_F_Real *__restrict__ dest, QDP_Int *src1, QDP_Int *src2, QDP_Subset subset )
{
  QDP_prepare_src(&src1->dc);
  QDP_prepare_src(&src2->dc);

  if( subset->indexed ) {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F_r_xeq_pI_dot_pI( dest, src1->ptr, src2->ptr, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F_r_xeq_pI_dot_I( dest, src1->ptr, src2->data, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F_r_xeq_I_dot_pI( dest, src1->data, src2->ptr, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F_r_xeq_I_dot_I( dest, src1->data, src2->data, subset->index, subset->len );
        //QDP_math_time += QDP_time();
      }
    }
  } else {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F_r_veq_pI_dot_pI( dest, src1->ptr+subset->offset, src2->ptr+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F_r_veq_pI_dot_I( dest, src1->ptr+subset->offset, src2->data+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_F_r_veq_I_dot_pI( dest, src1->data+subset->offset, src2->ptr+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_F_r_veq_I_dot_I( dest, src1->data+subset->offset, src2->data+subset->offset, subset->len );
        //QDP_math_time += QDP_time();
      }
    }
  }
  QDP_binary_reduce(QLA_F_R_peq_R, sizeof(QLA_F_Real), dest);
}
