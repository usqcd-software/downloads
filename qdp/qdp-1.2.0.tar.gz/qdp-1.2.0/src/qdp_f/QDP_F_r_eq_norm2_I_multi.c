/*
 *  Reductions
 *
 *  Multisubset Norms
 */

#include "qdp_f_internal.h"

void
QDP_F_r_eq_norm2_I_multi( QLA_F_Real dest[], QDP_Int *src, QDP_Subset subset[], int ns )
{
  int i;
  QDP_prepare_src(&src->dc);

  for(i=0; i<ns; i++) {
  if( subset[i]->indexed ) {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F_r_xeq_norm2_pI( dest, src->ptr, subset[i]->index, subset[i]->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F_r_xeq_norm2_I( dest, src->data, subset[i]->index, subset[i]->len );
      //QDP_math_time += QDP_time();
    }
  } else {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F_r_veq_norm2_pI( dest, src->ptr+subset[i]->offset, subset[i]->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F_r_veq_norm2_I( dest, src->data+subset[i]->offset, subset[i]->len );
      //QDP_math_time += QDP_time();
    }
  }
  }
  QDP_binary_reduce_multi(QLA_F_R_vpeq_R, sizeof(QLA_F_Real), dest, ns);
}
