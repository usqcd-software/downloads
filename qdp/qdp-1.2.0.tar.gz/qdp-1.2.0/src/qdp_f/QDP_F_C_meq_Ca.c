/*
 *  Unary Operations
 *
 *  Hermitian conjugate
 */

#include "qdp_f_internal.h"

void
QDP_F_C_meq_Ca( QDP_F_Complex *__restrict__ dest, QDP_F_Complex *src, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src->dc);

  if( subset->indexed ) {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F_C_xmeq_pCa( dest->data, src->ptr, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F_C_xmeq_Ca( dest->data, src->data, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    }
  } else {
    if( src->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F_C_vmeq_pCa( dest->data+subset->offset, src->ptr+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F_C_vmeq_Ca( dest->data+subset->offset, src->data+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    }
  }
}
