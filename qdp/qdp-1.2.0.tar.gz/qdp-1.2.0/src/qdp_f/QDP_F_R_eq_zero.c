/*
 *  Fills and random numbers
 *
 *  Zero fills
 */

#include "qdp_f_internal.h"

void
QDP_F_R_eq_zero( QDP_F_Real *__restrict__ dest, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);

  if( subset->indexed ) {
    QLA_F_R_xeq_zero( dest->data, subset->index, subset->len );
  } else {
    QLA_F_R_veq_zero( dest->data+subset->offset, subset->len );
  }
}
