/*
 *  Reductions
 *
 *  Real part of global inner product
 */

#include "qdp_f_internal.h"

void
QDP_F_r_veq_re_C_dot_C( QLA_F_Real dest[], QDP_F_Complex *src1[], QDP_F_Complex *src2[], QDP_Subset subset, int nv )
{
  int i, offset, blen;
  QLA_D_Real *dtemp;
  dtemp = (QLA_D_Real *) malloc(nv*sizeof(QLA_D_Real));
  for(i=0; i<nv; ++i) {
    QDP_prepare_src(&src1[i]->dc);
    QDP_prepare_src(&src2[i]->dc);
  }

  offset = 0;
  blen = QDP_block_size;
  while(1) {
    if( blen > subset->len - offset ) blen = subset->len - offset;
    if( blen <= 0) break;
    for(i=0; i<nv; ++i) {
    if( subset->indexed ) {
      if( src1[i]->ptr ) {
        if( src2[i]->ptr ) {
          //QDP_math_time -= QDP_time();
          QLA_DF_r_xeq_re_pC_dot_pC( &dtemp[i], src1[i]->ptr, src2[i]->ptr, subset->index+offset, blen );
          //QDP_math_time += QDP_time();
        } else {
          //QDP_math_time -= QDP_time();
          QLA_DF_r_xeq_re_pC_dot_C( &dtemp[i], src1[i]->ptr, src2[i]->data, subset->index+offset, blen );
          //QDP_math_time += QDP_time();
        }
      } else {
        if( src2[i]->ptr ) {
          //QDP_math_time -= QDP_time();
          QLA_DF_r_xeq_re_C_dot_pC( &dtemp[i], src1[i]->data, src2[i]->ptr, subset->index+offset, blen );
          //QDP_math_time += QDP_time();
        } else {
          //QDP_math_time -= QDP_time();
          QLA_DF_r_xeq_re_C_dot_C( &dtemp[i], src1[i]->data, src2[i]->data, subset->index+offset, blen );
          //QDP_math_time += QDP_time();
        }
      }
    } else {
      if( src1[i]->ptr ) {
        if( src2[i]->ptr ) {
          //QDP_math_time -= QDP_time();
          QLA_DF_r_veq_re_pC_dot_pC( &dtemp[i], src1[i]->ptr+subset->offset+offset, src2[i]->ptr+subset->offset+offset, blen );
          //QDP_math_time += QDP_time();
        } else {
          //QDP_math_time -= QDP_time();
          QLA_DF_r_veq_re_pC_dot_C( &dtemp[i], src1[i]->ptr+subset->offset+offset, src2[i]->data+subset->offset+offset, blen );
          //QDP_math_time += QDP_time();
        }
      } else {
        if( src2[i]->ptr ) {
          //QDP_math_time -= QDP_time();
          QLA_DF_r_veq_re_C_dot_pC( &dtemp[i], src1[i]->data+subset->offset+offset, src2[i]->ptr+subset->offset+offset, blen );
          //QDP_math_time += QDP_time();
        } else {
          //QDP_math_time -= QDP_time();
          QLA_DF_r_veq_re_C_dot_C( &dtemp[i], src1[i]->data+subset->offset+offset, src2[i]->data+subset->offset+offset, blen );
          //QDP_math_time += QDP_time();
        }
      }
    }
    }
    offset += blen;
  }
  QDP_binary_reduce_multi(QLA_D_R_vpeq_R, sizeof(QLA_D_Real), dtemp, nv);
  QLA_FD_R_veq_R(dest, dtemp, nv);
  free(dtemp);
}
