/*
 *  Fills and random numbers
 *
 *  Uniform random number fills
 */

#include "qdp_f_internal.h"

void
QDP_F_R_eq_random_S( QDP_F_Real *__restrict__ dest, QDP_RandomState *src, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src->dc);

  if( subset->indexed ) {
    QLA_F_R_xeq_random_S( dest->data, src->data, subset->index, subset->len );
  } else {
    QLA_F_R_veq_random_S( dest->data+subset->offset, src->data+subset->offset, subset->len );
  }
}
