/*
 *  Binary operations with constants
 *
 *  Multiplication by complex constant
 */

#include "qdp_f_internal.h"

void
QDP_F_C_meq_c_times_C( QDP_F_Complex *__restrict__ dest, QLA_F_Complex *src1, QDP_F_Complex *src2, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src2->dc);

  if( subset->indexed ) {
    if( src2->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F_C_xmeq_c_times_pC( dest->data, src1, src2->ptr, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F_C_xmeq_c_times_C( dest->data, src1, src2->data, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    }
  } else {
    if( src2->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F_C_vmeq_c_times_pC( dest->data+subset->offset, src1, src2->ptr+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F_C_vmeq_c_times_C( dest->data+subset->offset, src1, src2->data+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    }
  }
}
