/*
 *  Binary operations with constants
 *
 *  Multiplication by real constant
 */

#include "qdp_f_internal.h"

void
QDP_F_R_meq_r_times_R( QDP_F_Real *__restrict__ dest, QLA_F_Real *src1, QDP_F_Real *src2, QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src2->dc);

  if( subset->indexed ) {
    if( src2->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F_R_xmeq_r_times_pR( dest->data, src1, src2->ptr, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F_R_xmeq_r_times_R( dest->data, src1, src2->data, subset->index, subset->len );
      //QDP_math_time += QDP_time();
    }
  } else {
    if( src2->ptr ) {
      //QDP_math_time -= QDP_time();
      QLA_F_R_vmeq_r_times_pR( dest->data+subset->offset, src1, src2->ptr+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    } else {
      //QDP_math_time -= QDP_time();
      QLA_F_R_vmeq_r_times_R( dest->data+subset->offset, src1, src2->data+subset->offset, subset->len );
      //QDP_math_time += QDP_time();
    }
  }
}
