#include "qdp_f_internal.h"

void
QDP_F_discard_R(QDP_F_Real *dest)
{
  dest->dc.discarded = 1;
}
