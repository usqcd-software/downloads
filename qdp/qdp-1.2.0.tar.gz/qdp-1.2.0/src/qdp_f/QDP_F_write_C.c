#include <stdlib.h>
#include "qdp_f_internal.h"
#include <qdp_string.h>

#undef N
#define N -1
#if (+0) == -1
#define NC qf->nc,
#else
#define NC
#endif

#undef F
#undef D
#define F -1
#define D -1
#if (F+0) == -1
#define WS QDPIO_word_C(F)
#else
#define WS QDPIO_word_C(dummy)
#endif
#undef F
#undef D

/* Internal factory function for array of field data */
static void
QDP_F_vget_C(char *buf, size_t index, int count, void *qfin)
{
  struct QDP_IO_field *qf = qfin;
  QDP_F_Complex **field = (QDP_F_Complex **)(qf->data);
  QLA_F_Complex *src;
  QLA_F_Complex *dest = (QLA_F_Complex *)buf;
  int i;

/* For the site specified by "index", move an array of "count" data
   from the array of fields to the write buffer */
  for(i = 0; i < count; i++, dest++) {
    src = QDP_F_expose_C( field[i] ) + index;
    QDPIO_get_C(NC, F, _F, dest, src, qf->nc, QLA_Ns);
    QDP_F_reset_C( field[i] );
  }
}

/* Internal factory function for global data */
static void
QDP_F_vget_c(char *buf, size_t index, int count, void *qfin)
{
  struct QDP_IO_field *qf = qfin;
  QLA_F_Complex *src = (QLA_F_Complex *)(qf->data);
  QLA_F_Complex *dest = (QLA_F_Complex *)buf;
  int i;

  for(i = 0; i < count; i++, src++, dest++)
    QDPIO_get_C(NC, F, _F, dest, src, qf->nc, QLA_Ns);
}

/* Write an array of QDP fields */
int
QDP_F_vwrite_C(QDP_Writer *qdpw, QDP_String *md, QDP_F_Complex *field[],
		    int nv)
{
  struct QDP_IO_field qf;
  int i, status;
  QIO_RecordInfo *rec_info;

  qf.data = (char *) field;
  qf.size = QDPIO_size_C(F, 0, QLA_Ns);
  qf.nc = 0;
  qf.word_size = WS;

  rec_info = QIO_create_record_info(QIO_FIELD, "QDP_F_Complex", "F", 0,
				    QLA_Ns, qf.size, nv);

  for(i=0; i<nv; i++)
    QDP_prepare_dest( &field[i]->dc );

  status = QDP_write_check(qdpw, md, QIO_FIELD, QDP_F_vget_C, &qf, nv,
			   rec_info);
  return status;
}

/* Write a single QDP field */
int
QDP_F_write_C( QDP_Writer *qdpw, QDP_String *md, QDP_F_Complex *f)
{
  QDP_F_Complex *field[1];
  field[0] = f;
  return QDP_F_vwrite_C(qdpw, md, field, 1);
}

/* Write a global array of QLA data */
int
QDP_F_vwrite_c(QDP_Writer *qdpw, QDP_String *md, QLA_F_Complex *array,
		       int count)
{
  struct QDP_IO_field qf;
  QIO_RecordInfo *rec_info;

  qf.data = (char *) array;
  qf.size = QDPIO_size_C(F, 0, QLA_Ns);
  qf.nc = 0;
  qf.word_size = WS;

  rec_info = QIO_create_record_info(QIO_GLOBAL, "QDP_F_Complex", "F", 0,
				    QLA_Ns, qf.size, count);

  return QDP_write_check(qdpw, md, QIO_GLOBAL, QDP_F_vget_c,
			 &qf, count, rec_info);
}
