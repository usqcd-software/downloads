#include <stdlib.h>
#include "qdp_f.h"
#include "qdp_f_internal.h"

QDP_F_Complex *
QDP_F_create_C(void)
{
  QDP_F_Complex *m;

  m = (QDP_F_Complex *) malloc(sizeof(QDP_F_Complex));
  if(m!=NULL) {
    m->data = NULL;
    m->ptr = NULL;
    m->dc.data = (char **) &(m->data);
    m->dc.ptr = (char ***) &(m->ptr);
    m->dc.size = sizeof(QLA_F_Complex);
    m->dc.discarded = 1;
    m->dc.exposed = 0;
    m->dc.shift_src = NULL;
    m->dc.shift_dest = NULL;
  }

  return m;
}

void
QDP_F_destroy_C(QDP_F_Complex *field)
{
  QDP_prepare_destroy(&field->dc);
  free(field->data);
  free(field->ptr);
  free(field);
}
