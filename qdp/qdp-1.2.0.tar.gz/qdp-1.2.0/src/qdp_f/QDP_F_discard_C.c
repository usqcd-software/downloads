#include "qdp_f_internal.h"

void
QDP_F_discard_C(QDP_F_Complex *dest)
{
  dest->dc.discarded = 1;
}
