/*
 *  Reductions
 *
 *  Multisubset inner products
 */

#include "qdp_f_internal.h"

void
QDP_F_c_eq_C_dot_C_multi( QLA_F_Complex dest[], QDP_F_Complex *src1, QDP_F_Complex *src2, QDP_Subset subset[], int ns )
{
  int i;
  QLA_D_Complex *dtemp;
  dtemp = (QLA_D_Complex *) malloc(ns*sizeof(QLA_D_Complex));
  QDP_prepare_src(&src1->dc);
  QDP_prepare_src(&src2->dc);

  for(i=0; i<ns; i++) {
  if( subset[i]->indexed ) {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_DF_c_xeq_pC_dot_pC( &dtemp[i], src1->ptr, src2->ptr, subset[i]->index, subset[i]->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_DF_c_xeq_pC_dot_C( &dtemp[i], src1->ptr, src2->data, subset[i]->index, subset[i]->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_DF_c_xeq_C_dot_pC( &dtemp[i], src1->data, src2->ptr, subset[i]->index, subset[i]->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_DF_c_xeq_C_dot_C( &dtemp[i], src1->data, src2->data, subset[i]->index, subset[i]->len );
        //QDP_math_time += QDP_time();
      }
    }
  } else {
    if( src1->ptr ) {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_DF_c_veq_pC_dot_pC( &dtemp[i], src1->ptr+subset[i]->offset, src2->ptr+subset[i]->offset, subset[i]->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_DF_c_veq_pC_dot_C( &dtemp[i], src1->ptr+subset[i]->offset, src2->data+subset[i]->offset, subset[i]->len );
        //QDP_math_time += QDP_time();
      }
    } else {
      if( src2->ptr ) {
        //QDP_math_time -= QDP_time();
        QLA_DF_c_veq_C_dot_pC( &dtemp[i], src1->data+subset[i]->offset, src2->ptr+subset[i]->offset, subset[i]->len );
        //QDP_math_time += QDP_time();
      } else {
        //QDP_math_time -= QDP_time();
        QLA_DF_c_veq_C_dot_C( &dtemp[i], src1->data+subset[i]->offset, src2->data+subset[i]->offset, subset[i]->len );
        //QDP_math_time += QDP_time();
      }
    }
  }
  }
  QDP_binary_reduce_multi(QLA_D_C_vpeq_C, sizeof(QLA_D_Complex), dtemp, ns);
  QLA_FD_C_veq_C(dest, dtemp, ns);
  free(dtemp);
}
