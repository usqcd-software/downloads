/*
 *  Reductions
 *
 *  Multisubset real part of global inner product
 */

#include "qdp_f_internal.h"

void
QDP_F_r_veq_re_C_dot_C_multi( QLA_F_Real dest[], QDP_F_Complex *src1[], QDP_F_Complex *src2[], QDP_Subset subset[], int ns )
{
  int i;
  QLA_D_Real *dtemp;
  dtemp = (QLA_D_Real *) malloc(ns*sizeof(QLA_D_Real));
  for(i=0; i<ns; ++i) {
    QDP_prepare_src(&src1[i]->dc);
    QDP_prepare_src(&src2[i]->dc);
  }

  for(i=0; i<ns; ++i) {
    if( subset[i]->indexed ) {
      if( src1[i]->ptr ) {
        if( src2[i]->ptr ) {
          //QDP_math_time -= QDP_time();
          QLA_DF_r_xeq_re_pC_dot_pC( &dtemp[i], src1[i]->ptr, src2[i]->ptr, subset[i]->index, subset[i]->len );
          //QDP_math_time += QDP_time();
        } else {
          //QDP_math_time -= QDP_time();
          QLA_DF_r_xeq_re_pC_dot_C( &dtemp[i], src1[i]->ptr, src2[i]->data, subset[i]->index, subset[i]->len );
          //QDP_math_time += QDP_time();
        }
      } else {
        if( src2[i]->ptr ) {
          //QDP_math_time -= QDP_time();
          QLA_DF_r_xeq_re_C_dot_pC( &dtemp[i], src1[i]->data, src2[i]->ptr, subset[i]->index, subset[i]->len );
          //QDP_math_time += QDP_time();
        } else {
          //QDP_math_time -= QDP_time();
          QLA_DF_r_xeq_re_C_dot_C( &dtemp[i], src1[i]->data, src2[i]->data, subset[i]->index, subset[i]->len );
          //QDP_math_time += QDP_time();
        }
      }
    } else {
      if( src1[i]->ptr ) {
        if( src2[i]->ptr ) {
          //QDP_math_time -= QDP_time();
          QLA_DF_r_veq_re_pC_dot_pC( &dtemp[i], src1[i]->ptr+subset[i]->offset, src2[i]->ptr+subset[i]->offset, subset[i]->len );
          //QDP_math_time += QDP_time();
        } else {
          //QDP_math_time -= QDP_time();
          QLA_DF_r_veq_re_pC_dot_C( &dtemp[i], src1[i]->ptr+subset[i]->offset, src2[i]->data+subset[i]->offset, subset[i]->len );
          //QDP_math_time += QDP_time();
        }
      } else {
        if( src2[i]->ptr ) {
          //QDP_math_time -= QDP_time();
          QLA_DF_r_veq_re_C_dot_pC( &dtemp[i], src1[i]->data+subset[i]->offset, src2[i]->ptr+subset[i]->offset, subset[i]->len );
          //QDP_math_time += QDP_time();
        } else {
          //QDP_math_time -= QDP_time();
          QLA_DF_r_veq_re_C_dot_C( &dtemp[i], src1[i]->data+subset[i]->offset, src2[i]->data+subset[i]->offset, subset[i]->len );
          //QDP_math_time += QDP_time();
        }
      }
    }
  }
  QDP_binary_reduce_multi(QLA_D_R_vpeq_R, sizeof(QLA_D_Real), dtemp, ns);
  QLA_FD_R_veq_R(dest, dtemp, ns);
  free(dtemp);
}
