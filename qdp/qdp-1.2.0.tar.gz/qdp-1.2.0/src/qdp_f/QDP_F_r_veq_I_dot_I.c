/*
 *  Reductions
 *
 *  Global inner product
 */

#include "qdp_f_internal.h"

void
QDP_F_r_veq_I_dot_I( QLA_F_Real dest[], QDP_Int *src1[], QDP_Int *src2[], QDP_Subset subset, int nv )
{
  int i, offset, blen;
  QLA_D_Real *dtemp;
  dtemp = (QLA_D_Real *) malloc(nv*sizeof(QLA_D_Real));
  QLA_D_R_veq_zero(dtemp, nv);
  for(i=0; i<nv; ++i) {
    QDP_prepare_src(&src1[i]->dc);
    QDP_prepare_src(&src2[i]->dc);
  }

  offset = 0;
  blen = QDP_block_size;
  while(1) {
    if( blen > subset->len - offset ) blen = subset->len - offset;
    if( blen <= 0) break;
    for(i=0; i<nv; ++i) {
    if( subset->indexed ) {
      if( src1[i]->ptr ) {
        if( src2[i]->ptr ) {
          //QDP_math_time -= QDP_time();
          QLA_F_r_xpeq_pI_dot_pI( &dest[i], src1[i]->ptr, src2[i]->ptr, subset->index+offset, blen );
          //QDP_math_time += QDP_time();
        } else {
          //QDP_math_time -= QDP_time();
          QLA_F_r_xpeq_pI_dot_I( &dest[i], src1[i]->ptr, src2[i]->data, subset->index+offset, blen );
          //QDP_math_time += QDP_time();
        }
      } else {
        if( src2[i]->ptr ) {
          //QDP_math_time -= QDP_time();
          QLA_F_r_xpeq_I_dot_pI( &dest[i], src1[i]->data, src2[i]->ptr, subset->index+offset, blen );
          //QDP_math_time += QDP_time();
        } else {
          //QDP_math_time -= QDP_time();
          QLA_F_r_xpeq_I_dot_I( &dest[i], src1[i]->data, src2[i]->data, subset->index+offset, blen );
          //QDP_math_time += QDP_time();
        }
      }
    } else {
      if( src1[i]->ptr ) {
        if( src2[i]->ptr ) {
          //QDP_math_time -= QDP_time();
          QLA_F_r_vpeq_pI_dot_pI( &dest[i], src1[i]->ptr+subset->offset+offset, src2[i]->ptr+subset->offset+offset, blen );
          //QDP_math_time += QDP_time();
        } else {
          //QDP_math_time -= QDP_time();
          QLA_F_r_vpeq_pI_dot_I( &dest[i], src1[i]->ptr+subset->offset+offset, src2[i]->data+subset->offset+offset, blen );
          //QDP_math_time += QDP_time();
        }
      } else {
        if( src2[i]->ptr ) {
          //QDP_math_time -= QDP_time();
          QLA_F_r_vpeq_I_dot_pI( &dest[i], src1[i]->data+subset->offset+offset, src2[i]->ptr+subset->offset+offset, blen );
          //QDP_math_time += QDP_time();
        } else {
          //QDP_math_time -= QDP_time();
          QLA_F_r_vpeq_I_dot_I( &dest[i], src1[i]->data+subset->offset+offset, src2[i]->data+subset->offset+offset, blen );
          //QDP_math_time += QDP_time();
        }
      }
    }
    }
    offset += blen;
  }
  QDP_binary_reduce_multi(QLA_F_R_vpeq_R, sizeof(QLA_F_Real), dest, nv);
}
