#include <stdlib.h>
#include "qdp_f.h"
#include "qdp_f_internal.h"

QDP_F_Real *
QDP_F_create_R(void)
{
  QDP_F_Real *m;

  m = (QDP_F_Real *) malloc(sizeof(QDP_F_Real));
  if(m!=NULL) {
    m->data = NULL;
    m->ptr = NULL;
    m->dc.data = (char **) &(m->data);
    m->dc.ptr = (char ***) &(m->ptr);
    m->dc.size = sizeof(QLA_F_Real);
    m->dc.discarded = 1;
    m->dc.exposed = 0;
    m->dc.shift_src = NULL;
    m->dc.shift_dest = NULL;
  }

  return m;
}

void
QDP_F_destroy_R(QDP_F_Real *field)
{
  QDP_prepare_destroy(&field->dc);
  free(field->data);
  free(field->ptr);
  free(field);
}
