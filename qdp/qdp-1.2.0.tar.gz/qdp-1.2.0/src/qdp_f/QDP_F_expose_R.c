#include "qdp_f.h"
#include "qdp_f_internal.h"

QLA_F_Real *
QDP_F_expose_R(QDP_F_Real *dest)
{
  QDP_prepare_dest(&dest->dc);
  dest->dc.exposed = 1;
  return dest->data;
}

void
QDP_F_reset_R(QDP_F_Real *dest)
{
  if(!dest->dc.exposed) {
    fprintf(stderr,"error: trying to restore non-exposed data\n");
    QDP_abort();
  }
  dest->dc.exposed = 0;
}
