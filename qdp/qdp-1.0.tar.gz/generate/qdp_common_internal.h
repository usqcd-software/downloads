#ifndef _QDP_COMMON_INTERNAL
#define _QDP_COMMON_INTERNAL

#include "qla_types.h"
#include "qla_complex.h"
#include "qla_random.h"
#include "qdp_types.h"
#include "generic_includes.h"

struct QDP_Subset {
  int indexed;
  int offset;
  int *index;
  int len;
  int (*func)(int x[]);
  int colors;
  int coloring;
  struct QDP_Subset *first;
};

struct QDP_Shift {
  void (*func)(int sx[], int rx[], int fb, void *args);
  void *args;
  int argsize;
  int forward_index;
  int backward_index;
};

typedef struct QDP_shift_list_t {
  struct QDP_shift_src_t *ss;
  struct QDP_shift_list_t *next;
  struct QDP_shift_list_t *prev;
} QDP_shift_list_t;

typedef struct QDP_shift_src_t {
  QDP_Shift shift;
  int fb;
  QDP_Subset subset;
  int shift_pending;
  char **ptr;
  msg_tag *msgtag;
  QDP_shift_list_t *sl;
  struct QDP_data_common_t *dc;
  struct QDP_shift_src_t *next;
} QDP_shift_src_t;

typedef struct QDP_shift_dest_t {
  struct QDP_data_common_t *dc;
  struct QDP_shift_dest_t *next;
} QDP_shift_dest_t;

typedef struct QDP_data_common_t {
  char **data;
  char ***ptr;
  int size;
  int discarded;
  int exposed;
  QDP_shift_src_t *shift_src;
  QDP_shift_dest_t *shift_dest;
} QDP_data_common_t;

!ALLTYPES
struct $QDPPCTYPE {
  $QLAPCTYPE *data;
  $QLAPCTYPE **ptr;
  QDP_data_common_t dc;
};

!END
extern void QDP_clear_shift_list(void);
extern void QDP_prepare_destroy(QDP_data_common_t *dc);
extern void QDP_prepare_dest(QDP_data_common_t *dc);
extern void QDP_prepare_src(QDP_data_common_t *dc);
extern int QDP_prepare_shift(QDP_data_common_t *dest_dc, QDP_data_common_t *src_dc,
			     QDP_Shift shift, int fb, QDP_Subset subset);
extern void QDP_switch_ptr_to_data(QDP_data_common_t *dc);
extern void QDP_binary_reduce(void func(), int size, void *data);
extern void QDP_binary_reduce_multi(void func(), int size, void *data, int ns);
extern void QDP_N_binary_reduce(int nc, void func(), int size, void *data);
extern void QDP_N_binary_reduce_multi(int nc, void func(), int size, void *data, int ns);

extern int QDP_suspended;

#endif
