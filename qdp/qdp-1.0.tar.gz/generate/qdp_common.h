#ifndef _QDP_COMMON
#define _QDP_COMMON

#include "qdp_types.h"

extern QDP_Subset QDP_all;
extern QDP_Subset QDP_even_and_odd[2];
extern QDP_Subset QDP_even;
extern QDP_Subset QDP_odd;

extern QDP_Shift *QDP_neighbor;

extern int QDP_sites_on_node;
extern int QDP_this_node;
extern int QDP_forward;
extern int QDP_backward;

int QDP_initialize(int argc, char *argv[]);
void QDP_finalize(void);
void QDP_abort(void);
void QDP_suspend_comm(void);
void QDP_resume_comm(void);
void QDP_set_latsize(int nd, int size[]);
//void QDP_set_smp(void);
int QDP_create_layout(void);
int QDP_node_number(int x[]);
int QDP_index(int x[]);
void QDP_get_coords(int x[], int node, int i);
QDP_Subset *QDP_create_subset(int (*func)(int x[]), int n);
void QDP_destroy_subset(QDP_Subset *s);
QDP_Shift QDP_create_shift(int disp[]);
QDP_Shift QDP_create_map(void (*func)(int sx[], int rx[], int fb, void *args), void *args, int argsize);
void QDP_destroy_shift(QDP_Shift s);

#endif
