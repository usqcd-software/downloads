!PCSHIFTTYPES
/*
 *  T = func
 */

#include <stdlib.h>
#include "qdp_$lib.h"
#include "qdp_$lib_internal.h"

void
QLA$PC_$ABBR_veq_func( $QLAPCTYPE dest[], int offset,
		       void (*func)($QLAPCTYPE *dest, int coord[]),
		       int n )
{
  int i, *coords;
  coords = (int *)malloc(4*sizeof(int));

  n += offset;
  for(i=offset; i<n; ++i) {
    QDP_get_coords(coords, QDP_this_node, i);
    func( &dest[i], coords);
  }

  free(coords);
}

void
QLA$PC_$ABBR_xeq_func( $QLAPCTYPE dest[],
		       void (*func)($QLAPCTYPE *dest, int coord[]),
		       int index[], int n )
{
  int i, j, *coords;
  coords = (int *)malloc(4*sizeof(int));

  for(i=0; i<n; ++i) {
    j = index[i];
    QDP_get_coords(coords, QDP_this_node, j);
    func( &dest[j], coords);
  }

  free(coords);
}

void
QDP$PC_$ABBR_eq_func($NC$QDPPCTYPE *dest, void (*func)($QLAPCTYPE *dest, int coords[]), QDP_Subset subset )
{
  QDP_prepare_dest(&dest->dc);

  if(subset==QDP_all) {
    QLA$PC_$ABBR_veq_func( dest->data, 0, func, sites_on_node );
  } else if(subset==QDP_even) {
    QLA$PC_$ABBR_veq_func( dest->data, 0, func, even_sites_on_node );
  } else if(subset==QDP_odd) {
    QLA$PC_$ABBR_veq_func( dest->data, even_sites_on_node, func, odd_sites_on_node );
  } else {
    QLA$PC_$ABBR_xeq_func( dest->data, func, subset->index, subset->len );
  }
}
!END
