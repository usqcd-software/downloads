#ifdef _QDP_COLOR_GENERIC
#error already included a generic header: _QDP_COLOR_GENERIC
#else
#define _QDP_COLOR_GENERIC

!PCTYPES
#define $QDPPTYPE $QDPPCTYPE
!END

