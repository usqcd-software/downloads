!GAUGEMULT2
#include "qdp_$lib.h"
#include "qdp_$lib_internal.h"
#include "generic_includes.h"

#define fvpp QLA$PC_$ABBR3_veq_p$ABBR1$ADJ1_times_p$ABBR2$ADJ2
#define fxpp QLA$PC_$ABBR3_xeq_p$ABBR1$ADJ1_times_p$ABBR2$ADJ2

void
QDP$PC_$ABBR3_$EQOP_s$ABBR1$ADJ1_times_s$ABBR2$ADJ2($NC$QDPPCTYPE3 *dest, $QDPPCTYPE1 *src1, $QDPPCTYPE2 *src2, QDP_Shift shift, int fb, QDP_Subset subset)
{
  char **temp1, **temp2;
  int gather_index, gather_subset;
  msg_tag *mtag1, *mtag2;

  temp1 = (char **)malloc(QDP_sites_on_node*sizeof(char *));
  temp2 = (char **)malloc(QDP_sites_on_node*sizeof(char *));

  if(fb==QDP_forward) {
    gather_index = shift->forward_index;
  } else if(fb==QDP_backward) {
    gather_index = shift->backward_index;
  } else {
    fprintf(stderr,"QDP: error: bad fb in QDP$PC_$ABBR_eq_s$ABBR\n");
    terminate(1);
  }

  gather_subset = EVENANDODD;
  if(subset==QDP_even) gather_subset = EVEN;
  else if(subset==QDP_odd) gather_subset = ODD;

  /* prepare shift source 1 */
  if(src1->ptr==NULL) {
    if(src1->data==NULL) {
      fprintf(stderr,"error: shifting from uninitialized source\n");
      terminate(1);
    }
  } else {
    QDP_switch_ptr_to_data(&src1->dc);
  }
  mtag1 = declare_gather_from_temp( (char *)src1->data, sizeof($QLAPCTYPE1),
				   gather_index, gather_subset, temp1 );
  do_gather(mtag1);

  /* prepare shift source 2 */
  if(src2->ptr==NULL) {
    if(src2->data==NULL) {
      fprintf(stderr,"error: shifting from uninitialized source\n");
      terminate(1);
    }
  } else {
    QDP_switch_ptr_to_data(&src2->dc);
  }
  mtag2 = declare_gather_from_temp( (char *)src2->data, sizeof($QLAPCTYPE2),
				   gather_index, gather_subset, temp2 );
  do_gather(mtag2);

  QDP_prepare_dest(&dest->dc);
  QDP_prepare_src(&src2->dc);
  wait_gather(mtag1);
  wait_gather(mtag2);

#define SRC1 (($QLAPCTYPE1 **)temp1)
#define SRC2 (($QLAPCTYPE2 **)temp2)
  if(subset->indexed==0) {
    fvpp($NCVAR dest->data+subset->offset, SRC1+subset->offset, SRC2+subset->offset, subset->len );
  } else {
    fxpp($NCVAR dest->data, SRC1, SRC2, subset->index, subset->len );
  }

  cleanup_gather(mtag1);
  cleanup_gather(mtag2);
  free(temp1);
  free(temp2);
}
!END
