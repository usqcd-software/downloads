#ifndef _QDP_$LIB_INTERNAL
#define _QDP_$LIB_INTERNAL

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define CONTROL
#include "lattice.h"
#undef CONTROL
#include "comdefs.h"
#include "qla_types.h"
#include "qla_complex.h"
#include "qla_random.h"
#include "qla_$lib.h"
!QLAELIBS
#include "qla_$elib.h"
!END
#include "qdp_$lib.h"
#include "qdp_common_internal.h"

#endif
