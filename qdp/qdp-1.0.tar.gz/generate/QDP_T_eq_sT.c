!PCSHIFTTYPES
#include "qdp_$lib.h"
#include "qdp_$lib_internal.h"
#include "generic_includes.h"

void
QDP$PC_$ABBR_eq_s$ABBR($NC$QDPPCTYPE *dest, $QDPPCTYPE *src, QDP_Shift shift, int fb, QDP_Subset subset)
{
  int gather_index, gather_subset, restart;
  char **gather_dest;

  if(QDP_suspended) {
    fprintf(stderr,"QDP error: attempting shift while communications suspended\n");
    terminate(1);
  }

  if(fb==1) {
    gather_index = shift->forward_index;
  } else if(fb==-1) {
    gather_index = shift->backward_index;
  } else {
    fprintf(stderr,"QDP: error: bad fb in QDP$PC_$ABBR_eq_s$ABBR\n");
    terminate(1);
  }

  restart = QDP_prepare_shift(&dest->dc, &src->dc, shift, fb, subset);

  if(!restart) {

    gather_subset = EVENANDODD;
    gather_dest = (char **)dest->ptr;
    if(subset==QDP_even) gather_subset = EVEN;
    else if(subset==QDP_odd) gather_subset = ODD;
    else if(subset!=QDP_all) {
      gather_dest = (char **)malloc(sites_on_node*sizeof(char*));
    }

    dest->dc.shift_src->msgtag =
      declare_gather_from_temp( (char *)src->data, sizeof($QLAPCTYPE),
				gather_index, gather_subset, gather_dest );

    prepare_gather(dest->dc.shift_src->msgtag);

    if(gather_dest!=(char **)dest->ptr) {
      int i;
      for(i=0; i<subset->len; i++) {
	int k=subset->index[i];
	dest->ptr[k] = ($QLAPCTYPE *)gather_dest[i];
      }
    }

  }

  do_gather(dest->dc.shift_src->msgtag);
}
!END
