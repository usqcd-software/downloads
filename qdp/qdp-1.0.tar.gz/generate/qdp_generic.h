#ifdef _QDP_$PORPC_GENERIC
#error already included a generic header: QDP_$PORPC_GENERIC
#else
#define _QDP_$PORPC_GENERIC

!PCTYPES
#define $QDPTYPE $QDPPCTYPE
!END

