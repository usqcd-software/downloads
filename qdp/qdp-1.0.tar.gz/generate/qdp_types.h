#ifndef _QDP_TYPES
#define _QDP_TYPES

typedef struct QDP_Subset* QDP_Subset;
typedef struct QDP_Shift* QDP_Shift;

!ALLTYPES
typedef struct $QDPPCTYPE $QDPPCTYPE;
!END

#endif
