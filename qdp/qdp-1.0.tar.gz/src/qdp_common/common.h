#ifndef QDP_COMMON
#define QDP_COMMON

#include "qdp_types.h"

struct QDP_Subset {
  int *index;
  int len;
};

extern QDP_Subset *QDP_all;
extern QDP_Subset *QDP_even;
extern QDP_Subset *QDP_odd;

#endif

