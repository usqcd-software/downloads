#include "qdp_common_internal.h"

static QDP_shift_list_t *shift_list=NULL;
static QDP_shift_list_t *sl_free_list=NULL;
static QDP_shift_src_t *ss_free_list=NULL;
static QDP_shift_dest_t *sd_free_list=NULL;

/*******************
 * shift functions *
 *******************/

static void
QDP_finish_shifts(QDP_data_common_t *dc)
{
  QDP_shift_src_t *ss;
  ss = dc->shift_src;
  while(ss!=NULL) {
    if(ss->shift_pending) {
      QDP_shift_list_t *sl;
      ss->shift_pending = 0;
      sl = ss->sl->next;
      if(sl!=NULL) {
	sl->prev = ss->sl->prev;
      }
      if(ss->sl->prev!=NULL) {
	ss->sl->prev->next = sl;
      } else {
	shift_list = sl;
      }
      ss->sl->next = sl_free_list;
      sl_free_list = ss->sl;
      ss->sl = NULL;
      wait_gather(ss->msgtag);
    }
    ss = ss->next;
  }
}

static void
QDP_cleanup_shifts(QDP_data_common_t *dc)
{
  QDP_shift_src_t *ss;
  ss = dc->shift_src;
  while(ss!=NULL) {
    if(ss->msgtag!=NULL) {
      cleanup_gather(ss->msgtag);
      ss->msgtag = NULL;
    }
    ss = ss->next;
  }
}

/************************
 * dependency functions *
 ************************/

static void
QDP_clear_shift_src(QDP_data_common_t *dc)
{
  QDP_shift_src_t **pss;
  pss = &(dc->shift_src);
  if( *pss != NULL ) {
    do {
      QDP_shift_dest_t **psd;
      psd = &((*pss)->dc->shift_dest);
      while( *psd != NULL ) {
	if( (*psd)->dc == dc ) {
	  QDP_shift_dest_t *tsd;
	  tsd = *psd;
	  *psd = tsd->next;
	  tsd->next = sd_free_list;
	  sd_free_list = tsd;
	  //fprintf(stderr,"cleared shift dest\n");
	  break;
	}
	psd = &((*psd)->next);
      }
      pss = &((*pss)->next);
    } while(*pss!=NULL);
    *pss = ss_free_list;
    ss_free_list = dc->shift_src;
    dc->shift_src = NULL;
    //fprintf(stderr,"cleared shift src\n");
  }
}

static void
QDP_copy_ptr_to_data(QDP_data_common_t *dc)
{
  char *data, **ptr;
  data = *(dc->data);
  ptr = *(dc->ptr);
  if(ptr!=NULL) {
    int i;
    for(i=0; i<sites_on_node; i++) {
      if(ptr[i]) memcpy(&data[i*dc->size], ptr[i], dc->size);
    }
  }
}

static void
QDP_clear_shift_dest(QDP_data_common_t *dc)
{
  while(dc->shift_dest!=NULL) {
    QDP_switch_ptr_to_data(dc->shift_dest->dc);
  }
}

static void
QDP_clear_valid_shift_dest(QDP_data_common_t *dc)
{
  QDP_shift_dest_t *sd;
  sd = dc->shift_dest;
  while(sd!=NULL) {
    if(sd->dc->discarded) {
      sd = sd->next;
    } else {
      QDP_shift_dest_t *tsd;
      tsd = sd;
      sd = sd->next;
      QDP_switch_ptr_to_data(tsd->dc);
    }
  }
}

static QDP_shift_src_t *
QDP_alloc_shift_src_t(QDP_data_common_t *dc, QDP_Shift shift, int fb, QDP_Subset subset)
{
  QDP_shift_src_t *ss;
  if(ss_free_list==NULL) {
    ss = (QDP_shift_src_t *) malloc(sizeof(QDP_shift_src_t));
  } else {
    ss = ss_free_list;
    ss_free_list = ss->next;
  }
  ss->dc = dc;
  ss->shift = shift;
  ss->fb = fb;
  ss->subset = subset;
  return ss;
}

static QDP_shift_dest_t *
QDP_alloc_shift_dest_t(QDP_data_common_t *dc, QDP_shift_dest_t *next)
{
  QDP_shift_dest_t *sd;
  if(sd_free_list==NULL) {
    sd = (QDP_shift_dest_t *) malloc(sizeof(QDP_shift_dest_t));
  } else {
    sd = sd_free_list;
    sd_free_list = sd->next;
  }
  sd->dc = dc;
  sd->next = next;
  return sd;
}

/************************
 * data & ptr functions *
 ************************/

void
QDP_switch_ptr_to_data(QDP_data_common_t *dc)
{
  if(*(dc->data)==NULL) {
    *(dc->data) = (char *) malloc(sites_on_node*dc->size);
  } else {
    QDP_clear_valid_shift_dest(dc);
  }
  if(*(dc->ptr)!=NULL) {
    QDP_finish_shifts(dc);
    if(!dc->discarded) QDP_copy_ptr_to_data(dc);
    QDP_cleanup_shifts(dc);
    QDP_clear_shift_src(dc);
    free(*(dc->ptr));
    *(dc->ptr) = NULL;
  }
}

/**********************
 * external functions *
 **********************/

void
QDP_clear_shift_list(void)
{
  QDP_shift_list_t *sl;
  sl = shift_list;
  if(sl!=NULL) {
    while(1) {
      sl->ss->shift_pending = 0;
      sl->ss->sl = NULL;
      wait_gather(sl->ss->msgtag);
      if(sl->next==NULL) break;
      sl = sl->next;
    }
    sl->next = sl_free_list;
    sl_free_list = shift_list;
    shift_list = NULL;
  }
}

void
QDP_prepare_destroy(QDP_data_common_t *dc)
{
  QDP_finish_shifts(dc);
  QDP_cleanup_shifts(dc);
  QDP_clear_shift_src(dc);
  QDP_clear_shift_dest(dc);
}

void
QDP_prepare_dest(QDP_data_common_t *dc)
{
  if(dc->exposed) {
    fprintf(stderr,"error: attempt to use exposed field\n");
    terminate(1);
  }
  dc->discarded = 0;
  QDP_switch_ptr_to_data(dc);
}

void
QDP_prepare_src(QDP_data_common_t *dc)
{
  if(dc->discarded) {
    fprintf(stderr,"error: attempt to use discarded data\n");
    terminate(1);
  }
  if(dc->exposed) {
    fprintf(stderr,"error: attempt to use exposed field\n");
    terminate(1);
  }
  QDP_finish_shifts(dc);
}

int
QDP_prepare_shift(QDP_data_common_t *dest_dc, QDP_data_common_t *src_dc,
		  QDP_Shift shift, int fb, QDP_Subset subset)
{
  QDP_shift_src_t **pss, *ss;
  int restart=0;

  if(src_dc->discarded) {
    fprintf(stderr,"error: attempt to use discarded data\n");
    terminate(1);
  }
  if(src_dc->exposed) {
    fprintf(stderr,"error: attempt to use exposed field\n");
    terminate(1);
  }
  if(dest_dc->exposed) {
    fprintf(stderr,"error: attempt to use exposed field\n");
    terminate(1);
  }

  /* prepare shift source */
  if(*(src_dc->ptr)==NULL) {
    if(*(src_dc->data)==NULL) {
      fprintf(stderr,"error: shifting from uninitialized source\n");
      terminate(1);
    }
  } else {
    QDP_switch_ptr_to_data(src_dc);
  }

  /* check if this shift has been done before */
  pss = &dest_dc->shift_src;
  while(1) {
    if(*pss==NULL) {
      ss = QDP_alloc_shift_src_t(src_dc, shift, fb, subset);
      ss->next = dest_dc->shift_src;
      dest_dc->shift_src = ss;
      src_dc->shift_dest = QDP_alloc_shift_dest_t(dest_dc, src_dc->shift_dest);
      break;
    }
    ss = *pss;
    if( (ss->dc==src_dc) && (ss->shift==shift) &&
	(ss->fb==fb) && (ss->subset==subset) ) {
      if(ss->shift_pending) {
	ss->shift_pending = 0;
	wait_gather(ss->msgtag);
      }
      if(ss==dest_dc->shift_src) {
	restart = 1;
      } else {
	*pss = ss->next;
	ss->next = dest_dc->shift_src;
	dest_dc->shift_src = ss;
	if(ss->msgtag) cleanup_gather(ss->msgtag);
      }
      break;
    }
    pss = &(ss->next);
  }
  ss->shift_pending = 1;
  dest_dc->discarded = 0;
  {
    QDP_shift_list_t *sl;
    if(sl_free_list==NULL) {
      sl = (QDP_shift_list_t *) malloc(sizeof(QDP_shift_list_t));
    } else {
      sl = sl_free_list;
      sl_free_list = sl->next;
    }
    sl->next = shift_list;
    sl->prev = NULL;
    if(shift_list) shift_list->prev = sl;
    shift_list = sl;
    sl->ss = ss;
    ss->sl = sl;
  }

  /* prepare shift destination */
  if(*(dest_dc->ptr)==NULL) {
    *(dest_dc->ptr) = (char **)malloc(sites_on_node*sizeof(char *));
    if(*(dest_dc->data)!=NULL) { 
      char *data, **ptr;
      int i;
      data = *(dest_dc->data);
      ptr = *(dest_dc->ptr);
      for(i=0; i<sites_on_node; ++i) {
	ptr[i] = data + i*dest_dc->size;
      }
    } else {
      char **ptr;
      int i;
      ptr = *(dest_dc->ptr);
      for(i=0; i<sites_on_node; ++i) {
	ptr[i] = NULL;
      }
    }
  }

  return restart;
}
