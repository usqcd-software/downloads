#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define CONTROL
#include "lattice.h"
#undef CONTROL
#include "comdefs.h"
#include "qdp_common_internal.h"

extern void setup_layout(void);
extern void make_lattice(void);
extern void make_nn_gathers(void);

/*  Exported Globals  */

QDP_Subset QDP_all = NULL;
QDP_Subset QDP_even_and_odd[2] = {NULL,NULL};
QDP_Subset QDP_even = NULL;
QDP_Subset QDP_odd = NULL;

QDP_Shift *QDP_neighbor = NULL;

int QDP_sites_on_node = 0;
int QDP_this_node = -1;
int QDP_forward = 1;
int QDP_backward = -1;

int QDP_suspended = 0;

/* Private Globals */

static int ndim=-1;
static int *latsize;
//static int smpflag=0;

int
QDP_initialize(int argc, char *argv[])
{
  if(lattice==NULL) {
    initialize_machine(argc, argv);
    QDP_this_node = mynode();
    this_node = mynode();
  }
  return 0;
}

void
QDP_finalize(void)
{
  normal_exit(0);
}

void
QDP_abort(void)
{
  terminate(1);
}

void
QDP_suspend_comm(void)
{
  QDP_suspended = 1;
  QDP_clear_shift_list();
}

void
QDP_resume_comm(void)
{
  QDP_suspended = 0;
}

void
QDP_set_latsize(int nd, int size[])
{
  ndim = nd;
  latsize = (int *)malloc(ndim*sizeof(int));
  memcpy(latsize, size, ndim*sizeof(int));
}

#if 0
void
QDP_set_smp(void)
{
  smpflag = 1;
}
#endif

void
QDP_create_layout(void)
{
  int i;

  if(lattice==NULL) {

    if(ndim!=4) {
      fprintf(stderr, "QDP: error: only 4 dimensions currently supported!\n");
      exit(1);
      //return 1;
    }

    nx = latsize[0];
    ny = latsize[1];
    nz = latsize[2];
    nt = latsize[3];

    setup_layout();
    make_lattice();
    make_nn_gathers();

  } else {

    ndim = 4;
    latsize = (int *)malloc(ndim*sizeof(int));
    latsize[0] = nx;
    latsize[1] = ny;
    latsize[2] = nz;
    latsize[3] = nt;

  }

  QDP_neighbor = (QDP_Shift *) malloc(ndim*sizeof(QDP_Shift));
  for(i=0; i<ndim; ++i) {
    QDP_neighbor[i] = (QDP_Shift) malloc(sizeof(struct QDP_Shift));
    QDP_neighbor[i]->forward_index = i;
    QDP_neighbor[i]->backward_index = OPP_DIR(i);
  }

  QDP_all = (QDP_Subset) malloc(sizeof(struct QDP_Subset));
  QDP_even = (QDP_Subset) malloc(sizeof(struct QDP_Subset));
  QDP_odd = (QDP_Subset) malloc(sizeof(struct QDP_Subset));
  QDP_even_and_odd[0] = QDP_even;
  QDP_even_and_odd[1] = QDP_odd;

  QDP_all->indexed = 0;
  QDP_all->offset = 0;
  QDP_all->len = sites_on_node;

  QDP_even->indexed = 0;
  QDP_even->offset = 0;
  QDP_even->len = even_sites_on_node;

  QDP_odd->indexed = 0;
  QDP_odd->offset = even_sites_on_node;
  QDP_odd->len = odd_sites_on_node;

  QDP_sites_on_node = sites_on_node;

  //return 0;
}

int
QDP_node_number(int x[])
{
  return node_number(x[0], x[1], x[2], x[3]);
}

int
QDP_index(int x[])
{
  return node_index(x[0], x[1], x[2], x[3]);
}

void
QDP_get_coords(int x[], int node, int i)
{
  x[0] = lattice[i].x;
  x[1] = lattice[i].y;
  x[2] = lattice[i].z;
  x[3] = lattice[i].t;
}

QDP_Subset *
QDP_create_subset(int (*func)(int x[]), int n)
{
  int i, c, x[4];
  QDP_Subset obj, *ptr;

  obj = (QDP_Subset)malloc(n*sizeof(struct QDP_Subset));
  ptr = (QDP_Subset *)malloc(n*sizeof(QDP_Subset));

  for(i=0; i<n; ++i) {
    ptr[i] = &obj[i];
    obj[i].func = func;
    obj[i].colors = n;
    obj[i].coloring = i;
    obj[i].first = ptr[0];
    obj[i].len = 0;
    obj[i].indexed = 1;
  }

  for(i=0; i<QDP_sites_on_node; ++i) {
    QDP_get_coords(x, QDP_this_node, i);
    c = func(x);
    if((c>=0)&&(c<n)) {
      obj[c].len++;
    }
  }

  for(i=0; i<n; ++i) {
    if(obj[i].len>0) {
      obj[i].index = (int *)malloc(obj[i].len*sizeof(int));
    } else {
      obj[i].index = NULL;
    }
    obj[i].len = 0;
  }

  for(i=0; i<QDP_sites_on_node; ++i) {
    QDP_get_coords(x, QDP_this_node, i);
    c = func(x);
    if((c>=0)&&(c<n)) {
      obj[c].index[obj[c].len] = i;
      obj[c].len++;
    }
  }

  return ptr;
}

void
QDP_destroy_subset(QDP_Subset *s)
{
  int i, n;
  QDP_Subset obj;

  obj = s[0]->first;
  n = obj[0].colors;
  for(i=0; i<n; ++i) {
    free(obj[i].index);
  }
  free(obj);
  free(s);
}

static void
disp_func(int x, int y, int z, int t, int *args, int fb,
	  int *tx, int *ty, int *tz, int *tt)
{
  if(fb==FORWARDS) {
    *tx = (nx+x+args[0])%latsize[0];
    *ty = (ny+y+args[1])%latsize[1];
    *tz = (nz+z+args[2])%latsize[2];
    *tt = (nt+t+args[3])%latsize[3];
  } else {
    *tx = (nx+x-args[0])%latsize[0];
    *ty = (ny+y-args[1])%latsize[1];
    *tz = (nz+z-args[2])%latsize[2];
    *tt = (nt+t-args[3])%latsize[3];
  }
}

QDP_Shift
QDP_create_shift(int disp[])
{
  QDP_Shift shift;

  shift = (QDP_Shift) malloc(sizeof(struct QDP_Shift));
  shift->func = NULL;
  shift->args = NULL;
  shift->argsize = 0;
  shift->forward_index = make_gather(disp_func, (int *)disp, WANT_INVERSE,
				     ALLOW_EVEN_ODD, SWITCH_PARITY);
  shift->backward_index = shift->forward_index + 1;
  return shift;
}

static void (*global_func)(int sx[], int rx[], int fb, void *args);

static void
map_func(int x, int y, int z, int t, int *args, int fb, int *tx, int *ty, int *tz, int *tt)
{
  int sx[4], rx[4];
  sx[0] = x;
  sx[1] = y;
  sx[2] = z;
  sx[3] = t;
  if(fb==FORWARDS) {
    global_func(sx, rx, QDP_forward, (void *)args);
  } else {
    global_func(sx, rx, QDP_backward, (void *)args);
  }
  *tx = rx[0];
  *ty = rx[1];
  *tx = rx[2];
  *tt = rx[3];
}

QDP_Shift
QDP_create_map(void (*func)(int sx[], int rx[], int fb, void *args), void *args, int argsize)
{
  QDP_Shift shift;

  shift = (QDP_Shift) malloc(sizeof(struct QDP_Shift));
  shift->func = func;
  shift->args = args;
  shift->argsize = argsize;
  global_func = func;
  shift->forward_index = make_gather(map_func, (int *)args, WANT_INVERSE, ALLOW_EVEN_ODD,
				     SCRAMBLE_PARITY);
  shift->backward_index = shift->forward_index + 1;
  return shift;
}

void
QDP_destroy_shift(QDP_Shift s)
{
  free(s);
}
