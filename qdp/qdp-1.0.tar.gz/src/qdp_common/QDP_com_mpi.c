#include <stdlib.h>
#include <mpi.h>

static void (*gfunc)();
static int gnc;

static void
bfunc(void *invec, void *inoutvec, int *len, MPI_Datatype *datatype)
{
  gfunc(inoutvec, invec);
}

void
QDP_binary_reduce(void func(), int size, void *data)
{
  MPI_Datatype newtype;
  MPI_Op newop;
  void *buf;

  MPI_Type_contiguous(size, MPI_CHAR, &newtype);
  MPI_Type_commit(&newtype);

  MPI_Op_create(bfunc, 1, &newop);

  buf = (void *) malloc(size);
  memcpy(buf, data, size);

  gfunc = func;
  MPI_Allreduce(buf, data, 1, newtype, newop, MPI_COMM_WORLD);

  free(buf);
  MPI_Op_free(&newop);
  MPI_Type_free(&newtype);
}

static void
bfuncm(void *invec, void *inoutvec, int *len, MPI_Datatype *datatype)
{
  gfunc(inoutvec, invec, *len);
}

void
QDP_binary_reduce_multi(void func(), int size, void *data, int ns)
{
  MPI_Datatype newtype;
  MPI_Op newop;
  void *buf;

  MPI_Type_contiguous(size, MPI_CHAR, &newtype);
  MPI_Type_commit(&newtype);

  MPI_Op_create(bfuncm, 1, &newop);

  buf = (void *) malloc(ns*size);
  memcpy(buf, data, ns*size);

  gfunc = func;
  MPI_Allreduce(buf, data, ns, newtype, newop, MPI_COMM_WORLD);

  free(buf);
  MPI_Op_free(&newop);
  MPI_Type_free(&newtype);
}

static void
bfuncn(void *invec, void *inoutvec, int *len, MPI_Datatype *datatype)
{
  gfunc(gnc, inoutvec, invec);
}

void
QDP_N_binary_reduce(int nc, void func(), int size, void *data)
{
  MPI_Datatype newtype;
  MPI_Op newop;
  void *buf;

  MPI_Type_contiguous(size, MPI_CHAR, &newtype);
  MPI_Type_commit(&newtype);

  MPI_Op_create(bfuncn, 1, &newop);

  buf = (void *) malloc(size);
  memcpy(buf, data, size);

  gnc = nc;
  gfunc = func;
  MPI_Allreduce(buf, data, 1, newtype, newop, MPI_COMM_WORLD);

  free(buf);
  MPI_Op_free(&newop);
  MPI_Type_free(&newtype);
}

static void
bfuncnm(void *invec, void *inoutvec, int *len, MPI_Datatype *datatype)
{
  gfunc(gnc, inoutvec, invec, *len);
}

void
QDP_N_binary_reduce_multi(int nc, void func(), int size, void *data, int ns)
{
  MPI_Datatype newtype;
  MPI_Op newop;
  void *buf;

  MPI_Type_contiguous(size, MPI_CHAR, &newtype);
  MPI_Type_commit(&newtype);

  MPI_Op_create(bfuncnm, 1, &newop);

  buf = (void *) malloc(ns*size);
  memcpy(buf, data, ns*size);

  gnc = nc;
  gfunc = func;
  MPI_Allreduce(buf, data, ns, newtype, newop, MPI_COMM_WORLD);

  free(buf);
  MPI_Op_free(&newop);
  MPI_Type_free(&newtype);
}
