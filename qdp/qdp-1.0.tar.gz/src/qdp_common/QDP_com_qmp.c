#include <stdlib.h>
#include <qmp.h>

static void (*gfunc)();
static int glen;
static int gnc;

void
QDP_binary_reduce(void func(), int size, void *data)
{
  QMP_binary_reduction(data, size, func)
}

static void
bfuncm(void *inoutvec, void *invec)
{
  gfunc(inoutvec, invec, glen);
}

void
QDP_binary_reduce_multi(void func(), int size, void *data, int ns)
{
  gfunc = func;
  glen = ns;
  QMP_binary_reduction(data, size, bfuncm)
}

static void
bfuncn(void *inoutvec, void *invec)
{
  gfunc(gnc, inoutvec, invec);
}

void
QDP_N_binary_reduce(int nc, void func(), int size, void *data)
{
  gnc = nc;
  gfunc = func;
  QMP_binary_reduction(data, size, bfuncn)
}

static void
bfuncnm(void *inoutvec, void *invec)
{
  gfunc(gnc, inoutvec, invec, glen);
}

void
QDP_N_binary_reduce_multi(int nc, void func(), int size, void *data, int ns)
{
  gnc = nc;
  gfunc = func;
  glen = ns;
  QMP_binary_reduction(data, size, bfuncm)
}
