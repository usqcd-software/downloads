void
QDP_binary_reduce(void func(), int size, void *data)
{
}

void
QDP_binary_reduce_multi(void func(), int size, void *data, int ns)
{
}

void
QDP_N_binary_reduce(int nc, void func(), int size, void *data)
{
}

void
QDP_N_binary_reduce_multi(int nc, void func(), int size, void *data, int ns)
{
}
