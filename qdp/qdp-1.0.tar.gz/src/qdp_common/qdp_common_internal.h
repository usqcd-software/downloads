#ifndef _QDP_COMMON_INTERNAL
#define _QDP_COMMON_INTERNAL

#include "qla_types.h"
#include "qla_complex.h"
#include "qla_random.h"
#include "qdp_types.h"
#include "generic_includes.h"

struct QDP_Subset {
  int indexed;
  int offset;
  int *index;
  int len;
  int (*func)(int x[]);
  int colors;
  int coloring;
  struct QDP_Subset *first;
};

struct QDP_Shift {
  void (*func)(int sx[], int rx[], int fb, void *args);
  void *args;
  int argsize;
  int forward_index;
  int backward_index;
};

typedef struct QDP_shift_list_t {
  struct QDP_shift_src_t *ss;
  struct QDP_shift_list_t *next;
  struct QDP_shift_list_t *prev;
} QDP_shift_list_t;

typedef struct QDP_shift_src_t {
  QDP_Shift shift;
  int fb;
  QDP_Subset subset;
  int shift_pending;
  char **ptr;
  msg_tag *msgtag;
  QDP_shift_list_t *sl;
  struct QDP_data_common_t *dc;
  struct QDP_shift_src_t *next;
} QDP_shift_src_t;

typedef struct QDP_shift_dest_t {
  struct QDP_data_common_t *dc;
  struct QDP_shift_dest_t *next;
} QDP_shift_dest_t;

typedef struct QDP_data_common_t {
  char **data;
  char ***ptr;
  int size;
  int discarded;
  int exposed;
  QDP_shift_src_t *shift_src;
  QDP_shift_dest_t *shift_dest;
} QDP_data_common_t;

struct QDP_F2_ColorVector {
  QLA_F2_ColorVector *data;
  QLA_F2_ColorVector **ptr;
  QDP_data_common_t dc;
};

struct QDP_F3_ColorVector {
  QLA_F3_ColorVector *data;
  QLA_F3_ColorVector **ptr;
  QDP_data_common_t dc;
};

struct QDP_FN_ColorVector {
  QLA_FN_ColorVector *data;
  QLA_FN_ColorVector **ptr;
  QDP_data_common_t dc;
};

struct QDP_D2_ColorVector {
  QLA_D2_ColorVector *data;
  QLA_D2_ColorVector **ptr;
  QDP_data_common_t dc;
};

struct QDP_D3_ColorVector {
  QLA_D3_ColorVector *data;
  QLA_D3_ColorVector **ptr;
  QDP_data_common_t dc;
};

struct QDP_DN_ColorVector {
  QLA_DN_ColorVector *data;
  QLA_DN_ColorVector **ptr;
  QDP_data_common_t dc;
};

struct QDP_F_Real {
  QLA_F_Real *data;
  QLA_F_Real **ptr;
  QDP_data_common_t dc;
};

struct QDP_D_Real {
  QLA_D_Real *data;
  QLA_D_Real **ptr;
  QDP_data_common_t dc;
};

struct QDP_F2_DiracPropagator {
  QLA_F2_DiracPropagator *data;
  QLA_F2_DiracPropagator **ptr;
  QDP_data_common_t dc;
};

struct QDP_F3_DiracPropagator {
  QLA_F3_DiracPropagator *data;
  QLA_F3_DiracPropagator **ptr;
  QDP_data_common_t dc;
};

struct QDP_FN_DiracPropagator {
  QLA_FN_DiracPropagator *data;
  QLA_FN_DiracPropagator **ptr;
  QDP_data_common_t dc;
};

struct QDP_D2_DiracPropagator {
  QLA_D2_DiracPropagator *data;
  QLA_D2_DiracPropagator **ptr;
  QDP_data_common_t dc;
};

struct QDP_D3_DiracPropagator {
  QLA_D3_DiracPropagator *data;
  QLA_D3_DiracPropagator **ptr;
  QDP_data_common_t dc;
};

struct QDP_DN_DiracPropagator {
  QLA_DN_DiracPropagator *data;
  QLA_DN_DiracPropagator **ptr;
  QDP_data_common_t dc;
};

struct QDP_Int {
  QLA_Int *data;
  QLA_Int **ptr;
  QDP_data_common_t dc;
};

struct QDP_RandomState {
  QLA_RandomState *data;
  QLA_RandomState **ptr;
  QDP_data_common_t dc;
};

struct QDP_F2_DiracFermion {
  QLA_F2_DiracFermion *data;
  QLA_F2_DiracFermion **ptr;
  QDP_data_common_t dc;
};

struct QDP_F3_DiracFermion {
  QLA_F3_DiracFermion *data;
  QLA_F3_DiracFermion **ptr;
  QDP_data_common_t dc;
};

struct QDP_FN_DiracFermion {
  QLA_FN_DiracFermion *data;
  QLA_FN_DiracFermion **ptr;
  QDP_data_common_t dc;
};

struct QDP_D2_DiracFermion {
  QLA_D2_DiracFermion *data;
  QLA_D2_DiracFermion **ptr;
  QDP_data_common_t dc;
};

struct QDP_D3_DiracFermion {
  QLA_D3_DiracFermion *data;
  QLA_D3_DiracFermion **ptr;
  QDP_data_common_t dc;
};

struct QDP_DN_DiracFermion {
  QLA_DN_DiracFermion *data;
  QLA_DN_DiracFermion **ptr;
  QDP_data_common_t dc;
};

struct QDP_F_Complex {
  QLA_F_Complex *data;
  QLA_F_Complex **ptr;
  QDP_data_common_t dc;
};

struct QDP_D_Complex {
  QLA_D_Complex *data;
  QLA_D_Complex **ptr;
  QDP_data_common_t dc;
};

struct QDP_F2_HalfFermion {
  QLA_F2_HalfFermion *data;
  QLA_F2_HalfFermion **ptr;
  QDP_data_common_t dc;
};

struct QDP_F3_HalfFermion {
  QLA_F3_HalfFermion *data;
  QLA_F3_HalfFermion **ptr;
  QDP_data_common_t dc;
};

struct QDP_FN_HalfFermion {
  QLA_FN_HalfFermion *data;
  QLA_FN_HalfFermion **ptr;
  QDP_data_common_t dc;
};

struct QDP_D2_HalfFermion {
  QLA_D2_HalfFermion *data;
  QLA_D2_HalfFermion **ptr;
  QDP_data_common_t dc;
};

struct QDP_D3_HalfFermion {
  QLA_D3_HalfFermion *data;
  QLA_D3_HalfFermion **ptr;
  QDP_data_common_t dc;
};

struct QDP_DN_HalfFermion {
  QLA_DN_HalfFermion *data;
  QLA_DN_HalfFermion **ptr;
  QDP_data_common_t dc;
};

struct QDP_F2_ColorMatrix {
  QLA_F2_ColorMatrix *data;
  QLA_F2_ColorMatrix **ptr;
  QDP_data_common_t dc;
};

struct QDP_F3_ColorMatrix {
  QLA_F3_ColorMatrix *data;
  QLA_F3_ColorMatrix **ptr;
  QDP_data_common_t dc;
};

struct QDP_FN_ColorMatrix {
  QLA_FN_ColorMatrix *data;
  QLA_FN_ColorMatrix **ptr;
  QDP_data_common_t dc;
};

struct QDP_D2_ColorMatrix {
  QLA_D2_ColorMatrix *data;
  QLA_D2_ColorMatrix **ptr;
  QDP_data_common_t dc;
};

struct QDP_D3_ColorMatrix {
  QLA_D3_ColorMatrix *data;
  QLA_D3_ColorMatrix **ptr;
  QDP_data_common_t dc;
};

struct QDP_DN_ColorMatrix {
  QLA_DN_ColorMatrix *data;
  QLA_DN_ColorMatrix **ptr;
  QDP_data_common_t dc;
};

extern void QDP_clear_shift_list(void);
extern void QDP_prepare_destroy(QDP_data_common_t *dc);
extern void QDP_prepare_dest(QDP_data_common_t *dc);
extern void QDP_prepare_src(QDP_data_common_t *dc);
extern int QDP_prepare_shift(QDP_data_common_t *dest_dc, QDP_data_common_t *src_dc,
			     QDP_Shift shift, int fb, QDP_Subset subset);
extern void QDP_switch_ptr_to_data(QDP_data_common_t *dc);
extern void QDP_binary_reduce(void func(), int size, void *data);
extern void QDP_binary_reduce_multi(void func(), int size, void *data, int ns);
extern void QDP_N_binary_reduce(int nc, void func(), int size, void *data);
extern void QDP_N_binary_reduce_multi(int nc, void func(), int size, void *data, int ns);

extern int QDP_suspended;

#endif
