#include <qdp.h>

extern int
conjugate_gradient(QDP_ColorVector  *result,
		   void             (*prepare_Dirac_n)(void),
		   void             (*cleanup_Dirac_n)(void),
		   void             (*Dirac_n)(QDP_ColorVector*,
					       QDP_ColorMatrix**,
					       QDP_ColorVector*),
		   QDP_ColorMatrix  **gauge,
		   QDP_ColorVector  *rhs,
		   QLA_Real         mass,
		   int              max_iter,
		   double           epsilon);
