#include <qdp.h>

extern void prepare_Dirac_n(void);
extern void cleanup_Dirac_n(void);
extern void Dirac_n(QDP_ColorVector  *result,
		    QDP_ColorMatrix  **gauge,
		    QDP_ColorVector  *psi);
