#include <stdio.h>
#include <qdp.h>
#include "congrad_ks.h"

int
conjugate_gradient(QDP_ColorVector  *result,
		   void             (*prepare_Dirac_n)(void),
		   void             (*cleanup_Dirac_n)(void),
		   void             (*Dirac_n)(QDP_ColorVector*,
					       QDP_ColorMatrix**,
					       QDP_ColorVector*),
		   QDP_ColorMatrix  **gauge,
		   QDP_ColorVector  *rhs,
		   QLA_Real         mass,
		   int              max_iter,
		   double           epsilon)
{
  QLA_Real eps, a, b, c, d;
  QLA_Real rhs_norm, mass2;
  QDP_ColorVector *r, *p, *Mp, *MMp;
  int i;

  prepare_Dirac_n();

  r = QDP_create_V();
  p = QDP_create_V();
  Mp = QDP_create_V();
  MMp = QDP_create_V();

  mass2 = 4*mass*mass;

  QDP_r_eq_norm2_V(&rhs_norm, rhs, QDP_all);
  eps = rhs_norm * epsilon;

  if(QDP_this_node==0) printf("norm=%g  eps=%g\n",rhs_norm,eps);

  do {
    QDP_r_eq_norm2_V(&a,result,QDP_all);
    printf("result norm=%g\n",a);
    Dirac_n(p, gauge, result);
    //QDP_r_eq_norm2_V(&a,p,QDP_all);
    //printf("p norm=%g\n",a);
    Dirac_n(r, gauge, p);
    //QDP_r_eq_norm2_V(&a,r,QDP_all);
    //printf("r norm=%g\n",a);
    QDP_V_meq_r_times_V(r, &mass2, result, QDP_all);
    QDP_V_peq_V(r, rhs, QDP_all); /* r += rhs */
    QDP_V_eq_V(p, r, QDP_all);
    QDP_r_eq_norm2_V(&c, r, QDP_all);

    for (i = 0; i < max_iter; i++) {
      if(QDP_this_node==0) printf("%6i c=%g\n",i,c);
      if (c < eps) break;

      Dirac_n(Mp, gauge, p);
      Dirac_n(MMp, gauge, Mp);
      QDP_V_meq_r_times_V(MMp, &mass2, p, QDP_all);

      QDP_r_eq_re_V_dot_V(&d, p, MMp, QDP_all);
      //printf("d = %g\n",d);
      a = - c / d;
      QDP_V_peq_r_times_V(result, &a, p, QDP_all);  /* result += a*p */
      QDP_V_peq_r_times_V(r, &a, MMp, QDP_all);  /* r += a*MMp */
      QDP_r_eq_norm2_V(&d, r, QDP_all);
      b = d / c;
      c = d;
      QDP_V_eq_r_times_V_plus_V(p, &b, p, r, QDP_all);  /* p = b*p + r */
    }
  } while(c>eps);
  //fprintf(stderr,"done cg\n");

  QDP_destroy_V(r);
  QDP_destroy_V(p);
  QDP_destroy_V(Mp);
  QDP_destroy_V(MMp);

  //fprintf(stderr,"done free\n");

  cleanup_Dirac_n();

  //fprintf(stderr,"done cleanup\n");

  return i;
}
