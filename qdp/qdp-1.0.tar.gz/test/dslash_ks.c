#include <stdio.h>
#include <qdp.h>
#include "dslash_ks.h"

static QDP_ColorVector *temp0, *temp1[4], *temp2[4], *temp3[4];

/* allocate fields before calling Dirac_n */
/* this is so we can reuse the fields & gathers */
void
prepare_Dirac_n(void)
{
  int mu;

  temp0 = QDP_create_V();
  for (mu = 0; mu < 4; mu++) {
    temp1[mu] = QDP_create_V();
    temp2[mu] = QDP_create_V();
    temp3[mu] = QDP_create_V();
  }
}

/* free temporary fields when we're done using Dirac_n */
void
cleanup_Dirac_n(void)
{
  int mu;

  QDP_destroy_V(temp0);
  for (mu = 0; mu < 4; mu++) {
    QDP_destroy_V(temp1[mu]);
    QDP_destroy_V(temp2[mu]);
    QDP_destroy_V(temp3[mu]);
  }
}

/* Wilson D-slash */
void
Dirac_n(QDP_ColorVector *result,
	QDP_ColorMatrix **gauge,
	QDP_ColorVector *source)
{
  int mu;

  //if(QDP_this_node==0) fprintf(stderr, "begin Dirac_n\n");

  for (mu = 0; mu < 4; mu++) {
    QDP_V_eq_sV(temp1[mu], source, QDP_neighbor[mu], QDP_forward, QDP_all);
  }

  //if(QDP_this_node==0) fprintf(stderr, "shift\n");

  for (mu = 0; mu < 4; mu++) {
    QDP_V_eq_Ma_times_V(temp2[mu], gauge[mu], source, QDP_all);
    QDP_V_eq_sV(temp3[mu], temp2[mu], QDP_neighbor[mu], QDP_backward, QDP_all);
  }

  QDP_V_eq_M_times_V(result, gauge[0], temp1[0], QDP_all);
  QDP_discard_V(temp1[0]);
  for (mu = 1; mu < 4; mu++) {
    QDP_V_peq_M_times_V(result, gauge[mu], temp1[mu], QDP_all);
    QDP_discard_V(temp1[mu]);
  }

  for (mu = 0; mu < 4; mu++) {
    QDP_V_meq_V(result, temp3[mu], QDP_all);
    QDP_discard_V(temp3[mu]);
  }

  //if(QDP_this_node==0) fprintf(stderr, "end Dirac_n\n");
}
