/* QDP profiling header for $LIB */

#ifndef _QDP_$LIB_PROFILE_H
#define _QDP_$LIB_PROFILE_H
